/**
 * NOKIROVA — Client API
 *
 * Couche de communication avec le backend FastAPI.
 * - Intercepteur d'authentification (Bearer token)
 * - Rafraîchissement automatique du token
 * - Format de réponse unifié {success, message, data, errors, metadata}
 * - Retry automatique sur erreurs réseau
 * - Gestion des erreurs métier
 */

import toast from 'react-hot-toast';

// ─── Types ────────────────────────────────────────────────────────────────────

interface APIResponse<T = unknown> {
  success: boolean;
  message: string;
  data: T;
  errors?: Array<{ champ: string; message: string }>;
  metadata?: {
    total?: number;
    page?: number;
    par_page?: number;
    total_pages?: number;
  };
}

interface RequestOptions extends RequestInit {
  /** Délai d'attente en ms (défaut 30s) */
  delai?: number;
  /** Nombre de tentatives (défaut 3) */
  tentatives?: number;
  /** Retourner la réponse brute sans parser */
  brut?: boolean;
  /** Ne pas afficher de toast d'erreur */
  silencieux?: boolean;
}

// ─── Constantes ───────────────────────────────────────────────────────────────

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
const DELAI_DEFAUT = 30_000;
const TENTATIVES_DEFAUT = 3;

// ─── Client API ───────────────────────────────────────────────────────────────

class APIClient {
  private token: string | null = null;
  private isRefreshing = false;
  private queue: Array<() => void> = [];

  /** Définir le token JWT */
  setToken(token: string | null) {
    this.token = token;
  }

  /** Obtenir le token actuel */
  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return this.token || localStorage.getItem('nk_token');
    }
    return this.token;
  }

  /** Rafraîchir le token JWT */
  private async refreshToken(): Promise<string | null> {
    if (this.isRefreshing) {
      // Attendre la fin du rafraîchissement en cours
      return new Promise((resolve) => {
        this.queue.push(() => resolve(this.getToken()));
      });
    }

    this.isRefreshing = true;
    try {
      const rep = await fetch(`${BASE_URL}/api/v1/auth/rafraichir`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${this.getToken()}` },
      });

      if (!rep.ok) {
        // Token invalide — déconnexion
        this.setToken(null);
        localStorage.removeItem('nk_token');
        localStorage.removeItem('nk_user');
        if (typeof window !== 'undefined') window.location.href = '/connexion';
        return null;
      }

      const { data } = await rep.json();
      this.setToken(data.token);
      localStorage.setItem('nk_token', data.token);

      // Résoudre la file d'attente
      this.queue.forEach((cb) => cb());
      this.queue = [];

      return data.token;
    } catch {
      return null;
    } finally {
      this.isRefreshing = false;
    }
  }

  /** Construire les en-têtes par défaut */
  private buildHeaders(personnalises?: Record<string, string>): HeadersInit {
    const enTetes: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept-Language': 'fr',
      ...personnalises,
    };

    const tok = this.getToken();
    if (tok) {
      enTetes['Authorization'] = `Bearer ${tok}`;
    }

    return enTetes;
  }

  /** Exécuter une requête avec retry et intercepteurs */
  private async execute<T>(
    chemin: string,
    options: RequestOptions = {}
  ): Promise<APIResponse<T>> {
    const {
      delai = DELAI_DEFAUT,
      tentatives = TENTATIVES_DEFAUT,
      brut = false,
      silencieux = false,
      ...fetchOptions
    } = options;

    const url = chemin.startsWith('http') ? chemin : `${BASE_URL}${chemin}`;

    for (let tentative = 0; tentative <= tentatives; tentative++) {
      try {
        // Délai (abort controller)
        const controleur = new AbortController();
        const timerDelai = setTimeout(() => controleur.abort(), delai);

        const rep = await fetch(url, {
          ...fetchOptions,
          headers: this.buildHeaders(
            fetchOptions.headers as Record<string, string>
          ),
          signal: controleur.signal,
        });

        clearTimeout(timerDelai);

        // ── Token expiré → rafraîchir et retry ──
        if (rep.status === 401) {
          const nouveauToken = await this.refreshToken();
          if (nouveauToken && tentative < tentatives) {
            continue; // Retry avec le nouveau token
          }
          throw new Error('Session expirée. Veuillez vous reconnecter.');
        }

        // ── Réponse brute (fichiers, etc.) ──
        if (brut) {
          return {
            success: rep.ok,
            message: '',
            data: rep as unknown as T,
          };
        }

        const corps = await rep.json();

        // ── Erreurs serveur (5xx) → retry ──
        if (rep.status >= 500 && tentative < tentatives) {
          await new Promise((r) => setTimeout(r, (tentative + 1) * 1000));
          continue;
        }

        // ── Erreur métier ──
        if (!rep.ok || !corps.success) {
          const message = corps.message || 'Une erreur est survenue';
          if (!silencieux) {
            toast.error(message);
          }
          throw new APIError(message, rep.status, corps.errors);
        }

        return corps as APIResponse<T>;
      } catch (erreur) {
        if (erreur instanceof APIError) throw erreur;

        // Erreur réseau → retry
        if (tentative < tentatives) {
          await new Promise((r) => setTimeout(r, (tentative + 1) * 1000));
          continue;
        }

        const message =
          erreur instanceof DOMException && erreur.name === 'AbortError'
            ? 'La requête a expiré. Veuillez réessayer.'
            : 'Impossible de contacter le serveur. Vérifiez votre connexion.';

        if (!silencieux) toast.error(message);
        throw new APIError(message, 0);
      }
    }

    throw new APIError('Nombre maximum de tentatives atteint.', 0);
  }

  // ── Méthodes publiques ──────────────────────────────────────────────────────

  /** GET */
  async get<T>(chemin: string, params?: Record<string, string | number | boolean>, options?: RequestOptions): Promise<APIResponse<T>> {
    let url = chemin;
    if (params) {
      const recherche = new URLSearchParams(
        Object.entries(params).map(([k, v]) => [k, String(v)])
      ).toString();
      url += `?${recherche}`;
    }
    return this.execute<T>(url, { ...options, method: 'GET' });
  }

  /** POST */
  async create<T>(chemin: string, donnees?: unknown, options?: RequestOptions): Promise<APIResponse<T>> {
    return this.execute<T>(chemin, {
      ...options,
      method: 'POST',
      body: donnees ? JSON.stringify(donnees) : undefined,
    });
  }

  /** PUT */
  async replace<T>(chemin: string, donnees: unknown, options?: RequestOptions): Promise<APIResponse<T>> {
    return this.execute<T>(chemin, {
      ...options,
      method: 'PUT',
      body: JSON.stringify(donnees),
    });
  }

  /** PATCH */
  async update<T>(chemin: string, donnees: Partial<unknown>, options?: RequestOptions): Promise<APIResponse<T>> {
    return this.execute<T>(chemin, {
      ...options,
      method: 'PATCH',
      body: JSON.stringify(donnees),
    });
  }

  /** DELETE (archivage soft) */
  async remove<T>(chemin: string, options?: RequestOptions): Promise<APIResponse<T>> {
    return this.execute<T>(chemin, { ...options, method: 'DELETE' });
  }

  /** Upload de fichier */
  async upload<T>(chemin: string, fichier: File, champ = 'fichier', options?: RequestOptions): Promise<APIResponse<T>> {
    const formData = new FormData();
    formData.append(champ, fichier);

    const controleur = new AbortController();
    const timer = setTimeout(() => controleur.abort(), 120_000);

    try {
      const rep = await fetch(`${BASE_URL}${chemin}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.getToken()}`,
          'Accept-Language': 'fr',
        },
        body: formData,
        signal: controleur.signal,
      });

      clearTimeout(timer);
      const corps = await rep.json();

      if (!rep.ok || !corps.success) {
        throw new APIError(corps.message || 'Erreur d\'upload', rep.status);
      }

      return corps as APIResponse<T>;
    } catch (erreur) {
      clearTimeout(timer);
      throw erreur;
    }
  }
}

// ─── Erreur API personnalisée ─────────────────────────────────────────────────

export class APIError extends Error {
  public status: number;
  public erreurs?: Array<{ champ: string; message: string }>;

  constructor(message: string, status: number, erreurs?: Array<{ champ: string; message: string }>) {
    super(message);
    this.name = 'APIError';
    this.status = status;
    this.erreurs = erreurs;
  }
}

// ─── Instance singleton ──────────────────────────────────────────────────────

export const api = new APIClient();
export default api;
