/**
 * NOKIROVA — Utilitaires
 *
 * Fonctions utilitaires partagées :
 * - cn() : fusion de classes Tailwind
 * - formatageDate : dates en français
 * - formatageNombre : nombres localisés
 * - formatageDuree : durées en heures/minutes
 * - truncate : troncature avec ellipsis
 * - genererInitiales : initiales d'un nom
 * - sleep : attente asynchrone
 * - debounce/throttle : limitation d'appels
 */

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Fusion de classes Tailwind avec résolution des conflits */
export function cn(...entrees: ClassValue[]) {
  return twMerge(clsx(entrees));
}

/** Formater une date en français */
export function formatageDate(
  date: string | Date,
  options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' }
): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('fr-FR', options);
}

/** Formater une date relative (il y a 3 min, hier, etc.) */
export function formatageRelatif(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const maintenant = new Date();
  const diff = maintenant.getTime() - d.getTime();
  const secondes = Math.floor(diff / 1000);
  const minutes = Math.floor(secondes / 60);
  const heures = Math.floor(minutes / 60);
  const jours = Math.floor(heures / 24);

  if (secondes < 60) return "à l'instant";
  if (minutes < 60) return `il y a ${minutes} min`;
  if (heures < 24) return `il y a ${heures}h`;
  if (jours === 1) return 'hier';
  if (jours < 7) return `il y a ${jours}j`;
  return formatageDate(d);
}

/** Formater un nombre en français */
export function formatageNombre(nombre: number, options?: Intl.NumberFormatOptions): string {
  return nombre.toLocaleString('fr-FR', options);
}

/** Formater une durée en minutes vers « 2h 30min » */
export function formatageDuree(minutes: number): string {
  if (minutes < 1) return '< 1 min';
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}min`;
}

/** Troncature avec ellipsis */
export function truncate(texte: string, longueurMax: number): string {
  if (texte.length <= longueurMax) return texte;
  return texte.slice(0, longueurMax - 1) + '…';
}

/** Initiales d'un nom complet */
export function genererInitiales(prenom: string, nom: string): string {
  return (prenom[0] + nom[0]).toUpperCase();
}

/** Attente asynchrone */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Debounce */
export function debounce<T extends (...args: unknown[]) => void>(
  fn: T,
  delai: number
): (...args: Parameters<T>) => void {
  let timer: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delai);
  };
}

/** Throttle */
export function throttle<T extends (...args: unknown[]) => void>(
  fn: T,
  delai: number
): (...args: Parameters<T>) => void {
  let dernierAppel = 0;
  return (...args: Parameters<T>) => {
    const maintenant = Date.now();
    if (maintenant - dernierAppel >= delai) {
      dernierAppel = maintenant;
      fn(...args);
    }
  };
}

/** Générer un identifiant unique côté client */
export function genererId(): string {
  return `nk_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

/** Calculer le pourcentage d'XP pour le niveau actuel */
export function pourcentageXp(xp: number, niveau: number): number {
  // Seuils XP par niveau (système NOKIROVA 12 niveaux)
  const seuils = [0, 100, 250, 500, 1000, 2000, 4000, 7000, 11000, 16000, 22000, 30000, 40000];
  const seuilActuel = seuils[Math.min(niveau, seuils.length - 1)] || 0;
  const seuilSuivant = seuils[Math.min(niveau + 1, seuils.length - 1)] || seuilActuel + 1000;
  if (seuilSuivant === seuilActuel) return 100;
  return Math.min(100, Math.round(((xp - seuilActuel) / (seuilSuivant - seuilActuel)) * 100));
}

/** Couleur associée à une matière */
export function couleurMatiere(matiere: string): string {
  const couleurs: Record<string, string> = {
    mathematiques: 'bg-blue-100 text-blue-700',
    francais: 'bg-rose-100 text-rose-700',
    physique: 'bg-amber-100 text-amber-700',
    chimie: 'bg-emerald-100 text-emerald-700',
    histoire: 'bg-orange-100 text-orange-700',
    geographie: 'bg-teal-100 text-teal-700',
    philosophie: 'bg-purple-100 text-purple-700',
    anglais: 'bg-indigo-100 text-indigo-700',
    svt: 'bg-green-100 text-green-700',
    ses: 'bg-cyan-100 text-cyan-700',
  };
  return couleurs[matiere] || 'bg-nk-neutre-100 text-nk-neutre-700';
}
