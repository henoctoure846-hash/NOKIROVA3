'use client';

/**
 * NOKIROVA — RappelRevision
 *
 * Widget du dashboard affichant les rappels
 * de révision du jour (flashcards en retard,
 * prévues aujourd'hui, compteur streak).
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { Card, CardHeader, CardContent, Badge, Button, Progress } from '@/components/ui';
import type { RappelRevision as RappelType, Matiere } from '@/types';

interface RappelRevisionProps {
  rappels: RappelType[];
  enRetard: number;
  streakJours: number;
  onDemarrerRevision: () => void;
  onVoirTout: () => void;
}

const MATIERE_LABELS: Record<string, string> = {
  mathematiques: 'Maths', francais: 'Français', physique: 'Physique',
  chimie: 'Chimie', histoire: 'Histoire', geographie: 'Géo',
  philosophie: 'Philo', anglais: 'Anglais', svt: 'SVT',
  ses: 'SES', informatique: 'Info', economie: 'Éco',
};

export function RappelRevisionWidget({
  rappels,
  enRetard,
  streakJours,
  onDemarrerRevision,
  onVoirTout,
}: RappelRevisionProps) {
  const aujourdHui = rappels.filter((r) => r.statut === 'prevu').length;
  const total = rappels.length;

  return (
    <Card variante="elevee">
      <CardHeader
        icone={<span className="text-nk-accent">🔄</span>}
        action={
          <button className="nk-lien-subtle" onClick={onVoirTout}>
            Voir tout
          </button>
        }
      >
        <h3 className="nk-carte-titre-principal">Rappels de révision</h3>
      </CardHeader>

      <CardContent>
        {/* Streak */}
        <div className="nk-rappel-streak">
          <span className="nk-rappel-streak-icone">🔥</span>
          <span className="nk-rappel-streak-texte">
            <strong>{streakJours}</strong> jour{streakJours !== 1 ? 's' : ''} de suite
          </span>
        </div>

        {/* Compteurs */}
        <div className="nk-rappel-compteurs">
          {enRetard > 0 && (
            <Badge variante="accent" taille="sm">
              {enRetard} en retard
            </Badge>
          )}
          <Badge variante="info" taille="sm">
            {aujourdHui} prévu{aujourdHui !== 1 ? 's' : ''} aujourd'hui
          </Badge>
        </div>

        {/* Progression du jour */}
        <Progress
          valeur={total > 0 ? ((total - enRetard) / total) * 100 : 100}
          variante={enRetard > 0 ? 'avertissement' : 'succes'}
          taille="sm"
          label="Progression du jour"
          afficherPourcentage
        />

        {/* Liste des rappels */}
        <div className="nk-rappel-liste">
          {rappels.slice(0, 5).map((rappel) => (
            <div
              key={rappel.id}
              className={cn(
                'nk-rappel-item',
                rappel.statut === 'en_retard' && 'nk-rappel-item-retard',
                rappel.statut === 'fait' && 'nk-rappel-item-fait'
              )}
            >
              <span className="nk-rappel-item-statut">
                {rappel.statut === 'fait' ? '✅' : rappel.statut === 'en_retard' ? '⏰' : '📋'}
              </span>
              <span className="nk-rappel-item-id">Carte {rappel.flashcard_id.slice(0, 8)}</span>
              <span className="nk-rappel-item-date">
                {rappel.statut === 'fait' ? 'Terminé' : rappel.statut === 'en_retard' ? 'En retard' : 'Prévu'}
              </span>
            </div>
          ))}
        </div>

        {/* Bouton démarrer */}
        <Button
          variante="accent"
          taille="lg"
          pleinLargeur
          onClick={onDemarrerRevision}
          iconeDroite={<span>→</span>}
        >
          Démarrer ma révision
        </Button>
      </CardContent>
    </Card>
  );
}

export default RappelRevisionWidget;
