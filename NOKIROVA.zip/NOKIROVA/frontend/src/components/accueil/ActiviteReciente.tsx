'use client';

/**
 * NOKIROVA — ActiviteReciente
 *
 * Fil d'activité récente de l'utilisateur.
 * Affiche les dernières actions : cours suivis,
 * quiz complétés, documents produits, révisions.
 */

'use client';

import React from 'react';
import { cn, formatageRelatif } from '@/lib/utils';
import { Card, CardHeader, CardContent, Badge } from '@/components/ui';

export type TypeActivite =
  | 'cours_debut'
  | 'cours_termine'
  | 'quiz_complete'
  | 'flashcard_revisee'
  | 'document_cree'
  | 'objectif_atteint'
  | 'badge_obtenu'
  | 'succes_debloque'
  | 'groupe_rejoint'
  | 'ia_interaction'
  | 'streak_maintenu';

export interface EntreeActivite {
  id: string;
  type: TypeActivite;
  titre: string;
  description?: string;
  date: string; // ISO
  matiere?: string;
  points?: number;
  url?: string;
}

interface ActiviteRecienteProps {
  activites: EntreeActivite[];
  onVoirPlus?: () => void;
  limite?: number;
}

const TYPE_CONFIG: Record<
  TypeActivite,
  { icone: string; label: string; variante: 'primaire' | 'accent' | 'succes' | 'info' | 'avertissement' }
> = {
  cours_debut: { icone: '📖', label: 'Cours commencé', variante: 'primaire' },
  cours_termine: { icone: '✅', label: 'Cours terminé', variante: 'succes' },
  quiz_complete: { icone: '🧠', label: 'Quiz complété', variante: 'accent' },
  flashcard_revisee: { icone: '🔄', label: 'Révision', variante: 'info' },
  document_cree: { icone: '📝', label: 'Document créé', variante: 'primaire' },
  objectif_atteint: { icone: '🎯', label: 'Objectif atteint', variante: 'succes' },
  badge_obtenu: { icone: '🏆', label: 'Badge obtenu', variante: 'avertissement' },
  succes_debloque: { icone: '⭐', label: 'Succès débloqué', variante: 'avertissement' },
  groupe_rejoint: { icone: '👥', label: 'Groupe rejoint', variante: 'info' },
  ia_interaction: { icone: '🤖', label: 'Interaction IA', variante: 'accent' },
  streak_maintenu: { icone: '🔥', label: 'Streak maintenu', variante: 'accent' },
};

export function ActiviteRecienteWidget({
  activites,
  onVoirPlus,
  limite = 8,
}: ActiviteRecienteProps) {
  const activitesAffichees = activites.slice(0, limite);

  return (
    <Card variante="elevee">
      <CardHeader
        icone={<span className="text-nk-primaire">⚡</span>}
        action={
          onVoirPlus ? (
            <button className="nk-lien-subtle" onClick={onVoirPlus}>
              Voir plus
            </button>
          ) : undefined
        }
      >
        <h3 className="nk-carte-titre-principal">Activité récente</h3>
      </CardHeader>

      <CardContent>
        {activitesAffichees.length === 0 ? (
          <div className="nk-activite-vide">
            <span className="nk-activite-vide-icone">📋</span>
            <p>Aucune activité récente</p>
            <p className="nk-activite-vide-sous">
              Commencez un cours ou une révision pour voir votre activité ici.
            </p>
          </div>
        ) : (
          <div className="nk-activite-timeline">
            {activitesAffichees.map((activite, index) => {
              const config = TYPE_CONFIG[activite.type];
              return (
                <div
                  key={activite.id}
                  className={cn(
                    'nk-activite-item',
                    index === 0 && 'nk-activite-item-recent'
                  )}
                >
                  <div className="nk-activite-item-icone">{config.icone}</div>
                  <div className="nk-activite-item-contenu">
                    <div className="nk-activite-item-entete">
                      <span className="nk-activite-item-titre">{activite.titre}</span>
                      <Badge variante={config.variante} taille="xs">
                        {config.label}
                      </Badge>
                    </div>
                    {activite.description && (
                      <p className="nk-activite-item-description">{activite.description}</p>
                    )}
                    <div className="nk-activite-item-meta">
                      <span className="nk-activite-item-date">
                        {formatageRelatif(activite.date)}
                      </span>
                      {activite.points && activite.points > 0 && (
                        <span className="nk-activite-item-points">
                          +{activite.points} XP
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default ActiviteRecienteWidget;
