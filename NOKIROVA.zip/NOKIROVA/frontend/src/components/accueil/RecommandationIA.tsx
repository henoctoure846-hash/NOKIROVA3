'use client';

/**
 * NOKIROVA — RecommandationIA
 *
 * Widget affichant les recommandations
 * personnalisées de l'IA pour l'utilisateur.
 * Actions suggérées, cartes à réviser,
 * axes d'amélioration.
 */

'use client';

import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Card, CardHeader, CardContent, Button, Badge } from '@/components/ui';

export interface Recommandation {
  id: string;
  type: 'revision' | 'apprentissage' | 'objectif' | 'correction' | 'exploration';
  titre: string;
  description: string;
  priorite: 'basse' | 'moyenne' | 'haute';
  actionLabel: string;
  actionUrl: string;
  raison: string; // Pourquoi l'IA recommande ceci
}

interface RecommandationIAProps {
  recommandations: Recommandation[];
  onAction: (recommandation: Recommandation) => void;
  onIgnorer: (id: string) => void;
  onRecharger: () => void;
}

const TYPE_ICONES: Record<string, string> = {
  revision: '🔄',
  apprentissage: '📚',
  objectif: '🎯',
  correction: '✏️',
  exploration: '🔍',
};

const TYPE_LABELS: Record<string, string> = {
  revision: 'Révision',
  apprentissage: 'Apprentissage',
  objectif: 'Objectif',
  correction: 'Correction',
  exploration: 'Exploration',
};

const PRIORITE_VARIANTES: Record<string, 'info' | 'avertissement' | 'danger'> = {
  basse: 'info',
  moyenne: 'avertissement',
  haute: 'danger',
};

export function RecommandationIAWidget({
  recommandations,
  onAction,
  onIgnorer,
  onRecharger,
}: RecommandationIAProps) {
  const [indexVisible, setIndexVisible] = useState(0);
  const [listeIgnorees, setListeIgnorees] = useState<Set<string>>(new Set());

  const recommandationsVisibles = recommandations.filter(
    (r) => !listeIgnorees.has(r.id)
  );
  const actuelle = recommandationsVisibles[indexVisible];

  const ignorer = (id: string) => {
    setListeIgnorees((prev) => new Set(prev).add(id));
    onIgnorer(id);
  };

  const suivant = () => {
    if (indexVisible < recommandationsVisibles.length - 1) {
      setIndexVisible((i) => i + 1);
    }
  };

  const precedent = () => {
    if (indexVisible > 0) {
      setIndexVisible((i) => i - 1);
    }
  };

  return (
    <Card variante="elevee" className="nk-recommandation-ia">
      <CardHeader
        icone={<span className="text-nk-accent">🤖</span>}
        action={
          <button className="nk-lien-subtle" onClick={onRecharger} title="Actualiser">
            ↻
          </button>
        }
      >
        <h3 className="nk-carte-titre-principal">Recommandations IA</h3>
      </CardHeader>

      <CardContent>
        {!actuelle ? (
          <div className="nk-recommandation-vide">
            <span className="nk-recommandation-vide-icone">✨</span>
            <p>Aucune recommandation pour le moment</p>
            <p className="nk-recommandation-vide-sous">
              L'IA analyse votre progression pour vous proposer des suggestions personnalisées.
            </p>
          </div>
        ) : (
          <>
            <div className="nk-recommandation-entete">
              <span className="nk-recommandation-type-icone">
                {TYPE_ICONES[actuelle.type]}
              </span>
              <div className="nk-recommandation-entete-texte">
                <Badge variante={PRIORITE_VARIANTES[actuelle.priorite]} taille="sm">
                  {TYPE_LABELS[actuelle.type]}
                </Badge>
              </div>
            </div>

            <h4 className="nk-recommandation-titre">{actuelle.titre}</h4>
            <p className="nk-recommandation-description">{actuelle.description}</p>

            <div className="nk-recommandation-raison">
              <span className="nk-recommandation-raison-icone">💡</span>
              <p className="nk-recommandation-raison-texte">{actuelle.raison}</p>
            </div>

            <div className="nk-recommandation-actions">
              <Button
                variante="accent"
                taille="md"
                onClick={() => onAction(actuelle)}
              >
                {actuelle.actionLabel}
              </Button>
              <button
                className="nk-lien-subtle nk-recommandation-ignorer"
                onClick={() => ignorer(actuelle.id)}
              >
                Ignorer
              </button>
            </div>

            {/* Navigation */}
            {recommandationsVisibles.length > 1 && (
              <div className="nk-recommandation-nav">
                <button
                  className="nk-recommandation-nav-btn"
                  onClick={precedent}
                  disabled={indexVisible === 0}
                >
                  ←
                </button>
                <span className="nk-recommandation-nav-compteur">
                  {indexVisible + 1} / {recommandationsVisibles.length}
                </span>
                <button
                  className="nk-recommandation-nav-btn"
                  onClick={suivant}
                  disabled={indexVisible >= recommandationsVisibles.length - 1}
                >
                  →
                </button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default RecommandationIAWidget;
