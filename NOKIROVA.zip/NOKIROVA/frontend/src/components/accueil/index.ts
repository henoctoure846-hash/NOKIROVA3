/**
 * NOKIROVA — Export groupé des composants Accueil
 */

export { CarteStatistique } from './CarteStatistique';
export { RappelRevisionWidget } from './RappelRevision';
export { RecommandationIAWidget, type Recommandation } from './RecommandationIA';
export { ActiviteRecienteWidget, type EntreeActivite, type TypeActivite } from './ActiviteReciente';
export { AccesRapidesWidget, type AccesRapideItem } from './AccesRapides';
