/**
 * NOKIROVA — CarteStatistique
 *
 * Carte de statistique pour le dashboard Accueil.
 * Affiche une valeur, un label, une icône,
 * une tendance (+/−) et un changement %.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/ui';

type CouleurStat = 'primaire' | 'accent' | 'succes' | 'avertissement' | 'danger' | 'info';

interface CarteStatistiqueProps {
  label: string;
  valeur: string | number;
  icone: React.ReactNode;
  couleur?: CouleurStat;
  tendance?: 'hausse' | 'baisse' | 'stable';
  changement?: number; // pourcentage
  sousTexte?: string;
  suffixe?: string;
}

const COULEUR_CLASSES: Record<CouleurStat, string> = {
  primaire: 'nk-stat-primaire',
  accent: 'nk-stat-accent',
  succes: 'nk-stat-succes',
  avertissement: 'nk-stat-avertissement',
  danger: 'nk-stat-danger',
  info: 'nk-stat-info',
};

const TENDANCE_ICONES: Record<string, string> = {
  hausse: '↑',
  baisse: '↓',
  stable: '→',
};

export function CarteStatistique({
  label,
  valeur,
  icone,
  couleur = 'primaire',
  tendance,
  changement,
  sousTexte,
  suffixe,
}: CarteStatistiqueProps) {
  return (
    <Card variante="interactive" compacte>
      <div className={cn('nk-carte-stat', COULEUR_CLASSES[couleur])}>
        <div className="nk-carte-stat-icone">{icone}</div>
        <div className="nk-carte-stat-contenu">
          <p className="nk-carte-stat-label">{label}</p>
          <p className="nk-carte-stat-valeur">{valeur}{suffixe}</p>
          {(tendance || changement !== undefined) && (
            <div className="nk-carte-stat-tendance">
              {tendance && (
                <span className={cn(
                  'nk-tendance-indicateur',
                  tendance === 'hausse' && 'nk-tendance-hausse',
                  tendance === 'baisse' && 'nk-tendance-baisse',
                  tendance === 'stable' && 'nk-tendance-stable'
                )}>
                  {TENDANCE_ICONES[tendance]}
                </span>
              )}
              {changement !== undefined && (
                <span className={cn(
                  'nk-tendance-pourcentage',
                  changement > 0 && 'nk-tendance-hausse',
                  changement < 0 && 'nk-tendance-baisse'
                )}>
                  {changement > 0 ? '+' : ''}{changement}%
                </span>
              )}
            </div>
          )}
          {sousTexte && <p className="nk-carte-stat-sous-texte">{sousTexte}</p>}
        </div>
      </div>
    </Card>
  );
}

export default CarteStatistique;
