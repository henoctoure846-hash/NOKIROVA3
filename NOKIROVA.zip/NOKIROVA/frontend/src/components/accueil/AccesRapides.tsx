'use client';

/**
 * NOKIROVA — AccesRapides
 *
 * Grille d'accès rapides aux 8 espaces
 * et aux actions fréquentes depuis le dashboard.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { Card, CardHeader, CardContent } from '@/components/ui';
import Link from 'next/link';

export interface AccesRapideItem {
  id: string;
  label: string;
  description: string;
  icone: React.ReactNode;
  couleur: string;
  href: string;
  badge?: string; // ex: "3 en retard"
}

interface AccesRapidesProps {
  acces?: AccesRapideItem[];
  onAccesPersonnalise?: (id: string) => void;
}

/** Accès rapides par défaut — les 8 espaces NOKIROVA */
const ACCES_PAR_DEFAUT: AccesRapideItem[] = [
  {
    id: 'apprendre',
    label: 'Apprendre',
    description: 'Cours et chapitres',
    icone: '📚',
    couleur: 'nk-couleur-bleu',
    href: '/apprendre',
  },
  {
    id: 'reviser',
    label: 'Réviser',
    description: 'Flashcards & quiz',
    icone: '🔄',
    couleur: 'nk-couleur-vert',
    href: '/reviser',
  },
  {
    id: 'produire',
    label: 'Produire',
    description: 'Documents & notes',
    icone: '📝',
    couleur: 'nk-couleur-orange',
    href: '/produire',
  },
  {
    id: 'ia-studio',
    label: 'IA Studio',
    description: 'Assistant intelligent',
    icone: '🤖',
    couleur: 'nk-couleur-violet',
    href: '/ia-studio',
  },
  {
    id: 'communaute',
    label: 'Communauté',
    description: 'Forum & groupes',
    icone: '👥',
    couleur: 'nk-couleur-rose',
    href: '/communaute',
  },
  {
    id: 'progression',
    label: 'Progression',
    description: 'Stats & objectifs',
    icone: '📊',
    couleur: 'nk-couleur-jaune',
    href: '/progression',
  },
];

export function AccesRapidesWidget({
  acces = ACCES_PAR_DEFAUT,
  onAccesPersonnalise,
}: AccesRapidesProps) {
  return (
    <Card variante="elevee">
      <CardHeader icone={<span className="text-nk-primaire">⚡</span>}>
        <h3 className="nk-carte-titre-principal">Accès rapides</h3>
      </CardHeader>

      <CardContent>
        <div className="nk-acces-rapides-grille">
          {acces.map((item) => (
            <Link
              key={item.id}
              href={item.href}
              className={cn('nk-acces-rapide-item', item.couleur)}
              onClick={() => onAccesPersonnalise?.(item.id)}
            >
              <div className="nk-acces-rapide-icone">{item.icone}</div>
              <div className="nk-acces-rapide-contenu">
                <span className="nk-acces-rapide-label">{item.label}</span>
                <span className="nk-acces-rapide-description">{item.description}</span>
              </div>
              {item.badge && (
                <span className="nk-acces-rapide-badge">{item.badge}</span>
              )}
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default AccesRapidesWidget;
