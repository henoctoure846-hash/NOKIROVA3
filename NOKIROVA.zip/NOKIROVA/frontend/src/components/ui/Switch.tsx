'use client';

/**
 * NOKIROVA — Composant Switch (interrupteur bascule)
 *
 * Basculeur activé/désactivé avec label
 * et support clavier accessible.
 */

'use client';

import React, { useId } from 'react';
import { cn } from '@/lib/utils';

interface SwitchProps {
  /** État activé du switch */  active?: boolean;
  /** Appelé quand la valeur change */  onChange?: (actif: boolean) => void;
  /** Label affiché à côté */  label?: string;
  /** Description optionnelle sous le label */  description?: string;
  /** Désactivé */  desactive?: boolean;
  /** Taille */  taille?: 'sm' | 'md' | 'lg';
  /** Classes supplémentaires */  className?: string;
  /** Nom pour formulaire */  nom?: string;
}

export function Switch({
  active = false,
  onChange,
  label,
  description,
  desactive = false,
  taille = 'md',
  className,
  nom,
}: SwitchProps) {
  const id = useId();

  const taillesTrack = {
    sm: 'nk-switch-track-sm',
    md: 'nk-switch-track-md',
    lg: 'nk-switch-track-lg',
  };

  const taillesPouce = {
    sm: 'nk-switch-pouce-sm',
    md: 'nk-switch-pouce-md',
    lg: 'nk-switch-pouce-lg',
  };

  const handleClick = () => {
    if (!desactive) onChange?.(!active);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      handleClick();
    }
  };

  return (
    <div className={cn('nk-switch-groupe', desactive && 'nk-switch-desactive', className)}>
      <button
        type="button"
        role="switch"
        aria-checked={active}
        aria-labelledby={label ? id : undefined}
        aria-disabled={desactive}
        className={cn(
          'nk-switch-track',
          taillesTrack[taille],
          active && 'nk-switch-actif'
        )}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        name={nom}
      >
        <span
          className={cn(
            'nk-switch-pouce',
            taillesPouce[taille],
            active && 'nk-switch-pouce-actif'
          )}
        />
      </button>
      {(label || description) && (
        <div className="nk-switch-texte">
          {label && (
            <label id={id} className="nk-switch-label" onClick={handleClick}>
              {label}
            </label>
          )}
          {description && (
            <span className="nk-switch-description">{description}</span>
          )}
        </div>
      )}
    </div>
  );
}

export default Switch;
