'use client';

/**
 * NOKIROVA — Composant FileUpload (téléversement de fichiers)
 *
 * Zone de glisser-déposer avec aperçu,
 * validation de type/taille et barre de progression.
 */

'use client';

import React, { useState, useRef, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { Button } from './Button';

interface FichierUploade {
  id: string;
  nom: string;
  taille: number;
  type: string;
  progression: number;
  statut: 'en_attente' | 'televersement' | 'termine' | 'erreur';
  erreur?: string;
  apercu?: string;
  fichier: File;
}

interface FileUploadProps {
  /** Types MIME acceptés */
  typesAcceptes?: string[];
  /** Taille max en Mo */
  tailleMaxMo?: number;
  /** Nombre max de fichiers */
  maxFichiers?: number;
  /** Multiple fichiers */
  multiple?: boolean;
  /** Appelé quand des fichiers sont sélectionnés */
  onFichiersSelectionnes?: (fichiers: File[]) => void;
  /** Appelé pendant le téléversement */
  onProgression?: (fichierId: string, progression: number) => void;
  /** Appelé quand un fichier est terminé */
  onFichierTermine?: (fichierId: string, url: string) => void;
  /** Appelé en cas d'erreur */
  onErreur?: (fichierId: string, erreur: string) => void;
  /** Désactivé */
  desactive?: boolean;
  /** Label */
  label?: string;
  /** Texte d'aide */
  aide?: string;
  /** Classes supplémentaires */
  className?: string;
}

export function FileUpload({
  typesAcceptes = ['image/*', 'application/pdf', 'text/plain'],
  tailleMaxMo = 10,
  maxFichiers = 5,
  multiple = false,
  onFichiersSelectionnes,
  onProgression,
  onFichierTermine,
  onErreur,
  desactive = false,
  label = 'Glissez vos fichiers ici',
  aide,
  className,
}: FileUploadProps) {
  const [fichiers, setFichiers] = useState<FichierUploade[]>([]);
  const [glisserActif, setGlisserActif] = useState(false);
  const [erreurGlobale, setErreurGlobale] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const tailleMaxOctets = tailleMaxMo * 1024 * 1024;

  /** Génère un identifiant unique */
  const genererId = () => `fichier_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

  /** Formate la taille en Ko/Mo */
  const formaterTaille = (octets: number): string => {
    if (octets < 1024) return `${octets} o`;
    if (octets < 1024 * 1024) return `${(octets / 1024).toFixed(1)} Ko`;
    return `${(octets / (1024 * 1024)).toFixed(1)} Mo`;
  };

  /** Vérifie le type MIME */
  const verifierType = (fichier: File): boolean => {
    if (typesAcceptes.includes('*')) return true;
    return typesAcceptes.some((type) => {
      if (type.endsWith('/*')) {
        return fichier.type.startsWith(type.replace('/*', '/'));
      }
      return fichier.type === type;
    });
  }

  /** Ajoute des fichiers à la liste */
  const ajouterFichiers = useCallback(
    (nouveauxFichiers: FileList | File[]) => {
      setErreurGlobale(null);
      const fichiersArray = Array.from(nouveauxFichiers);

      // Vérifier le nombre max
      if (fichiers.length + fichiersArray.length > maxFichiers) {
        setErreurGlobale(`Maximum ${maxFichiers} fichier(s) autorisé(s)`);
        return;
      }

      const fichiersValides: FichierUploade[] = [];

      for (const fichier of fichiersArray) {
        // Vérifier la taille
        if (fichier.size > tailleMaxOctets) {
          setErreurGlobale(`« ${fichier.name} » dépasse ${tailleMaxMo} Mo`);
          onErreur?.(genererId(), `Fichier trop volumineux : ${formaterTaille(fichier.size)}`);
          continue;
        }

        // Vérifier le type
        if (!verifierType(fichier)) {
          setErreurGlobale(`« ${fichier.name} » : type non supporté`);
          onErreur?.(genererId(), `Type non supporté : ${fichier.type}`);
          continue;
        }

        const id = genererId();
        const nouveaufichier: FichierUploade = {
          id,
          nom: fichier.name,
          taille: fichier.size,
          type: fichier.type,
          progression: 0,
          statut: 'en_attente',
          fichier,
        };

        // Générer un aperçu pour les images
        if (fichier.type.startsWith('image/')) {
          nouveaufichier.apercu = URL.createObjectURL(fichier);
        }

        fichiersValides.push(nouveaufichier);
      }

      if (fichiersValides.length > 0) {
        setFichiers((prev) => [...prev, ...fichiersValides]);
        onFichiersSelectionnes?.(fichiersValides.map((f) => f.fichier));

        // Simuler le téléversement
        fichiersValides.forEach((f) => {
          simulerTeleversement(f.id);
        });
      }
    },
    [fichiers.length, maxFichiers, tailleMaxOctets, tailleMaxMo, typesAcceptes]
  );

  /** Simule un téléversement avec progression */
  const simulerTeleversement = (fichierId: string) => {
    setFichiers((prev) =>
      prev.map((f) => f.id === fichierId ? { ...f, statut: 'televersement' } : f)
    );

    let progression = 0;
    const interval = setInterval(() => {
      progression += Math.random() * 20 + 5;
      if (progression >= 100) {
        progression = 100;
        clearInterval(interval);
        setFichiers((prev) =>
          prev.map((f) => f.id === fichierId ? { ...f, progression: 100, statut: 'termine' } : f)
        );
        onFichierTermine?.(fichierId, `/uploads/${fichierId}`);
      } else {
        setFichiers((prev) =>
          prev.map((f) => f.id === fichierId ? { ...f, progression: Math.round(progression) } : f)
        );
        onProgression?.(fichierId, Math.round(progression));
      }
    }, 200);
  };

  /** Supprime un fichier de la liste */
  const supprimerFichier = (fichierId: string) => {
    setFichiers((prev) => {
      const fichier = prev.find((f) => f.id === fichierId);
      if (fichier?.apercu) URL.revokeObjectURL(fichier.apercu);
      return prev.filter((f) => f.id !== fichierId);
    });
  };

  /** Gestionnaires de glisser-déposer */
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!desactive) setGlisserActif(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setGlisserActif(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setGlisserActif(false);
    if (!desactive && e.dataTransfer.files.length > 0) {
      ajouterFichiers(e.dataTransfer.files);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      ajouterFichiers(e.target.files);
      e.target.value = ''; // réinitialiser
    }
  };

  return (
    <div className={cn('nk-fileupload', desactive && 'nk-fileupload-desactive', className)}>
      {label && <label className="nk-fileupload-label">{label}</label>}

      {/* Zone de dépôt */}
      <div
        className={cn(
          'nk-fileupload-zone',
          glisserActif && 'nk-fileupload-zone-glisse',
          desactive && 'nk-fileupload-zone-desactive'
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !desactive && inputRef.current?.click()}
        role="button"
        tabIndex={0}
        aria-label="Zone de dépôt de fichiers"
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            inputRef.current?.click();
          }
        }}
      >
        <input
          ref={inputRef}
          type="file"
          className="nk-fileupload-input"
          accept={typesAcceptes.join(',')}
          multiple={multiple}
          onChange={handleInputChange}
          disabled={desactive}
          aria-hidden="true"
        />
        <div className="nk-fileupload-icone">
          <svg viewBox="0 0 48 48" fill="none" className="nk-fileupload-icone-svg">
            <path
              d="M24 6v24M16 14l8-8 8 8"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M8 28v8a4 4 0 004 4h24a4 4 0 004-4v-8"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <p className="nk-fileupload-texte">
          {glisserActif ? 'Déposez vos fichiers ici' : label || 'Glissez vos fichiers ici'}
        </p>
        <p className="nk-fileupload-soustexte">
          ou <span className="nk-fileupload-lien">parcourir</span>
        </p>
        {aide && <p className="nk-fileupload-aide">{aide}</p>}
      </div>

      {/* Erreur globale */}
      {erreurGlobale && (
        <p className="nk-fileupload-erreur" role="alert">{erreurGlobale}</p>
      )}

      {/* Liste des fichiers */}
      {fichiers.length > 0 && (
        <ul className="nk-fileupload-liste">
          {fichiers.map((fichier) => (
            <li key={fichier.id} className="nk-fileupload-element">
              {/* Aperçu image */}
              {fichier.apercu && (
                <img
                  src={fichier.apercu}
                  alt={`Aperçu de ${fichier.nom}`}
                  className="nk-fileupload-apercu"
                />
              )}
              {!fichier.apercu && (
                <div className="nk-fileupload-icone-fichier">
                  <svg viewBox="0 0 24 24" fill="none">
                    <path
                      d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              )}

              {/* Informations */}
              <div className="nk-fileupload-infos">
                <span className="nk-fileupload-nom">{fichier.nom}</span>
                <span className="nk-fileupload-taille">{formaterTaille(fichier.taille)}</span>
                {fichier.statut === 'televersement' && (
                  <div className="nk-fileupload-barre">
                    <div
                      className="nk-fileupload-progression"
                      style={{ width: `${fichier.progression}%` }}
                    />
                  </div>
                )}
                {fichier.statut === 'erreur' && (
                  <span className="nk-fileupload-erreur-fichier">{fichier.erreur}</span>
                )}
              </div>

              {/* Actions */}
              <div className="nk-fileupload-actions">
                {fichier.statut === 'termine' && (
                  <span className="nk-fileupload-succes">✓</span>
                )}
                <Button
                  variante="ghost"
                  taille="xs"
                  onClick={() => supprimerFichier(fichier.id)}
                  aria-label={`Supprimer ${fichier.nom}`}
                >
                  ✕
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default FileUpload;
