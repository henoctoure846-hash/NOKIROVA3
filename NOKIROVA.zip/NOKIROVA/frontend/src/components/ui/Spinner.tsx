/**
 * NOKIROVA — Composant Spinner (indicateur de chargement)
 *
 * Indicateur visuel de chargement
 * avec variantes de taille et couleur.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';

type TailleSpinner = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
type VarianteSpinner = 'primaire' | 'secondaire' | 'blanc' | 'accent';

interface SpinnerProps {
  /** Taille du spinner */
  taille?: TailleSpinner;
  /** Variante de couleur */
  variante?: VarianteSpinner;
  /** Texte d'accompagnement */
  texte?: string;
  /** Pleine largeur centré */
  centre?: boolean;
  /** Classes supplémentaires */
  className?: string;
}

const taillesMap: Record<TailleSpinner, string> = {
  xs: 'nk-spinner-xs',
  sm: 'nk-spinner-sm',
  md: 'nk-spinner-md',
  lg: 'nk-spinner-lg',
  xl: 'nk-spinner-xl',
};

const variantesMap: Record<VarianteSpinner, string> = {
  primaire: 'nk-spinner-primaire',
  secondaire: 'nk-spinner-secondaire',
  blanc: 'nk-spinner-blanc',
  accent: 'nk-spinner-accent',
};

export function Spinner({
  taille = 'md',
  variante = 'primaire',
  texte,
  centre = false,
  className,
}: SpinnerProps) {
  return (
    <div
      className={cn(
        'nk-spinner-conteneur',
        centre && 'nk-spinner-centre',
        className
      )}
      role="status"
      aria-label={texte || 'Chargement en cours'}
    >
      <div className={cn('nk-spinner', taillesMap[taille], variantesMap[variante])}>
        <svg viewBox="0 0 50 50" className="nk-spinner-svg">
          <circle
            cx="25"
            cy="25"
            r="20"
            fill="none"
            strokeWidth="4"
            strokeLinecap="round"
            className="nk-spinner-trace"
          />
          <circle
            cx="25"
            cy="25"
            r="20"
            fill="none"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray="80 200"
            strokeDashoffset="0"
            className="nk-spinner-arc"
          />
        </svg>
      </div>
      {texte && <span className="nk-spinner-texte">{texte}</span>}
    </div>
  );
}

export default Spinner;
