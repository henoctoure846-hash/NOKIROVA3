'use client';

/**
 * NOKIROVA — Composant Pagination
 *
 * Pagination accessible avec boutons
 * première/précédente/suivante/dernière
 * et sélection du nombre d'éléments par page.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from './Button';

interface PaginationProps {
  /** Page actuelle */
  pageActuelle: number;
  /** Nombre total de pages */
  totalPages: number;
  /** Nombre total d'éléments */
  totalElements?: number;
  /** Éléments par page */
  elementsParPage?: number;
  /** Options de taille de page */
  optionsTaillePage?: number[];
  /** Appelé au changement de page */
  onChangementPage: (page: number) => void;
  /** Appelé au changement de taille */
  onChangementTaille?: (taille: number) => void;
  /** Désactivé */
  desactive?: boolean;
  /** Classes supplémentaires */
  className?: string;
}

export function Pagination({
  pageActuelle,
  totalPages,
  totalElements,
  elementsParPage = 20,
  optionsTaillePage = [10, 20, 50, 100],
  onChangementPage,
  onChangementTaille,
  desactive = false,
  className,
}: PaginationProps) {
  /** Calcule les numéros de pages à afficher */
  const calculerPlagePages = (): (number | string)[] => {
    const pages: (number | string)[] = [];
    const delta = 2; // pages de chaque côté de la page courante

    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
      return pages;
    }

    pages.push(1);

    if (pageActuelle > delta + 2) {
      pages.push('...');
    }

    const debut = Math.max(2, pageActuelle - delta);
    const fin = Math.min(totalPages - 1, pageActuelle + delta);

    for (let i = debut; i <= fin; i++) {
      pages.push(i);
    }

    if (pageActuelle < totalPages - delta - 1) {
      pages.push('...');
    }

    pages.push(totalPages);

    return pages;
  };

  const plagePages = calculerPlagePages();
  const premierElement = (pageActuelle - 1) * elementsParPage + 1;
  const dernierElement = Math.min(pageActuelle * elementsParPage, totalElements || 0);

  return (
    <div className={cn('nk-pagination', className)}>
      {/* Informations sur les éléments */}
      {totalElements !== undefined && (
        <div className="nk-pagination-info">
          <span className="nk-pagination-texte">
            {premierElement}–{dernierElement} sur {totalElements}
          </span>
          {onChangementTaille && (
            <select
              className="nk-pagination-select"
              value={elementsParPage}
              onChange={(e) => onChangementTaille(Number(e.target.value))}
              disabled={desactive}
              aria-label="Éléments par page"
            >
              {optionsTaillePage.map((taille) => (
                <option key={taille} value={taille}>
                  {taille} / page
                </option>
              ))}
            </select>
          )}
        </div>
      )}

      {/* Boutons de navigation */}
      <nav className="nk-pagination-navigation" aria-label="Pagination">
        <Button
          variante="ghost"
          taille="sm"
          onClick={() => onChangementPage(1)}
          disabled={desactive || pageActuelle <= 1}
          aria-label="Première page"
          className="nk-pagination-bouton"
        >
          ««
        </Button>
        <Button
          variante="ghost"
          taille="sm"
          onClick={() => onChangementPage(pageActuelle - 1)}
          disabled={desactive || pageActuelle <= 1}
          aria-label="Page précédente"
          className="nk-pagination-bouton"
        >
          «
        </Button>

        {plagePages.map((page, index) =>
          page === '...' ? (
            <span key={`ellipsis-${index}`} className="nk-pagination-ellipsis">
              …
            </span>
          ) : (
            <button
              key={page}
              className={cn(
                'nk-pagination-page',
                page === pageActuelle && 'nk-pagination-page-active'
              )}
              onClick={() => onChangementPage(page as number)}
              disabled={desactive}
              aria-label={`Page ${page}`}
              aria-current={page === pageActuelle ? 'page' : undefined}
            >
              {page}
            </button>
          )
        )}

        <Button
          variante="ghost"
          taille="sm"
          onClick={() => onChangementPage(pageActuelle + 1)}
          disabled={desactive || pageActuelle >= totalPages}
          aria-label="Page suivante"
          className="nk-pagination-bouton"
        >
          »
        </Button>
        <Button
          variante="ghost"
          taille="sm"
          onClick={() => onChangementPage(totalPages)}
          disabled={desactive || pageActuelle >= totalPages}
          aria-label="Dernière page"
          className="nk-pagination-bouton"
        >
          »»
        </Button>
      </nav>
    </div>
  );
}

export default Pagination;
