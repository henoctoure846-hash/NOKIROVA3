/**
 * NOKIROVA — Composant Input
 *
 * Champ de saisie réutilisable avec label,
 * erreur, icône, variante.
 * Utilise nk-input + variantes.
 */

'use client';

import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';

type VarianteInput = 'defaut' | 'rempli' | 'sous-ligne';
type EtatInput = 'defaut' | 'succes' | 'erreur' | 'avertissement';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  erreur?: string;
  indice?: string;
  iconeGauche?: React.ReactNode;
  iconeDroite?: React.ReactNode;
  variante?: VarianteInput;
  etat?: EtatInput;
  pleinLargeur?: boolean;
}

const VARIANTE_CLASSES: Record<VarianteInput, string> = {
  defaut: 'nk-input-defaut',
  rempli: 'nk-input-rempli',
  'sous-ligne': 'nk-input-sous-ligne',
};

const ETAT_CLASSES: Record<EtatInput, string> = {
  defaut: '',
  succes: 'nk-input-succes',
  erreur: 'nk-input-erreur',
  avertissement: 'nk-input-avertissement',
};

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({
    label,
    erreur,
    indice,
    iconeGauche,
    iconeDroite,
    variante = 'defaut',
    etat = erreur ? 'erreur' : 'defaut',
    pleinLargeur = true,
    className,
    id,
    ...props
  }, ref) => {
    const inputId = id || `nk-input-${label?.replace(/\s+/g, '-').toLowerCase()}`;

    return (
      <div className={cn('nk-input-groupe', pleinLargeur && 'nk-input-plein', className)}>
        {label && (
          <label htmlFor={inputId} className="nk-input-label">
            {label}
          </label>
        )}
        <div className={cn('nk-input-conteneur', iconeGauche && 'nk-input-avec-icone-gauche', iconeDroite && 'nk-input-avec-icone-droite')}>
          {iconeGauche && <span className="nk-input-icone nk-input-icone-gauche">{iconeGauche}</span>}
          <input
            ref={ref}
            id={inputId}
            className={cn('nk-input', VARIANTE_CLASSES[variante], ETAT_CLASSES[etat])}
            aria-invalid={etat === 'erreur'}
            aria-describedby={erreur ? `${inputId}-erreur` : indice ? `${inputId}-indice` : undefined}
            {...props}
          />
          {iconeDroite && <span className="nk-input-icone nk-input-icone-droite">{iconeDroite}</span>}
        </div>
        {erreur && (
          <p id={`${inputId}-erreur`} className="nk-input-erreur-texte" role="alert">
            {erreur}
          </p>
        )}
        {indice && !erreur && (
          <p id={`${inputId}-indice`} className="nk-input-indice-texte">
            {indice}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export default Input;
