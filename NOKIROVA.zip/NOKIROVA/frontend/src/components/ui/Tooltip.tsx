'use client';

/**
 * NOKIROVA — Composant Tooltip (infobulle)
 *
 * Infobulle au survol avec positionnement
 * configurable et délai d'apparition.
 */

'use client';

import React, { useState, useRef, useCallback, useId } from 'react';
import { cn } from '@/lib/utils';

type PositionTooltip = 'haut' | 'bas' | 'gauche' | 'droite';

interface TooltipProps {
  /** Contenu de l'infobulle */  contenu: React.ReactNode;
  /** Élément déclencheur */  enfants: React.ReactNode;
  /** Position de l'infobulle */  position?: PositionTooltip;
  /** Délai d'apparition en ms */  delai?: number;
  /** Délai de disparition en ms */  delaiMasquage?: number;
  /** Largeur max */  largeurMax?: number;
  /** Désactivé */  desactive?: boolean;
  /** Classes supplémentaires */  className?: string;
}

export function Tooltip({
  contenu,
  enfants,
  position = 'haut',
  delai = 300,
  delaiMasquage = 150,
  largeurMax = 240,
  desactive = false,
  className,
}: TooltipProps) {
  const [visible, setVisible] = useState(false);
  const delaiRef = useRef<ReturnType<typeof setTimeout>>();
  const id = useId();

  const montrer = useCallback(() => {
    if (desactive) return;
    clearTimeout(delaiRef.current);
    delaiRef.current = setTimeout(() => setVisible(true), delai);
  }, [delai, desactive]);

  const cacher = useCallback(() => {
    clearTimeout(delaiRef.current);
    delaiRef.current = setTimeout(() => setVisible(false), delaiMasquage);
  }, [delaiMasquage]);

  const positionClasses: Record<PositionTooltip, string> = {
    haut: 'nk-tooltip-haut',
    bas: 'nk-tooltip-bas',
    gauche: 'nk-tooltip-gauche',
    droite: 'nk-tooltip-droite',
  };

  return (
    <div
      className={cn('nk-tooltip-conteneur', className)}
      onMouseEnter={montrer}
      onMouseLeave={cacher}
      onFocus={montrer}
      onBlur={cacher}
    >
      {enfants}
      {visible && (
        <div
          id={id}
          role="tooltip"
          className={cn('nk-tooltip', positionClasses[position], visible && 'nk-tooltip-visible')}
          style={{ maxWidth: largeurMax }}
        >
          {contenu}
          <span className="nk-tooltip-fleche" />
        </div>
      )}
    </div>
  );
}

export default Tooltip;
