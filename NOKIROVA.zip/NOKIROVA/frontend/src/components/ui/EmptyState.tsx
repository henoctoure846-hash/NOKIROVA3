'use client';

/**
 * NOKIROVA — Composant EmptyState (état vide)
 *
 * Affichage quand aucune donnée n'est disponible.
 * Icône, titre, description et action optionnelle.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from './Button';

interface EmptyStateProps {
  /** Icône ou illustration */
  icone?: React.ReactNode;
  /** Titre principal */
  titre: string;
  /** Description explicative */
  description?: string;
  /** Texte du bouton d'action */
  texteAction?: string;
  /** Action au clic */
  onAction?: () => void;
  /** Variante du bouton */
  varianteAction?: 'primaire' | 'secondaire' | 'outline';
  /** Taille */
  taille?: 'sm' | 'md' | 'lg';
  /** Classes supplémentaires */
  className?: string;
}

const taillesMap = {
  sm: 'nk-etat-vide-sm',
  md: 'nk-etat-vide-md',
  lg: 'nk-etat-vide-lg',
};

/** Icônes par défaut pour les espaces */
const iconesDefaut: Record<string, React.ReactNode> = {
  cours: (
    <svg className="nk-etat-vide-icone" viewBox="0 0 64 64" fill="none">
      <rect x="8" y="12" width="48" height="40" rx="4" stroke="currentColor" strokeWidth="2" />
      <path d="M20 24h24M20 32h18M20 40h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  recherche: (
    <svg className="nk-etat-vide-icone" viewBox="0 0 64 64" fill="none">
      <circle cx="26" cy="26" r="14" stroke="currentColor" strokeWidth="2" />
      <path d="M36 36l14 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  carte: (
    <svg className="nk-etat-vide-icone" viewBox="0 0 64 64" fill="none">
      <rect x="10" y="18" width="44" height="28" rx="3" stroke="currentColor" strokeWidth="2" />
      <path d="M10 28h44M24 18v28" stroke="currentColor" strokeWidth="2" />
    </svg>
  ),
};

export function EmptyState({
  icone,
  titre,
  description,
  texteAction,
  onAction,
  varianteAction = 'primaire',
  taille = 'md',
  className,
}: EmptyStateProps) {
  return (
    <div className={cn('nk-etat-vide', taillesMap[taille], className)}>
      <div className="nk-etat-vide-illustration">
        {icone || iconesDefaut.cours}
      </div>
      <h3 className="nk-etat-vide-titre">{titre}</h3>
      {description && <p className="nk-etat-vide-description">{description}</p>}
      {texteAction && onAction && (
        <Button
          variante={varianteAction === 'outline' ? 'secondaire' : varianteAction === 'secondaire' ? 'secondaire' : 'primaire'}
          onClick={onAction}
          className="nk-etat-vide-action"
        >
          {texteAction}
        </Button>
      )}
    </div>
  );
}

export default EmptyState;
