'use client';

/**
 * NOKIROVA — Composant Textarea
 *
 * Zone de texte multiligne stylisée
 * avec compteur de caractères.
 */

'use client';

import React, { useState, useId } from 'react';
import { cn } from '@/lib/utils';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  erreur?: string;
  aide?: string;
  compteur?: boolean;
  limiteCaracteres?: number;
  autoRedimensionnement?: boolean;
}

export function Textarea({
  label,
  erreur,
  aide,
  compteur = false,
  limiteCaracteres,
  autoRedimensionnement = false,
  className,
  id: idProp,
  value,
  onChange,
  maxLength,
  rows = 4,
  ...props
}: TextareaProps) {
  const idGenere = useId();
  const id = idProp || idGenere;
  const [compteurValeur, setCompteurValeur] = useState(
    typeof value === 'string' ? value.length : 0
  );

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCompteurValeur(e.target.value.length);

    if (autoRedimensionnement) {
      e.target.style.height = 'auto';
      e.target.style.height = `${e.target.scrollHeight}px`;
    }

    onChange?.(e);
  };

  const limite = limiteCaracteres || maxLength;

  return (
    <div className={cn('nk-textarea-groupe', erreur && 'nk-textarea-erreur', className)}>
      {label && (
        <label htmlFor={id} className="nk-textarea-label">
          {label}
        </label>
      )}
      <textarea
        id={id}
        className="nk-textarea"
        value={value}
        onChange={handleChange}
        maxLength={limite}
        rows={rows}
        aria-invalid={!!erreur}
        aria-describedby={erreur ? `${id}-erreur` : aide ? `${id}-aide` : undefined}
        {...props}
      />
      <div className="nk-textarea-pied">
        {erreur && (
          <span id={`${id}-erreur`} className="nk-textarea-message-erreur" role="alert">
            {erreur}
          </span>
        )}
        {!erreur && aide && (
          <span id={`${id}-aide`} className="nk-textarea-aide">
            {aide}
          </span>
        )}
        {compteur && limite && (
          <span
            className={cn(
              'nk-textarea-compteur',
              compteurValeur > limite * 0.9 && 'nk-textarea-compteur-limite'
            )}
          >
            {compteurValeur}/{limite}
          </span>
        )}
      </div>
    </div>
  );
}

export default Textarea;
