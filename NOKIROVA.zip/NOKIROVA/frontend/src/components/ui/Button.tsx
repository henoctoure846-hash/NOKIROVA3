/**
 * NOKIROVA — Composant Bouton
 *
 * Bouton réutilisable avec variante, taille,
 * icône, chargement, plein/plein contour.
 * Utilise les classes nk-bouton-*.
 */

'use client';

import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';

type VarianteBouton = 'primaire' | 'secondaire' | 'accent' | 'succes' | 'danger' | 'ghost' | 'lien';
type TailleBouton = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variante?: VarianteBouton;
  taille?: TailleBouton;
  iconeGauche?: React.ReactNode;
  iconeDroite?: React.ReactNode;
  estChargement?: boolean;
  pleinLargeur?: boolean;
}

const VARIANTE_CLASSES: Record<VarianteBouton, string> = {
  primaire: 'nk-bouton-primaire',
  secondaire: 'nk-bouton-secondaire',
  accent: 'nk-bouton-accent',
  succes: 'nk-bouton-succes',
  danger: 'nk-bouton-danger',
  ghost: 'nk-bouton-ghost',
  lien: 'nk-bouton-lien',
};

const TAILLE_CLASSES: Record<TailleBouton, string> = {
  xs: 'nk-bouton-xs',
  sm: 'nk-bouton-sm',
  md: 'nk-bouton-md',
  lg: 'nk-bouton-lg',
  xl: 'nk-bouton-xl',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({
    variante = 'primaire',
    taille = 'md',
    iconeGauche,
    iconeDroite,
    estChargement = false,
    pleinLargeur = false,
    className,
    disabled,
    children,
    ...props
  }, ref) => {
    const estDesactive = disabled || estChargement;

    return (
      <button
        ref={ref}
        className={cn(
          'nk-bouton',
          VARIANTE_CLASSES[variante],
          TAILLE_CLASSES[taille],
          pleinLargeur && 'nk-bouton-plein',
          estDesactive && 'nk-bouton-desactive',
          estChargement && 'nk-bouton-chargement',
          className
        )}
        disabled={estDesactive}
        {...props}
      >
        {estChargement ? (
          <span className="nk-bouton-spinner" aria-hidden="true" />
        ) : (
          iconeGauche && <span className="nk-bouton-icone-gauche">{iconeGauche}</span>
        )}
        <span className="nk-bouton-texte">{children}</span>
        {!estChargement && iconeDroite && (
          <span className="nk-bouton-icone-droite">{iconeDroite}</span>
        )}
      </button>
    );
  }
);

Button.displayName = 'Button';

export default Button;
