'use client';

/**
 * NOKIROVA — Composant Tabs
 *
 * Onglets réutilisables avec variante,
 * icônes, compteur, navigation clavier.
 * Utilisé dans chaque espace NOKIROVA.
 */

'use client';

import React, { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

type VarianteTabs = 'ligne' | 'pilule' | 'encadre';

interface Onglet {
  id: string;
  label: string;
  icone?: React.ReactNode;
  compteur?: number;
  desactive?: boolean;
  contenu: React.ReactNode;
}

interface TabsProps {
  onglets: Onglet[];
  ongletActif?: string;
  onChangement?: (ongletId: string) => void;
  variante?: VarianteTabs;
  pleinLargeur?: boolean;
  className?: string;
}

export function Tabs({
  onglets,
  ongletActif,
  onChangement,
  variante = 'ligne',
  pleinLargeur = false,
  className,
}: TabsProps) {
  const [actif, setActif] = useState(ongletActif || onglets[0]?.id);
  const listeRef = useRef<HTMLDivElement>(null);

  // Synchronise l'onglet actif si contrôlé de l'extérieur
  useEffect(() => {
    if (ongletActif) setActif(ongletActif);
  }, [ongletActif]);

  const selectionner = (id: string) => {
    setActif(id);
    onChangement?.(id);
  };

  // Navigation clavier (flèches gauche/droite)
  const gererClavier = (e: React.KeyboardEvent) => {
    const idx = onglets.findIndex((o) => o.id === actif);
    const actifs = onglets.filter((o) => !o.desactive);
    const actifIdx = actifs.findIndex((o) => o.id === actif);

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      const prochain = actifs[(actifIdx + 1) % actifs.length];
      selectionner(prochain.id);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      const precedent = actifs[(actifIdx - 1 + actifs.length) % actifs.length];
      selectionner(precedent.id);
    }
  };

  const ongletActuel = onglets.find((o) => o.id === actif);

  return (
    <div className={cn('nk-tabs', `nk-tabs-${variante}`, className)}>
      {/* Barre d'onglets */}
      <div
        ref={listeRef}
        className={cn('nk-tabs-liste', pleinLargeur && 'nk-tabs-liste-plein')}
        role="tablist"
        onKeyDown={gererClavier}
      >
        {onglets.map((onglet) => (
          <button
            key={onglet.id}
            id={`tab-${onglet.id}`}
            className={cn(
              'nk-tabs-onglet',
              actif === onglet.id && 'nk-tabs-onglet-actif',
              onglet.desactive && 'nk-tabs-onglet-desactive'
            )}
            role="tab"
            aria-selected={actif === onglet.id}
            aria-controls={`panel-${onglet.id}`}
            aria-disabled={onglet.desactive}
            tabIndex={actif === onglet.id ? 0 : -1}
            onClick={() => !onglet.desactive && selectionner(onglet.id)}
          >
            {onglet.icone && <span className="nk-tabs-onglet-icone">{onglet.icone}</span>}
            <span className="nk-tabs-onglet-label">{onglet.label}</span>
            {onglet.compteur !== undefined && (
              <span className="nk-tabs-onglet-compteur">{onglet.compteur}</span>
            )}
          </button>
        ))}
      </div>

      {/* Panneau contenu */}
      <div
        id={`panel-${actif}`}
        className="nk-tabs-panneau"
        role="tabpanel"
        aria-labelledby={`tab-${actif}`}
        tabIndex={0}
      >
        {ongletActuel?.contenu}
      </div>
    </div>
  );
}

export default Tabs;
