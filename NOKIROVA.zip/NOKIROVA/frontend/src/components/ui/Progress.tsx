/**
 * NOKIROVA — Composant Progress
 *
 * Barre de progression avec label,
 * variante couleur, animation, taille.
 * Utilisé pour XP, cours, objectifs.
 */

'use client';

import React from 'react';
import { cn, pourcentageXp } from '@/lib/utils';

type VarianteProgress = 'primaire' | 'succes' | 'avertissement' | 'danger' | 'accent' | 'neutre';
type TailleProgress = 'xs' | 'sm' | 'md' | 'lg';

interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  valeur: number; // 0-100
  variante?: VarianteProgress;
  taille?: TailleProgress;
  label?: string;
  afficherPourcentage?: boolean;
  anime?: boolean;
  raye?: boolean;
  indetermine?: boolean;
}

const VARIANTE_CLASSES: Record<VarianteProgress, string> = {
  primaire: 'nk-progress-primaire',
  succes: 'nk-progress-succes',
  avertissement: 'nk-progress-avertissement',
  danger: 'nk-progress-danger',
  accent: 'nk-progress-accent',
  neutre: 'nk-progress-neutre',
};

const TAILLE_CLASSES: Record<TailleProgress, string> = {
  xs: 'nk-progress-xs',
  sm: 'nk-progress-sm',
  md: 'nk-progress-md',
  lg: 'nk-progress-lg',
};

export function Progress({
  valeur,
  variante = 'primaire',
  taille = 'md',
  label,
  afficherPourcentage = false,
  anime = true,
  raye = false,
  indetermine = false,
  className,
  ...props
}: ProgressProps) {
  const pourcentage = Math.min(100, Math.max(0, valeur));

  return (
    <div className={cn('nk-progress', className)} {...props}>
      {(label || afficherPourcentage) && (
        <div className="nk-progress-info">
          {label && <span className="nk-progress-label">{label}</span>}
          {afficherPourcentage && (
            <span className="nk-progress-pourcentage">{Math.round(pourcentage)}%</span>
          )}
        </div>
      )}
      <div
        className={cn(
          'nk-progress-piste',
          TAILLE_CLASSES[taille]
        )}
        role="progressbar"
        aria-valuenow={indetermine ? undefined : pourcentage}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label}
      >
        <div
          className={cn(
            'nk-progress-remplissage',
            VARIANTE_CLASSES[variante],
            anime && 'nk-progress-anime',
            raye && 'nk-progress-raye',
            indetermine && 'nk-progress-indetermine'
          )}
          style={indetermine ? undefined : { width: `${pourcentage}%` }}
        />
      </div>
    </div>
  );
}

export default Progress;
