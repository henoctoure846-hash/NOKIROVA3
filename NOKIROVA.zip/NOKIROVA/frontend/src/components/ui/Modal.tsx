'use client';

/**
 * NOKIROVA — Composant Modal
 *
 * Boîte de dialogue modale accessible,
 * tailles, animation, overlay, fermeture
 * par Escape/clic extérieur.
 */

'use client';

import React, { useEffect, useCallback, useRef } from 'react';
import { cn } from '@/lib/utils';

type TailleModal = 'petit' | 'moyen' | 'grand' | 'plein';

interface ModalProps {
  estOuvert: boolean;
  onFermer: () => void;
  titre?: string;
  taille?: TailleModal;
  fermable?: boolean;
  children: React.ReactNode;
  className?: string;
  piedDePage?: React.ReactNode;
}

const TAILLE_CLASSES: Record<TailleModal, string> = {
  petit: 'nk-modal-petit',
  moyen: 'nk-modal-moyen',
  grand: 'nk-modal-grand',
  plein: 'nk-modal-plein',
};

export function Modal({
  estOuvert,
  onFermer,
  titre,
  taille = 'moyen',
  fermable = true,
  children,
  className,
  piedDePage,
}: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const precedentFocus = useRef<HTMLElement | null>(null);

  const gererFermer = useCallback(() => {
    if (fermable) onFermer();
  }, [fermable, onFermer]);

  // Gestion clavier (Escape)
  useEffect(() => {
    if (!estOuvert) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && fermable) {
        e.preventDefault();
        onFermer();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [estOuvert, fermable, onFermer]);

  // Piège le focus dans la modale
  useEffect(() => {
    if (estOuvert) {
      precedentFocus.current = document.activeElement as HTMLElement;
      dialogRef.current?.focus();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      precedentFocus.current?.focus();
    }
    return () => { document.body.style.overflow = ''; };
  }, [estOuvert]);

  if (!estOuvert) return null;

  return (
    <div className="nk-modal-overlay" onClick={gererFermer} role="presentation">
      <div
        ref={dialogRef}
        className={cn('nk-modal', TAILLE_CLASSES[taille], className)}
        role="dialog"
        aria-modal="true"
        aria-label={titre}
        tabIndex={-1}
        onClick={(e) => e.stopPropagation()}
      >
        {/* En-tête */}
        {(titre || fermable) && (
          <div className="nk-modal-entete">
            {titre && <h2 className="nk-modal-titre">{titre}</h2>}
            {fermable && (
              <button
                className="nk-modal-fermer"
                onClick={onFermer}
                aria-label="Fermer la modale"
                type="button"
              >
                ✕
              </button>
            )}
          </div>
        )}

        {/* Contenu */}
        <div className="nk-modal-contenu">{children}</div>

        {/* Pied de page */}
        {piedDePage && <div className="nk-modal-pied">{piedDePage}</div>}
      </div>
    </div>
  );
}

export default Modal;
