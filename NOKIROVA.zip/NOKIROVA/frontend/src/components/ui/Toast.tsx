'use client';

/**
 * NOKIROVA — Composant Toast
 *
 * Notifications toast empilées, auto-retrait,
 * 4 types (info/succes/avertissement/erreur),
 * animations d'entrée/sortie.
 */

'use client';

import React, { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { useUIStore, type ToastItem } from '@/stores/uiStore';

const TYPE_CLASSES: Record<ToastItem['type'], string> = {
  info: 'nk-toast-info',
  succes: 'nk-toast-succes',
  avertissement: 'nk-toast-avertissement',
  erreur: 'nk-toast-erreur',
};

const TYPE_ICONES: Record<ToastItem['type'], string> = {
  info: 'ℹ️',
  succes: '✅',
  avertissement: '⚠️',
  erreur: '❌',
};

function ToastUnique({ toast, onRetirer }: { toast: ToastItem; onRetirer: (id: string) => void }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Animation d'entrée
    requestAnimationFrame(() => setVisible(true));
  }, []);

  const fermer = () => {
    setVisible(false);
    setTimeout(() => onRetirer(toast.id), 300);
  };

  return (
    <div
      className={cn(
        'nk-toast',
        TYPE_CLASSES[toast.type],
        visible ? 'nk-toast-visible' : 'nk-toast-cache'
      )}
      role="alert"
    >
      <span className="nk-toast-icone">{TYPE_ICONES[toast.type]}</span>
      <div className="nk-toast-contenu">
        <p className="nk-toast-titre">{toast.titre}</p>
        {toast.message && <p className="nk-toast-message">{toast.message}</p>}
      </div>
      <button className="nk-toast-fermer" onClick={fermer} aria-label="Fermer">
        ✕
      </button>
    </div>
  );
}

export function ToastConteneur() {
  const { toasts, retirerToast } = useUIStore();

  if (toasts.length === 0) return null;

  return (
    <div className="nk-toast-conteneur" aria-live="polite">
      {toasts.map((t) => (
        <ToastUnique key={t.id} toast={t} onRetirer={retirerToast} />
      ))}
    </div>
  );
}

export default ToastConteneur;
