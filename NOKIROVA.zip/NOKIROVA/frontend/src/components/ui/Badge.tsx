'use client';

/**
 * NOKIROVA — Composant Badge
 *
 * Badge / pastille avec variante de couleur,
 * taille, icône, point d'indicateur.
 * Utilise nk-badge-*.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';

type VarianteBadge = 'primaire' | 'secondaire' | 'accent' | 'succes' | 'danger' | 'avertissement' | 'info' | 'neutre';
type TailleBadge = 'xs' | 'sm' | 'md' | 'lg';

type BadgeForme = 'pilule' | 'carre' | 'cercle' | 'point';

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variante?: VarianteBadge;
  taille?: TailleBadge;
  forme?: BadgeForme;
  iconeGauche?: React.ReactNode;
  iconeDroite?: React.ReactNode;
  supprimable?: boolean;
  onSupprimer?: () => void;
  clignotant?: boolean;
}

const VARIANTE_CLASSES: Record<VarianteBadge, string> = {
  primaire: 'nk-badge-primaire',
  secondaire: 'nk-badge-secondaire',
  accent: 'nk-badge-accent',
  succes: 'nk-badge-succes',
  danger: 'nk-badge-danger',
  avertissement: 'nk-badge-avertissement',
  info: 'nk-badge-info',
  neutre: 'nk-badge-neutre',
};

const TAILLE_CLASSES: Record<TailleBadge, string> = {
  xs: 'nk-badge-xs',
  sm: 'nk-badge-sm',
  md: 'nk-badge-md',
  lg: 'nk-badge-lg',
};

const FORME_CLASSES: Record<BadgeForme, string> = {
  pilule: 'nk-badge-pilule',
  carre: 'nk-badge-carre',
  cercle: 'nk-badge-cercle',
  point: 'nk-badge-point',
};

export function Badge({
  variante = 'primaire',
  taille = 'md',
  forme = 'pilule',
  iconeGauche,
  iconeDroite,
  supprimable = false,
  onSupprimer,
  clignotant = false,
  className,
  children,
  ...props
}: BadgeProps) {
  return (
    <span
      className={cn(
        'nk-badge',
        VARIANTE_CLASSES[variante],
        TAILLE_CLASSES[taille],
        FORME_CLASSES[forme],
        clignotant && 'nk-badge-clignotant',
        className
      )}
      {...props}
    >
      {iconeGauche && <span className="nk-badge-icone-gauche">{iconeGauche}</span>}
      <span className="nk-badge-texte">{children}</span>
      {iconeDroite && <span className="nk-badge-icone-droite">{iconeDroite}</span>}
      {supprimable && (
        <button
          className="nk-badge-supprimer"
          onClick={(e) => { e.stopPropagation(); onSupprimer?.(); }}
          aria-label="Supprimer"
          type="button"
        >
          ✕
        </button>
      )}
    </span>
  );
}

export default Badge;
