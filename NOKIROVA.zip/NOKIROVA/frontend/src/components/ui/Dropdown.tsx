'use client';

/**
 * NOKIROVA — Composant Dropdown
 *
 * Menu déroulant positionné sous un déclencheur,
 * avec items, séparateurs, icônes.
 */

'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';

interface ItemDropdown {
  id: string;
  label: string;
  icone?: React.ReactNode;
  raccourci?: string;
  desactive?: boolean;
  danger?: boolean;
  separator?: boolean;
  onClick?: () => void;
}

interface DropdownProps {
  declencheur: React.ReactNode;
  items: ItemDropdown[];
  alignement?: 'gauche' | 'droite' | 'centre';
  className?: string;
}

export function Dropdown({ declencheur, items, alignement = 'gauche', className }: DropdownProps) {
  const [ouvert, setOuvert] = useState(false);
  const conteneurRef = useRef<HTMLDivElement>(null);

  // Fermeture au clic extérieur
  useEffect(() => {
    if (!ouvert) return;
    const handler = (e: MouseEvent) => {
      if (conteneurRef.current && !conteneurRef.current.contains(e.target as Node)) {
        setOuvert(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [ouvert]);

  // Fermeture Escape
  useEffect(() => {
    if (!ouvert) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOuvert(false);
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [ouvert]);

  const gererClicItem = useCallback((item: ItemDropdown) => {
    if (item.desactive || item.separator) return;
    item.onClick?.();
    setOuvert(false);
  }, []);

  return (
    <div ref={conteneurRef} className={cn('nk-dropdown', className)}>
      <div className="nk-dropdown-declencheur" onClick={() => setOuvert(!ouvert)}>
        {declencheur}
      </div>
      {ouvert && (
        <div
          className={cn(
            'nk-dropdown-menu',
            alignement === 'gauche' && 'nk-dropdown-gauche',
            alignement === 'droite' && 'nk-dropdown-droite',
            alignement === 'centre' && 'nk-dropdown-centre'
          )}
          role="menu"
        >
          {items.map((item) =>
            item.separator ? (
              <div key={item.id} className="nk-dropdown-separateur" role="separator" />
            ) : (
              <button
                key={item.id}
                className={cn(
                  'nk-dropdown-item',
                  item.desactive && 'nk-dropdown-item-desactive',
                  item.danger && 'nk-dropdown-item-danger'
                )}
                role="menuitem"
                disabled={item.desactive}
                onClick={() => gererClicItem(item)}
              >
                {item.icone && <span className="nk-dropdown-item-icone">{item.icone}</span>}
                <span className="nk-dropdown-item-label">{item.label}</span>
                {item.raccourci && <span className="nk-dropdown-item-raccourci">{item.raccourci}</span>}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
}

export default Dropdown;
