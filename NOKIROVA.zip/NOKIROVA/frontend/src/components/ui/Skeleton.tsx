/**
 * NOKIROVA — Composant Skeleton
 *
 * Placeholder animé pendant le chargement.
 * Variante de forme, taille, animation.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';

type FormeSkeleton = 'texte' | 'cercle' | 'carre' | 'rectangle' | 'carte';

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  forme?: FormeSkeleton;
  lignes?: number;
  largeur?: string;
  hauteur?: string;
  anime?: boolean;
}

const FORME_CLASSES: Record<FormeSkeleton, string> = {
  texte: 'nk-skeleton-texte',
  cercle: 'nk-skeleton-cercle',
  carre: 'nk-skeleton-carre',
  rectangle: 'nk-skeleton-rectangle',
  carte: 'nk-skeleton-carte',
};

export function Skeleton({
  forme = 'rectangle',
  lignes = 1,
  largeur,
  hauteur,
  anime = true,
  className,
  ...props
}: SkeletonProps) {
  if (forme === 'texte' && lignes > 1) {
    return (
      <div className={cn('nk-skeleton-groupe', className)} {...props}>
        {Array.from({ length: lignes }, (_, i) => (
          <div
            key={i}
            className={cn(
              'nk-skeleton',
              FORME_CLASSES.texte,
              anime && 'nk-skeleton-anime',
              i === lignes - 1 && 'nk-skeleton-derniere-ligne'
            )}
            style={{ width: i === lignes - 1 ? '75%' : '100%' }}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={cn(
        'nk-skeleton',
        FORME_CLASSES[forme],
        anime && 'nk-skeleton-anime',
        className
      )}
      style={{
        width: largeur,
        height: hauteur,
      }}
      {...props}
    />
  );
}

/** Pré-configuré : skeleton d'une carte statistique */
export function SkeletonCarteStat() {
  return (
    <div className="nk-skeleton-carte-stat">
      <Skeleton forme="cercle" largeur="40px" hauteur="40px" />
      <div className="nk-skeleton-carte-stat-texte">
        <Skeleton forme="texte" largeur="60%" hauteur="12px" />
        <Skeleton forme="texte" largeur="40%" hauteur="20px" />
      </div>
    </div>
  );
}

/** Pré-configuré : skeleton d'une liste */
export function SkeletonListe({ count = 5 }: { count?: number }) {
  return (
    <div className="nk-skeleton-liste">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="nk-skeleton-liste-item">
          <Skeleton forme="cercle" largeur="36px" hauteur="36px" />
          <div className="nk-skeleton-liste-item-texte">
            <Skeleton forme="texte" largeur="80%" hauteur="14px" />
            <Skeleton forme="texte" largeur="50%" hauteur="12px" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default Skeleton;
