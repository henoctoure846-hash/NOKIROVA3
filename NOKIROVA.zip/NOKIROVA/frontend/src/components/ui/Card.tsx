/**
 * NOKIROVA — Composant Carte
 *
 * Carte réutilisable avec en-tête, contenu,
 * pied, variante de style.
 * Utilise nk-carte + variantes.
 */

'use client';

import React from 'react';
import { cn } from '@/lib/utils';

type VarianteCarte = 'defaut' | 'elevee' | 'aplatie' | 'interactive' | 'glassmorphism';

type BordureCarte = 'aucune' | 'subtile' | 'moyenne' | 'forte';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variante?: VarianteCarte;
  bordure?: BordureCarte;
  surbrillance?: boolean;
  compacte?: boolean;
}

interface CardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  icone?: React.ReactNode;
  action?: React.ReactNode;
}

interface CardFooterProps extends React.HTMLAttributes<HTMLDivElement> {
  alignement?: 'gauche' | 'centre' | 'droite' | 'espace';
}

const VARIANTE_CLASSES: Record<VarianteCarte, string> = {
  defaut: 'nk-carte',
  elevee: 'nk-carte nk-carte-elevee',
  aplatie: 'nk-carte nk-carte-aplatie',
  interactive: 'nk-carte nk-carte-interactive',
  glassmorphism: 'nk-carte nk-carte-glassmorphism',
};

const BORDURE_CLASSES: Record<BordureCarte, string> = {
  aucune: '',
  subtile: 'nk-carte-bordure-subtile',
  moyenne: 'nk-carte-bordure-moyenne',
  forte: 'nk-carte-bordure-forte',
};

export function Card({
  variante = 'defaut',
  bordure = 'aucune',
  surbrillance = false,
  compacte = false,
  className,
  children,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        VARIANTE_CLASSES[variante],
        BORDURE_CLASSES[bordure],
        surbrillance && 'nk-carte-surbrillance',
        compacte && 'nk-carte-compacte',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ icone, action, className, children, ...props }: CardHeaderProps) {
  return (
    <div className={cn('nk-carte-entete', className)} {...props}>
      {icone && <span className="nk-carte-icone">{icone}</span>}
      <div className="nk-carte-titre">{children}</div>
      {action && <div className="nk-carte-action">{action}</div>}
    </div>
  );
}

export function CardContent({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('nk-carte-contenu', className)} {...props}>
      {children}
    </div>
  );
}

export function CardFooter({ alignement = 'droite', className, children, ...props }: CardFooterProps) {
  return (
    <div
      className={cn(
        'nk-carte-pied',
        alignement === 'gauche' && 'nk-carte-pied-gauche',
        alignement === 'centre' && 'nk-carte-pied-centre',
        alignement === 'droite' && 'nk-carte-pied-droite',
        alignement === 'espace' && 'nk-carte-pied-espace',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export default Card;
