/**
 * NOKIROVA — Composant Avatar
 *
 * Avatar utilisateur avec initiales,
 * image, tailles, indicateur en ligne.
 */

'use client';

import React from 'react';
import { cn, genererInitiales } from '@/lib/utils';

type TailleAvatar = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
type EtatAvatar = 'en_ligne' | 'absent' | 'occupe' | 'hors_ligne';

interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  src?: string | null;
  alt?: string;
  prenom?: string;
  nom?: string;
  taille?: TailleAvatar;
  etat?: EtatAvatar;
  forme?: 'cercle' | 'carre' | 'arrondi';
}

const TAILLE_CLASSES: Record<TailleAvatar, string> = {
  xs: 'nk-avatar-xs',
  sm: 'nk-avatar-sm',
  md: 'nk-avatar-md',
  lg: 'nk-avatar-lg',
  xl: 'nk-avatar-xl',
  '2xl': 'nk-avatar-2xl',
};

const ETAT_CLASSES: Record<EtatAvatar, string> = {
  en_ligne: 'nk-avatar-en-ligne',
  absent: 'nk-avatar-absent',
  occupe: 'nk-avatar-occupe',
  hors_ligne: 'nk-avatar-hors-ligne',
};

const FORME_CLASSES: Record<string, string> = {
  cercle: 'nk-avatar-cercle',
  carre: 'nk-avatar-carre',
  arrondi: 'nk-avatar-arrondi',
};

export function Avatar({
  src,
  alt,
  prenom = '',
  nom = '',
  taille = 'md',
  etat,
  forme = 'cercle',
  className,
  ...props
}: AvatarProps) {
  const initiales = genererInitiales(prenom, nom);

  return (
    <div
      className={cn(
        'nk-avatar',
        TAILLE_CLASSES[taille],
        FORME_CLASSES[forme],
        etat && ETAT_CLASSES[etat],
        className
      )}
      {...props}
    >
      {src ? (
        <img
          src={src}
          alt={alt || `Avatar de ${prenom} ${nom}`}
          className="nk-avatar-image"
          onError={(e) => {
            // Fallback vers initiales si l'image échoue
            (e.target as HTMLImageElement).style.display = 'none';
          }}
        />
      ) : (
        <span className="nk-avatar-initiales" aria-label={`${prenom} ${nom}`}>
          {initiales}
        </span>
      )}
      {etat && <span className="nk-avatar-indicateur" aria-label={etat.replace('_', ' ')} />}
    </div>
  );
}

export default Avatar;
