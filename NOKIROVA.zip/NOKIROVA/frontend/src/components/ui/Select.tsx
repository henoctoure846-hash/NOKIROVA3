/**
 * NOKIROVA — Composant Select
 *
 * Liste déroulante avec label, erreur,
 * recherche, variante.
 */

'use client';

import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';

interface OptionSelect {
  valeur: string;
  label: string;
  desactive?: boolean;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  erreur?: string;
  indice?: string;
  options: OptionSelect[];
  variante?: 'defaut' | 'rempli';
  pleinLargeur?: boolean;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, erreur, indice, options, variante = 'defaut', pleinLargeur = true, className, id, ...props }, ref) => {
    const selectId = id || `nk-select-${label?.replace(/\s+/g, '-').toLowerCase()}`;

    return (
      <div className={cn('nk-select-groupe', pleinLargeur && 'nk-select-plein', className)}>
        {label && <label htmlFor={selectId} className="nk-select-label">{label}</label>}
        <select
          ref={ref}
          id={selectId}
          className={cn('nk-select', variante === 'rempli' && 'nk-select-rempli', erreur && 'nk-select-erreur')}
          aria-invalid={!!erreur}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.valeur} value={opt.valeur} disabled={opt.desactive}>
              {opt.label}
            </option>
          ))}
        </select>
        {erreur && <p className="nk-select-erreur-texte" role="alert">{erreur}</p>}
        {indice && !erreur && <p className="nk-select-indice-texte">{indice}</p>}
      </div>
    );
  }
);

Select.displayName = 'Select';

export default Select;
