'use client';

/**
 * NOKIROVA — En-tête principal
 *
 * Barre supérieure avec recherche, notifications,
 * profil, et bascule thème.
 *
 * Accessibilité :
 * - aria-labels sur tous les boutons iconiques
 * - role="banner" implicite sur <header>
 * - aria-expanded sur le menu profil
 * - aria-live sur le badge notifications
 * - focus-visible rings
 * - Escape ferme le menu profil
 */

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Bell, Sun, Moon, Menu, X,
  ChevronDown, User, Settings, LogOut,
  Sparkles, MessageCircle,
} from 'lucide-react';

export default function EnTete() {
  const routeur = useRouter();
  const [recherche, setRecherche] = useState('');
  const [rechercheOuverte, setRechercheOuverte] = useState(false);
  const [themeSombre, setThemeSombre] = useState(false);
  const [notifications, setNotifications] = useState(3);
  const [menuProfil, setMenuProfil] = useState(false);
  const refMenu = useRef<HTMLDivElement>(null);

  // Fermer le menu au clic extérieur ou Escape
  useEffect(() => {
    function handleClickExterieur(e: MouseEvent) {
      if (refMenu.current && !refMenu.current.contains(e.target as Node)) {
        setMenuProfil(false);
      }
    }
    function handleEscape(e: KeyboardEvent) {
      if (e.key === 'Escape' && menuProfil) {
        setMenuProfil(false);
      }
    }
    document.addEventListener('mousedown', handleClickExterieur);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickExterieur);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [menuProfil]);

  const basculerTheme = () => {
    setThemeSombre(!themeSombre);
    document.documentElement.classList.toggle('dark');
  };

  const gererRecherche = (e: React.FormEvent) => {
    e.preventDefault();
    if (recherche.trim()) {
      routeur.push(`/apprendre?q=${encodeURIComponent(recherche.trim())}`);
      setRechercheOuverte(false);
    }
  };

  return (
    <header
      className="fixed top-0 left-[280px] right-0 h-16 bg-white/80 dark:bg-nk-neutre-900/80
        backdrop-blur-md border-b border-nk-neutre-100 dark:border-nk-neutre-800 z-30
        flex items-center justify-between px-6"
      role="banner"
    >
      {/* Zone gauche — Recherche */}
      <div className="flex items-center gap-4 flex-1 max-w-xl">
        {/* Bouton recherche mobile */}
        <button
          onClick={() => setRechercheOuverte(!rechercheOuverte)}
          className="lg:hidden p-2 rounded-lg text-nk-neutre-500 hover:bg-nk-neutre-50
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
          aria-label={rechercheOuverte ? 'Fermer la recherche' : 'Ouvrir la recherche'}
          aria-expanded={rechercheOuverte}
        >
          {rechercheOuverte ? <X className="h-5 w-5" aria-hidden="true" /> : <Search className="h-5 w-5" aria-hidden="true" />}
        </button>

        {/* Barre de recherche */}
        <form onSubmit={gererRecherche} className="hidden lg:flex items-center flex-1 relative" role="search" aria-label="Rechercher dans NOKIROVA">
          <Search className="absolute left-3 h-4 w-4 text-nk-neutre-400" aria-hidden="true" />
          <input
            type="search"
            value={recherche}
            onChange={(e) => setRecherche(e.target.value)}
            placeholder="Rechercher cours, fiches, sujets..."
            aria-label="Rechercher cours, fiches, sujets"
            className="w-full pl-10 pr-4 py-2 bg-nk-neutre-50 dark:bg-nk-neutre-800 rounded-xl
              text-sm text-nk-neutre-700 dark:text-nk-neutre-200 border border-nk-neutre-200
              dark:border-nk-neutre-700 focus:outline-none focus:border-nk-primaire-400
              focus:ring-2 focus:ring-nk-primaire-100 transition-all placeholder:text-nk-neutre-400"
          />
          <kbd
            className="absolute right-3 px-1.5 py-0.5 text-[10px] text-nk-neutre-400 bg-nk-neutre-100
              dark:bg-nk-neutre-700 rounded border border-nk-neutre-200 dark:border-nk-neutre-600"
            aria-hidden="true"
          >
            ⌘K
          </kbd>
        </form>
      </div>

      {/* Zone droite — Actions */}
      <div className="flex items-center gap-2">
        {/* Bouton IA rapide */}
        <button
          onClick={() => routeur.push('/ia-studio')}
          className="p-2 rounded-xl text-violet-500 hover:bg-violet-50 dark:hover:bg-violet-950 transition-colors
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
          aria-label="Ouvrir IA Studio"
        >
          <Sparkles className="h-5 w-5" aria-hidden="true" />
        </button>

        {/* Bascule thème */}
        <button
          onClick={basculerTheme}
          className="p-2 rounded-xl text-nk-neutre-500 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800 transition-colors
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
          aria-label={themeSombre ? 'Activer le mode clair' : 'Activer le mode sombre'}
        >
          {themeSombre ? <Sun className="h-5 w-5" aria-hidden="true" /> : <Moon className="h-5 w-5" aria-hidden="true" />}
        </button>

        {/* Notifications */}
        <button
          className="p-2 rounded-xl text-nk-neutre-500 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800 transition-colors relative
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
          aria-label={`Notifications${notifications > 0 ? ` — ${notifications} non lues` : ''}`}
        >
          <Bell className="h-5 w-5" aria-hidden="true" />
          {notifications > 0 && (
            <span
              className="absolute top-1 right-1 w-4 h-4 bg-nk-danger-500 text-white
                text-[10px] font-bold rounded-full flex items-center justify-center"
              aria-live="polite"
              aria-label={`${notifications} notifications non lues`}
            >
              {notifications}
            </span>
          )}
        </button>

        {/* Messages */}
        <button
          onClick={() => routeur.push('/communaute')}
          className="p-2 rounded-xl text-nk-neutre-500 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800 transition-colors
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
          aria-label="Messages de la communauté"
        >
          <MessageCircle className="h-5 w-5" aria-hidden="true" />
        </button>

        {/* Profil */}
        <div ref={refMenu} className="relative">
          <button
            onClick={() => setMenuProfil(!menuProfil)}
            className="flex items-center gap-2 pl-2 pr-1 py-1.5 rounded-xl hover:bg-nk-neutre-50
              dark:hover:bg-nk-neutre-800 transition-colors
              focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
            aria-label="Menu du profil"
            aria-expanded={menuProfil}
            aria-haspopup="true"
          >
            <div className="w-7 h-7 rounded-full bg-nk-primaire-100 flex items-center justify-center text-sm" aria-hidden="true">
              👩‍🎓
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-nk-neutre-400" aria-hidden="true" />
          </button>

          <AnimatePresence>
            {menuProfil && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-nk-neutre-800
                  rounded-xl shadow-lg border border-nk-neutre-100 dark:border-nk-neutre-700
                  overflow-hidden z-50"
                role="menu"
                aria-label="Menu profil"
              >
                <div className="p-3 border-b border-nk-neutre-100 dark:border-nk-neutre-700">
                  <p className="text-sm font-medium text-nk-neutre-800 dark:text-white">Marie Lambert</p>
                  <p className="text-xs text-nk-neutre-400">marie.lambert@exemple.fr</p>
                </div>
                <div className="p-1">
                  {[
                    { icone: <User className="h-4 w-4" aria-hidden="true" />, label: 'Mon profil', action: () => routeur.push('/parametres') },
                    { icone: <Settings className="h-4 w-4" aria-hidden="true" />, label: 'Paramètres', action: () => routeur.push('/parametres') },
                  ].map((item) => (
                    <button
                      key={item.label}
                      onClick={() => { item.action(); setMenuProfil(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-nk-neutre-600
                        dark:text-nk-neutre-300 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-700 rounded-lg
                        focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
                      role="menuitem"
                    >
                      {item.icone} {item.label}
                    </button>
                  ))}
                </div>
                <div className="p-1 border-t border-nk-neutre-100 dark:border-nk-neutre-700">
                  <button
                    className="w-full flex items-center gap-3 px-3 py-2 text-sm text-nk-danger-600
                      hover:bg-nk-danger-50 rounded-lg
                      focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-danger-500 focus-visible:ring-offset-1"
                    role="menuitem"
                    aria-label="Se déconnecter"
                  >
                    <LogOut className="h-4 w-4" aria-hidden="true" /> Déconnexion
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Barre de recherche mobile (overlay) */}
      <AnimatePresence>
        {rechercheOuverte && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-16 left-4 right-4 bg-white dark:bg-nk-neutre-800
              rounded-xl shadow-lg border border-nk-neutre-100 dark:border-nk-neutre-700 p-4 z-50 lg:hidden"
            role="search"
            aria-label="Recherche mobile"
          >
            <form onSubmit={gererRecherche} className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-nk-neutre-400" aria-hidden="true" />
              <input
                type="search"
                value={recherche}
                onChange={(e) => setRecherche(e.target.value)}
                placeholder="Rechercher..."
                autoFocus
                aria-label="Rechercher dans NOKIROVA"
                className="w-full pl-10 pr-4 py-2 bg-nk-neutre-50 dark:bg-nk-neutre-700
                  rounded-lg text-sm border border-nk-neutre-200 dark:border-nk-neutre-600
                  focus:outline-none focus:border-nk-primaire-400"
              />
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
