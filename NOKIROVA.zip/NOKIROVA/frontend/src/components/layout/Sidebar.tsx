'use client';

/**
 * NOKIROVA — Barre latérale de navigation
 *
 * 280px étendue / 72px réduite.
 * 9 espaces + logo + profil.
 *
 * Accessibilité :
 * - aria-label sur aside et nav
 * - aria-current="page" sur l'élément actif
 * - aria-label sur le bouton réduire/étendre
 * - role="img" + aria-label sur l'icône logo
 * - focus-visible visible sur tous les liens et boutons
 */

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home, BookOpen, RefreshCw, PenTool, Bot, Users,
  TrendingUp, Settings, ChevronLeft, ChevronRight,
  LogOut, Sparkles, Activity,
} from 'lucide-react';

const espaces = [
  { id: 'accueil', chemin: '/', label: 'Accueil', icone: Home, couleur: 'text-nk-primaire-600' },
  { id: 'apprendre', chemin: '/apprendre', label: 'Apprendre', icone: BookOpen, couleur: 'text-nk-accent-600' },
  { id: 'reviser', chemin: '/reviser', label: 'Réviser', icone: RefreshCw, couleur: 'text-nk-avertissement-600' },
  { id: 'produire', chemin: '/produire', label: 'Produire', icone: PenTool, couleur: 'text-nk-info-600' },
  { id: 'ia-studio', chemin: '/ia-studio', label: 'IA Studio', icone: Bot, couleur: 'text-violet-600' },
  { id: 'communaute', chemin: '/communaute', label: 'Communauté', icone: Users, couleur: 'text-emerald-600' },
  { id: 'progression', chemin: '/progression', label: 'Progression', icone: TrendingUp, couleur: 'text-nk-succes-600' },
  { id: 'parametres', chemin: '/parametres', label: 'Paramètres', icone: Settings, couleur: 'text-nk-neutre-500' },
  { id: 'mission-control', chemin: '/mission-control', label: 'Mission Control', icone: Activity, couleur: 'text-nk-primaire-600' },
];

interface BarreLateraleProps {
        reduit?: boolean;
        onBasculer?: () => void;
}

export default function BarreLaterale({ reduit: reduitProp, onBasculer }: BarreLateraleProps) {
  const [reduitInterne, setReduitInterne] = useState(false);
  const reduit = reduitProp ?? reduitInterne;
  const basculer = onBasculer ?? (() => setReduitInterne(!reduitInterne));
  const pathname = usePathname();

  return (
    <aside
      role="navigation"
      aria-label="Navigation principale"
      className={`fixed top-0 left-0 h-full bg-white dark:bg-nk-neutre-900 border-r border-nk-neutre-200
        dark:border-nk-neutre-700 z-40 transition-all duration-300 flex flex-col ${
        reduit ? 'w-[72px]' : 'w-[280px]'
      }`}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-nk-neutre-100 dark:border-nk-neutre-800">
        <Link
          href="/"
          className="flex items-center gap-3 overflow-hidden focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-2 rounded-lg"
          aria-label="Accueil NOKIROVA"
        >
          <div
            className="w-9 h-9 rounded-lg bg-gradient-to-br from-nk-primaire-500 to-nk-accent-500 flex items-center justify-center flex-shrink-0"
            role="img"
            aria-label="Logo NOKIROVA"
          >
            <Sparkles className="h-5 w-5 text-white" aria-hidden="true" />
          </div>
          <AnimatePresence>
            {!reduit && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                className="font-titre font-bold text-lg text-nk-neutre-900 dark:text-white whitespace-nowrap"
              >
                NOKIROVA
              </motion.span>
            )}
          </AnimatePresence>
        </Link>
      </div>

      {/* Navigation */}
      <nav aria-label="Espaces NOKIROVA" className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {espaces.map((espace) => {
          const actif = pathname === espace.chemin ||
            (espace.chemin !== '/' && pathname.startsWith(espace.chemin));
          const Icone = espace.icone;

          return (
            <Link
              key={espace.id}
              href={espace.chemin}
              aria-current={actif ? 'page' : undefined}
              aria-label={`${espace.label}${actif ? ' (page active)' : ''}`}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group relative
                focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1 ${
                actif
                  ? 'bg-nk-primaire-50 dark:bg-nk-primaire-950 text-nk-primaire-700 dark:text-nk-primaire-300'
                  : 'text-nk-neutre-600 dark:text-nk-neutre-400 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800'
              }`}
            >
              {/* Indicateur actif */}
              {actif && (
                <motion.div
                  layoutId="sidebar-actif"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-nk-primaire-600 rounded-r-full"
                  aria-hidden="true"
                />
              )}
              <Icone className={`h-5 w-5 flex-shrink-0 ${actif ? espace.couleur : ''}`} aria-hidden="true" />
              <AnimatePresence>
                {!reduit && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-sm font-medium whitespace-nowrap"
                  >
                    {espace.label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {/* Bas de la barre */}
      <div className="p-2 border-t border-nk-neutre-100 dark:border-nk-neutre-800">
        {/* Bouton réduire/étendre */}
        <button
          onClick={basculer}
          aria-label={reduit ? 'Étendre la barre latérale' : 'Réduire la barre latérale'}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-nk-neutre-500 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800 transition-colors
            focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
        >
          {reduit ? (
            <ChevronRight className="h-5 w-5 flex-shrink-0" aria-hidden="true" />
          ) : (
            <>
              <ChevronLeft className="h-5 w-5 flex-shrink-0" aria-hidden="true" />
              <span className="text-sm">Réduire</span>
            </>
          )}
        </button>

        {/* Profil */}
        <div className="flex items-center gap-3 px-3 py-2.5 mt-1" role="status" aria-label="Profil utilisateur">
          <div
            className="w-8 h-8 rounded-full bg-nk-primaire-100 flex items-center justify-center flex-shrink-0 text-sm"
            aria-hidden="true"
          >
            👩‍🎓
          </div>
          <AnimatePresence>
            {!reduit && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="overflow-hidden"
              >
                <p className="text-sm font-medium text-nk-neutre-800 dark:text-white truncate">
                  Marie L.
                </p>
                <p className="text-xs text-nk-neutre-400 truncate">Niveau 3</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </aside>
  );
}
