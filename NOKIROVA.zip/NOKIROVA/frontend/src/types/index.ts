/**
 * NOKIROVA — Types TypeScript
 *
 * Types partagés alignés sur les modèles backend.
 * Toutes les interfaces correspondent aux entités
 * SQLAlchemy et DTOs Pydantic.
 */

// ─── Utilisateurs ─────────────────────────────────────────────────────────────

export interface Utilisateur {
  id: string;
  email: string;
  prenom: string;
  nom: string;
  role: 'etudiant' | 'enseignant' | 'admin' | 'institution';
  plan: 'gratuit' | 'etudiant' | 'premium' | 'institution';
  niveau: number;
  xp: number;
  streak_jours: number;
  avatar_url: string | null;
  etablissement: string | null;
  bio: string | null;
  date_inscription: string;
  dernier_acces: string;
  est_actif: boolean;
  est_verifie: boolean;
  preferences: PreferencesUtilisateur;
}

export interface PreferencesUtilisateur {
  theme: 'clair' | 'sombre' | 'systeme';
  langue: 'fr' | 'en' | 'es';
  notifications_email: boolean;
  notifications_push: boolean;
  notifications_sms: boolean;
  periode_tranquilite_debut: string | null;
  periode_tranquilite_fin: string | null;
  rappels_revision: boolean;
  rapport_hebdo: boolean;
}

// ─── Cours ─────────────────────────────────────────────────────────────────────

export interface Cours {
  id: string;
  titre: string;
  description: string;
  matiere: Matiere;
  niveau: number;
  chapitre: string;
  difficulte: 'debutant' | 'intermediaire' | 'avance' | 'expert';
  duree_estimee_min: number;
  image_url: string | null;
  cree_par: string;
  cree_le: string;
  modifie_le: string;
  est_publie: boolean;
  tags: string[];
  progression: number; // 0-100
  nb_chapitres: number;
  nb_chapitres_completes: number;
}

export type Matiere =
  | 'mathematiques' | 'francais' | 'physique' | 'chimie'
  | 'histoire' | 'geographie' | 'philosophie' | 'anglais'
  | 'svt' | 'ses' | 'informatique' | 'economie';

export interface Chapitre {
  id: string;
  cours_id: string;
  titre: string;
  ordre: number;
  contenu: string;
  resume_ia: string | null;
  duree_estimee_min: number;
  est_complete: boolean;
}

// ─── Flashcards ────────────────────────────────────────────────────────────────

export interface Flashcard {
  id: string;
  cours_id: string;
  recto: string;
  verso: string;
  explication: string | null;
  matiere: Matiere;
  difficulte: 'facile' | 'moyen' | 'difficile';
  intervalle_jours: number;
  prochaine_revision: string;
  nb_revisions: number;
  derniere_note: 0 | 1 | 2 | 3 | 4 | 5;
  cree_le: string;
}

// ─── Quiz ──────────────────────────────────────────────────────────────────────

export interface Quiz {
  id: string;
  titre: string;
  cours_id: string;
  matiere: Matiere;
  type: 'entrainement' | 'examen_blanc' | 'evaluation' | 'adaptatif';
  difficulte: 'facile' | 'moyen' | 'difficile' | 'mixte';
  nb_questions: number;
  duree_min: number | null;
  score: number | null;
  score_max: number;
  est_complete: boolean;
  cree_le: string;
}

export interface QuestionQuiz {
  id: string;
  quiz_id: string;
  type: 'choix_unique' | 'choix_multiple' | 'vrai_faux' | 'texte_libre' | 'association';
  enonce: string;
  choix: ChoixQuestion[];
  reponse_correcte: string | string[];
  explication: string;
  difficulte: 'facile' | 'moyen' | 'difficile';
  points: number;
}

export interface ChoixQuestion {
  id: string;
  texte: string;
  est_correct: boolean;
}

// ─── Révision ──────────────────────────────────────────────────────────────────

export interface SessionRevision {
  id: string;
  utilisateur_id: string;
  type: 'flashcards' | 'quiz' | 'examen_blanc' | 'mixte';
  matiere: Matiere | null;
  carte_ids: string[];
  nb_cartes_total: number;
  nb_cartes_revisees: number;
  score: number | null;
  debut: string;
  fin: string | null;
  duree_min: number;
  est_complete: boolean;
}

export interface RappelRevision {
  id: string;
  flashcard_id: string;
  date_prevue: string;
  statut: 'prevu' | 'fait' | 'en_retard' | 'reporte';
  note: 0 | 1 | 2 | 3 | 4 | 5;
}

// ─── Documents ────────────────────────────────────────────────────────────────

export interface Document {
  id: string;
  titre: string;
  type: 'fiche' | 'note' | 'resume' | 'essai' | 'dissertation' | 'notes' | 'carte_mentale' | 'autre';
  contenu: string;
  matiere: Matiere | null;
  cours_id: string | null;
  genere_par_ia: boolean;
  version: number;
  mot_cles: string[];
  cree_le: string;
  modifie_le: string;
  taille_octets: number;
  est_archive: boolean;
  est_partage: boolean;
}

// ─── IA Studio ─────────────────────────────────────────────────────────────────

export type AgentIA =
  | 'tuteur' | 'correcteur' | 'generateur_flashcards'
  | 'generateur_quiz' | 'assistant_cours' | 'analyseur_progression';

export type FournisseurIA = 'openai' | 'anthropic' | 'google' | 'mistral' | 'huggingface' | 'cohere' | 'local';

export interface AgentIADetail {
  id: string;
  nom: string;
  description: string;
  specialite: string;
  modele_ia: string;
  temperature: number;
  system_prompt: string;
  est_actif: boolean;
  nb_conversations: number;
  note_moyenne: number;
}


export interface SessionIA {
  id: string;
  agent: AgentIA;
  agent_id?: string;
  fournisseur: FournisseurIA;
  modele: string;
  contexte: Record<string, unknown>;
  messages: MessageIA[];
  statut: 'active' | 'terminee' | 'erreur';
  tokens_utilises: number;
  cout_estime: number;
  debut: string;
  fin: string | null;
}

export interface MessageIA {
  id: string;
  role: 'utilisateur' | 'assistant' | 'systeme' | 'user';
  contenu: string;
  horodatage: string;
  tokens: number;
  modele?: string;
  duree_ms?: number;
  session_id?: string;
  agent_id?: string;
  tokens_utilises?: number;
}

export interface QuotaIA {
  plan: 'gratuit' | 'etudiant' | 'premium' | 'institution';
  tokens_max_jour: number;
  tokens_utilises_jour: number;
  requetes_max_jour: number;
  requetes_utilisees_jour: number;
  date_reinitialisation: string;
  /** Alias utilisés par le frontend */
  tokens_utilises: number;
  tokens_limite: number;
  requetes_utilises: number;
  requetes_limite: number;
}

// ─── Communauté ────────────────────────────────────────────────────────────────

export interface PublicationForum {
  id: string;
  auteur_id: string;
  auteur_nom: string;
  auteur_avatar: string | null;
  titre: string;
  contenu: string;
  categorie: 'question' | 'discussion' | 'partage' | 'astuce' | 'annonce';
  matiere: Matiere | null;
  nb_likes: number;
  nb_commentaires: number;
  nb_vues: number;
  est_epingle: boolean;
  est_resolu: boolean;
  cree_le: string;
  modifie_le: string;
}

export interface GroupeEtude {
  id: string;
  nom: string;
  description: string;
  matiere: Matiere;
  nb_membres: number;
  max_membres: number;
  est_prive: boolean;
  cree_par: string;
  cree_le: string;
}

// ─── Gamification ──────────────────────────────────────────────────────────────

export interface Badge {
  id: string;
  code: string;
  nom: string;
  description: string;
  categorie: 'apprentissage' | 'revision' | 'communaute' | 'production' | 'ia' | 'streak' | 'special';
  icone: string;
  rarete: 'commun' | 'rare' | 'epique' | 'legendaire';
  xp_recompense: number;
  conditions: Record<string, number | string>;
  est_debloque: boolean;
  debloque_le: string | null;
}

export interface Succes {
  id: string;
  code: string;
  nom: string;
  description: string;
  progression_actuelle: number;
  objectif: number;
  est_complete: boolean;
  recompense_xp: number;
}

export interface ClassementEntree {
  rang: number;
  utilisateur_id: string;
  pseudo: string;
  avatar_url: string | null;
  niveau: number;
  xp: number;
  streak: number;
  badges_count: number;
}

// ─── Progression ──────────────────────────────────────────────────────────────

export interface StatistiquesProgression {
  xp_total: number;
  niveau_actuel: number;
  xp_niveau_actuel: number;
  xp_prochain_niveau: number;
  streak_jours: number;
  streak_max: number;
  temps_total_min: number;
  cours_completes: number;
  cours_en_cours: number;
  flashcards_revisees: number;
  quizzes_completes: number;
  score_moyen: number;
  documents_crees: number;
  badges_debloques: number;
  jours_actifs_mois: number;
}

export interface Objectif {
  id: string;
  titre: string;
  type: 'quotidien' | 'hebdomadaire' | 'mensuel' | 'personnalise';
  cible: number;
  actuel: number;
  unite: string;
  est_atteint: boolean;
  date_limite: string;
  xp_recompense: number;
}

// ─── Notifications ─────────────────────────────────────────────────────────────

export type CanalNotification = 'push' | 'email' | 'in_app' | 'websocket' | 'sms';

export interface Notification {
  id: string;
  type: 'info' | 'succes' | 'avertissement' | 'erreur' | 'rappel' | 'social';
  titre: string;
  message: string;
  canal: CanalNotification;
  lien: string | null;
  image_url: string | null;
  est_lue: boolean;
  cree_le: string;
  lu_le: string | null;
}

// ─── Recherche ────────────────────────────────────────────────────────────────

export interface ResultatRecherche {
  id: string;
  type: 'cours' | 'flashcard' | 'quiz' | 'document' | 'publication' | 'utilisateur';
  titre: string;
  description: string;
  matiere: Matiere | null;
  score_pertinence: number;
  url: string;
  surbrillance: string;
}

export interface ReponseRecherche {
  resultats: ResultatRecherche[];
  total: number;
  page: number;
  par_page: number;
  facettes: Record<string, Record<string, number>>;
  suggestions: string[];
  temps_ms: number;
}


// ─── Réponse paginée ──────────────────────────────────────────────────────────

export interface ReponsePaginee<T> {
  items: T[];
  total: number;
  page: number;
  par_page: number;
  total_pages: number;
}

// ─── Réponse API unifiée ──────────────────────────────────────────────────────

export interface ReponseAPIUnifiee<T> {
  success: boolean;
  message: string;
  data: T;
  errors?: Array<{ champ: string; message: string }>;
  metadata?: {
    total?: number;
    page?: number;
    par_page?: number;
    total_pages?: number;
  };
}

// ─── Pagination ────────────────────────────────────────────────────────────────

export interface ParamsPagination {
  page?: number;
  par_page?: number;
  tri?: string;
  ordre?: 'asc' | 'desc';
}
