'use client';

/**
 * NOKIROVA — Espace Produire
 *
 * Création de documents, fiches de révision, résumés,
 * dissertations, notes structurées et cartes mentales.
 * Intégré au store documents (filtres, CRUD, IA).
 */
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText, Search, Plus, Filter,
  File, FileEdit, FileCheck, Brain,
  Sparkles, MoreHorizontal, Trash2, Archive, Share2, Eye,
} from 'lucide-react';
import { useDocumentStore } from '@/stores/documentStore';
import type { Document, Matiere } from '@/types';

// ─── Données de démonstration ─────────────────────────────────────────────────

const DOCUMENTS_DEMO: Document[] = [
  {
    id: '1',
    titre: 'Fiche Révision — Théorème de Pythagore',
    type: 'fiche',
    contenu: 'Le théorème de Pythagore établit que dans un triangle rectangle...',
    matiere: 'mathematiques',
    cours_id: '1',
    genere_par_ia: true,
    version: 2,
    mot_cles: ['pythagore', 'triangle', 'geometrie'],
    cree_le: '2025-01-20T10:00:00Z',
    modifie_le: '2025-02-01T14:00:00Z',
    taille_octets: 4200,
    est_archive: false,
    est_partage: true,
  },
  {
    id: '2',
    titre: "Dissertation — L'illusion théâtrale chez Molière",
    type: 'dissertation',
    contenu: 'Introduction : Le théâtre de Molière met en scène...',
    matiere: 'francais',
    cours_id: '3',
    genere_par_ia: false,
    version: 1,
    mot_cles: ['moliere', 'theatre', 'dissertation'],
    cree_le: '2025-01-25T09:00:00Z',
    modifie_le: '2025-01-26T11:00:00Z',
    taille_octets: 12800,
    est_archive: false,
    est_partage: false,
  },
  {
    id: '3',
    titre: 'Résumé — La Révolution Industrielle',
    type: 'resume',
    contenu: 'La Révolution industrielle (XVIIIe-XIXe) a transformé...',
    matiere: 'histoire',
    cours_id: '4',
    genere_par_ia: true,
    version: 3,
    mot_cles: ['revolution', 'industrie', 'xixe'],
    cree_le: '2025-02-01T08:00:00Z',
    modifie_le: '2025-02-10T15:00:00Z',
    taille_octets: 6500,
    est_archive: false,
    est_partage: true,
  },
  {
    id: '4',
    titre: 'Notes de cours — Chimie Organique',
    type: 'notes',
    contenu: 'Les hydrocarbures sont composés uniquement de carbone...',
    matiere: 'chimie',
    cours_id: '6',
    genere_par_ia: false,
    version: 1,
    mot_cles: ['chimie', 'organique', 'hydrocarbures'],
    cree_le: '2025-02-05T10:00:00Z',
    modifie_le: '2025-02-05T10:00:00Z',
    taille_octets: 3100,
    est_archive: false,
    est_partage: false,
  },
  {
    id: '5',
    titre: 'Carte mentale — Physique Quantique',
    type: 'carte_mentale',
    contenu: 'Concepts clés : dualité onde-corpuscule, principe d\'incertitude...',
    matiere: 'physique',
    cours_id: '2',
    genere_par_ia: true,
    version: 1,
    mot_cles: ['quantique', 'physique', 'onde'],
    cree_le: '2025-02-08T14:00:00Z',
    modifie_le: '2025-02-08T14:00:00Z',
    taille_octets: 2800,
    est_archive: true,
    est_partage: false,
  },
];

const TYPE_LABELS: Record<Document['type'], string> = {
  fiche: 'Fiche de révision',
  note: 'Note',
  resume: 'Résumé',
  essai: 'Essai',
  dissertation: 'Dissertation',
  notes: 'Notes de cours',
  carte_mentale: 'Carte mentale',
  autre: 'Autre',
};

const TYPE_ICONES: Record<Document['type'], React.ReactNode> = {
  fiche: <FileCheck className="h-5 w-5" />,
  note: <File className="h-5 w-5" />,
  resume: <FileText className="h-5 w-5" />,
  essai: <FileEdit className="h-5 w-5" />,
  dissertation: <FileEdit className="h-5 w-5" />,
  notes: <File className="h-5 w-5" />,
  carte_mentale: <Brain className="h-5 w-5" />,
  autre: <File className="h-5 w-5" />,
};

const TYPE_COULEURS: Record<Document['type'], string> = {
  fiche: 'text-nk-accent-600 bg-nk-accent-100 dark:bg-nk-accent-900/30',
  note: 'text-nk-neutre-600 bg-nk-neutre-100 dark:bg-nk-neutre-900/30',
  resume: 'text-nk-primaire-600 bg-nk-primaire-100 dark:bg-nk-primaire-900/30',
  essai: 'text-nk-primaire-600 bg-nk-primaire-100 dark:bg-nk-primaire-900/30',
  dissertation: 'text-nk-espace-produire bg-nk-espace-produire/10',
  notes: 'text-nk-attention-600 bg-nk-attention-100 dark:bg-nk-attention-900/30',
  carte_mentale: 'text-nk-danger-600 bg-nk-danger-100 dark:bg-nk-danger-900/30',
  autre: 'text-nk-neutre-600 bg-nk-neutre-100 dark:bg-nk-neutre-900/30',
};

const MATIERES_LABELS: Record<Matiere, string> = {
  mathematiques: 'Mathématiques',
  francais: 'Français',
  physique: 'Physique',
  chimie: 'Chimie',
  histoire: 'Histoire',
  geographie: 'Géographie',
  philosophie: 'Philosophie',
  anglais: 'Anglais',
  svt: 'SVT',
  ses: 'SES',
  informatique: 'Informatique',
  economie: 'Économie',
};

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageProduire() {
  const {
    documents, documentActif, filtres, setFiltres,
    setDocuments, setDocumentActif,
    ajouterDocument, archiverDocument, supprimerDocument,
    reinitialiserFiltres,
  } = useDocumentStore();

  const [menuOuvert, setMenuOuvert] = useState<string | null>(null);

  // Initialiser les données de démo au montage
  useEffect(() => {
    if (documents.length === 0) {
      setDocuments(DOCUMENTS_DEMO);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Filtrer les documents
  const docsFiltres = documents.filter((d) => {
    if (d.est_archive && filtres.type !== null) return false;
    const matchType = !filtres.type || d.type === filtres.type;
    const matchMatiere = !filtres.matiere || d.matiere === filtres.matiere;
    const matchRecherche = !filtres.recherche ||
      d.titre.toLowerCase().includes(filtres.recherche.toLowerCase()) ||
      d.mot_cles.some((mc) => mc.toLowerCase().includes(filtres.recherche.toLowerCase()));
    return matchType && matchMatiere && matchRecherche && !d.est_archive;
  });

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-produire/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-nk-espace-produire" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Produire</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Créez des fiches, résumés, dissertations et plus
              </p>
            </div>
          </div>

          <button className="nk-bouton-primaire nk-bouton-md gap-2">
            <Plus className="h-4 w-4" /> Nouveau document
          </button>
        </div>
      </div>

      {/* Barre de filtres */}
      <div className="px-6 py-4 border-b border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900">
        <div className="flex items-center gap-4 max-w-7xl mx-auto">
          {/* Recherche */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-nk-neutre-400 dark:text-nk-neutre-500" />
            <input
              type="text"
              placeholder="Rechercher un document..."
              value={filtres.recherche}
              onChange={(e) => setFiltres({ recherche: e.target.value })}
              className="nk-input pl-9"
            />
          </div>

          {/* Types */}
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={() => setFiltres({ type: null })}
              className={`nk-bouton nk-bouton-sm whitespace-nowrap ${
                !filtres.type ? 'nk-bouton-primaire' : 'nk-bouton-ghost'
              }`}
            >
              Tous
            </button>
            {(Object.keys(TYPE_LABELS) as Document['type'][]).map((type) => (
              <button
                key={type}
                onClick={() => setFiltres({ type })}
                className={`nk-bouton nk-bouton-sm whitespace-nowrap ${
                  filtres.type === type
                    ? 'nk-bouton-primaire'
                    : 'nk-bouton-ghost'
                }`}
              >
                {TYPE_LABELS[type]}
              </button>
            ))}
          </div>

          {/* Filtre matière */}
          <select
            value={filtres.matiere || ''}
            onChange={(e) => setFiltres({ matiere: (e.target.value || null) as Matiere | null })}
            className="nk-input text-sm py-1.5 max-w-[160px]"
          >
            <option value="">Toutes matières</option>
            {Object.entries(MATIERES_LABELS).map(([key, label]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Contenu : liste + éditeur */}
      <div className="nk-espace-contenu">
        <div className="flex gap-6 max-w-7xl mx-auto">
          {/* Panneau gauche : liste documents */}
          <div className="w-1/3 space-y-3">
            {docsFiltres.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-10 w-10 text-nk-neutre-300 dark:text-nk-neutre-600 mx-auto mb-3" />
                <p className="text-nk-neutre-500 dark:text-nk-neutre-400">Aucun document trouvé.</p>
                <button
                  onClick={reinitialiserFiltres}
                  className="nk-bouton nk-bouton-sm nk-bouton-ghost mt-2"
                >
                  Réinitialiser les filtres
                </button>
              </div>
            ) : (
              docsFiltres.map((doc, index) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => setDocumentActif(doc)}
                  className={`nk-carte p-4 cursor-pointer group relative ${
                    documentActif?.id === doc.id
                      ? 'border-nk-espace-produire ring-1 ring-nk-espace-produire/20'
                      : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${TYPE_COULEURS[doc.type]}`}>
                      {TYPE_ICONES[doc.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm text-nk-neutre-900 dark:text-nk-neutre-100 truncate">
                        {doc.titre}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="nk-badge nk-badge-neutre text-[10px]">{doc.matiere ? MATIERES_LABELS[doc.matiere] : 'Non assigné'}</span>
                        {doc.genere_par_ia && (
                          <span className="nk-badge nk-badge-accent text-[10px] gap-0.5">
                            <Sparkles className="h-2.5 w-2.5" /> IA
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-nk-neutre-400 dark:text-nk-neutre-500 mt-1">
                        v{doc.version} — {new Date(doc.modifie_le).toLocaleDateString('fr-FR')}
                      </p>
                    </div>

                    {/* Menu contextuel */}
                    <div className="relative">
                      <button
                        onClick={(e) => { e.stopPropagation(); setMenuOuvert(menuOuvert === doc.id ? null : doc.id); }}
                        className="p-1 rounded-md opacity-0 group-hover:opacity-100 hover:bg-nk-neutre-100 dark:hover:bg-nk-neutre-800 transition-all"
                      >
                        <MoreHorizontal className="h-4 w-4 text-nk-neutre-400" />
                      </button>
                      <AnimatePresence>
                        {menuOuvert === doc.id && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="absolute right-0 top-8 z-10 w-40 rounded-lg shadow-lg border border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-800 py-1"
                          >
                            <button
                              onClick={(e) => { e.stopPropagation(); setDocumentActif(doc); setMenuOuvert(null); }}
                              className="w-full px-3 py-2 text-sm text-left hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-700 flex items-center gap-2 text-nk-neutre-700 dark:text-nk-neutre-200"
                            >
                              <Eye className="h-3.5 w-3.5" /> Ouvrir
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); archiverDocument(doc.id); setMenuOuvert(null); }}
                              className="w-full px-3 py-2 text-sm text-left hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-700 flex items-center gap-2 text-nk-neutre-700 dark:text-nk-neutre-200"
                            >
                              <Archive className="h-3.5 w-3.5" /> Archiver
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); supprimerDocument(doc.id); setMenuOuvert(null); }}
                              className="w-full px-3 py-2 text-sm text-left hover:bg-nk-danger-50 dark:hover:bg-nk-danger-900/20 flex items-center gap-2 text-nk-danger-600"
                            >
                              <Trash2 className="h-3.5 w-3.5" /> Supprimer
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {/* Panneau droit : éditeur / aperçu */}
          <div className="flex-1">
            {documentActif ? (
              <motion.div
                key={documentActif.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="nk-carte p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-lg ${TYPE_COULEURS[documentActif.type]}`}>
                      {TYPE_ICONES[documentActif.type]}
                    </div>
                    <div>
                      <h2 className="text-lg font-semibold text-nk-neutre-900 dark:text-nk-neutre-100">
                        {documentActif.titre}
                      </h2>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="nk-badge nk-badge-neutre">{TYPE_LABELS[documentActif.type]}</span>
                        <span className="nk-badge nk-badge-neutre">{documentActif.matiere ? MATIERES_LABELS[documentActif.matiere] : 'Non assigné'}</span>
                        {documentActif.genere_par_ia && (
                          <span className="nk-badge nk-badge-accent gap-1">
                            <Sparkles className="h-3 w-3" /> Généré par IA
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="nk-bouton nk-bouton-sm nk-bouton-ghost gap-1">
                      <Share2 className="h-3.5 w-3.5" /> Partager
                    </button>
                    <button className="nk-bouton nk-bouton-sm nk-bouton-ghost gap-1">
                      <Sparkles className="h-3.5 w-3.5 text-nk-accent-500" /> Améliorer avec l'IA
                    </button>
                  </div>
                </div>

                {/* Contenu du document */}
                <div className="border border-nk-neutre-200 dark:border-nk-neutre-700 rounded-lg p-6 min-h-[400px] bg-nk-neutre-50/50 dark:bg-nk-neutre-800/50">
                  <p className="text-nk-neutre-700 dark:text-nk-neutre-200 leading-relaxed">
                    {documentActif.contenu}
                  </p>
                </div>

                {/* Métadonnées */}
                <div className="flex items-center gap-4 mt-4 text-xs text-nk-neutre-400 dark:text-nk-neutre-500">
                  <span>Version {documentActif.version}</span>
                  <span>•</span>
                  <span>Créé le {new Date(documentActif.cree_le).toLocaleDateString('fr-FR')}</span>
                  <span>•</span>
                  <span>Modifié le {new Date(documentActif.modifie_le).toLocaleDateString('fr-FR')}</span>
                  <span>•</span>
                  <span>{Math.round(documentActif.taille_octets / 1024)} Ko</span>
                </div>
              </motion.div>
            ) : (
              <div className="nk-carte p-12 text-center">
                <FileText className="h-16 w-16 text-nk-neutre-300 dark:text-nk-neutre-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-nk-neutre-700 dark:text-nk-neutre-200 mb-2">
                  Sélectionnez un document
                </h3>
                <p className="text-nk-neutre-500 dark:text-nk-neutre-400">
                  Choisissez un document dans la liste ou créez-en un nouveau.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
