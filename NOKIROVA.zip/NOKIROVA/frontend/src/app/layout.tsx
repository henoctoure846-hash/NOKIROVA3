'use client';

/**
 * NOKIROVA — Layout racine
 *
 * Layout principal de l'application avec :
 * - Sidebar de navigation (9 espaces)
 * - Header contextuel
 * - Zone de contenu principal
 * - Providers (Query, Toast, WebSocket, Auth)
 * - PWA Service Worker
 * - Accessibilité : skip-to-content, aria-labels
 *
 * Principe BIBLE #7 Hors connexion :
 * Service Worker enregistré pour navigation offline.
 */

import { ReactNode, useState, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import Sidebar from '@/components/layout/Sidebar';
import Header from '@/components/layout/Header';
import { WebSocketProvider } from '@/providers/WebSocketProvider';
import { AuthProvider } from '@/providers/AuthProvider';
import { usePWA } from '@/hooks/usePWA';
import './globals.css';

// Création du client Query en dehors du composant pour éviter
// la recréation à chaque rendu
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (anciennement cacheTime)
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

/**
 * Composant interne pour l'enregistrement PWA
 * (ne peut pas appeler usePWA directement dans RootLayout
 *  car RootLayout est un composant serveur potentiel)
 */
function EnregistrementPWA() {
  const { miseAJourDisponible, horsConnexion, appliquerMiseAJour } = usePWA();

  // Afficher une notification de mise à jour
  useEffect(() => {
    if (miseAJourDisponible) {
      // La logique de notification est gérée par le hook
      // Ici on pourrait afficher un toast ou une bannière
    }
  }, [miseAJourDisponible]);

  // Indicateur offline dans la console
  useEffect(() => {
    if (horsConnexion) {
    }
  }, [horsConnexion]);

  return (
    <>
      {/* Bannière de mise à jour PWA */}
      {miseAJourDisponible && (
        <div
          role="alert"
          aria-live="polite"
          className="fixed bottom-4 right-4 z-50 rounded-xl border border-nk-primaire-200
            bg-nk-primaire-50 px-4 py-3 shadow-lg"
        >
          <p className="text-sm font-medium text-nk-primaire-800">
            🔄 Nouvelle version disponible
          </p>
          <button
            onClick={appliquerMiseAJour}
            className="mt-2 rounded-lg bg-nk-primaire-600 px-4 py-1.5 text-sm
              font-semibold text-white transition-colors hover:bg-nk-primaire-700
              focus:outline-none focus:ring-2 focus:ring-nk-primaire-500 focus:ring-offset-2"
            aria-label="Mettre à jour l'application"
          >
            Mettre à jour
          </button>
        </div>
      )}

      {/* Indicateur hors connexion */}
      {horsConnexion && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-4 left-4 z-50 rounded-xl border border-amber-200
            bg-amber-50 px-4 py-2 shadow-lg"
        >
          <p className="text-sm font-medium text-amber-800">
            📡 Mode hors connexion
          </p>
        </div>
      )}
    </>
  );
}

interface RootLayoutProps {
  children: ReactNode;
}

export default function RootLayout({ children }: RootLayoutProps) {
  const [sidebarReduit, setSidebarReduit] = useState(false);

  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <title>NOKIROVA — Écosystème éducatif propulsé par l'IA</title>
        <meta name="description" content="NOKIROVA, votre compagnon éducatif intelligent : apprendre, réviser, produire et progresser avec l'IA" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#6366f1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
      </head>
      <body className="min-h-screen bg-nk-neutre-50">
        {/* Lien d'accès rapide au contenu — accessibilité */}
        <a
          href="#contenu-principal"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4
            focus:z-[100] focus:rounded-lg focus:bg-nk-primaire-600 focus:px-4
            focus:py-2 focus:text-white focus:shadow-lg"
        >
          Aller au contenu principal
        </a>

        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <WebSocketProvider>
              <div className="flex h-screen overflow-hidden">
                {/* Sidebar */}
                <Sidebar
                  reduit={sidebarReduit}
                  onBasculer={() => setSidebarReduit(!sidebarReduit)}
                />

                {/* Zone principale */}
                <div className="flex flex-1 flex-col overflow-hidden">
                  {/* Header contextuel */}
                  <Header />

                  {/* Contenu de la page */}
                  <main
                    id="contenu-principal"
                    className="flex-1 overflow-y-auto nk-scrollbar-cache"
                    role="main"
                    aria-label="Contenu principal"
                  >
                    {children}
                  </main>
                </div>
              </div>

              {/* Notifications toast */}
              <Toaster
                position="top-right"
                toastOptions={{
                  duration: 4000,
                  style: {
                    borderRadius: '0.75rem',
                    background: '#ffffff',
                    color: '#212529',
                    boxShadow: '0 4px 6px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.06)',
                    border: '1px solid #dee2e6',
                    padding: '12px 16px',
                    fontSize: '0.875rem',
                  },
                  success: {
                    iconTheme: { primary: '#20c997', secondary: '#ffffff' },
                  },
                  error: {
                    iconTheme: { primary: '#ff6b6b', secondary: '#ffffff' },
                  },
                }}
              />

              {/* Enregistrement PWA + indicateurs */}
              <EnregistrementPWA />
            </WebSocketProvider>
          </AuthProvider>
        </QueryClientProvider>
      </body>
    </html>
  );
}
