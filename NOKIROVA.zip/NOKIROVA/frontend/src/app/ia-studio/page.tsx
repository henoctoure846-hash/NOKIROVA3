'use client';

/**
 * NOKIROVA — Espace IA Studio
 *
 * Hub IA central : agents spécialisés, chat, génération
 * de contenu, analyse, traduction, question-réponse.
 * Intégré au store IA (session, messages, agents, quota).
 */
'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles, Send, Bot, User, Cpu,
  BookOpen, PenTool, Brain, BarChart3,
  Languages, Lightbulb, Zap, Clock, MessageSquare,
  AlertCircle, ChevronDown,
} from 'lucide-react';
import { useAIStore } from '@/stores/aiStore';
import type { AgentIADetail, AgentIA } from '@/types';

// ─── Agents IA disponibles ───────────────────────────────────────────────────

const AGENTS_DISPO: AgentIADetail[] = [
  {
    id: 'tuteur',
    nom: 'Tuteur',
    description: 'Explication de concepts, aide aux devoirs, soutien personnalisé.',
    specialite: 'pedagogie',
    modele_ia: 'gpt-4o',
    temperature: 0.7,
    system_prompt: 'Tu es un tuteur bienveillant...',
    est_actif: true,
    nb_conversations: 1200,
    note_moyenne: 4.8,
  },
  {
    id: 'redacteur',
    nom: 'Rédacteur',
    description: 'Rédaction, correction et amélioration de textes académiques.',
    specialite: 'redaction',
    modele_ia: 'gpt-4o',
    temperature: 0.5,
    system_prompt: 'Tu es un expert en rédaction...',
    est_actif: true,
    nb_conversations: 850,
    note_moyenne: 4.6,
  },
  {
    id: 'analyste',
    nom: 'Analyste',
    description: 'Analyse de documents, extraction de points clés, synthèse.',
    specialite: 'analyse',
    modele_ia: 'gpt-4o',
    temperature: 0.3,
    system_prompt: 'Tu es un analyste rigoureux...',
    est_actif: true,
    nb_conversations: 620,
    note_moyenne: 4.7,
  },
  {
    id: 'createur',
    nom: 'Créateur',
    description: 'Génération de fiches, résumés, flashcards et exercices.',
    specialite: 'generation',
    modele_ia: 'gpt-4o',
    temperature: 0.8,
    system_prompt: 'Tu es un créateur de contenu...',
    est_actif: true,
    nb_conversations: 1400,
    note_moyenne: 4.9,
  },
  {
    id: 'traducteur',
    nom: 'Traducteur',
    description: 'Traduction multilingue et explication de textes étrangers.',
    specialite: 'traduction',
    modele_ia: 'gpt-4o',
    temperature: 0.4,
    system_prompt: 'Tu es un traducteur expert...',
    est_actif: true,
    nb_conversations: 400,
    note_moyenne: 4.5,
  },
];

const AGENT_ICONES: Record<string, React.ReactNode> = {
  pedagogie: <BookOpen className="h-5 w-5" />,
  redaction: <PenTool className="h-5 w-5" />,
  analyse: <BarChart3 className="h-5 w-5" />,
  generation: <Sparkles className="h-5 w-5" />,
  traduction: <Languages className="h-5 w-5" />,
};

const AGENT_COULEURS: Record<string, string> = {
  pedagogie: 'text-nk-accent-600 bg-nk-accent-100 dark:bg-nk-accent-900/30',
  redaction: 'text-nk-primaire-600 bg-nk-primaire-100 dark:bg-nk-primaire-900/30',
  analyse: 'text-nk-attention-600 bg-nk-attention-100 dark:bg-nk-attention-900/30',
  generation: 'text-nk-espace-ia-studio bg-nk-espace-ia-studio/10',
  traduction: 'text-nk-danger-600 bg-nk-danger-100 dark:bg-nk-danger-900/30',
};

// ─── Messages de démo ────────────────────────────────────────────────────────

const MESSAGES_DEMO = [
  {
    id: '1',
    session_id: 'demo',
    role: 'assistant' as const,
    contenu: "Bonjour ! 👋 Je suis votre assistant IA NOKIROVA. Je peux vous aider à apprendre, réviser, produire des documents et bien plus. Que souhaitez-vous faire ?",
    horodatage: new Date(Date.now() - 60000).toISOString(),
    agent_id: 'tuteur',
    tokens: 45,
    tokens_utilises: 45,
    modele: 'gpt-4o',
  },
];

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageIAStudio() {
  const [saisie, setSaisie] = useState('');
  const [afficherAgents, setAfficherAgents] = useState(true);
  const messagesFinRef = useRef<HTMLDivElement>(null);

  const {
    messages, agentActif, quota, estGeneration: generation, streaming, erreur,
    setSessionActive, ajouterMessage, setAgentActif,
    setQuota, setStreaming, setErreur, reinitialiser,
  } = useAIStore();

  // Initialiser les données de démo au montage
  useEffect(() => {
    if (messages.length === 0) {
      setSessionActive({
        id: 'demo',
        agent: 'tuteur',
        fournisseur: 'openai',
        modele: 'gpt-4o',
        contexte: {},
        messages: [],
        statut: 'active',
        tokens_utilises: 45,
        cout_estime: 0,
        debut: new Date().toISOString(),
        fin: null,
      });
      MESSAGES_DEMO.forEach((m) => ajouterMessage(m));
      setAgentActif('tuteur');
      setQuota({ plan: 'etudiant', tokens_max_jour: 50000, tokens_utilises_jour: 5000, requetes_max_jour: 50, requetes_utilisees_jour: 10, date_reinitialisation: new Date().toISOString(), tokens_utilises: 5000, tokens_limite: 50000, requetes_utilises: 10, requetes_limite: 50 });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Scroll auto vers le bas
  useEffect(() => {
    messagesFinRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Envoyer un message
  const envoyerMessage = () => {
    if (!saisie.trim()) return;

    ajouterMessage({
      id: Date.now().toString(),
      session_id: 'demo',
      role: 'user',
      contenu: saisie,
      horodatage: new Date().toISOString(),
      agent_id: agentActif || 'tuteur',
      tokens: 0,
      tokens_utilises: 0,
      modele: 'gpt-4o',
    });
    setSaisie('');

    // Simuler la réponse IA
    setStreaming(true);
    setTimeout(() => {
      ajouterMessage({
        id: (Date.now() + 1).toString(),
        session_id: 'demo',
        role: 'assistant',
        contenu: `C'est une excellente question ! En tant qu'agent ${agentActif || 'tuteur'}, voici ce que je peux vous dire : votre sujet est très intéressant et mérite une exploration approfondie. N'hésitez pas à me poser des questions plus spécifiques.`,
        horodatage: new Date().toISOString(),
        agent_id: agentActif || 'tuteur',
        tokens_utilises: Math.floor(Math.random() * 200) + 50,
        tokens: Math.floor(Math.random() * 200) + 50,
        modele: 'gpt-4o',
      });
      setStreaming(false);
    }, 1500);
  };

  // Calculs quota
  const pctTokens = quota ? Math.round((quota.tokens_utilises / quota.tokens_limite) * 100) : 0;
  const pctRequetes = quota ? Math.round((quota.requetes_utilises / quota.requetes_limite) * 100) : 0;

  return (
    <div className="nk-espace h-full">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-ia-studio/10 flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-nk-espace-ia-studio" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">IA Studio</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Vos agents IA pour apprendre plus efficacement
              </p>
            </div>
          </div>

          {/* Quota */}
          {quota && (
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <Zap className="h-3.5 w-3.5 text-nk-espace-ia-studio" />
                <div>
                  <div className="font-medium text-nk-neutre-700 dark:text-nk-neutre-200">{Math.round(quota.tokens_utilises / 1000)}K / {Math.round(quota.tokens_limite / 1000)}K</div>
                  <div className="text-nk-neutre-400 dark:text-nk-neutre-500">tokens/jour</div>
                </div>
                <div className="w-20 h-1.5 bg-nk-neutre-100 dark:bg-nk-neutre-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${pctTokens > 80 ? 'bg-nk-danger-500' : pctTokens > 50 ? 'bg-nk-attention-500' : 'bg-nk-espace-ia-studio'}`}
                    style={{ width: `${pctTokens}%` }}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-3.5 w-3.5 text-nk-espace-ia-studio" />
                <div>
                  <div className="font-medium text-nk-neutre-700 dark:text-nk-neutre-200">{quota.requetes_utilises} / {quota.requetes_limite}</div>
                  <div className="text-nk-neutre-400 dark:text-nk-neutre-500">requêtes/jour</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex h-[calc(100vh-8rem)]">
        {/* Panneau gauche : agents */}
        <div className={`w-64 border-r border-nk-neutre-200 dark:border-nk-neutre-700 bg-nk-neutre-50/50 dark:bg-nk-neutre-800/50 overflow-y-auto transition-all ${afficherAgents ? 'ml-0' : '-ml-64'}`}>
          <div className="p-4">
            <h3 className="text-sm font-semibold text-nk-neutre-900 dark:text-nk-neutre-100 mb-3">Agents IA</h3>
            <div className="space-y-2">
              {AGENTS_DISPO.map((agent) => (
                <button
                  key={agent.id}
                  onClick={() => setAgentActif(agent.id as AgentIA)}
                  className={`w-full p-3 rounded-lg text-left transition-all ${
                    agentActif === agent.id
                      ? 'bg-nk-espace-ia-studio/10 border border-nk-espace-ia-studio/30'
                      : 'hover:bg-nk-neutre-100 dark:hover:bg-nk-neutre-700 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-md ${AGENT_COULEURS[agent.specialite]}`}>
                      {AGENT_ICONES[agent.specialite]}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-nk-neutre-900 dark:text-nk-neutre-100">{agent.nom}</div>
                      <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400 line-clamp-1">{agent.description}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Zone de chat */}
        <div className="flex-1 flex flex-col">
          {/* Zone messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role === 'assistant' && (
                    <div className={`p-2 rounded-lg flex-shrink-0 ${
                      AGENT_COULEURS[AGENTS_DISPO.find((a) => a.id === msg.agent_id)?.specialite || 'pedagogie']
                    }`}>
                      <Bot className="h-5 w-5" />
                    </div>
                  )}

                  <div className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                    msg.role === 'user'
                      ? 'bg-nk-primaire-600 text-white'
                      : 'bg-nk-neutre-100 dark:bg-nk-neutre-800 text-nk-neutre-800 dark:text-nk-neutre-100'
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.contenu}</p>
                    <span className="text-[10px] mt-1 block opacity-50">
                      {msg.role === 'assistant' && msg.tokens_utilises
                        ? `${msg.tokens_utilises} tokens`
                        : new Date(msg.horodatage).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
                      }
                    </span>
                  </div>

                  {msg.role === 'user' && (
                    <div className="p-2 rounded-lg flex-shrink-0 bg-nk-primaire-100 dark:bg-nk-primaire-900/30">
                      <User className="h-5 w-5 text-nk-primaire-600" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Indicateur de streaming */}
            {streaming && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 text-nk-neutre-400 dark:text-nk-neutre-500"
              >
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-nk-espace-ia-studio rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-nk-espace-ia-studio rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-nk-espace-ia-studio rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-sm">L'IA réfléchit...</span>
              </motion.div>
            )}

            {/* Erreur */}
            {erreur && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-nk-danger-50 dark:bg-nk-danger-900/20 text-nk-danger-700 dark:text-nk-danger-400 text-sm">
                <AlertCircle className="h-4 w-4" /> {erreur}
              </div>
            )}

            <div ref={messagesFinRef} />
          </div>

          {/* Zone de saisie */}
          <div className="px-6 py-4 border-t border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900">
            <div className="flex items-center gap-3 max-w-4xl mx-auto">
              <button
                onClick={() => setAfficherAgents(!afficherAgents)}
                className="p-2 rounded-lg hover:bg-nk-neutre-100 dark:hover:bg-nk-neutre-800 transition-colors"
                title="Afficher/masquer les agents"
              >
                <Cpu className="h-5 w-5 text-nk-neutre-400 dark:text-nk-neutre-500" />
              </button>

              <div className="flex-1 relative">
                <input
                  type="text"
                  value={saisie}
                  onChange={(e) => setSaisie(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && envoyerMessage()}
                  placeholder="Posez une question à l'IA..."
                  className="nk-input pr-12"
                  disabled={streaming}
                />
              </div>

              <button
                onClick={envoyerMessage}
                disabled={streaming || !saisie.trim()}
                className="p-2.5 rounded-lg bg-nk-espace-ia-studio text-white hover:bg-nk-espace-ia-studio/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>

            {/* Raccourcis suggérés */}
            <div className="flex items-center gap-2 mt-3 max-w-4xl mx-auto">
              {['Explique-moi', 'Crée une fiche', 'Résume ce cours', 'Traduis en anglais'].map((raccourci) => (
                <button
                  key={raccourci}
                  onClick={() => setSaisie(raccourci)}
                  className="nk-bouton nk-bouton-sm nk-bouton-ghost text-xs"
                >
                  {raccourci}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
