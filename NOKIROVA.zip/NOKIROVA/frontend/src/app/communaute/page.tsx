'use client';

/**
 * NOKIROVA — Espace Communauté
 *
 * Forum, groupes d'étude, classement, messages,
 * partage de ressources et collaboration.
 *
 * Store intégré : useGamificationStore (classement)
 * Dark mode complet sur tous les éléments.
 */
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Users, MessageCircle, Trophy, BookMarked,
  Heart, Share2, Pin,
  TrendingUp, Plus, Search,
} from 'lucide-react';
import { useGamificationStore } from '@/stores/gamificationStore';
import type { ClassementEntree, PublicationForum, GroupeEtude } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

type OngletCommunaute = 'forum' | 'groupes' | 'classement' | 'ressources';

// ─── Données de démonstration ─────────────────────────────────────────────────

const PUBLICATIONS_DEMO: PublicationForum[] = [
  {
    id: '1', auteur_id: 'u1', auteur_nom: 'Marie L.', auteur_avatar: null,
    titre: 'Aide pour le théorème de Thalès',
    contenu: "Quelqu'un peut m'expliquer la réciproque du théorème de Thalès ? Je confonds toujours avec la contraposée...",
    categorie: 'question', matiere: 'mathematiques', nb_likes: 12, nb_commentaires: 5, nb_vues: 48,
    est_epingle: false, est_resolu: false, cree_le: new Date().toISOString(), modifie_le: new Date().toISOString(),
  },
  {
    id: '2', auteur_id: 'u2', auteur_nom: 'Thomas B.', auteur_avatar: null,
    titre: '📢 Session de révision groupe — Samedi 10h',
    contenu: 'On organise une session de révision en ligne sur les fonctions dérivées. Rejoignez le groupe Mathématiques !',
    categorie: 'annonce', matiere: 'mathematiques', nb_likes: 24, nb_commentaires: 8, nb_vues: 120,
    est_epingle: true, est_resolu: false, cree_le: new Date().toISOString(), modifie_le: new Date().toISOString(),
  },
  {
    id: '3', auteur_id: 'u3', auteur_nom: 'Sophie R.', auteur_avatar: null,
    titre: 'Mes fiches de révision en SVT',
    contenu: "J'ai partagé mes fiches sur la division cellulaire et la génétique. N'hésitez pas à les utiliser !",
    categorie: 'partage', matiere: 'svt', nb_likes: 45, nb_commentaires: 12, nb_vues: 200,
    est_epingle: false, est_resolu: false, cree_le: new Date().toISOString(), modifie_le: new Date().toISOString(),
  },
];

const GROUPES_DEMO: GroupeEtude[] = [
  { id: '1', nom: 'Math Sup', description: 'Groupe de préparation aux maths avancées', matiere: 'mathematiques', nb_membres: 34, max_membres: 50, est_prive: false, cree_par: 'u1', cree_le: new Date().toISOString() },
  { id: '2', nom: 'Philo Club', description: 'Discussions philosophiques et dissertations', matiere: 'philosophie', nb_membres: 22, max_membres: 30, est_prive: false, cree_par: 'u2', cree_le: new Date().toISOString() },
  { id: '3', nom: 'SVT Warriors', description: 'Révisions et entraide en sciences de la vie', matiere: 'svt', nb_membres: 18, max_membres: 40, est_prive: false, cree_par: 'u3', cree_le: new Date().toISOString() },
  { id: '4', nom: 'Code & Maths', description: 'Intersection programmation et mathématiques', matiere: 'informatique', nb_membres: 56, max_membres: 80, est_prive: true, cree_par: 'u4', cree_le: new Date().toISOString() },
];

const CLASSEMENT_DEMO: ClassementEntree[] = [
  { rang: 1, utilisateur_id: 'u3', pseudo: 'Sophie R.', avatar_url: null, niveau: 9, xp: 12500, streak: 18, badges_count: 8 },
  { rang: 2, utilisateur_id: 'u1', pseudo: 'Marie L.', avatar_url: null, niveau: 8, xp: 11200, streak: 14, badges_count: 6 },
  { rang: 3, utilisateur_id: 'u2', pseudo: 'Thomas B.', avatar_url: null, niveau: 7, xp: 10800, streak: 21, badges_count: 5 },
  { rang: 4, utilisateur_id: 'u4', pseudo: 'Lucas M.', avatar_url: null, niveau: 6, xp: 9600, streak: 9, badges_count: 4 },
  { rang: 5, utilisateur_id: 'u5', pseudo: 'Emma D.', avatar_url: null, niveau: 6, xp: 8900, streak: 7, badges_count: 3 },
];

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageCommunaute() {
  const [ongletActif, setOngletActif] = useState<OngletCommunaute>('forum');
  const { classement, setClassement } = useGamificationStore();

  // Initialisation des données démo si le store est vide
  useEffect(() => {
    if (classement.length === 0) {
      setClassement(CLASSEMENT_DEMO);
    }
  }, [classement.length, setClassement]);

  const onglets: { id: OngletCommunaute; label: string; icone: React.ReactNode }[] = [
    { id: 'forum', label: 'Forum', icone: <MessageCircle className="h-4 w-4" /> },
    { id: 'groupes', label: 'Groupes', icone: <Users className="h-4 w-4" /> },
    { id: 'classement', label: 'Classement', icone: <Trophy className="h-4 w-4" /> },
    { id: 'ressources', label: 'Ressources', icone: <BookMarked className="h-4 w-4" /> },
  ];

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-communaute/10 dark:bg-nk-espace-communaute/20 flex items-center justify-center">
              <Users className="h-5 w-5 text-nk-espace-communaute" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Communauté</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Entraide, partage et collaboration
              </p>
            </div>
          </div>

          <button className="nk-bouton-primaire nk-bouton-md gap-2">
            <Plus className="h-4 w-4" /> Nouveau sujet
          </button>
        </div>
      </div>

      {/* Onglets */}
      <div className="px-6 py-3 border-b border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900 flex items-center gap-2">
        {onglets.map((onglet) => (
          <button
            key={onglet.id}
            onClick={() => setOngletActif(onglet.id)}
            className={`nk-bouton nk-bouton-sm gap-2 ${
              ongletActif === onglet.id
                ? 'nk-bouton-primaire'
                : 'nk-bouton-ghost'
            }`}
          >
            {onglet.icone} {onglet.label}
          </button>
        ))}
      </div>

      {/* Contenu */}
      <div className="nk-espace-contenu">
        {ongletActif === 'forum' && <Forum publications={PUBLICATIONS_DEMO} />}
        {ongletActif === 'groupes' && <Groupes groupes={GROUPES_DEMO} />}
        {ongletActif === 'classement' && <Classement />}
        {ongletActif === 'ressources' && <Ressources />}
      </div>
    </div>
  );
}

// ─── Forum ────────────────────────────────────────────────────────────────────

function Forum({ publications }: { publications: PublicationForum[] }) {
  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      {/* Barre de recherche */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-nk-neutre-400 dark:text-nk-neutre-500" />
        <input
          type="text"
          placeholder="Rechercher dans le forum..."
          className="nk-input pl-9"
        />
      </div>

      {publications.map((pub, index) => (
        <motion.div
          key={pub.id}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`nk-carte p-5 cursor-pointer group ${pub.est_epingle ? 'border-nk-espace-communaute/30 dark:border-nk-espace-communaute/40' : ''}`}
        >
          <div className="flex items-start gap-3">
            <span className="text-2xl">👩‍🎓</span>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                {pub.est_epingle && <Pin className="h-3.5 w-3.5 text-nk-espace-communaute" />}
                <h3 className="font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 group-hover:text-nk-espace-communaute transition-colors">
                  {pub.titre}
                </h3>
              </div>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 line-clamp-2 mb-3">{pub.contenu}</p>
              <div className="flex items-center gap-4 text-xs text-nk-neutre-400 dark:text-nk-neutre-500">
                <span className="font-medium text-nk-neutre-600 dark:text-nk-neutre-300">{pub.auteur_nom}</span>
                <span className="nk-badge nk-badge-neutre">{pub.matiere}</span>
                <span>Il y a {index === 0 ? '30min' : index === 1 ? '2h' : '1j'}</span>
              </div>
              <div className="flex items-center gap-4 mt-3">
                <button className="flex items-center gap-1 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 hover:text-nk-danger-500 transition-colors">
                  <Heart className="h-3.5 w-3.5" /> {pub.nb_likes}
                </button>
                <button className="flex items-center gap-1 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 hover:text-nk-espace-communaute transition-colors">
                  <MessageCircle className="h-3.5 w-3.5" /> {pub.nb_commentaires}
                </button>
                <button className="flex items-center gap-1 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 hover:text-nk-primaire-600 transition-colors">
                  <Share2 className="h-3.5 w-3.5" /> Partager
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

// ─── Groupes ──────────────────────────────────────────────────────────────────

function Groupes({ groupes }: { groupes: GroupeEtude[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
      {groupes.map((groupe, index) => (
        <motion.div
          key={groupe.id}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          className="nk-carte p-5 cursor-pointer group hover:border-nk-espace-communaute/50 dark:hover:border-nk-espace-communaute/60"
        >
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 group-hover:text-nk-espace-communaute transition-colors">
              {groupe.nom}
            </h3>
            <span className={`nk-badge ${!groupe.est_prive ? 'nk-badge-accent' : 'nk-badge-neutre'}`}>
              {!groupe.est_prive ? 'Public' : 'Privé'}
            </span>
          </div>
          <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 mb-3">{groupe.description}</p>
          <div className="flex items-center justify-between text-xs text-nk-neutre-400 dark:text-nk-neutre-500">
            <span className="nk-badge nk-badge-neutre">{groupe.matiere}</span>
            <span className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" /> {groupe.nb_membres}/{groupe.max_membres} membres
            </span>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

// ─── Classement (données du store useGamificationStore) ──────────────────────

function Classement() {
  const classement = useGamificationStore((s) => s.classement);

  const medailles = ['🥇', '🥈', '🥉'];

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-6 flex items-center gap-2">
        <Trophy className="h-5 w-5 text-nk-attention-500" /> Top contributeurs
      </h2>
      <div className="space-y-3">
        {classement.map((entry, index) => (
          <motion.div
            key={entry.utilisateur_id}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`nk-carte p-4 flex items-center gap-4 ${
              entry.rang <= 3 ? 'border-nk-attention-200 dark:border-nk-attention-700' : ''
            }`}
          >
            <div className="text-2xl w-10 text-center">
              {medailles[entry.rang - 1] || (
                <span className="text-nk-neutre-400 dark:text-nk-neutre-500 font-bold">{entry.rang}</span>
              )}
            </div>
            <div className="flex-1">
              <span className="font-medium text-nk-neutre-800 dark:text-nk-neutre-200">{entry.pseudo}</span>
              <div className="flex items-center gap-3 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 mt-0.5">
                <span>Niv. {entry.niveau}</span>
                <span>🔥 {entry.streak}j</span>
                <span>🏅 {entry.badges_count}</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-sm font-medium text-nk-espace-communaute">
              <TrendingUp className="h-4 w-4" /> {entry.xp.toLocaleString('fr-FR')} XP
            </div>
          </motion.div>
        ))}
      </div>

      {classement.length === 0 && (
        <div className="text-center py-10 text-nk-neutre-400 dark:text-nk-neutre-500">
          Chargement du classement...
        </div>
      )}
    </div>
  );
}

// ─── Ressources ──────────────────────────────────────────────────────────────

function Ressources() {
  const ressources = [
    { id: '1', titre: 'Fiches Maths Terminale', auteur: 'Sophie R.', telechargements: 234, type: 'Fiches' },
    { id: '2', titre: 'Annales Bac Physique', auteur: 'Lucas M.', telechargements: 189, type: 'Annale' },
    { id: '3', titre: 'Méthodologie Dissertation', auteur: 'Marie L.', telechargements: 156, type: 'Guide' },
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-6 flex items-center gap-2">
        <BookMarked className="h-5 w-5 text-nk-espace-communaute" /> Ressources partagées
      </h2>
      <div className="space-y-3">
        {ressources.map((res, index) => (
          <motion.div
            key={res.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="nk-carte p-4 flex items-center gap-4 group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-lg bg-nk-espace-communaute/10 dark:bg-nk-espace-communaute/20 flex items-center justify-center flex-shrink-0">
              <BookMarked className="h-5 w-5 text-nk-espace-communaute" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-nk-neutre-800 dark:text-nk-neutre-200 group-hover:text-nk-espace-communaute transition-colors">
                {res.titre}
              </h3>
              <div className="flex items-center gap-3 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 mt-1">
                <span>{res.auteur}</span>
                <span>{res.telechargements} téléchargements</span>
              </div>
            </div>
            <span className="nk-badge nk-badge-neutre">{res.type}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
