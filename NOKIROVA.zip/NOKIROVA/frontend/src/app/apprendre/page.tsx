'use client';

/**
 * NOKIROVA — Espace Apprendre
 *
 * Catalogue de cours, leçons, modules d'apprentissage.
 * Parcours adaptatifs, progression par chapitre.
 * Intégré au store cours (filtres, pagination, vue).
 */
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  BookOpen, Search, Grid3X3, List,
  GraduationCap, Clock, Star, ChevronRight,
} from 'lucide-react';
import { useCoursesStore } from '@/stores/coursesStore';
import type { Cours, Matiere } from '@/types';

// ─── Données de démonstration ─────────────────────────────────────────────────

const COURS_DEMO: Cours[] = [
  {
    id: '1',
    titre: 'Introduction aux Mathématiques',
    description: 'Maîtrisez les fondamentaux : algèbre, géométrie et analyse.',
    matiere: 'mathematiques',
    niveau: 1,
    chapitre: 'Chapitre 1',
    difficulte: 'debutant',
    duree_estimee_min: 120,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-01-15T10:00:00Z',
    modifie_le: '2025-02-01T14:00:00Z',
    est_publie: true,
    tags: ['algebre', 'geometrie', 'analyse'],
    progression: 65,
    nb_chapitres: 12,
    nb_chapitres_completes: 8,
  },
  {
    id: '2',
    titre: 'Physique Quantique',
    description: 'Explorez le monde subatomique et ses lois fascinantes.',
    matiere: 'physique',
    niveau: 3,
    chapitre: 'Chapitre 1',
    difficulte: 'avance',
    duree_estimee_min: 300,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-01-10T08:00:00Z',
    modifie_le: '2025-01-20T09:00:00Z',
    est_publie: true,
    tags: ['quantique', 'physique', 'atome'],
    progression: 0,
    nb_chapitres: 20,
    nb_chapitres_completes: 0,
  },
  {
    id: '3',
    titre: 'Littérature Française',
    description: 'De Molière à Camus, un voyage à travers les grands textes.',
    matiere: 'francais',
    niveau: 2,
    chapitre: 'Chapitre 1',
    difficulte: 'intermediaire',
    duree_estimee_min: 180,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-01-12T11:00:00Z',
    modifie_le: '2025-02-05T16:00:00Z',
    est_publie: true,
    tags: ['litterature', 'theatre', 'roman'],
    progression: 30,
    nb_chapitres: 15,
    nb_chapitres_completes: 5,
  },
  {
    id: '4',
    titre: 'Histoire de la Révolution',
    description: "De 1789 à l'Empire, les bouleversements qui ont façonné la France.",
    matiere: 'histoire',
    niveau: 2,
    chapitre: 'Chapitre 1',
    difficulte: 'intermediaire',
    duree_estimee_min: 150,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-02-01T09:00:00Z',
    modifie_le: '2025-02-10T12:00:00Z',
    est_publie: true,
    tags: ['revolution', 'france', '1789'],
    progression: 10,
    nb_chapitres: 10,
    nb_chapitres_completes: 1,
  },
  {
    id: '5',
    titre: 'Programmation Python',
    description: 'Les bases de la programmation avec Python : variables, boucles, fonctions.',
    matiere: 'informatique',
    niveau: 1,
    chapitre: 'Chapitre 1',
    difficulte: 'debutant',
    duree_estimee_min: 200,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-01-20T10:00:00Z',
    modifie_le: '2025-02-15T11:00:00Z',
    est_publie: true,
    tags: ['python', 'code', 'programmation'],
    progression: 45,
    nb_chapitres: 18,
    nb_chapitres_completes: 8,
  },
  {
    id: '6',
    titre: 'Chimie Organique',
    description: 'Comprendre les molécules du carbone et leurs réactions.',
    matiere: 'chimie',
    niveau: 2,
    chapitre: 'Chapitre 1',
    difficulte: 'avance',
    duree_estimee_min: 240,
    image_url: null,
    cree_par: 'systeme',
    cree_le: '2025-01-18T08:00:00Z',
    modifie_le: '2025-02-08T10:00:00Z',
    est_publie: true,
    tags: ['organique', 'carbone', 'reaction'],
    progression: 0,
    nb_chapitres: 14,
    nb_chapitres_completes: 0,
  },
];

const MATIERES_LABELS: Record<Matiere, string> = {
  mathematiques: 'Mathématiques',
  francais: 'Français',
  physique: 'Physique',
  chimie: 'Chimie',
  histoire: 'Histoire',
  geographie: 'Géographie',
  philosophie: 'Philosophie',
  anglais: 'Anglais',
  svt: 'SVT',
  ses: 'SES',
  informatique: 'Informatique',
  economie: 'Économie',
};

const MATIERES_LISTE: Matiere[] = [
  'mathematiques', 'francais', 'physique', 'chimie',
  'histoire', 'informatique', 'svt', 'philosophie',
];

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageApprendre() {
  const {
    cours, filtres, setCours, setFiltres, reinitialiserFiltres,
  } = useCoursesStore();

  // Initialiser les données de démo au montage
  useEffect(() => {
    if (cours.length === 0) {
      setCours(COURS_DEMO);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Filtrer les cours selon les filtres du store
  const coursFiltres = cours.filter((c) => {
    const matchRecherche = !filtres.recherche ||
      c.titre.toLowerCase().includes(filtres.recherche.toLowerCase()) ||
      c.description.toLowerCase().includes(filtres.recherche.toLowerCase());
    const matchMatiere = !filtres.matiere || c.matiere === filtres.matiere;
    return matchRecherche && matchMatiere;
  });

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-apprendre/10 flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-nk-espace-apprendre" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Apprendre</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Explorez des cours et développez vos compétences
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Barre de filtres */}
      <div className="px-6 py-4 border-b border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900">
        <div className="flex items-center gap-4 max-w-7xl mx-auto">
          {/* Recherche */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-nk-neutre-400 dark:text-nk-neutre-500" />
            <input
              type="text"
              placeholder="Rechercher un cours..."
              value={filtres.recherche}
              onChange={(e) => setFiltres({ recherche: e.target.value })}
              className="nk-input pl-9"
            />
          </div>

          {/* Matières */}
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={() => setFiltres({ matiere: null })}
              className={`nk-bouton nk-bouton-sm whitespace-nowrap ${
                !filtres.matiere ? 'nk-bouton-primaire' : 'nk-bouton-ghost'
              }`}
            >
              Toutes
            </button>
            {MATIERES_LISTE.map((matiere) => (
              <button
                key={matiere}
                onClick={() => setFiltres({ matiere })}
                className={`nk-bouton nk-bouton-sm whitespace-nowrap ${
                  filtres.matiere === matiere
                    ? 'nk-bouton-primaire'
                    : 'nk-bouton-ghost'
                }`}
              >
                {MATIERES_LABELS[matiere]}
              </button>
            ))}
          </div>

          {/* Toggle vue */}
          <div className="flex items-center gap-1 ml-auto">
            <button
              onClick={() => setFiltres({ vue: 'grille' })}
              className={`p-2 rounded-lg ${
                filtres.vue === 'grille'
                  ? 'bg-nk-primaire-100 dark:bg-nk-primaire-900/30 text-nk-primaire-600'
                  : 'text-nk-neutre-400 dark:text-nk-neutre-500'
              }`}
            >
              <Grid3X3 className="h-4 w-4" />
            </button>
            <button
              onClick={() => setFiltres({ vue: 'liste' })}
              className={`p-2 rounded-lg ${
                filtres.vue === 'liste'
                  ? 'bg-nk-primaire-100 dark:bg-nk-primaire-900/30 text-nk-primaire-600'
                  : 'text-nk-neutre-400 dark:text-nk-neutre-500'
              }`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Liste des cours */}
      <div className="nk-espace-contenu">
        {filtres.vue === 'grille' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {coursFiltres.map((c, index) => (
              <CarteCoursGrille key={c.id} cours={c} index={index} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {coursFiltres.map((c, index) => (
              <CarteCoursListe key={c.id} cours={c} index={index} />
            ))}
          </div>
        )}

        {coursFiltres.length === 0 && (
          <div className="text-center py-20">
            <BookOpen className="h-12 w-12 text-nk-neutre-300 dark:text-nk-neutre-600 mx-auto mb-4" />
            <p className="text-nk-neutre-500 dark:text-nk-neutre-400">Aucun cours ne correspond à vos critères.</p>
            <button
              onClick={reinitialiserFiltres}
              className="nk-bouton nk-bouton-sm nk-bouton-ghost mt-3"
            >
              Réinitialiser les filtres
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Carte cours (grille) ────────────────────────────────────────────────────

function CarteCoursGrille({ cours, index }: { cours: Cours; index: number }) {
  const difficulteLabel = {
    debutant: 'Débutant',
    intermediaire: 'Intermédiaire',
    avance: 'Avancé',
    expert: 'Expert',
  }[cours.difficulte];

  const difficulteCouleur = {
    debutant: 'nk-badge-accent',
    intermediaire: 'nk-badge-attention',
    avance: 'nk-badge-danger',
    expert: 'nk-badge-danger',
  }[cours.difficulte];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="nk-carte overflow-hidden group cursor-pointer"
    >
      {/* Image / placeholder */}
      <div className="h-40 bg-gradient-to-br from-nk-espace-apprendre/20 to-nk-espace-apprendre/5 flex items-center justify-center">
        <GraduationCap className="h-12 w-12 text-nk-espace-apprendre/40" />
      </div>

      <div className="p-5">
        <div className="flex items-center gap-2 mb-2">
          <span className={`nk-badge ${difficulteCouleur}`}>{difficulteLabel}</span>
          <span className="nk-badge nk-badge-neutre">{MATIERES_LABELS[cours.matiere]}</span>
        </div>

        <h3 className="font-semibold text-nk-neutre-900 dark:text-nk-neutre-100 mb-1 group-hover:text-nk-primaire-600 transition-colors">
          {cours.titre}
        </h3>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 line-clamp-2 mb-3">
          {cours.description}
        </p>

        <div className="flex items-center gap-4 text-xs text-nk-neutre-400 dark:text-nk-neutre-500 mb-3">
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> {cours.duree_estimee_min} min
          </span>
          <span>{cours.nb_chapitres} chapitres</span>
        </div>

        {/* Barre de progression */}
        {cours.progression > 0 && (
          <div className="mb-2">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-nk-neutre-500 dark:text-nk-neutre-400">Progression</span>
              <span className="font-medium text-nk-primaire-600">{cours.progression}%</span>
            </div>
            <div className="h-2 bg-nk-neutre-100 dark:bg-nk-neutre-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-nk-espace-apprendre rounded-full transition-all"
                style={{ width: `${cours.progression}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ─── Carte cours (liste) ─────────────────────────────────────────────────────

function CarteCoursListe({ cours, index }: { cours: Cours; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="nk-carte p-4 flex items-center gap-4 hover:border-nk-primaire-300 cursor-pointer group"
    >
      <div className="w-16 h-16 rounded-lg bg-nk-espace-apprendre/10 flex items-center justify-center flex-shrink-0">
        <GraduationCap className="h-7 w-7 text-nk-espace-apprendre" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-nk-neutre-900 dark:text-nk-neutre-100 group-hover:text-nk-primaire-600 transition-colors">
          {cours.titre}
        </h3>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 truncate">{cours.description}</p>
      </div>
      <div className="flex items-center gap-6 text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
        {cours.progression > 0 && (
          <span className="font-medium text-nk-primaire-600">{cours.progression}%</span>
        )}
      </div>
      <ChevronRight className="h-5 w-5 text-nk-neutre-300 dark:text-nk-neutre-600 group-hover:text-nk-primaire-500 transition-colors" />
    </motion.div>
  );
}
