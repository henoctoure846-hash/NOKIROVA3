'use client';

/**
 * NOKIROVA — Espace Progression
 *
 * Gamification, niveaux, badges, séries, statistiques,
 * objectifs personnels et visualisation des progrès.
 *
 * Store intégré : useGamificationStore (stats, badges, classement, objectifs)
 * Dark mode complet sur tous les éléments.
 */
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3, Target, Award, Flame, TrendingUp,
  Calendar, Clock, Star, Zap, Trophy,
  ChevronRight, ArrowUpRight,
} from 'lucide-react';
import { useGamificationStore } from '@/stores/gamificationStore';
import type { StatistiquesProgression, Badge, Objectif, ClassementEntree } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

type OngletProgression = 'vue-ensemble' | 'badges' | 'objectifs' | 'statistiques';

// ─── Données de démonstration ─────────────────────────────────────────────────

const STATS_DEMO: StatistiquesProgression = {
  xp_total: 8750,
  niveau_actuel: 7,
  xp_niveau_actuel: 750,
  xp_prochain_niveau: 1000,
  streak_jours: 12,
  streak_max: 21,
  temps_total_min: 2890,
  cours_completes: 14,
  cours_en_cours: 6,
  flashcards_revisees: 230,
  quizzes_completes: 42,
  score_moyen: 78,
  documents_crees: 8,
  badges_debloques: 4,
  jours_actifs_mois: 18,
};

const BADGES_DEMO: Badge[] = [
  { id: '1', code: 'premier_pas', nom: 'Premier pas', description: 'Complétez votre première leçon', categorie: 'apprentissage', icone: '🌱', rarete: 'commun', xp_recompense: 50, conditions: {}, est_debloque: true, debloque_le: '2025-01-15' },
  { id: '2', code: 'bosseur', nom: 'Bosseur', description: '7 jours consécutifs de révision', categorie: 'streak', icone: '🔥', rarete: 'commun', xp_recompense: 100, conditions: {}, est_debloque: true, debloque_le: '2025-01-22' },
  { id: '3', code: 'quiz_master', nom: 'Quiz Master', description: '10 quiz avec 100% de bonnes réponses', categorie: 'revision', icone: '🎯', rarete: 'rare', xp_recompense: 200, conditions: {}, est_debloque: true, debloque_le: '2025-02-05' },
  { id: '4', code: 'ecrivain', nom: 'Écrivain', description: 'Rédigez 5 dissertations', categorie: 'production', icone: '✍️', rarete: 'rare', xp_recompense: 200, conditions: {}, est_debloque: true, debloque_le: '2025-02-12' },
  { id: '5', code: 'polyvalent', nom: 'Polyvalent', description: 'Étudiez 5 matières différentes', categorie: 'apprentissage', icone: '🌈', rarete: 'epique', xp_recompense: 500, conditions: {}, est_debloque: false, debloque_le: null },
  { id: '6', code: 'legende', nom: 'Légende', description: 'Atteignez le niveau 10', categorie: 'special', icone: '👑', rarete: 'legendaire', xp_recompense: 1000, conditions: {}, est_debloque: false, debloque_le: null },
  { id: '7', code: 'genereux', nom: 'Généreux', description: 'Aidez 50 personnes sur le forum', categorie: 'communaute', icone: '🤝', rarete: 'epique', xp_recompense: 500, conditions: {}, est_debloque: false, debloque_le: null },
  { id: '8', code: 'explorateur', nom: 'Explorateur', description: 'Explorez tous les espaces NOKIROVA', categorie: 'special', icone: '🧭', rarete: 'commun', xp_recompense: 100, conditions: {}, est_debloque: false, debloque_le: null },
];

const OBJECTIFS_DEMO: Objectif[] = [
  { id: '1', titre: 'Réviser les maths chaque jour', type: 'quotidien', cible: 7, actuel: 5, unite: 'jours', est_atteint: false, date_limite: '2025-03-31', xp_recompense: 100 },
  { id: '2', titre: 'Compléter le cours de physique', type: 'mensuel', cible: 100, actuel: 45, unite: '%', est_atteint: false, date_limite: '2025-04-15', xp_recompense: 300 },
  { id: '3', titre: 'Atteindre 10 000 XP', type: 'personnalise', cible: 10000, actuel: 8750, unite: 'XP', est_atteint: false, date_limite: '2025-03-30', xp_recompense: 500 },
];

const CLASSEMENT_DEMO: ClassementEntree[] = [
  { rang: 1, utilisateur_id: 'u3', pseudo: 'Sophie R.', avatar_url: null, niveau: 9, xp: 12500, streak: 18, badges_count: 8 },
  { rang: 2, utilisateur_id: 'u1', pseudo: 'Marie L.', avatar_url: null, niveau: 8, xp: 11200, streak: 14, badges_count: 6 },
  { rang: 3, utilisateur_id: 'u2', pseudo: 'Thomas B.', avatar_url: null, niveau: 7, xp: 10800, streak: 21, badges_count: 5 },
  { rang: 4, utilisateur_id: 'u4', pseudo: 'Lucas M.', avatar_url: null, niveau: 6, xp: 9600, streak: 9, badges_count: 4 },
  { rang: 5, utilisateur_id: 'u5', pseudo: 'Emma D.', avatar_url: null, niveau: 6, xp: 8900, streak: 7, badges_count: 3 },
];

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageProgression() {
  const [ongletActif, setOngletActif] = useState<OngletProgression>('vue-ensemble');
  const { stats, badges, objectifs, classement, setStats, setBadges, setObjectifs, setClassement } = useGamificationStore();

  // Initialisation des données démo si le store est vide
  useEffect(() => {
    if (!stats) setStats(STATS_DEMO);
    if (badges.length === 0) setBadges(BADGES_DEMO);
    if (objectifs.length === 0) setObjectifs(OBJECTIFS_DEMO);
    if (classement.length === 0) setClassement(CLASSEMENT_DEMO);
  }, [stats, badges.length, objectifs.length, classement.length, setStats, setBadges, setObjectifs, setClassement]);

  const onglets: { id: OngletProgression; label: string; icone: React.ReactNode }[] = [
    { id: 'vue-ensemble', label: "Vue d'ensemble", icone: <BarChart3 className="h-4 w-4" /> },
    { id: 'badges', label: 'Badges', icone: <Award className="h-4 w-4" /> },
    { id: 'objectifs', label: 'Objectifs', icone: <Target className="h-4 w-4" /> },
    { id: 'statistiques', label: 'Statistiques', icone: <TrendingUp className="h-4 w-4" /> },
  ];

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-progression/10 dark:bg-nk-espace-progression/20 flex items-center justify-center">
              <BarChart3 className="h-5 w-5 text-nk-espace-progression" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Progression</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Suivez votre évolution et atteignez vos objectifs
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Onglets */}
      <div className="px-6 py-3 border-b border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900 flex items-center gap-2">
        {onglets.map((onglet) => (
          <button
            key={onglet.id}
            onClick={() => setOngletActif(onglet.id)}
            className={`nk-bouton nk-bouton-sm gap-2 ${
              ongletActif === onglet.id
                ? 'nk-bouton-primaire'
                : 'nk-bouton-ghost'
            }`}
          >
            {onglet.icone} {onglet.label}
          </button>
        ))}
      </div>

      {/* Contenu */}
      <div className="nk-espace-contenu">
        {ongletActif === 'vue-ensemble' && <VueEnsemble />}
        {ongletActif === 'badges' && <Badges />}
        {ongletActif === 'objectifs' && <Objectifs />}
        {ongletActif === 'statistiques' && <Statistiques />}
      </div>
    </div>
  );
}

// ─── Vue d'ensemble ──────────────────────────────────────────────────────────

function VueEnsemble() {
  const stats = useGamificationStore((s) => s.stats);
  const badges = useGamificationStore((s) => s.badges);

  if (!stats) return null;

  const cartesStat = [
    { label: 'Niveau', valeur: `${stats.niveau_actuel}`, sousLabel: 'Explorateur', icone: <Zap className="h-5 w-5" />, couleur: 'text-nk-espace-progression', bg: 'bg-nk-espace-progression/10 dark:bg-nk-espace-progression/20' },
    { label: 'XP total', valeur: stats.xp_total.toLocaleString('fr-FR'), sousLabel: `+320 cette semaine`, icone: <Star className="h-5 w-5" />, couleur: 'text-nk-attention-500', bg: 'bg-nk-attention-50 dark:bg-nk-attention-900/30' },
    { label: 'Série active', valeur: `${stats.streak_jours}j`, sousLabel: `Record : ${stats.streak_max} jours`, icone: <Flame className="h-5 w-5" />, couleur: 'text-nk-danger-500', bg: 'bg-nk-danger-50 dark:bg-nk-danger-900/30' },
    { label: 'Badges', valeur: `${stats.badges_debloques}/${badges.length}`, sousLabel: `${stats.badges_debloques} débloqués`, icone: <Award className="h-5 w-5" />, couleur: 'text-nk-accent-600', bg: 'bg-nk-accent-50 dark:bg-nk-accent-900/30' },
  ];

  return (
    <div className="space-y-6">
      {/* Cartes statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cartesStat.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="nk-carte p-5"
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center ${stat.couleur}`}>
                {stat.icone}
              </div>
              <ArrowUpRight className="h-4 w-4 text-nk-accent-500" />
            </div>
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">{stat.valeur}</div>
            <div className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">{stat.label}</div>
            <div className="text-xs text-nk-accent-600 dark:text-nk-accent-400 mt-1">{stat.sousLabel}</div>
          </motion.div>
        ))}
      </div>

      {/* Barre de progression niveau */}
      <div className="nk-carte p-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">Progression de niveau</h2>
          <span className="text-sm font-medium text-nk-espace-progression">
            {stats.xp_niveau_actuel} / {stats.xp_prochain_niveau} XP
          </span>
        </div>
        <div className="h-4 bg-nk-neutre-100 dark:bg-nk-neutre-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${(stats.xp_niveau_actuel / stats.xp_prochain_niveau) * 100}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="h-full bg-nk-espace-progression rounded-full"
          />
        </div>
      </div>

      {/* Progression par matière */}
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Progression par matière</h2>
        <div className="space-y-4">
          {[
            { matiere: 'Mathématiques', progression: 72, couleur: 'bg-nk-espace-apprendre' },
            { matiere: 'Physique', progression: 45, couleur: 'bg-nk-espace-ia' },
            { matiere: 'Français', progression: 60, couleur: 'bg-nk-espace-produire' },
            { matiere: 'SVT', progression: 30, couleur: 'bg-nk-espace-reviser' },
          ].map((item) => (
            <div key={item.matiere}>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-nk-neutre-700 dark:text-nk-neutre-300 font-medium">{item.matiere}</span>
                <span className="text-nk-neutre-500 dark:text-nk-neutre-400">{item.progression}%</span>
              </div>
              <div className="h-3 bg-nk-neutre-100 dark:bg-nk-neutre-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${item.progression}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                  className={`h-full ${item.couleur} rounded-full`}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Derniers badges */}
      <div className="nk-carte p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">Derniers badges débloqués</h2>
          <ChevronRight className="h-5 w-5 text-nk-neutre-400 dark:text-nk-neutre-500" />
        </div>
        <div className="flex items-center gap-4">
          {badges.filter(b => b.est_debloque).slice(0, 4).map((badge) => (
            <div key={badge.id} className="text-center">
              <div className="w-14 h-14 rounded-full bg-nk-attention-50 dark:bg-nk-attention-900/30 flex items-center justify-center text-2xl mx-auto mb-1">
                {badge.icone}
              </div>
              <span className="text-xs text-nk-neutre-600 dark:text-nk-neutre-400">{badge.nom}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Badges ──────────────────────────────────────────────────────────────────

function Badges() {
  const badges = useGamificationStore((s) => s.badges);
  const debloques = badges.filter(b => b.est_debloque);
  const verrouilles = badges.filter(b => !b.est_debloque);

  // Couleur de rareté
  const couleurRarete = (rarete: string) => {
    switch (rarete) {
      case 'legendaire': return 'text-nk-attention-500';
      case 'epique': return 'text-nk-accent-600 dark:text-nk-accent-400';
      case 'rare': return 'text-nk-espace-progression';
      default: return 'text-nk-neutre-600 dark:text-nk-neutre-400';
    }
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <div>
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4 flex items-center gap-2">
          <Trophy className="h-5 w-5 text-nk-attention-500" /> Débloqués ({debloques.length})
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {debloques.map((badge, index) => (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="nk-carte p-4 text-center"
            >
              <div className="text-3xl mb-2">{badge.icone}</div>
              <h3 className="font-medium text-nk-neutre-800 dark:text-nk-neutre-200 text-sm">{badge.nom}</h3>
              <p className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400 mt-1">{badge.description}</p>
              <span className={"text-xs mt-2 block " + couleurRarete(badge.rarete)}>
                {badge.rarete.charAt(0).toUpperCase() + badge.rarete.slice(1)}
              </span>
              {badge.debloque_le && (
                <span className="text-xs text-nk-accent-600 dark:text-nk-accent-400 mt-1 block">
                  {new Date(badge.debloque_le).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                </span>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4 flex items-center gap-2">
          🔒 Verrouillés ({verrouilles.length})
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {verrouilles.map((badge, index) => (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 0.6, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="nk-carte p-4 text-center opacity-60 grayscale"
            >
              <div className="text-3xl mb-2">{badge.icone}</div>
              <h3 className="font-medium text-nk-neutre-800 dark:text-nk-neutre-200 text-sm">{badge.nom}</h3>
              <p className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400 mt-1">{badge.description}</p>
              <span className={"text-xs mt-2 block " + couleurRarete(badge.rarete)}>
                {badge.rarete.charAt(0).toUpperCase() + badge.rarete.slice(1)}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Objectifs ───────────────────────────────────────────────────────────────

function Objectifs() {
  const objectifs = useGamificationStore((s) => s.objectifs);

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">Mes objectifs</h2>
        <button className="nk-bouton nk-bouton-sm nk-bouton-primaire gap-1">
          <Target className="h-3.5 w-3.5" /> Nouvel objectif
        </button>
      </div>
      {objectifs.map((obj, index) => {
        const pourcentage = Math.min(100, Math.round((obj.actuel / obj.cible) * 100));
        return (
          <motion.div
            key={obj.id}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="nk-carte p-5"
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-nk-neutre-800 dark:text-nk-neutre-200">{obj.titre}</h3>
              <div className="flex items-center gap-2">
                <span className="nk-badge nk-badge-neutre">{obj.type}</span>
                {obj.est_atteint && <span className="nk-badge nk-badge-accent">✓ Atteint</span>}
              </div>
            </div>
            <div className="flex items-center gap-4 mb-3">
              <div className="flex-1">
                <div className="h-3 bg-nk-neutre-100 dark:bg-nk-neutre-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pourcentage}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                    className={`h-full rounded-full ${obj.est_atteint ? 'bg-nk-accent-500' : 'bg-nk-espace-progression'}`}
                  />
                </div>
              </div>
              <span className="text-sm font-medium text-nk-espace-progression">{pourcentage}%</span>
            </div>
            <div className="flex items-center justify-between text-xs text-nk-neutre-400 dark:text-nk-neutre-500">
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" /> Échéance : {new Date(obj.date_limite).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}
              </span>
              <span className="text-nk-accent-600 dark:text-nk-accent-400">+{obj.xp_recompense} XP</span>
            </div>
          </motion.div>
        );
      })}

      {objectifs.length === 0 && (
        <div className="text-center py-10 text-nk-neutre-400 dark:text-nk-neutre-500">
          Aucun objectif défini. Créez votre premier objectif !
        </div>
      )}
    </div>
  );
}

// ─── Statistiques ─────────────────────────────────────────────────────────────

function Statistiques() {
  const stats = useGamificationStore((s) => s.stats);

  if (!stats) return null;

  const formatDuree = (minutes: number) => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${h}h ${m < 10 ? '0' : ''}${m}min`;
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Temps d'étude */}
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4 flex items-center gap-2">
          <Clock className="h-5 w-5 text-nk-espace-progression" /> Temps d'étude
        </h2>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">2h 15min</div>
            <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">Aujourd'hui</div>
          </div>
          <div className="p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">12h 30min</div>
            <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">Cette semaine</div>
          </div>
          <div className="p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">{formatDuree(stats.temps_total_min)}</div>
            <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">Ce mois</div>
          </div>
        </div>
      </div>

      {/* Statistiques détaillées */}
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Statistiques détaillées</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'Cours complétés', valeur: stats.cours_completes, icone: '📚' },
            { label: 'Cours en cours', valeur: stats.cours_en_cours, icone: '📖' },
            { label: 'Flashcards révisées', valeur: stats.flashcards_revisees, icone: '🃏' },
            { label: 'Quiz complétés', valeur: stats.quizzes_completes, icone: '✅' },
            { label: 'Score moyen', valeur: `${stats.score_moyen}%`, icone: '📊' },
            { label: 'Documents créés', valeur: stats.documents_crees, icone: '📝' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-3 p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
              <span className="text-xl">{item.icone}</span>
              <div>
                <div className="text-lg font-bold text-nk-neutre-800 dark:text-nk-neutre-100">{item.valeur}</div>
                <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">{item.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activité par jour */}
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Activité cette semaine</h2>
        <div className="flex items-end gap-2 h-32">
          {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((jour, i) => {
            const hauteur = [60, 80, 45, 90, 70, 30, 50][i];
            return (
              <div key={jour} className="flex-1 flex flex-col items-center gap-1">
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${hauteur}%` }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="w-full bg-nk-espace-progression/20 dark:bg-nk-espace-progression/30 rounded-t"
                  style={{ minHeight: 4 }}
                />
                <span className="text-xs text-nk-neutre-400 dark:text-nk-neutre-500">{jour}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Classement rapide */}
      <div className="nk-carte p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">Votre position</h2>
          <ChevronRight className="h-5 w-5 text-nk-neutre-400 dark:text-nk-neutre-500" />
        </div>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-nk-espace-progression/10 dark:bg-nk-espace-progression/20 flex items-center justify-center">
            <Trophy className="h-6 w-6 text-nk-espace-progression" />
          </div>
          <div>
            <div className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">Position dans le classement</div>
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">#4</div>
          </div>
          <div className="ml-auto text-right">
            <div className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">Jours actifs ce mois</div>
            <div className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">{stats.jours_actifs_mois}/30</div>
          </div>
        </div>
      </div>
    </div>
  );
}
