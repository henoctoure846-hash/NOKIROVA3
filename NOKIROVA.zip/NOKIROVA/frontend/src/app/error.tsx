'use client';

/**
 * NOKIROVA — Page d'erreur globale
 */
'use client';

import { AlertTriangle, RotateCcw } from 'lucide-react';

export default function Erreur({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-full bg-nk-danger-50 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="h-8 w-8 text-nk-danger-500" />
        </div>
        <h2 className="text-xl font-semibold text-nk-neutre-800 mb-2">
          Une erreur est survenue
        </h2>
        <p className="text-nk-neutre-500 mb-6">
          {error.message || 'Quelque chose s\'est mal passé. Veuillez réessayer.'}
        </p>
        <button
          onClick={reset}
          className="nk-bouton-primaire nk-bouton-md gap-2"
        >
          <RotateCcw className="h-4 w-4" /> Réessayer
        </button>
      </div>
    </div>
  );
}
