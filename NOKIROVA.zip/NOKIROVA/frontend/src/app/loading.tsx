/**
 * NOKIROVA — Page de chargement globale
 */
export default function Chargement() {
  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-nk-primaire-200 border-t-nk-primaire-600 rounded-full animate-spin mx-auto mb-4" />
        <p className="text-nk-neutre-500">Chargement...</p>
      </div>
    </div>
  );
}
