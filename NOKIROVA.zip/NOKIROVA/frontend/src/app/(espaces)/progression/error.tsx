/**
 * NOKIROVA — Erreur espace Progression
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface ProgressionErreurProps {
  error: Error;
  reset: () => void;
}

export default function ProgressionErreur({ error, reset }: ProgressionErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger la progression"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement de vos statistiques et badges.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
