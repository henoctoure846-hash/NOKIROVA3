/**
 * NOKIROVA — Chargement espace Progression
 */

import { Skeleton } from '@/components/ui';

export default function ProgressionChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-52 mb-2" />
        <Skeleton className="h-4 w-64" />
      </div>
      <div className="nk-espace-contenu">
        {/* Stats globales */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        {/* Graphique de progression */}
        <Skeleton className="h-64 rounded-xl mb-8" />
        {/* Badges et achievements */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        {/* Historique des sessions */}
        <Skeleton className="h-48 rounded-xl" />
      </div>
    </div>
  );
}
