/**
 * NOKIROVA — Chargement espace Produire
 */

import { Skeleton } from '@/components/ui';

export default function ProduireChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-52 mb-2" />
        <Skeleton className="h-4 w-72" />
      </div>
      <div className="nk-espace-contenu">
        {/* Onglets création */}
        <div className="flex gap-2 mb-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-32 rounded-lg" />
          ))}
        </div>
        {/* Zone de création */}
        <Skeleton className="h-96 rounded-xl mb-6" />
        {/* Documents récents */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      </div>
    </div>
  );
}
