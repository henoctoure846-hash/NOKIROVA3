/**
 * NOKIROVA — Erreur espace Produire
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface ProduireErreurProps {
  error: Error;
  reset: () => void;
}

export default function ProduireErreur({ error, reset }: ProduireErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger l'espace Produire"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement de vos documents et outils de création.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
