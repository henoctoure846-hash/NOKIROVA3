/**
 * NOKIROVA — Erreur espace Paramètres
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface ParametresErreurProps {
  error: Error;
  reset: () => void;
}

export default function ParametresErreur({ error, reset }: ParametresErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger les paramètres"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement de vos paramètres.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
