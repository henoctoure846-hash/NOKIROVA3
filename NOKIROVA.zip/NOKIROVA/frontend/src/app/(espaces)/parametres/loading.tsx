/**
 * NOKIROVA — Chargement espace Paramètres
 */

import { Skeleton } from '@/components/ui';

export default function ParametresChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-52 mb-2" />
        <Skeleton className="h-4 w-64" />
      </div>
      <div className="nk-espace-contenu">
        {/* Navigation latérale paramètres */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Menu latéral */}
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 rounded-lg" />
            ))}
          </div>
          {/* Contenu paramètres */}
          <div className="lg:col-span-3 space-y-6">
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-48 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
}
