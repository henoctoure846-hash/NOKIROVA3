/**
 * NOKIROVA — Erreur espace Réviser
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface ReviserErreurProps {
  error: Error;
  reset: () => void;
}

export default function ReviserErreur({ error, reset }: ReviserErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger les révisions"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement de vos cartes et sessions de révision.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
