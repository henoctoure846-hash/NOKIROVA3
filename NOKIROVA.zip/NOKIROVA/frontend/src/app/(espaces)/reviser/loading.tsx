/**
 * NOKIROVA — Chargement espace Réviser
 */

import { Skeleton } from '@/components/ui';

export default function ReviserChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-48 mb-2" />
        <Skeleton className="h-4 w-64" />
      </div>
      <div className="nk-espace-contenu">
        {/* Onglets */}
        <div className="flex gap-2 mb-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-28 rounded-lg" />
          ))}
        </div>
        {/* Cartes de révision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))
          }
        </div>
        {/* Calendrier de révision */}
        <Skeleton className="h-64 rounded-xl" />
      </div>
    </div>
  );
}
