/**
 * NOKIROVA — Chargement espace Apprendre
 */

import { Skeleton } from '@/components/ui';

export default function ApprendreChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-56 mb-2" />
        <Skeleton className="h-4 w-80" />
      </div>
      <div className="nk-espace-contenu">
        {/* Barre de filtres */}
        <div className="flex gap-3 mb-6">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-9 w-20 rounded-full" />
          ))}
        </div>
        {/* Grille de cours */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      </div>
    </div>
  );
}
