/**
 * NOKIROVA — Erreur espace Apprendre
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface ApprendreErreurProps {
  error: Error;
  reset: () => void;
}

export default function ApprendreErreur({ error, reset }: ApprendreErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger les cours"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement du catalogue de cours.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
