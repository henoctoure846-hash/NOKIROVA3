/**
 * NOKIROVA — Erreur espace Communauté
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface CommunauteErreurProps {
  error: Error;
  reset: () => void;
}

export default function CommunauteErreur({ error, reset }: CommunauteErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger la communauté"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement du fil d\'actualité et des groupes.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
