/**
 * NOKIROVA — Chargement espace Communauté
 */

import { Skeleton } from '@/components/ui';

export default function CommunauteChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-52 mb-2" />
        <Skeleton className="h-4 w-72" />
      </div>
      <div className="nk-espace-contenu">
        {/* Onglets communauté */}
        <div className="flex gap-2 mb-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-24 rounded-lg" />
          ))}
        </div>
        {/* Fil d'actualité */}
        <div className="space-y-4 mb-8">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
        {/* Groupes + Classement */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Skeleton className="h-56 rounded-xl" />
          <Skeleton className="h-56 rounded-xl" />
        </div>
      </div>
    </div>
  );
}
