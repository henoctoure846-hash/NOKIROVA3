/**
 * NOKIROVA — Erreur espace IA Studio
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface IAStudioErreurProps {
  error: Error;
  reset: () => void;
}

export default function IAStudioErreur({ error, reset }: IAStudioErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger l'IA Studio"
          description={
            error.message ||
            'Une erreur est survenue lors du chargement de vos agents et sessions IA.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
