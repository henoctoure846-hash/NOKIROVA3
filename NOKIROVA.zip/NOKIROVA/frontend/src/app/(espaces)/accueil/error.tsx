/**
 * NOKIROVA — Erreur espace Accueil
 */

'use client';

import { Button, EmptyState } from '@/components/ui';

interface AccueilErreurProps {
  error: Error;
  reset: () => void;
}

export default function AccueilErreur({ error, reset }: AccueilErreurProps) {
  return (
    <div className="nk-espace">
      <div className="nk-espace-contenu">
        <EmptyState
          titre="Impossible de charger le tableau de bord"
          description={
            error.message ||
            'Une erreur inattendue est survenue lors du chargement de votre espace Accueil.'
          }
          texteAction="Réessayer"
          onAction={reset}
          varianteAction="primaire"
          taille="lg"
        />
      </div>
    </div>
  );
}
