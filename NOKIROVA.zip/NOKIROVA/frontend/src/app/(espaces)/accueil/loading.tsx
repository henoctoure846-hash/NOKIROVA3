/**
 * NOKIROVA — Chargement espace Accueil
 */

import { Skeleton } from '@/components/ui';

export default function AccueilChargement() {
  return (
    <div className="nk-espace">
      <div className="nk-espace-entete">
        <Skeleton className="h-8 w-48 mb-2" />
        <Skeleton className="h-4 w-72" />
      </div>
      <div className="nk-espace-contenu">
        {/* Statistiques */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        {/* Rappels + Recommandations */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
        {/* Activité récente */}
        <Skeleton className="h-48 rounded-xl" />
      </div>
    </div>
  );
}
