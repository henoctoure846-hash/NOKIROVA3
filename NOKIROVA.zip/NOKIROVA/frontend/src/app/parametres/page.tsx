'use client';

/**
 * NOKIROVA — Espace Paramètres
 *
 * Gestion du compte, préférences, abonnement, sécurité,
 * notifications, thème, accessibilité, données.
 *
 * Stores intégrés :
 * - useAuthStore (profil, connexion/déconnexion)
 * - useUIStore (thème clair/sombre/système)
 * - useNotificationsStore (préférences notifications)
 * Dark mode complet sur tous les éléments.
 */
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Settings, User, Shield, Bell, Palette,
  CreditCard, Download, Trash2, Moon, Sun,
  Monitor, Globe, Lock, Eye, EyeOff,
  ChevronRight, Check, AlertTriangle,
} from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useUIStore } from '@/stores/uiStore';
import { useNotificationsStore } from '@/stores/notificationsStore';
import type { Utilisateur } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

type SectionParam = 'profil' | 'securite' | 'notifications' | 'apparence' | 'abonnement' | 'donnees';

// ─── Données de démonstration ─────────────────────────────────────────────────

const UTILISATEUR_DEMO: Utilisateur = {
  id: 'u1',
  email: 'marie.lambert@exemple.fr',
  prenom: 'Marie',
  nom: 'Lambert',
  role: 'etudiant',
  plan: 'gratuit',
  niveau: 7,
  xp: 8750,
  streak_jours: 12,
  avatar_url: null,
  etablissement: 'Lycée Victor Hugo',
  bio: null,
  date_inscription: '2025-01-10',
  dernier_acces: new Date().toISOString(),
  est_actif: true,
  est_verifie: true,
  preferences: {
    theme: 'clair',
    langue: 'fr',
    notifications_email: true,
    notifications_push: true,
    notifications_sms: false,
    periode_tranquilite_debut: null,
    periode_tranquilite_fin: null,
    rappels_revision: true,
    rapport_hebdo: true,
  },
};

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageParametres() {
  const [sectionActive, setSectionActive] = useState<SectionParam>('profil');
  const { utilisateur, setUtilisateur } = useAuthStore();

  // Initialisation de l'utilisateur démo si non connecté
  useEffect(() => {
    if (!utilisateur) {
      setUtilisateur(UTILISATEUR_DEMO);
    }
  }, [utilisateur, setUtilisateur]);

  const sections: { id: SectionParam; label: string; icone: React.ReactNode }[] = [
    { id: 'profil', label: 'Profil', icone: <User className="h-4 w-4" /> },
    { id: 'securite', label: 'Sécurité', icone: <Shield className="h-4 w-4" /> },
    { id: 'notifications', label: 'Notifications', icone: <Bell className="h-4 w-4" /> },
    { id: 'apparence', label: 'Apparence', icone: <Palette className="h-4 w-4" /> },
    { id: 'abonnement', label: 'Abonnement', icone: <CreditCard className="h-4 w-4" /> },
    { id: 'donnees', label: 'Données', icone: <Download className="h-4 w-4" /> },
  ];

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-nk-neutre-200 dark:bg-nk-neutre-700 flex items-center justify-center">
            <Settings className="h-5 w-5 text-nk-neutre-600 dark:text-nk-neutre-300" />
          </div>
          <div>
            <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Paramètres</h1>
            <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
              Gérez votre compte et vos préférences
            </p>
          </div>
        </div>
      </div>

      <div className="nk-espace-contenu">
        <div className="flex gap-6 max-w-5xl mx-auto">
          {/* Navigation latérale */}
          <nav className="w-56 flex-shrink-0">
            <div className="nk-carte p-2 space-y-1">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setSectionActive(section.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                    sectionActive === section.id
                      ? 'bg-nk-primaire-50 dark:bg-nk-primaire-900/30 text-nk-primaire-700 dark:text-nk-primaire-300 font-medium'
                      : 'text-nk-neutre-600 dark:text-nk-neutre-400 hover:bg-nk-neutre-50 dark:hover:bg-nk-neutre-800'
                  }`}
                >
                  {section.icone} {section.label}
                </button>
              ))}
            </div>
          </nav>

          {/* Contenu */}
          <div className="flex-1">
            <motion.div
              key={sectionActive}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2 }}
            >
              {sectionActive === 'profil' && <SectionProfil />}
              {sectionActive === 'securite' && <SectionSecurite />}
              {sectionActive === 'notifications' && <SectionNotifications />}
              {sectionActive === 'apparence' && <SectionApparence />}
              {sectionActive === 'abonnement' && <SectionAbonnement />}
              {sectionActive === 'donnees' && <SectionDonnees />}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Section Profil (useAuthStore) ───────────────────────────────────────────

function SectionProfil() {
  const { utilisateur, setUtilisateur } = useAuthStore();

  // État local du formulaire
  const [prenom, setPrenom] = useState(utilisateur?.prenom ?? '');
  const [nom, setNom] = useState(utilisateur?.nom ?? '');
  const [email, setEmail] = useState(utilisateur?.email ?? '');
  const [etablissement, setEtablissement] = useState(utilisateur?.etablissement ?? '');

  // Synchroniser quand l'utilisateur du store change
  useEffect(() => {
    if (utilisateur) {
      setPrenom(utilisateur.prenom);
      setNom(utilisateur.nom);
      setEmail(utilisateur.email);
      setEtablissement(utilisateur.etablissement ?? '');
    }
  }, [utilisateur]);

  const enregistrerProfil = () => {
    if (!utilisateur) return;
    setUtilisateur({
      ...utilisateur,
      prenom,
      nom,
      email,
      etablissement: etablissement || null,
    });
  };

  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Informations personnelles</h2>
        <div className="flex items-center gap-6 mb-6">
          <div className="w-20 h-20 rounded-full bg-nk-primaire-100 dark:bg-nk-primaire-900/40 flex items-center justify-center text-3xl">
            👩‍🎓
          </div>
          <div>
            <button className="nk-bouton nk-bouton-sm nk-bouton-ghost">Changer la photo</button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Prénom</label>
            <input className="nk-input" value={prenom} onChange={(e) => setPrenom(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Nom</label>
            <input className="nk-input" value={nom} onChange={(e) => setNom(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Email</label>
            <input className="nk-input" value={email} onChange={(e) => setEmail(e.target.value)} type="email" />
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Établissement</label>
            <input className="nk-input" value={etablissement} onChange={(e) => setEtablissement(e.target.value)} />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button className="nk-bouton-primaire nk-bouton-md" onClick={enregistrerProfil}>Enregistrer</button>
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Résumé du compte</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Plan', valeur: utilisateur?.plan ?? 'gratuit', icone: '📋' },
            { label: 'Niveau', valeur: `${utilisateur?.niveau ?? 0}`, icone: '⭐' },
            { label: 'XP', valeur: `${(utilisateur?.xp ?? 0).toLocaleString('fr-FR')}`, icone: '✨' },
            { label: 'Série', valeur: `${utilisateur?.streak_jours ?? 0}j`, icone: '🔥' },
          ].map((item) => (
            <div key={item.label} className="p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
              <span className="text-lg">{item.icone}</span>
              <div className="text-lg font-bold text-nk-neutre-800 dark:text-nk-neutre-100 mt-1">{item.valeur}</div>
              <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Section Sécurité ───────────────────────────────────────────────────────

function SectionSecurite() {
  const [mdpVisible, setMdpVisible] = useState(false);

  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Changer le mot de passe</h2>
        <div className="space-y-4 max-w-md">
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Mot de passe actuel</label>
            <div className="relative">
              <input className="nk-input pr-10" type={mdpVisible ? 'text' : 'password'} />
              <button
                onClick={() => setMdpVisible(!mdpVisible)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-nk-neutre-400 dark:text-nk-neutre-500"
              >
                {mdpVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Nouveau mot de passe</label>
            <input className="nk-input" type="password" />
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Confirmer le mot de passe</label>
            <input className="nk-input" type="password" />
          </div>
          <button className="nk-bouton-primaire nk-bouton-md">Mettre à jour</button>
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Authentification à deux facteurs</h2>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 mb-4">
          Ajoutez une couche de sécurité supplémentaire à votre compte.
        </p>
        <button className="nk-bouton nk-bouton-md nk-bouton-ghost gap-2">
          <Lock className="h-4 w-4" /> Activer la 2FA
        </button>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Sessions actives</h2>
        <div className="space-y-3">
          {[
            { appareil: 'Chrome — MacOS', lieu: 'Paris, France', actif: true },
            { appareil: 'Safari — iPhone', lieu: 'Paris, France', actif: false },
          ].map((session, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-nk-neutre-50 dark:bg-nk-neutre-800">
              <div>
                <div className="text-sm font-medium text-nk-neutre-800 dark:text-nk-neutre-200">{session.appareil}</div>
                <div className="text-xs text-nk-neutre-400 dark:text-nk-neutre-500">{session.lieu}</div>
              </div>
              {session.actif && <span className="nk-badge nk-badge-accent">Actuelle</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Section Notifications (useNotificationsStore) ──────────────────────────

function SectionNotifications() {
  const { notifications, nonLues } = useNotificationsStore();
  const utilisateur = useAuthStore((s) => s.utilisateur);
  const setUtilisateur = useAuthStore((s) => s.setUtilisateur);

  // Préférences dérivées du store auth
  const prefs = utilisateur?.preferences ?? {
    notifications_email: true,
    notifications_push: true,
    notifications_sms: false,
    rappels_revision: true,
    rapport_hebdo: true,
  };

  const togglePref = (key: keyof typeof prefs) => {
    if (!utilisateur) return;
    setUtilisateur({
      ...utilisateur,
      preferences: {
        ...utilisateur.preferences,
        [key]: !prefs[key],
      },
    });
  };

  const labels: Record<string, string> = {
    notifications_email: 'Notifications par email',
    notifications_push: 'Notifications push',
    notifications_sms: 'Notifications SMS',
    rappels_revision: 'Rappels de révision',
    rapport_hebdo: 'Rapport hebdomadaire',
  };

  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">Préférences de notification</h2>
          {nonLues > 0 && (
            <span className="nk-badge nk-badge-accent">{nonLues} non lues</span>
          )}
        </div>
        <div className="space-y-4">
          {(Object.keys(labels) as (keyof typeof labels)[]).map((key) => (
            <div key={key} className="flex items-center justify-between py-2">
              <span className="text-sm text-nk-neutre-700 dark:text-nk-neutre-300">{labels[key]}</span>
              <button
                onClick={() => togglePref(key as keyof typeof prefs)}
                className={`relative w-10 h-6 rounded-full transition-colors ${
                  prefs[key as keyof typeof prefs]
                    ? 'bg-nk-primaire-500'
                    : 'bg-nk-neutre-200 dark:bg-nk-neutre-600'
                }`}
              >
                <span
                  className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform shadow ${
                    prefs[key as keyof typeof prefs] ? 'left-5' : 'left-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Notifications récentes</h2>
        <div className="space-y-2">
          {notifications.length > 0 ? notifications.slice(0, 5).map((n) => (
            <div
              key={n.id}
              className={`p-3 rounded-lg ${n.est_lue ? 'bg-nk-neutre-50 dark:bg-nk-neutre-800' : 'bg-nk-primaire-50 dark:bg-nk-primaire-900/20 border-l-2 border-nk-primaire-500'}`}
            >
              <div className="text-sm font-medium text-nk-neutre-800 dark:text-nk-neutre-200">{n.titre}</div>
              <div className="text-xs text-nk-neutre-500 dark:text-nk-neutre-400">{n.message}</div>
            </div>
          )) : (
            <p className="text-sm text-nk-neutre-400 dark:text-nk-neutre-500">Aucune notification pour le moment.</p>
          )}
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Période de tranquillité</h2>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 mb-4">
          Désactivez les notifications pendant certaines heures.
        </p>
        <div className="grid grid-cols-2 gap-4 max-w-sm">
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Début</label>
            <input className="nk-input" type="time" defaultValue="22:00" />
          </div>
          <div>
            <label className="block text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 mb-1">Fin</label>
            <input className="nk-input" type="time" defaultValue="07:00" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Section Apparence (useUIStore) ──────────────────────────────────────────

function SectionApparence() {
  // Thème courant depuis le store auth (préférences utilisateur)
  const utilisateur = useAuthStore((s) => s.utilisateur);
  const setUtilisateur = useAuthStore((s) => s.setUtilisateur);
  const theme = utilisateur?.preferences.theme ?? 'clair';

  const setTheme = (nouveauTheme: 'clair' | 'sombre' | 'systeme') => {
    if (!utilisateur) return;
    setUtilisateur({
      ...utilisateur,
      preferences: { ...utilisateur.preferences, theme: nouveauTheme },
    });
    // Appliquer le thème au document
    if (nouveauTheme === 'sombre') {
      document.documentElement.classList.add('dark');
    } else if (nouveauTheme === 'clair') {
      document.documentElement.classList.remove('dark');
    } else {
      // Système : suivre la préférence OS
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', prefersDark);
    }
  };

  const langue = utilisateur?.preferences.langue ?? 'fr';

  const setLangue = (nouvelleLangue: 'fr' | 'en' | 'es') => {
    if (!utilisateur) return;
    setUtilisateur({
      ...utilisateur,
      preferences: { ...utilisateur.preferences, langue: nouvelleLangue },
    });
  };

  const nomsLangues: Record<string, string> = { fr: 'Français (France)', en: 'English', es: 'Español' };

  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Thème</h2>
        <div className="grid grid-cols-3 gap-4 max-w-md">
          {[
            { id: 'clair' as const, label: 'Clair', icone: <Sun className="h-5 w-5" /> },
            { id: 'sombre' as const, label: 'Sombre', icone: <Moon className="h-5 w-5" /> },
            { id: 'systeme' as const, label: 'Système', icone: <Monitor className="h-5 w-5" /> },
          ].map((option) => (
            <button
              key={option.id}
              onClick={() => setTheme(option.id)}
              className={`nk-carte p-4 text-center transition-colors ${
                theme === option.id
                  ? 'border-nk-primaire-500 bg-nk-primaire-50 dark:bg-nk-primaire-900/30'
                  : 'hover:border-nk-neutre-300 dark:hover:border-nk-neutre-600'
              }`}
            >
              <div className={`mx-auto mb-2 ${theme === option.id ? 'text-nk-primaire-600 dark:text-nk-primaire-400' : 'text-nk-neutre-400 dark:text-nk-neutre-500'}`}>
                {option.icone}
              </div>
              <span className={`text-sm font-medium ${theme === option.id ? 'text-nk-primaire-700 dark:text-nk-primaire-300' : 'text-nk-neutre-600 dark:text-nk-neutre-400'}`}>
                {option.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Langue</h2>
        <div className="flex items-center gap-3">
          <Globe className="h-4 w-4 text-nk-neutre-500 dark:text-nk-neutre-400" />
          <select
            className="nk-input"
            value={langue}
            onChange={(e) => setLangue(e.target.value as 'fr' | 'en' | 'es')}
          >
            {Object.entries(nomsLangues).map(([code, nom]) => (
              <option key={code} value={code}>{nom}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Accessibilité</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-nk-neutre-700 dark:text-nk-neutre-300">Texte plus grand</span>
            <button className="relative w-10 h-6 rounded-full transition-colors bg-nk-neutre-200 dark:bg-nk-neutre-600">
              <span className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform shadow" />
            </button>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-nk-neutre-700 dark:text-nk-neutre-300">Réduction des animations</span>
            <button className="relative w-10 h-6 rounded-full transition-colors bg-nk-neutre-200 dark:bg-nk-neutre-600">
              <span className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform shadow" />
            </button>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-nk-neutre-700 dark:text-nk-neutre-300">Contraste élevé</span>
            <button className="relative w-10 h-6 rounded-full transition-colors bg-nk-neutre-200 dark:bg-nk-neutre-600">
              <span className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform shadow" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Section Abonnement ──────────────────────────────────────────────────────

function SectionAbonnement() {
  const utilisateur = useAuthStore((s) => s.utilisateur);
  const planActuel = utilisateur?.plan ?? 'gratuit';

  const plans = [
    {
      id: 'gratuit', nom: 'Gratuit', prix: '0€', periode: '',
      features: ['50K tokens/jour', '50 requêtes/jour', 'Accès limité', 'Publicités'],
    },
    {
      id: 'etudiant', nom: 'Étudiant', prix: '4,99€', periode: '/mois',
      features: ['200K tokens/jour', '200 requêtes/jour', 'Accès complet', 'Sans publicités'],
    },
    {
      id: 'premium', nom: 'Premium', prix: '9,99€', periode: '/mois',
      features: ['1M tokens/jour', '1 000 requêtes/jour', 'Accès prioritaire', 'Support dédié'],
    },
    {
      id: 'institution', nom: 'Institution', prix: '29,99€', periode: '/mois',
      features: ['10M tokens/jour', '10 000 requêtes/jour', 'Multi-utilisateurs', 'API dédiée'],
    },
  ];

  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Votre plan actuel</h2>
        <div className="flex items-center gap-3 mb-4">
          <span className="nk-badge nk-badge-neutre">Plan {planActuel.charAt(0).toUpperCase() + planActuel.slice(1)}</span>
          <span className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
            {planActuel === 'gratuit' ? 'Basique' : planActuel === 'etudiant' ? 'Études' : planActuel === 'premium' ? 'Avancé' : 'Complet'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`nk-carte p-5 ${plan.id === planActuel ? 'border-nk-primaire-500 dark:border-nk-primaire-400' : ''}`}
          >
            <h3 className="font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-1">{plan.nom}</h3>
            <div className="mb-4">
              <span className="text-2xl font-bold text-nk-neutre-800 dark:text-nk-neutre-100">{plan.prix}</span>
              <span className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">{plan.periode}</span>
            </div>
            <ul className="space-y-2 mb-4">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm text-nk-neutre-600 dark:text-nk-neutre-400">
                  <Check className="h-3.5 w-3.5 text-nk-accent-500" /> {f}
                </li>
              ))}
            </ul>
            <button
              className={`w-full nk-bouton nk-bouton-md ${
                plan.id === planActuel
                  ? 'nk-bouton-ghost cursor-default'
                  : 'nk-bouton-primaire'
              }`}
            >
              {plan.id === planActuel ? 'Plan actuel' : 'Choisir'}
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ─── Section Données ─────────────────────────────────────────────────────────

function SectionDonnees() {
  return (
    <div className="space-y-6">
      <div className="nk-carte p-6">
        <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">Exporter vos données</h2>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 mb-4">
          Téléchargez une copie de toutes vos données au format JSON ou CSV.
        </p>
        <div className="flex gap-3">
          <button className="nk-bouton nk-bouton-md nk-bouton-ghost gap-2">
            <Download className="h-4 w-4" /> Exporter en JSON
          </button>
          <button className="nk-bouton nk-bouton-md nk-bouton-ghost gap-2">
            <Download className="h-4 w-4" /> Exporter en CSV
          </button>
        </div>
      </div>

      <div className="nk-carte p-6 border-nk-danger-200 dark:border-nk-danger-800">
        <h2 className="text-lg font-semibold text-nk-danger-700 dark:text-nk-danger-400 mb-2 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" /> Zone dangereuse
        </h2>
        <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400 mb-4">
          Ces actions sont irréversibles. Vos données seront définitivement supprimées après 30 jours dans la corbeille.
        </p>
        <div className="flex gap-3">
          <button className="nk-bouton nk-bouton-md bg-nk-danger-50 dark:bg-nk-danger-900/30 text-nk-danger-700 dark:text-nk-danger-400 hover:bg-nk-danger-100 dark:hover:bg-nk-danger-900/50 gap-2">
            <Trash2 className="h-4 w-4" /> Supprimer le compte
          </button>
        </div>
      </div>
    </div>
  );
}
