'use client';

/**
 * NOKIROVA — Page Mission Control
 *
 * Tableau de bord de monitoring en temps réel :
 * - Santé des composants (PostgreSQL, Redis, IA, Event Bus)
 * - Statistiques de l'Event Bus
 * - Incidents de self-healing
 * - Métriques système (CPU, RAM, disque)
 * - Actions manuelles (vérification forcée)
 *
 * Principe BIBLE #10 Fiabilité : visibilité totale du système.
 * Principe BIBLE #12 Excellence : design soigné, données actionnables.
 *
 * Accessibilité :
 * - aria-labels sur toutes les jauges, cartes, sections
 * - aria-live sur les valeurs dynamiques
 * - role="status" sur les indicateurs de santé
 * - focus-visible rings sur tous les boutons
 * - aria-hidden sur les icônes décoratives
 * - role="img" + aria-label sur les jauges de progression
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, Database, Cpu, HardDrive, Radio,
  ShieldCheck, AlertTriangle, CheckCircle2,
  XCircle, RefreshCw, Zap, Server,
  ChevronDown, ChevronUp, Clock, Bug,
} from 'lucide-react';
import useMissionControl from '@/hooks/useMissionControl';

// ─── Composants utilitaires ───────────────────────────────────────────────────

function CarteStat({
  label, valeur, icone: Icone, couleur, sousLabel,
}: {
  label: string;
  valeur: string | number;
  icone: any;
  couleur: string;
  sousLabel?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white dark:bg-nk-neutre-800 rounded-2xl p-5 border border-nk-neutre-200 dark:border-nk-neutre-700 shadow-sm"
      role="status"
      aria-label={`${label} : ${valeur}${sousLabel ? ` — ${sousLabel}` : ''}`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">{label}</span>
        <Icone className={`h-5 w-5 ${couleur}`} aria-hidden="true" />
      </div>
      <p className="text-2xl font-bold text-nk-neutre-900 dark:text-white" aria-live="polite">
        {valeur}
      </p>
      {sousLabel && (
        <p className="text-xs text-nk-neutre-400 mt-1">{sousLabel}</p>
      )}
    </motion.div>
  );
}

function IndicateurSante({ nom, ok }: { nom: string; ok: boolean }) {
  return (
    <div
      className="flex items-center gap-2 py-2"
      role="status"
      aria-label={`${nom} : ${ok ? 'Opérationnel' : 'Indisponible'}`}
    >
      {ok ? (
        <CheckCircle2 className="h-4 w-4 text-nk-succes-500" aria-hidden="true" />
      ) : (
        <XCircle className="h-4 w-4 text-nk-avertissement-500" aria-hidden="true" />
      )}
      <span className="text-sm text-nk-neutre-700 dark:text-nk-neutre-300">{nom}</span>
      <span
        className={`text-xs font-medium px-2 py-0.5 rounded-full ${
          ok
            ? 'bg-nk-succes-50 text-nk-succes-700 dark:bg-nk-succes-900 dark:text-nk-succes-300'
            : 'bg-nk-avertissement-50 text-nk-avertissement-700 dark:bg-nk-avertissement-900 dark:text-nk-avertissement-300'
        }`
        }
        aria-live="polite"
      >
        {ok ? 'Opérationnel' : 'Indisponible'}
      </span>
    </div>
  );
}

function Jauge({ valeur, couleur, label }: { valeur: number; couleur: string; label?: string }) {
  const pourcentage = Math.min(Math.max(valeur, 0), 100);
  return (
    <div
      className="w-full bg-nk-neutre-100 dark:bg-nk-neutre-700 rounded-full h-2 overflow-hidden"
      role="progressbar"
      aria-valuenow={Math.round(pourcentage)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label ?? `Progression : ${Math.round(pourcentage)}%`}
    >
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${pourcentage}%` }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className={`h-full rounded-full ${couleur}`}
      />
    </div>
  );
}

// ─── Sections ────────────────────────────────────────────────────────────────

function SectionSante({ sante }: { sante: Record<string, any> }) {
  const [ouvert, setOuvert] = useState(true);

  const nomsComposants: Record<string, string> = {
    postgresql: 'PostgreSQL',
    redis: 'Redis',
    ia: 'IA (LLM)',
  event_bus: 'Event Bus',
    self_healing: 'Self-Healing',
    index_recherche: 'Index de recherche',
    queue_taches: 'File de tâches',
    websockets: 'WebSockets',
    plugins: 'Plugins',
    stockage: 'Stockage',
  };

  return (
    <section
      className="bg-white dark:bg-nk-neutre-800 rounded-2xl border border-nk-neutre-200 dark:border-nk-neutre-700 shadow-sm"
      aria-label="Santé des composants"
    >
      <button
        onClick={() => setOuvert(!ouvert)}
        className="w-full flex items-center justify-between p-5
          focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
        aria-expanded={ouvert}
        aria-controls="section-sante-contenu"
        aria-label="Santé des composants — développer ou réduire"
      >
        <div className="flex items-center gap-3">
          <Activity className="h-5 w-5 text-nk-primaire-600" aria-hidden="true" />
          <h3 className="font-titre font-semibold text-nk-neutre-900 dark:text-white">
            Santé des composants
          </h3>
        </div>
        {ouvert ? <ChevronUp className="h-4 w-4" aria-hidden="true" /> : <ChevronDown className="h-4 w-4" aria-hidden="true" />}
      </button>
      <AnimatePresence>
        {ouvert && (
          <motion.div
            id="section-sante-contenu"
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            className="overflow-hidden"
            role="region"
            aria-label="Liste des composants"
          >
            <div className="px-5 pb-5 space-y-1">
              {Object.entries(sante).map(([cle, val]) => (
                <IndicateurSante
                  key={cle}
                  nom={nomsComposants[cle] || cle}
                  ok={val?.ok ?? false}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

function SectionEventBus({ eventBus }: { eventBus: any }) {
  const publies = eventBus?.published ?? 0;
  const traites = eventBus?.processed ?? 0;
  const echoues = eventBus?.failed ?? 0;
  const deadLetters = eventBus?.dead_letter_count ?? 0;

  return (
    <section
      className="bg-white dark:bg-nk-neutre-800 rounded-2xl border border-nk-neutre-200 dark:border-nk-neutre-700 shadow-sm p-5"
      aria-label="Statistiques de l'Event Bus"
    >
      <div className="flex items-center gap-3 mb-4">
        <Radio className="h-5 w-5 text-violet-600" aria-hidden="true" />
        <h3 className="font-titre font-semibold text-nk-neutre-900 dark:text-white">
          Event Bus
        </h3>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <CarteStat
          label="Publiés"
          valeur={publies}
          icone={Zap}
          couleur="text-violet-500"
          sousLabel="Événements émis"
        />
        <CarteStat
          label="Traités"
          valeur={traites}
          icone={CheckCircle2}
          couleur="text-nk-succes-500"
          sousLabel="Événements consommés"
        />
        <CarteStat
          label="Échoués"
          valeur={echoues}
          icone={AlertTriangle}
          couleur="text-nk-avertissement-500"
          sousLabel="Dead-letters"
        />
        <CarteStat
          label="Dead Letter"
          valeur={deadLetters}
          icone={Bug}
          couleur="text-nk-erreur-500"
          sousLabel="File d'erreur"
        />
      </div>
    </section>
  );
}

function SectionSelfHealing({ selfHealing }: { selfHealing: any }) {
  const running = selfHealing?.running ?? false;
  const total = selfHealing?.total_incidents ?? 0;
  const resolus = selfHealing?.incidents_resolus ?? 0;
  const echoues = selfHealing?.incidents_echoues ?? 0;
  const escalades = selfHealing?.incidents_escalades ?? 0;
  const incidents24h = selfHealing?.incidents_24h ?? 0;
  const autoReparations24h = selfHealing?.auto_reparations_24h ?? 0;
  const strategies = selfHealing?.strategies_actives ?? 0;
  const incidentsActifs = selfHealing?.incidents_actifs ?? [];

  return (
    <section
      className="bg-white dark:bg-nk-neutre-800 rounded-2xl border border-nk-neutre-200 dark:border-nk-neutre-700 shadow-sm p-5"
      aria-label="Self-Healing — incidents et réparations"
    >
      <div className="flex items-center gap-3 mb-4">
        <ShieldCheck className="h-5 w-5 text-nk-succes-600" aria-hidden="true" />
        <h3 className="font-titre font-semibold text-nk-neutre-900 dark:text-white">
          Self-Healing
        </h3>
        <span
          className={`text-xs font-medium px-2 py-0.5 rounded-full ${
            running
              ? 'bg-nk-succes-50 text-nk-succes-700 dark:bg-nk-succes-900 dark:text-nk-succes-300'
              : 'bg-nk-neutre-100 text-nk-neutre-500'
          }`}
          role="status"
          aria-live="polite"
          aria-label={running ? 'Self-Healing actif' : 'Self-Healing en veille'}
        >
          {running ? 'Actif' : 'En veille'}
        </span>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-4">
        <CarteStat
          label="Stratégies"
          valeur={strategies}
          icone={ShieldCheck}
          couleur="text-nk-primaire-500"
        />
        <CarteStat
          label="Incidents 24h"
          valeur={incidents24h}
          icone={AlertTriangle}
          couleur="text-nk-avertissement-500"
        />
        <CarteStat
          label="Auto-réparations"
          valeur={autoReparations24h}
          icone={RefreshCw}
          couleur="text-nk-succes-500"
        />
      </div>

      {/* Taux de résolution */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm text-nk-neutre-500">Taux de résolution</span>
          <span
            className="text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300"
            aria-live="polite"
          >
            {total > 0 ? Math.round((resolus / total) * 100) : 100}%
          </span>
        </div>
        <Jauge
          valeur={total > 0 ? (resolus / total) * 100 : 100}
          couleur="bg-nk-succes-500"
          label="Taux de résolution des incidents"
        />
      </div>

      {/* Incidents actifs */}
      {incidentsActifs.length > 0 && (
        <div className="mt-4" role="list" aria-label="Incidents actifs">
          <h4 className="text-sm font-medium text-nk-neutre-600 dark:text-nk-neutre-400 mb-2">
            Incidents actifs
          </h4>
          <div className="space-y-2">
            {incidentsActifs.map((incident: any) => (
              <div
                key={incident.id}
                className="flex items-center gap-2 p-2 bg-nk-avertissement-50 dark:bg-nk-avertissement-900/30 rounded-lg"
                role="listitem"
                aria-label={`Incident ${incident.severity} : ${incident.message || incident.category} — ${incident.status}`}
              >
                <AlertTriangle className="h-4 w-4 text-nk-avertissement-500 flex-shrink-0" aria-hidden="true" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-nk-neutre-800 dark:text-white truncate">
                    {incident.message || incident.category}
                  </p>
                  <p className="text-xs text-nk-neutre-400">
                    {incident.severity} · {incident.status}
                  </p>
                </div>
                <Clock className="h-3 w-3 text-nk-neutre-400" aria-hidden="true" />
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function SectionMetriques({ metriques }: { metriques: any }) {
  const cpu = metriques?.cpu_pourcent ?? 0;
  const memoire = metriques?.memoire_pourcent ?? 0;
  const disque = metriques?.disque_pourcent ?? 0;

  const couleurJauge = (val: number) => {
    if (val < 60) return 'bg-nk-succes-500';
    if (val < 80) return 'bg-nk-avertissement-500';
    return 'bg-nk-erreur-500';
  };

  return (
    <section
      className="bg-white dark:bg-nk-neutre-800 rounded-2xl border border-nk-neutre-200 dark:border-nk-neutre-700 shadow-sm p-5"
      aria-label="Métriques système — CPU, mémoire, disque"
    >
      <div className="flex items-center gap-3 mb-4">
        <Server className="h-5 w-5 text-nk-info-600" aria-hidden="true" />
        <h3 className="font-titre font-semibold text-nk-neutre-900 dark:text-white">
          Métriques système
        </h3>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="h-4 w-4 text-nk-neutre-400" aria-hidden="true" />
            <span className="text-sm text-nk-neutre-600 dark:text-nk-neutre-400">CPU</span>
            <span
              className="text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 ml-auto"
              aria-live="polite"
            >
              {cpu}%
            </span>
          </div>
          <Jauge valeur={cpu} couleur={couleurJauge(cpu)} label="Utilisation CPU" />
        </div>

        <div>
          <div className="flex items-center gap-2 mb-1">
            <Database className="h-4 w-4 text-nk-neutre-400" aria-hidden="true" />
            <span className="text-sm text-nk-neutre-600 dark:text-nk-neutre-400">Mémoire</span>
            <span
              className="text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 ml-auto"
              aria-live="polite"
            >
              {memoire}%
            </span>
          </div>
          <Jauge valeur={memoire} couleur={couleurJauge(memoire)} label="Utilisation mémoire" />
        </div>

        <div>
          <div className="flex items-center gap-2 mb-1">
            <HardDrive className="h-4 w-4 text-nk-neutre-400" aria-hidden="true" />
            <span className="text-sm text-nk-neutre-600 dark:text-nk-neutre-400">Disque</span>
            <span
              className="text-sm font-medium text-nk-neutre-700 dark:text-nk-neutre-300 ml-auto"
              aria-live="polite"
            >
              {disque}%
            </span>
          </div>
          <Jauge valeur={disque} couleur={couleurJauge(disque)} label="Utilisation disque" />
        </div>
      </div>
    </section>
  );
}

// ─── Page principale ─────────────────────────────────────────────────────────

export default function PageMissionControl() {
  const {
    donnees,
    chargement,
    erreur,
    derniereMiseAJour,
    rafraichir,
    declencherVerification,
  } = useMissionControl(5000);

  const [verificationEnCours, setVerificationEnCours] = useState(false);

  const handleVerification = async () => {
    setVerificationEnCours(true);
    await declencherVerification();
    setTimeout(() => setVerificationEnCours(false), 3000);
  };

  return (
    <main
      className="min-h-screen bg-nk-neutre-50 dark:bg-nk-neutre-950 p-6 md:p-8"
      role="main"
      aria-label="Mission Control — Tableau de bord de monitoring"
    >
      {/* En-tête */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-nk-primaire-500 to-violet-500 flex items-center justify-center"
            aria-hidden="true"
          >
            <Activity className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-titre font-bold text-nk-neutre-900 dark:text-white">
              Mission Control
            </h1>
            <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
              Monitoring en temps réel du système NOKIROVA
            </p>
          </div>
        </div>

        {/* Barre d'actions */}
        <div className="flex items-center gap-3 mt-4" role="toolbar" aria-label="Actions Mission Control">
          <button
            onClick={rafraichir}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-nk-primaire-600 text-white text-sm font-medium hover:bg-nk-primaire-700 transition-colors
              focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-primaire-500 focus-visible:ring-offset-1"
            aria-label="Rafraîchir les données"
          >
            <RefreshCw className="h-4 w-4" aria-hidden="true" />
            Rafraîchir
          </button>
          <button
            onClick={handleVerification}
            disabled={verificationEnCours}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-nk-succes-600 text-white text-sm font-medium hover:bg-nk-succes-700 transition-colors disabled:opacity-50
              focus:outline-none focus-visible:ring-2 focus-visible:ring-nk-succes-500 focus-visible:ring-offset-1"
            aria-label={verificationEnCours ? 'Vérification en cours' : 'Lancer une vérification système'}
          >
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            {verificationEnCours ? 'Vérification...' : 'Vérifier maintenant'}
          </button>

          {/* Dernière mise à jour */}
          {derniereMiseAJour && (
            <span
              className="text-xs text-nk-neutre-400 ml-auto"
              role="status"
              aria-live="polite"
              aria-label={`Dernière mise à jour : ${new Date(derniereMiseAJour).toLocaleTimeString('fr-FR')}`}
            >
              Dernière MAJ : {new Date(derniereMiseAJour).toLocaleTimeString('fr-FR')}
            </span>
          )}
        </div>

        {/* Erreur */}
        {erreur && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-3 p-3 bg-nk-erreur-50 dark:bg-nk-erreur-900/20 text-nk-erreur-700 dark:text-nk-erreur-300 rounded-xl text-sm"
            role="alert"
            aria-live="assertive"
          >
            <AlertTriangle className="h-4 w-4 inline mr-2" aria-hidden="true" />
            {erreur}
          </motion.div>
        )}
      </div>

      {/* Contenu */}
      {chargement && !donnees ? (
        <div
          className="flex items-center justify-center h-64"
          role="status"
          aria-label="Chargement des données système en cours"
          aria-live="polite"
        >
          <RefreshCw className="h-8 w-8 text-nk-primaire-500 animate-spin" aria-hidden="true" />
          <span className="ml-3 text-nk-neutre-500">Chargement des données système...</span>
        </div>
      ) : donnees ? (
        <div className="space-y-6">
          {/* Statistiques rapides */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4" role="region" aria-label="Statistiques rapides du système">
            <CarteStat
              label="CPU"
              valeur={`${donnees.metriques?.cpu_pourcent ?? 0}%`}
              icone={Cpu}
              couleur="text-nk-info-500"
            />
            <CarteStat
              label="Mémoire"
              valeur={`${donnees.metriques?.memoire_pourcent ?? 0}%`}
              icone={Database}
              couleur="text-violet-500"
            />
            <CarteStat
              label="Self-Healing"
              valeur={donnees.self_healing?.running ? 'Actif' : 'Veille'}
              icone={ShieldCheck}
              couleur={donnees.self_healing?.running ? 'text-nk-succes-500' : 'text-nk-neutre-400'}
            />
            <CarteStat
              label="Event Bus"
              valeur={donnees.event_bus?.published ?? 0}
              icone={Radio}
              couleur="text-nk-primaire-500"
              sousLabel="Événements publiés"
            />
          </div>

          {/* Sections détaillées */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <SectionSante sante={donnees.sante} />
            <SectionEventBus eventBus={donnees.event_bus} />
            <SectionSelfHealing selfHealing={donnees.self_healing} />
            <SectionMetriques metriques={donnees.metriques} />
          </div>
        </div>
      ) : (
        <div
          className="text-center text-nk-neutre-500 py-12"
          role="status"
          aria-live="polite"
        >
          Aucune donnée disponible. Vérifiez que le backend est en cours d'exécution.
        </div>
      )}
    </main>
  );
}
