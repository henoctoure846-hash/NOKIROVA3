'use client';

/**
 * NOKIROVA — Page d'accueil (Espace Accueil)
 *
 * Dashboard principal avec :
 * - Message de bienvenue personnalisé
 * - Statistiques de progression (CarteStatistique)
 * - Rappels de révision (RappelRevisionWidget)
 * - Recommandations IA (RecommandationIAWidget)
 * - Activité récente (ActiviteRecienteWidget)
 * - Accès rapides (AccesRapidesWidget)
 */
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import {
  BookOpen,
  Brain,
  Sparkles,
  TrendingUp,
  Clock,
  ArrowRight,
} from 'lucide-react';

import { CarteStatistique } from '@/components/accueil/CarteStatistique';
import type { RappelRevision } from '@/types';
import { RappelRevisionWidget } from '@/components/accueil/RappelRevision';
import {
  RecommandationIAWidget,
  type Recommandation,
} from '@/components/accueil/RecommandationIA';
import {
  ActiviteRecienteWidget,
  type EntreeActivite,
} from '@/components/accueil/ActiviteReciente';
import { AccesRapidesWidget } from '@/components/accueil/AccesRapides';

import { useAuthStore } from '@/stores/authStore';
import { useRevisionStore } from '@/stores/revisionStore';
import { useGamificationStore } from '@/stores/gamificationStore';

// ─── Animations ──────────────────────────────────────────────────────────────

const variantConteneur = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const variantItem = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

// ─── Données temporaires (seront remplacées par les hooks API) ────────────────

const RAPPELS_MOCK: RappelRevision[] = [
  { id: 'r1', flashcard_id: 'fc-math-001', statut: 'en_retard' as const, date_prevue: '2026-08-16', note: 3 as const },
  { id: 'r2', flashcard_id: 'fc-phys-012', statut: 'en_retard' as const, date_prevue: '2026-08-15', note: 2 as const },
  { id: 'r3', flashcard_id: 'fc-fr-007', statut: 'prevu' as const, date_prevue: '2026-08-16', note: 4 as const },
  { id: 'r4', flashcard_id: 'fc-ang-023', statut: 'prevu' as const, date_prevue: '2026-08-16', note: 5 as const },
  { id: 'r5', flashcard_id: 'fc-hist-005', statut: 'fait' as const, date_prevue: '2026-08-16', note: 3 as const },
];

const RECOMMANDATIONS_MOCK: Recommandation[] = [
  {
    id: 'rec-1',
    type: 'revision',
    titre: 'Réviser les matrices',
    description: 'Votre taux de réussite sur les matrices a baissé. Il est temps de renforcer ce chapitre.',
    priorite: 'haute',
    actionLabel: 'Réviser maintenant',
    actionUrl: '/reviser?matiere=mathematiques&chapitre=matrices',
    raison: 'Taux de réussite passé de 85% à 62% sur les 5 dernières sessions.',
  },
  {
    id: 'rec-2',
    type: 'apprentissage',
    titre: 'Découvrir la mécanique quantique',
    description: 'Vous avez terminé le module classique. Le module suivant est disponible.',
    priorite: 'moyenne',
    actionLabel: 'Commencer le chapitre',
    actionUrl: '/apprendre?cours=physique-quantique',
    raison: 'Prérequis validés, module suivant débloqué dans votre parcours.',
  },
  {
    id: 'rec-3',
    type: 'objectif',
    titre: 'Atteindre 30 jours de série',
    description: 'Vous êtes à 7 jours ! Continuez pour débloquer le badge Persévérance.',
    priorite: 'basse',
    actionLabel: 'Voir mes objectifs',
    actionUrl: '/progression',
    raison: 'Badge Persévérance à 23 jours restants.',
  },
];

const ACTIVITES_MOCK: EntreeActivite[] = [
  {
    id: 'act-1',
    type: 'quiz_complete',
    titre: 'Quiz : Limites et continuité',
    description: 'Score : 8/10 — Très bien !',
    date: '2026-08-16T20:30:00Z',
    points: 45,
  },
  {
    id: 'act-2',
    type: 'flashcard_revisee',
    titre: '12 cartes révisées — Physique',
    date: '2026-08-16T19:00:00Z',
    points: 25,
  },
  {
    id: 'act-3',
    type: 'cours_debut',
    titre: 'Cours : Les probabilités conditionnelles',
    description: 'Chapitre 3 — Mathématiques',
    date: '2026-08-16T17:15:00Z',
  },
  {
    id: 'act-4',
    type: 'badge_obtenu',
    titre: 'Badge : Explorateur',
    description: 'Vous avez visité tous les espaces !',
    date: '2026-08-16T14:00:00Z',
    points: 100,
  },
  {
    id: 'act-5',
    type: 'document_cree',
    titre: 'Fiche de révision : Thermodynamique',
    date: '2026-08-16T11:30:00Z',
    points: 30,
  },
  {
    id: 'act-6',
    type: 'ia_interaction',
    titre: 'Session IA : Correction dissertation',
    description: 'Durée : 15 min',
    date: '2026-08-15T21:00:00Z',
    points: 20,
  },
];

// ─── Composant principal ─────────────────────────────────────────────────────

export default function PageAccueil() {
  const utilisateur = useAuthStore((s) => s.utilisateur);
  const prenom = utilisateur?.prenom ?? 'Étudiant';

  const gamification = useGamificationStore((s) => s);
  const streakJours = gamification.stats?.streak_jours ?? 7;
  const xpJour = gamification.stats?.xp_niveau_actuel ?? 145;

  const revision = useRevisionStore((s) => s);
  const cartesAReviser = revision.cartesAReviser?.length ?? 23;

  // À implémenter : Remplacer les données mock par les hooks API quand le backend sera connecté
  // const { data: rappels } = useRevision();
  // const { data: recommandations } = useAI();

  return (
    <div className="nk-espace">
      {/* ─── En-tête de bienvenue ─────────────────────────────── */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">
              Bonjour, {prenom} 👋
            </h1>
            <p className="mt-1 text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
              Voici votre résumé du jour. Continuez à progresser !
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
            <Clock className="h-4 w-4" />
            <span>
              {new Date().toLocaleDateString('fr-FR', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
              })}
            </span>
          </div>
        </div>
      </div>

      {/* ─── Contenu principal ──────────────────────────────── */}
      <motion.div
        className="nk-espace-contenu space-y-8"
        variants={variantConteneur}
        initial="hidden"
        animate="visible"
      >
        {/* ─── Statistiques rapides ───────────────────────── */}
        <motion.section variants={variantItem} aria-label="Vue d'ensemble">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">
            Vue d&apos;ensemble
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <CarteStatistique
              icone={<BookOpen className="h-5 w-5" />}
              label="Cours en cours"
              valeur={5}
              couleur="primaire"
              tendance="hausse"
              changement={12}
              sousTexte="2 terminés cette semaine"
            />
            <CarteStatistique
              icone={<Brain className="h-5 w-5" />}
              label="Cartes à réviser"
              valeur={cartesAReviser}
              couleur="accent"
              tendance="baisse"
              changement={-8}
              sousTexte="3 en retard aujourd'hui"
            />
            <CarteStatistique
              icone={<TrendingUp className="h-5 w-5" />}
              label="Série active"
              valeur={streakJours}
              suffixe="jours"
              couleur="succes"
              tendance="hausse"
            />
            <CarteStatistique
              icone={<Sparkles className="h-5 w-5" />}
              label="XP gagné aujourd'hui"
              valeur={xpJour}
              couleur="avertissement"
              tendance="hausse"
              changement={23}
            />
          </div>
        </motion.section>

        {/* ─── Rappels de révision ────────────────────────── */}
        <motion.section variants={variantItem} aria-label="Rappels de révision">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">
              Rappels de révision
            </h2>
            <a
              href="/reviser"
              className="nk-bouton-ghost nk-bouton-sm flex items-center gap-1"
            >
              Tout voir <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
          <RappelRevisionWidget
            rappels={RAPPELS_MOCK}
            enRetard={2}
            streakJours={streakJours}
            onDemarrerRevision={() => {
              // À implémenter : naviguer vers /reviser/session
              window.location.href = '/reviser';
            }}
            onVoirTout={() => {
              window.location.href = '/reviser';
            }}
          />
        </motion.section>

        {/* ─── Recommandations IA ─────────────────────────── */}
        <motion.section variants={variantItem} aria-label="Recommandations IA">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">
              Recommandations IA
            </h2>
            <a
              href="/ia-studio"
              className="nk-bouton-ghost nk-bouton-sm flex items-center gap-1"
            >
              IA Studio <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
          <RecommandationIAWidget
            recommandations={RECOMMANDATIONS_MOCK}
            onAction={(rec) => {
              // À implémenter : naviguer vers l'URL d'action
              window.location.href = rec.actionUrl;
            }}
            onIgnorer={(id) => {
            }}
            onRecharger={() => {
              // À implémenter : déclencher un rechargement via le store IA
            }}
          />
        </motion.section>

        {/* ─── Activité récente ──────────────────────────── */}
        <motion.section variants={variantItem} aria-label="Activité récente">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200">
              Activité récente
            </h2>
          </div>
          <ActiviteRecienteWidget
            activites={ACTIVITES_MOCK}
            limite={8}
            onVoirPlus={() => {
              window.location.href = '/progression';
            }}
          />
        </motion.section>

        {/* ─── Accès rapides ─────────────────────────────── */}
        <motion.section variants={variantItem} aria-label="Accès rapides">
          <h2 className="text-lg font-semibold text-nk-neutre-800 dark:text-nk-neutre-200 mb-4">
            Accès rapides
          </h2>
          <AccesRapidesWidget
            onAccesPersonnalise={(id) => {
            }}
          />
        </motion.section>
      </motion.div>
    </div>
  );
}
