/**
 * NOKIROVA — Page 404
 */
import Link from 'next/link';
import { Home, Search } from 'lucide-react';

export default function NonTrouve() {
  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center max-w-md">
        <div className="text-6xl font-titre font-bold text-nk-primaire-200 mb-4">404</div>
        <h2 className="text-xl font-semibold text-nk-neutre-800 mb-2">
          Page introuvable
        </h2>
        <p className="text-nk-neutre-500 mb-6">
          La page que vous recherchez n'existe pas ou a été déplacée.
        </p>
        <div className="flex gap-3 justify-center">
          <Link href="/" className="nk-bouton-primaire nk-bouton-md gap-2">
            <Home className="h-4 w-4" /> Accueil
          </Link>
          <Link href="/apprendre" className="nk-bouton nk-bouton-md nk-bouton-ghost gap-2">
            <Search className="h-4 w-4" /> Explorer
          </Link>
        </div>
      </div>
    </div>
  );
}
