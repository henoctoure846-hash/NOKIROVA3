'use client';

/**
 * NOKIROVA — Espace Réviser
 *
 * Flashcards, révision espacée, quiz, simulation d'examens.
 * Algorithme de répétition espacée adaptatif.
 * Intégré au store révision (cartes, session, notation).
 */
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain, RotateCcw, ChevronLeft, ChevronRight,
  CheckCircle, XCircle, Clock, BarChart3,
  Layers, Play, Star,
} from 'lucide-react';
import { useRevisionStore } from '@/stores/revisionStore';
import type { Flashcard, Matiere } from '@/types';

// ─── Données de démonstration ─────────────────────────────────────────────────

const FLASHCARDS_DEMO: Flashcard[] = [
  {
    id: '1',
        cours_id: 'demo',
    recto: 'Quelle est la dérivée de f(x) = x² ?',
    verso: "f'(x) = 2x. La dérivée d'une fonction puissance x^n est nx^(n-1).",
    matiere: 'mathematiques',
    difficulte: 'moyen',
    intervalle_jours: 3,
    prochaine_revision: new Date().toISOString(),
    nb_revisions: 2,
    derniere_note: 4,
    explication: 'La dérivée d\'une fonction puissance x^n est nx^(n-1), donc pour x² on obtient 2x.',
    cree_le: '2025-01-10T10:00:00Z',
  },
  {
    id: '2',
        cours_id: 'demo',
    recto: 'Énoncé du théorème de Pythagore',
    verso: "Dans un triangle rectangle, le carré de l'hypoténuse est égal à la somme des carrés des deux autres côtés : a² + b² = c²",
    matiere: 'mathematiques',
    difficulte: 'facile',
    intervalle_jours: 7,
    prochaine_revision: new Date().toISOString(),
    nb_revisions: 5,
    derniere_note: 5,
    explication: 'Théorème fondamental de géométrie, applicable uniquement aux triangles rectangles.',
    cree_le: '2025-01-08T08:00:00Z',
  },
  {
    id: '3',
        cours_id: 'demo',
    recto: "Qu'est-ce que la photosynthèse ?",
    verso: "Processus par lequel les plantes convertissent la lumière du soleil, le CO₂ et l'eau en glucose et oxygène : 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂",
    matiere: 'svt',
    difficulte: 'moyen',
    intervalle_jours: 5,
    prochaine_revision: new Date().toISOString(),
    nb_revisions: 1,
    derniere_note: 3,
    explication: 'Processus chimique essentiel à la vie des plantes, se déroulant dans les chloroplastes.',
    cree_le: '2025-01-12T14:00:00Z',
  },
  {
    id: '4',
        cours_id: 'demo',
    recto: 'Quelle est la formule de l\'accélération ?',
    verso: 'a = Δv / Δt. L\'accélération est la variation de la vitesse divisée par la variation du temps.',
    matiere: 'physique',
    difficulte: 'difficile',
    intervalle_jours: 2,
    prochaine_revision: new Date().toISOString(),
    nb_revisions: 1,
    derniere_note: 2,
    explication: 'Grandeur vectorielle exprimée en m/s², liée au changement de vitesse.',
    cree_le: '2025-01-15T09:00:00Z',
  },
  {
    id: '5',
        cours_id: 'demo',
    recto: 'Différence entre métaphore et comparaison ?',
    verso: 'La comparaison utilise un outil de comparaison (comme, tel que) tandis que la métaphore établit une identification directe sans outil.',
    matiere: 'francais',
    difficulte: 'facile',
    intervalle_jours: 10,
    prochaine_revision: new Date().toISOString(),
    nb_revisions: 4,
    derniere_note: 5,
    explication: 'La métaphore est une figure d\'identification, la comparaison utilise un outil explicite.',
    cree_le: '2025-01-05T11:00:00Z',
  },
];

const MATIERES_LABELS: Record<Matiere, string> = {
  mathematiques: 'Mathématiques',
  francais: 'Français',
  physique: 'Physique',
  chimie: 'Chimie',
  histoire: 'Histoire',
  geographie: 'Géographie',
  philosophie: 'Philosophie',
  anglais: 'Anglais',
  svt: 'SVT',
  ses: 'SES',
  informatique: 'Informatique',
  economie: 'Économie',
};

// ─── Types ────────────────────────────────────────────────────────────────────

type OngletRevision = 'flashcards' | 'quiz' | 'examens';

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function PageReviser() {
  const [ongletActif, setOngletActif] = useState<OngletRevision>('flashcards');
  const {
    cartesAReviser, carteActuelle, indexCarte,
    cartesRevisees, bonnesReponses,
    sessionEnCours, matiereSelectionnee, modeRevision,
    setCartesAReviser, setSessionEnCours,
    setMatiereSelectionnee, setModeRevision,
    reinitialiserSession,
  } = useRevisionStore();

  // Initialiser les données de démo au montage
  useEffect(() => {
    if (cartesAReviser.length === 0) {
      setCartesAReviser(FLASHCARDS_DEMO);
      setSessionEnCours({
        id: 'demo-session',
        utilisateur_id: 'demo',
        type: 'flashcards',
        matiere: null,
        carte_ids: FLASHCARDS_DEMO.map((f) => f.id),
        nb_cartes_total: FLASHCARDS_DEMO.length,
        nb_cartes_revisees: 0,
        score: null,
        debut: new Date().toISOString(),
        fin: null,
        duree_min: 0,
        est_complete: false,
      });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onglets: { id: OngletRevision; label: string; icone: React.ReactNode }[] = [
    { id: 'flashcards', label: 'Flashcards', icone: <Layers className="h-4 w-4" /> },
    { id: 'quiz', label: 'Quiz', icone: <Play className="h-4 w-4" /> },
    { id: 'examens', label: 'Examens blancs', icone: <BarChart3 className="h-4 w-4" /> },
  ];

  const tauxReussite = cartesRevisees > 0
    ? Math.round((bonnesReponses / cartesRevisees) * 100)
    : 0;

  return (
    <div className="nk-espace">
      {/* En-tête */}
      <div className="nk-espace-entete">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-nk-espace-reviser/10 flex items-center justify-center">
              <Brain className="h-5 w-5 text-nk-espace-reviser" />
            </div>
            <div>
              <h1 className="text-xl font-titre font-bold text-nk-neutre-900 dark:text-nk-neutre-100">Réviser</h1>
              <p className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
                Espacée, active et efficace avec l'IA
              </p>
            </div>
          </div>

          {/* Statistiques rapides */}
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-lg font-bold text-nk-espace-reviser">{cartesAReviser.length}</div>
              <div className="text-xs text-nk-neutre-400 dark:text-nk-neutre-500">À réviser</div>
            </div>
            <div className="w-px h-8 bg-nk-neutre-200 dark:bg-nk-neutre-700" />
            <div className="text-center">
              <div className="text-lg font-bold text-nk-accent-600">{tauxReussite}%</div>
              <div className="text-xs text-nk-neutre-400 dark:text-nk-neutre-500">Taux réussite</div>
            </div>
          </div>
        </div>
      </div>

      {/* Onglets */}
      <div className="px-6 py-3 border-b border-nk-neutre-200 dark:border-nk-neutre-700 bg-white dark:bg-nk-neutre-900 flex items-center gap-2">
        {onglets.map((onglet) => (
          <button
            key={onglet.id}
            onClick={() => setOngletActif(onglet.id)}
            className={`nk-bouton nk-bouton-sm gap-2 ${
              ongletActif === onglet.id
                ? 'nk-bouton-primaire'
                : 'nk-bouton-ghost'
            }`}
          >
            {onglet.icone} {onglet.label}
          </button>
        ))}

        {/* Sélecteur de mode */}
        <div className="ml-auto flex items-center gap-2">
          <select
            value={modeRevision}
            onChange={(e) => setModeRevision(e.target.value as typeof modeRevision)}
            className="nk-input text-sm py-1"
          >
            <option value="classique">Classique</option>
            <option value="difficile">Difficile</option>
            <option value="aleatoire">Aléatoire</option>
            <option value="examen_blanc">Examen blanc</option>
          </select>
        </div>
      </div>

      {/* Contenu par onglet */}
      <div className="nk-espace-contenu">
        <AnimatePresence mode="wait">
          {ongletActif === 'flashcards' && (
            <motion.div
              key="flashcards"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <FlashcardsInterface />
            </motion.div>
          )}
          {ongletActif === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <QuizInterface />
            </motion.div>
          )}
          {ongletActif === 'examens' && (
            <motion.div
              key="examens"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <ExamensInterface />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ─── Interface Flashcards ────────────────────────────────────────────────────

function FlashcardsInterface() {
  const [retourne, setRetourne] = useState(false);
  const {
    carteActuelle, indexCarte, cartesAReviser,
    cartesRevisees, bonnesReponses,
    avancerCarte, reculerCarte, noterCarte,
    reinitialiserSession,
  } = useRevisionStore();

  if (!carteActuelle) {
    return (
      <div className="text-center py-20">
        <CheckCircle className="h-16 w-16 text-nk-accent-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-nk-neutre-800 dark:text-nk-neutre-100 mb-2">
          Toutes les cartes révisées !
        </h2>
        <p className="text-nk-neutre-500 dark:text-nk-neutre-400 mb-2">
          {cartesRevisees} cartes révisées — {bonnesReponses} bonnes réponses
        </p>
        <p className="text-nk-neutre-400 dark:text-nk-neutre-500 mb-6">Revenez plus tard pour de nouvelles révisions.</p>
        <button
          onClick={() => { reinitialiserSession(); }}
          className="nk-bouton-primaire nk-bouton-md gap-2"
        >
          <RotateCcw className="h-4 w-4" /> Recommencer
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Compteur */}
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-nk-neutre-500 dark:text-nk-neutre-400">
          Carte {indexCarte + 1} / {cartesAReviser.length}
        </span>
        <span className="nk-badge nk-badge-neutre">{MATIERES_LABELS[carteActuelle.matiere]}</span>
      </div>

      {/* Carte */}
      <motion.div
        className="nk-carte min-h-[300px] cursor-pointer perspective-1000"
        onClick={() => setRetourne(!retourne)}
        animate={{ rotateY: retourne ? 180 : 0 }}
        transition={{ duration: 0.6 }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        <div
          className="p-8 flex flex-col items-center justify-center min-h-[300px]"
          style={{ backfaceVisibility: 'hidden' }}
        >
          <span className="nk-badge nk-badge-neutre mb-4">Recto</span>
          <p className="text-xl text-center font-medium text-nk-neutre-800 dark:text-nk-neutre-100">
            {carteActuelle.recto}
          </p>
          <p className="mt-4 text-sm text-nk-neutre-400 dark:text-nk-neutre-500">
            Cliquez pour révéler la réponse
          </p>
        </div>

        <div
          className="p-8 flex flex-col items-center justify-center min-h-[300px] absolute inset-0"
          style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
        >
          <span className="nk-badge nk-badge-accent mb-4">Verso</span>
          <p className="text-lg text-center text-nk-neutre-700 dark:text-nk-neutre-200">
            {carteActuelle.verso}
          </p>
        </div>
      </motion.div>

      {/* Navigation */}
      <div className="flex items-center justify-center gap-3 mt-6">
        <button
          onClick={() => { setRetourne(false); reculerCarte(); }}
          disabled={indexCarte === 0}
          className="nk-bouton nk-bouton-ghost nk-bouton-md gap-1"
        >
          <ChevronLeft className="h-4 w-4" /> Précédent
        </button>

        {retourne && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3"
          >
            <button
              onClick={() => {
                noterCarte(carteActuelle.id, 1);
                setRetourne(false);
                avancerCarte();
              }}
              className="nk-bouton nk-bouton-lg bg-nk-danger-100 dark:bg-nk-danger-900/30 text-nk-danger-700 hover:bg-nk-danger-200"
            >
              <XCircle className="h-5 w-5" /> À revoir
            </button>
            <button
              onClick={() => {
                noterCarte(carteActuelle.id, 5);
                setRetourne(false);
                avancerCarte();
              }}
              className="nk-bouton nk-bouton-lg bg-nk-accent-100 dark:bg-nk-accent-900/30 text-nk-accent-700 hover:bg-nk-accent-200"
            >
              <CheckCircle className="h-5 w-5" /> Compris !
            </button>
          </motion.div>
        )}

        <button
          onClick={() => { setRetourne(false); avancerCarte(); }}
          disabled={indexCarte >= cartesAReviser.length - 1}
          className="nk-bouton nk-bouton-ghost nk-bouton-md gap-1"
        >
          Suivant <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Mini-stats session */}
      <div className="flex items-center justify-center gap-6 mt-8 text-xs text-nk-neutre-400 dark:text-nk-neutre-500">
        <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3 text-nk-accent-500" /> {bonnesReponses} correctes</span>
        <span className="flex items-center gap-1"><XCircle className="h-3 w-3 text-nk-danger-500" /> {cartesRevisees - bonnesReponses} à revoir</span>
        <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {cartesRevisees} / {cartesAReviser.length}</span>
      </div>
    </div>
  );
}

// ─── Interface Quiz ──────────────────────────────────────────────────────────

function QuizInterface() {
  return (
    <div className="max-w-2xl mx-auto text-center py-12">
      <Play className="h-16 w-16 text-nk-espace-reviser mx-auto mb-4" />
      <h2 className="text-xl font-semibold text-nk-neutre-800 dark:text-nk-neutre-100 mb-2">
        Quiz adaptatif
      </h2>
      <p className="text-nk-neutre-500 dark:text-nk-neutre-400 mb-6">
        L'IA génère des quiz personnalisés selon votre niveau et vos lacunes.
      </p>
      <button className="nk-bouton-primaire nk-bouton-lg gap-2">
        <Play className="h-5 w-5" /> Démarrer un quiz
      </button>
    </div>
  );
}

// ─── Interface Examens ──────────────────────────────────────────────────────

function ExamensInterface() {
  return (
    <div className="max-w-2xl mx-auto text-center py-12">
      <BarChart3 className="h-16 w-16 text-nk-espace-reviser mx-auto mb-4" />
      <h2 className="text-xl font-semibold text-nk-neutre-800 dark:text-nk-neutre-100 mb-2">
        Examens blancs
      </h2>
      <p className="text-nk-neutre-500 dark:text-nk-neutre-400 mb-6">
        Simulez les conditions réelles d'examen pour vous préparer efficacement.
      </p>
      <button className="nk-bouton-primaire nk-bouton-lg gap-2">
        <Star className="h-5 w-5" /> Créer un examen blanc
      </button>
    </div>
  );
}
