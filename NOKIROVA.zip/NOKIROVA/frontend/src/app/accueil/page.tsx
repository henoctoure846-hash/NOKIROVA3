/**
 * NOKIROVA — Espace Accueil
 *
 * Redirige vers la page racine qui est l'accueil.
 */
import PageAccueil from '../page';
export default PageAccueil;
