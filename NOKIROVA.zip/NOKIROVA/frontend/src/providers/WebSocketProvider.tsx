'use client';

/**
 * NOKIROVA — Fournisseur WebSocket
 *
 * Connexion temps réel via Socket.IO.
 * Gère la reconnexion automatique, les événements
 * et les canaux par espace.
 */
'use client';

import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

// ─── Types ────────────────────────────────────────────────────────────────────

type TypeEvenement =
  | 'notification_nouvelle'
  | 'message_nouveau'
  | 'revision_rappel'
  | 'xp_gagne'
  | 'badge_debloque'
  | 'cours_mis_a_jour'
  | 'communaute_publication'
  | 'ia_reponse'
  | 'sync_donnees'
  | 'utilisateur_en_ligne'
  | 'utilisateur_hors_ligne';

interface EvenementWS {
  type: TypeEvenement;
  charge_utile: unknown;
  horodatage: string;
  canal: string;
}

interface WebSocketContexte {
  estConnecte: boolean;
  sAbonner: (type: TypeEvenement, callback: (data: unknown) => void) => () => void;
  emettre: (type: TypeEvenement, data: unknown) => void;
  rejoindreCanal: (canal: string) => void;
  quitterCanal: (canal: string) => void;
  derniereActivite: Date | null;
}

const WebSocketContexte = createContext<WebSocketContexte | null>(null);

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useWebSocket() {
  const ctx = useContext(WebSocketContexte);
  if (!ctx) throw new Error('useWebSocket doit être utilisé dans WebSocketProvider');
  return ctx;
}

// ─── Provider ─────────────────────────────────────────────────────────────────

export function WebSocketProvider({ enfants: enfantsProp, children }: { enfants?: React.ReactNode; children?: React.ReactNode }) {
        const enfants = enfantsProp ?? children;
  const socketRef = useRef<Socket | null>(null);
  const [estConnecte, setEstConnecte] = useState(false);
  const [derniereActivite, setDerniereActivite] = useState<Date | null>(null);
  const abonnementsRef = useRef<Map<TypeEvenement, Set<(data: unknown) => void>>>(new Map());

  useEffect(() => {
    // Connexion au serveur WebSocket
    const socket = io(process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:8000', {
      path: '/ws',
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 20,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 30000,
      timeout: 10000,
      autoConnect: true,
    });

    socketRef.current = socket;

    // ── Événements de connexion ──
    socket.on('connect', () => {
      setEstConnecte(true);
      setDerniereActivite(new Date());
    });

    socket.on('disconnect', (raison) => {
      setEstConnecte(false);
      console.warn('[WS] Déconnecté :', raison);
    });

    socket.on('connect_error', (err) => {
      setEstConnecte(false);
      console.error('[WS] Erreur connexion :', err.message);
    });

    // ── Routage des événements vers les abonnés ──
    socket.on('evenement', (evt: EvenementWS) => {
      setDerniereActivite(new Date());
      const abonnes = abonnementsRef.current.get(evt.type);
      if (abonnes) {
        abonnes.forEach((cb) => {
          try { cb(evt.charge_utile); } catch (e) { console.error('[WS] Erreur callback:', e); }
        });
      }
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, []);

  // ── S'abonner à un type d'événement ──
  const sAbonner = useCallback((type: TypeEvenement, callback: (data: unknown) => void) => {
    if (!abonnementsRef.current.has(type)) {
      abonnementsRef.current.set(type, new Set());
    }
    abonnementsRef.current.get(type)!.add(callback);

    // Retourner la fonction de désabonnement
    return () => {
      abonnementsRef.current.get(type)?.delete(callback);
    };
  }, []);

  // ── Émettre un événement ──
  const emettre = useCallback((type: TypeEvenement, data: unknown) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('evenement', {
        type,
        charge_utile: data,
        horodatage: new Date().toISOString(),
      });
    }
  }, []);

  // ── Rejoindre un canal ──
  const rejoindreCanal = useCallback((canal: string) => {
    socketRef.current?.emit('rejoindre', { canal });
  }, []);

  // ── Quitter un canal ──
  const quitterCanal = useCallback((canal: string) => {
    socketRef.current?.emit('quitter', { canal });
  }, []);

  const valeur: WebSocketContexte = {
    estConnecte,
    sAbonner,
    emettre,
    rejoindreCanal,
    quitterCanal,
    derniereActivite,
  };

  return <WebSocketContexte.Provider value={valeur}>{enfants}</WebSocketContexte.Provider>;
}
