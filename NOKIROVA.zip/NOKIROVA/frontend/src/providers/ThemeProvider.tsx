'use client';

/**
 * NOKIROVA — Fournisseur de thème
 *
 * Gestion clair/sombre/système avec
 * persistance localStorage.
 */
'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

type Theme = 'clair' | 'sombre' | 'systeme';

interface ThemeContexte {
  theme: Theme;
  estSombre: boolean;
  changerTheme: (theme: Theme) => void;
}

const ThemeCtx = createContext<ThemeContexte | null>(null);

export function useTheme() {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error('useTheme doit être utilisé dans ThemeProvider');
  return ctx;
}

export function ThemeProvider({ enfants }: { enfants: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('nk_theme') as Theme) || 'systeme';
    }
    return 'systeme';
  });

  const [estSombre, setEstSombre] = useState(false);

  const appliquerTheme = useCallback((t: Theme) => {
    const sombre =
      t === 'sombre' ||
      (t === 'systeme' && window.matchMedia('(prefers-color-scheme: dark)').matches);

    setEstSombre(sombre);
    document.documentElement.classList.toggle('dark', sombre);
  }, []);

  useEffect(() => {
    appliquerTheme(theme);
    localStorage.setItem('nk_theme', theme);

    // Écouter les changements système si mode système
    if (theme === 'systeme') {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      const handler = (e: MediaQueryListEvent) => {
        setEstSombre(e.matches);
        document.documentElement.classList.toggle('dark', e.matches);
      };
      media.addEventListener('change', handler);
      return () => media.removeEventListener('change', handler);
    }
  }, [theme, appliquerTheme]);

  const changerTheme = useCallback((nouveau: Theme) => {
    setTheme(nouveau);
  }, []);

  return (
    <ThemeCtx.Provider value={{ theme, estSombre, changerTheme }}>
      {enfants}
    </ThemeCtx.Provider>
  );
}
