'use client';

/**
 * NOKIROVA — Fournisseur d'authentification
 *
 * Gère l'état de connexion, le token JWT,
 * le rafraîchissement automatique, et les rôles.
 */
'use client';

import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Utilisateur {
  id: string;
  email: string;
  prenom: string;
  nom: string;
  role: 'etudiant' | 'enseignant' | 'admin' | 'institution';
  plan: 'gratuit' | 'etudiant' | 'premium' | 'institution';
  niveau: number;
  xp: number;
  avatar_url: string | null;
  etablissement: string | null;
  cree_le: string;
  dernier_acces: string;
}

interface AuthContexte {
  utilisateur: Utilisateur | null;
  estConnecte: boolean;
  estChargement: boolean;
  token: string | null;
  connexion: (email: string, mdp: string) => Promise<void>;
  inscription: (donnees: Partial<Utilisateur> & { mdp: string }) => Promise<void>;
  deconnexion: () => void;
  rafraichirToken: () => Promise<string | null>;
  mettreAJourProfil: (donnees: Partial<Utilisateur>) => Promise<void>;
}

const AuthContexte = createContext<AuthContexte | null>(null);

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useAuth() {
  const ctx = useContext(AuthContexte);
  if (!ctx) throw new Error('useAuth doit être utilisé dans AuthProvider');
  return ctx;
}

/** Alias pour useAuth — utilisé par les ré-exports */
export const useAuthContext = useAuth;

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AuthProvider({ enfants: enfantsProp, children }: { enfants?: React.ReactNode; children?: React.ReactNode }) {
        const enfants = enfantsProp ?? children;
  const [utilisateur, setUtilisateur] = useState<Utilisateur | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [estChargement, setEstChargement] = useState(true);
  const timerRafraichissement = useRef<NodeJS.Timeout | null>(null);

  // ── Restaurer la session au montage ──
  useEffect(() => {
    const tokenSauvegarde = localStorage.getItem('nk_token');
    const userSauvegarde = localStorage.getItem('nk_user');

    if (tokenSauvegarde && userSauvegarde) {
      try {
        setToken(tokenSauvegarde);
        setUtilisateur(JSON.parse(userSauvegarde));
        demarrerRafraichissement(tokenSauvegarde);
      } catch {
        localStorage.removeItem('nk_token');
        localStorage.removeItem('nk_user');
      }
    }
    setEstChargement(false);
  }, []);

  // ── Rafraîchissement automatique du token (5 min avant expiration) ──
  const demarrerRafraichissement = (tok: string) => {
    if (timerRafraichissement.current) clearInterval(timerRafraichissement.current);

    try {
      const payload = JSON.parse(atob(tok.split('.')[1]));
      const delai = Math.max((payload.exp * 1000) - Date.now() - 5 * 60 * 1000, 0);
      timerRafraichissement.current = setTimeout(async () => {
        await rafraichirToken();
      }, delai);
    } catch {
      // Token invalide, on ne planifie rien
    }
  };

  // ── Connexion ──
  const connexion = useCallback(async (email: string, mdp: string) => {
    const rep = await fetch('/api/v1/auth/connexion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, mot_de_passe: mdp }),
    });

    if (!rep.ok) {
      const err = await rep.json();
      throw new Error(err.message || 'Erreur de connexion');
    }

    const { data } = await rep.json();
    setToken(data.token);
    setUtilisateur(data.utilisateur);
    localStorage.setItem('nk_token', data.token);
    localStorage.setItem('nk_user', JSON.stringify(data.utilisateur));
    demarrerRafraichissement(data.token);
  }, []);

  // ── Inscription ──
  const inscription = useCallback(async (donnees: Partial<Utilisateur> & { mdp: string }) => {
    const rep = await fetch('/api/v1/auth/inscription', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(donnees),
    });

    if (!rep.ok) {
      const err = await rep.json();
      throw new Error(err.message || 'Erreur d\'inscription');
    }

    const { data } = await rep.json();
    setToken(data.token);
    setUtilisateur(data.utilisateur);
    localStorage.setItem('nk_token', data.token);
    localStorage.setItem('nk_user', JSON.stringify(data.utilisateur));
  }, []);

  // ── Déconnexion ──
  const deconnexion = useCallback(() => {
    setToken(null);
    setUtilisateur(null);
    localStorage.removeItem('nk_token');
    localStorage.removeItem('nk_user');
    if (timerRafraichissement.current) clearTimeout(timerRafraichissement.current);
  }, []);

  // ── Rafraîchir le token ──
  const rafraichirToken = useCallback(async (): Promise<string | null> => {
    try {
      const rep = await fetch('/api/v1/auth/rafraichir', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!rep.ok) {
        deconnexion();
        return null;
      }

      const { data } = await rep.json();
      setToken(data.token);
      localStorage.setItem('nk_token', data.token);
      demarrerRafraichissement(data.token);
      return data.token;
    } catch {
      deconnexion();
      return null;
    }
  }, [token, deconnexion]);

  // ── Mise à jour profil ──
  const mettreAJourProfil = useCallback(async (donnees: Partial<Utilisateur>) => {
    const rep = await fetch('/api/v1/utilisateurs/moi', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(donnees),
    });

    if (!rep.ok) {
      const err = await rep.json();
      throw new Error(err.message || 'Erreur de mise à jour');
    }

    const { data } = await rep.json();
    setUtilisateur(data);
    localStorage.setItem('nk_user', JSON.stringify(data));
  }, [token]);

  const valeur: AuthContexte = {
    utilisateur,
    estConnecte: !!utilisateur,
    estChargement,
    token,
    connexion,
    inscription,
    deconnexion,
    rafraichirToken,
    mettreAJourProfil,
  };

  return <AuthContexte.Provider value={valeur}>{enfants}</AuthContexte.Provider>;
}
