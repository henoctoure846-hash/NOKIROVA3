'use client';

/**
 * NOKIROVA — Fournisseur TanStack Query
 *
 * Configuration du client de requêtes :
 * - Retry automatique (3 tentatives)
 * - Stale time 5 min
 * - Cache time 10 min
 * - Refetch on reconnect
 */
'use client';

import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

export function QueryProvider({ enfants }: { enfants: React.ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            retry: 3,
            retryDelay: (tentative) => Math.min(tentative * 1000, 5000),
            staleTime: 5 * 60 * 1000, // 5 minutes
            gcTime: 10 * 60 * 1000, // 10 minutes (anciennement cacheTime)
            refetchOnWindowFocus: false,
            refetchOnReconnect: true,
            networkMode: 'offlineFirst',
          },
          mutations: {
            retry: 1,
            networkMode: 'online',
          },
        },
      })
  );

  return <QueryClientProvider client={client}>{enfants}</QueryClientProvider>;
}
