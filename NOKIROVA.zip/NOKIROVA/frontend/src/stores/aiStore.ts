/**
 * NOKIROVA — Store IA (Zustand)
 *
 * Sessions IA, quota, agent actif,
 * historique des conversations.
 */

import { create } from 'zustand';
import type { SessionIA, MessageIA, AgentIA, QuotaIA } from '@/types';

interface AIState {
  sessionActive: SessionIA | null;
  messages: MessageIA[];
  agentActif: AgentIA;
  agentsDisponibles: AgentIA[];
  quota: QuotaIA | null;
  estGeneration: boolean;
  streaming: boolean;
  erreur: string | null;

  // Actions
  setSessionActive: (session: SessionIA | null) => void;
  ajouterMessage: (msg: MessageIA) => void;
  majDernierMessage: (contenu: string) => void;
  setAgentActif: (agent: AgentIA) => void;
  setQuota: (quota: QuotaIA) => void;
  setGeneration: (v: boolean) => void;
  setStreaming: (v: boolean) => void;
  setErreur: (err: string | null) => void;
  reinitialiser: () => void;
}

const AGENTS_PAR_DEFAUT: AgentIA[] = [
  'tuteur', 'correcteur', 'generateur_flashcards',
  'generateur_quiz', 'assistant_cours', 'analyseur_progression',
];

export const useAIStore = create<AIState>()((set, get) => ({
  sessionActive: null,
  messages: [],
  agentActif: 'tuteur',
  agentsDisponibles: AGENTS_PAR_DEFAUT,
  quota: null,
  estGeneration: false,
  streaming: false,
  erreur: null,

  setSessionActive: (session) => set({ sessionActive: session }),

  ajouterMessage: (msg) => set((s) => ({ messages: [...s.messages, msg] })),

  majDernierMessage: (contenu) => set((s) => {
    const msgs = [...s.messages];
    if (msgs.length > 0) {
      msgs[msgs.length - 1] = { ...msgs[msgs.length - 1], contenu };
    }
    return { messages: msgs };
  }),

  setAgentActif: (agent) => set({ agentActif: agent, messages: [], sessionActive: null }),
  setQuota: (quota) => set({ quota }),
  setGeneration: (v) => set({ estGeneration: v }),
  setStreaming: (v) => set({ streaming: v }),
  setErreur: (err) => set({ erreur: err }),
  reinitialiser: () => set({
    sessionActive: null,
    messages: [],
    estGeneration: false,
    streaming: false,
    erreur: null,
  }),
}));
