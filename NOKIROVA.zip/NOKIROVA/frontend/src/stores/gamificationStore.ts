/**
 * NOKIROVA — Store Gamification (Zustand)
 *
 * XP, niveaux, streaks, badges, succès, classement.
 * Aligné sur le Gamification Service backend.
 */

import { create } from 'zustand';
import type { Badge, Succes, ClassementEntree, StatistiquesProgression, Objectif } from '@/types';

interface GamificationState {
  stats: StatistiquesProgression | null;
  badges: Badge[];
  succes: Succes[];
  classement: ClassementEntree[];
  objectifs: Objectif[];
  evenements: EvenementGamification[];
  estChargement: boolean;

  // Actions
  setStats: (stats: StatistiquesProgression) => void;
  setBadges: (badges: Badge[]) => void;
  setSucces: (succes: Succes[]) => void;
  setClassement: (classement: ClassementEntree[]) => void;
  setObjectifs: (objectifs: Objectif[]) => void;
  ajouterEvenement: (evt: EvenementGamification) => void;
  setChargement: (v: boolean) => void;
  ajouterXp: (montant: number) => void;
  debloquerBadge: (badge: Badge) => void;
  completerObjectif: (id: string) => void;
}

export interface EvenementGamification {
  id: string;
  type: 'xp_gagne' | 'niveau_atteint' | 'badge_debloque' | 'succes_complete' | 'streak_maj' | 'objectif_atteint';
  donnees: Record<string, unknown>;
  horodatage: string;
}

export const useGamificationStore = create<GamificationState>()((set, get) => ({
  stats: null,
  badges: [],
  succes: [],
  classement: [],
  objectifs: [],
  evenements: [],
  estChargement: false,

  setStats: (stats) => set({ stats }),
  setBadges: (badges) => set({ badges }),
  setSucces: (succes) => set({ succes }),
  setClassement: (classement) => set({ classement }),
  setObjectifs: (objectifs) => set({ objectifs }),

  ajouterEvenement: (evt) => set((s) => ({ evenements: [evt, ...s.evenements].slice(0, 50) })),
  setChargement: (v) => set({ estChargement: v }),

  ajouterXp: (montant) => {
    const { stats } = get();
    if (!stats) return;
    const nouveauXp = stats.xp_total + montant;
    const nouveauNiveau = Math.floor(nouveauXp / 1000) + 1; // 1000 XP par niveau
    set({
      stats: {
        ...stats,
        xp_total: nouveauXp,
        niveau_actuel: nouveauNiveau,
        xp_niveau_actuel: nouveauXp % 1000,
        xp_prochain_niveau: 1000,
      },
    });
  },

  debloquerBadge: (badge) => set((s) => ({
    badges: s.badges.map((b) =>
      b.id === badge.id
        ? { ...b, est_debloque: true, debloque_le: new Date().toISOString() }
        : b
    ),
    stats: s.stats ? { ...s.stats, badges_debloques: s.stats.badges_debloques + 1 } : null,
  })),

  completerObjectif: (id) => set((s) => ({
    objectifs: s.objectifs.map((o) =>
      o.id === id ? { ...o, est_atteint: true } : o
    ),
  })),
}));
