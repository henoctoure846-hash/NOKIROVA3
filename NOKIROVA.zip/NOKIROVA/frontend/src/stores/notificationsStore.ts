/**
 * NOKIROVA — Store Notifications (Zustand)
 *
 * Liste des notifications, compteurs non-lus,
 * préférences par canal.
 */

import { create } from 'zustand';
import type { Notification } from '@/types';

interface NotificationsState {
  notifications: Notification[];
  nonLues: number;
  estChargement: boolean;
  panneauOuvert: boolean;

  // Actions
  setNotifications: (n: Notification[]) => void;
  ajouterNotification: (n: Notification) => void;
  marquerLue: (id: string) => void;
  marquerToutesLues: () => void;
  supprimerNotification: (id: string) => void;
  setChargement: (v: boolean) => void;
  togglePanneau: () => void;
  setPanneauOuvert: (ouvert: boolean) => void;
}

export const useNotificationsStore = create<NotificationsState>()((set, get) => ({
  notifications: [],
  nonLues: 0,
  estChargement: false,
  panneauOuvert: false,

  setNotifications: (notifications) => set({
    notifications,
    nonLues: notifications.filter((n) => !n.est_lue).length,
  }),

  ajouterNotification: (n) => set((s) => ({
    notifications: [n, ...s.notifications],
    nonLues: s.nonLues + (n.est_lue ? 0 : 1),
  })),

  marquerLue: (id) => set((s) => ({
    notifications: s.notifications.map((n) =>
      n.id === id ? { ...n, est_lue: true, lu_le: new Date().toISOString() } : n
    ),
    nonLues: Math.max(0, s.nonLues - 1),
  })),

  marquerToutesLues: () => set((s) => ({
    notifications: s.notifications.map((n) => ({
      ...n, est_lue: true, lu_le: new Date().toISOString(),
    })),
    nonLues: 0,
  })),

  supprimerNotification: (id) => set((s) => ({
    notifications: s.notifications.filter((n) => n.id !== id),
    nonLues: s.notifications.find((n) => n.id === id)?.est_lue === false
      ? Math.max(0, s.nonLues - 1)
      : s.nonLues,
  })),

  setChargement: (v) => set({ estChargement: v }),
  togglePanneau: () => set((s) => ({ panneauOuvert: !s.panneauOuvert })),
  setPanneauOuvert: (ouvert) => set({ panneauOuvert: ouvert }),
}));
