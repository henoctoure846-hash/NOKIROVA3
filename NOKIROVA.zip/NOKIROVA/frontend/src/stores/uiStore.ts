/**
 * NOKIROVA — Store UI (Zustand)
 *
 * État global de l'interface :
 * - Sidebar ouverte/fermée
 * - Modal active
 * - Toast empilés
 * - Recherche globale
 * - Mobile vs desktop
 */

import { create } from 'zustand';

export interface ToastItem {
  id: string;
  type: 'info' | 'succes' | 'avertissement' | 'erreur';
  titre: string;
  message: string;
  duree?: number;
}

export interface ModalConfig {
  id: string;
  titre: string;
  contenu: React.ReactNode;
  taille?: 'petit' | 'moyen' | 'grand' | 'plein';
  fermable?: boolean;
}

interface UIState {
  // Sidebar
  sidebarOuverte: boolean;
  sidebarMobile: boolean;

  // Modals
  modaleActive: ModalConfig | null;

  // Toasts
  toasts: ToastItem[];

  // Recherche
  rechercheOuverte: boolean;
  rechercheQuery: string;

  // Mobile
  estMobile: boolean;

  // Overlay
  overlayActif: boolean;

  // Actions
  toggleSidebar: () => void;
  setSidebar: (ouverte: boolean) => void;
  setSidebarMobile: (ouverte: boolean) => void;
  ouvrirModale: (config: ModalConfig) => void;
  fermerModale: () => void;
  ajouterToast: (toast: Omit<ToastItem, 'id'>) => void;
  retirerToast: (id: string) => void;
  setRechercheOuverte: (ouverte: boolean) => void;
  setRechercheQuery: (query: string) => void;
  setEstMobile: (mobile: boolean) => void;
  setOverlay: (actif: boolean) => void;
}

let _toastId = 0;

export const useUIStore = create<UIState>()((set, get) => ({
  sidebarOuverte: true,
  sidebarMobile: false,
  modaleActive: null,
  toasts: [],
  rechercheOuverte: false,
  rechercheQuery: '',
  estMobile: false,
  overlayActif: false,

  toggleSidebar: () => set((s) => ({ sidebarOuverte: !s.sidebarOuverte })),
  setSidebar: (ouverte) => set({ sidebarOuverte: ouverte }),
  setSidebarMobile: (ouverte) => set({ sidebarMobile: ouverte }),

  ouvrirModale: (config) => set({ modaleActive: config, overlayActif: true }),
  fermerModale: () => set({ modaleActive: null, overlayActif: false }),

  ajouterToast: (toast) => {
    const id = `toast_${++_toastId}`;
    set((s) => ({ toasts: [...s.toasts, { ...toast, id }] }));
    // Auto-retrait après la durée
    const duree = toast.duree ?? 5000;
    setTimeout(() => get().retirerToast(id), duree);
  },

  retirerToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),

  setRechercheOuverte: (ouverte) => set({ rechercheOuverte: ouverte }),
  setRechercheQuery: (query) => set({ rechercheQuery: query }),
  setEstMobile: (mobile) => set({ estMobile: mobile }),
  setOverlay: (actif) => set({ overlayActif: actif }),
}));
