/**
 * NOKIROVA — Store Cours (Zustand)
 *
 * Catalogue de cours, filtres, progression.
 */

import { create } from 'zustand';
import type { Cours, Matiere, Chapitre } from '@/types';

interface FiltresCours {
  matiere: Matiere | null;
  difficulte: string | null;
  recherche: string;
  tri: 'pertinence' | 'populaire' | 'recent' | 'progression';
  vue: 'grille' | 'liste';
}

interface CoursesState {
  cours: Cours[];
  coursActif: Cours | null;
  chapitres: Chapitre[];
  filtres: FiltresCours;
  estChargement: boolean;
  page: number;
  total: number;

  // Actions
  setCours: (cours: Cours[]) => void;
  setCoursActif: (cours: Cours | null) => void;
  setChapitres: (chapitres: Chapitre[]) => void;
  setFiltres: (filtres: Partial<FiltresCours>) => void;
  setChargement: (v: boolean) => void;
  setPagination: (page: number, total: number) => void;
  reinitialiserFiltres: () => void;
}

const filtresParDefaut: FiltresCours = {
  matiere: null,
  difficulte: null,
  recherche: '',
  tri: 'pertinence',
  vue: 'grille',
};

export const useCoursesStore = create<CoursesState>()((set) => ({
  cours: [],
  coursActif: null,
  chapitres: [],
  filtres: { ...filtresParDefaut },
  estChargement: false,
  page: 1,
  total: 0,

  setCours: (cours) => set({ cours }),
  setCoursActif: (cours) => set({ coursActif: cours }),
  setChapitres: (chapitres) => set({ chapitres }),
  setFiltres: (filtres) => set((s) => ({ filtres: { ...s.filtres, ...filtres } })),
  setChargement: (v) => set({ estChargement: v }),
  setPagination: (page, total) => set({ page, total }),
  reinitialiserFiltres: () => set({ filtres: { ...filtresParDefaut } }),
}));
