/**
 * NOKIROVA — Store Documents (Zustand)
 *
 * Gestion des documents produits par l'utilisateur :
 * fiches, résumés, dissertations, notes, cartes mentales.
 * Filtres par type/matière, document actif, CRUD.
 */

import { create } from 'zustand';
import type { Document, Matiere } from '@/types';

interface FiltresDocument {
  type: Document['type'] | null;
  matiere: Matiere | null;
  recherche: string;
}

interface DocumentState {
  documents: Document[];
  documentActif: Document | null;
  filtres: FiltresDocument;
  estChargement: boolean;

  // Actions
  setDocuments: (documents: Document[]) => void;
  setDocumentActif: (doc: Document | null) => void;
  setFiltres: (filtres: Partial<FiltresDocument>) => void;
  ajouterDocument: (doc: Document) => void;
  modifierDocument: (id: string, maj: Partial<Document>) => void;
  supprimerDocument: (id: string) => void;
  archiverDocument: (id: string) => void;
  setChargement: (v: boolean) => void;
  reinitialiserFiltres: () => void;
}

const filtresParDefaut: FiltresDocument = {
  type: null,
  matiere: null,
  recherche: '',
};

export const useDocumentStore = create<DocumentState>()((set, get) => ({
  documents: [],
  documentActif: null,
  filtres: { ...filtresParDefaut },
  estChargement: false,

  setDocuments: (documents) => set({ documents }),
  setDocumentActif: (doc) => set({ documentActif: doc }),

  setFiltres: (filtres) => set((s) => ({ filtres: { ...s.filtres, ...filtres } })),

  ajouterDocument: (doc) => set((s) => ({ documents: [doc, ...s.documents] })),

  modifierDocument: (id, maj) => set((s) => ({
    documents: s.documents.map((d) =>
      d.id === id ? { ...d, ...maj, modifie_le: new Date().toISOString() } : d
    ),
  })),

  supprimerDocument: (id) => set((s) => ({
    documents: s.documents.filter((d) => d.id !== id),
    documentActif: s.documentActif?.id === id ? null : s.documentActif,
  })),

  archiverDocument: (id) => set((s) => ({
    documents: s.documents.map((d) =>
      d.id === id ? { ...d, est_archive: true } : d
    ),
  })),

  setChargement: (v) => set({ estChargement: v }),
  reinitialiserFiltres: () => set({ filtres: { ...filtresParDefaut } }),
}));
