/**
 * NOKIROVA — Store Recherche (Zustand)
 *
 * Recherche globale, facettes, suggestions,
 * historique de recherche.
 */

import { create } from 'zustand';
import type { ResultatRecherche, ReponseRecherche, Matiere } from '@/types';

interface SearchState {
  query: string;
  resultats: ResultatRecherche[];
  total: number;
  page: number;
  facettes: Record<string, Record<string, number>>;
  suggestions: string[];
  historique: string[];
  filtreType: string | null;
  filtreMatiere: Matiere | null;
  estChargement: boolean;
  estOuvert: boolean;
  tempsMs: number;

  // Actions
  setQuery: (q: string) => void;
  setResultats: (reponse: ReponseRecherche) => void;
  setSuggestions: (s: string[]) => void;
  ajouterHistorique: (q: string) => void;
  viderHistorique: () => void;
  setFiltreType: (type: string | null) => void;
  setFiltreMatiere: (matiere: Matiere | null) => void;
  setChargement: (v: boolean) => void;
  setOuvert: (v: boolean) => void;
  reinitialiser: () => void;
}

export const useSearchStore = create<SearchState>()((set, get) => ({
  query: '',
  resultats: [],
  total: 0,
  page: 1,
  facettes: {},
  suggestions: [],
  historique: [],
  filtreType: null,
  filtreMatiere: null,
  estChargement: false,
  estOuvert: false,
  tempsMs: 0,

  setQuery: (q) => set({ query: q }),
  setResultats: (reponse) => set({
    resultats: reponse.resultats,
    total: reponse.total,
    page: reponse.page,
    facettes: reponse.facettes,
    suggestions: reponse.suggestions,
    tempsMs: reponse.temps_ms,
  }),

  setSuggestions: (s) => set({ suggestions: s }),

  ajouterHistorique: (q) => {
    if (!q.trim()) return;
    const historique = [q, ...get().historique.filter((h) => h !== q)].slice(0, 20);
    set({ historique });
  },

  viderHistorique: () => set({ historique: [] }),
  setFiltreType: (type) => set({ filtreType: type }),
  setFiltreMatiere: (matiere) => set({ filtreMatiere: matiere }),
  setChargement: (v) => set({ estChargement: v }),
  setOuvert: (v) => set({ estOuvert: v }),
  reinitialiser: () => set({
    query: '', resultats: [], total: 0, page: 1,
    facettes: {}, suggestions: [], filtreType: null, filtreMatiere: null,
  }),
}));
