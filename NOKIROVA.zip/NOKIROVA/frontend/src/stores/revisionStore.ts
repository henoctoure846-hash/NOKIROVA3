/**
 * NOKIROVA — Store Révision (Zustand)
 *
 * Sessions de révision, flashcards, rappels,
 * planificateur spaced repetition.
 */

import { create } from 'zustand';
import type { Flashcard, SessionRevision, RappelRevision, Matiere } from '@/types';

interface RevisionState {
  // Flashcards à réviser
  cartesAReviser: Flashcard[];
  carteActuelle: Flashcard | null;
  indexCarte: number;

  // Session en cours
  sessionEnCours: SessionRevision | null;
  notesSession: Map<string, number>; // flashcard_id → note

  // Rappels
  rappels: RappelRevision[];
  rappelsEnRetard: number;

  // Filtres
  matiereSelectionnee: Matiere | null;
  modeRevision: 'classique' | 'difficile' | 'aleatoire' | 'examen_blanc';

  // Stats de la session
  cartesRevisees: number;
  bonnesReponses: number;

  // Chargement
  estChargement: boolean;

  // Actions
  setCartesAReviser: (cartes: Flashcard[]) => void;
  setCarteActuelle: (carte: Flashcard | null) => void;
  avancerCarte: () => void;
  reculerCarte: () => void;
  noterCarte: (id: string, note: number) => void;
  setSessionEnCours: (session: SessionRevision | null) => void;
  setRappels: (rappels: RappelRevision[]) => void;
  setMatiereSelectionnee: (matiere: Matiere | null) => void;
  setModeRevision: (mode: RevisionState['modeRevision']) => void;
  setChargement: (v: boolean) => void;
  reinitialiserSession: () => void;
}

export const useRevisionStore = create<RevisionState>()((set, get) => ({
  cartesAReviser: [],
  carteActuelle: null,
  indexCarte: 0,
  sessionEnCours: null,
  notesSession: new Map(),
  rappels: [],
  rappelsEnRetard: 0,
  matiereSelectionnee: null,
  modeRevision: 'classique',
  cartesRevisees: 0,
  bonnesReponses: 0,
  estChargement: false,

  setCartesAReviser: (cartes) => set({
    cartesAReviser: cartes,
    carteActuelle: cartes[0] ?? null,
    indexCarte: 0,
  }),

  setCarteActuelle: (carte) => set({ carteActuelle: carte }),

  avancerCarte: () => {
    const { cartesAReviser, indexCarte } = get();
    const next = Math.min(indexCarte + 1, cartesAReviser.length - 1);
    set({ indexCarte: next, carteActuelle: cartesAReviser[next] ?? null });
  },

  reculerCarte: () => {
    const { cartesAReviser, indexCarte } = get();
    const prev = Math.max(indexCarte - 1, 0);
    set({ indexCarte: prev, carteActuelle: cartesAReviser[prev] ?? null });
  },

  noterCarte: (id, note) => {
    const { notesSession, cartesRevisees, bonnesReponses } = get();
    const nouvellesNotes = new Map(notesSession);
    nouvellesNotes.set(id, note);
    const estNouvelle = !notesSession.has(id);
    set({
      notesSession: nouvellesNotes,
      cartesRevisees: estNouvelle ? cartesRevisees + 1 : cartesRevisees,
      bonnesReponses: note >= 3 ? bonnesReponses + (estNouvelle ? 1 : 0) : bonnesReponses,
    });
  },

  setSessionEnCours: (session) => set({ sessionEnCours: session }),
  setRappels: (rappels) => set({
    rappels,
    rappelsEnRetard: rappels.filter((r) => r.statut === 'en_retard').length,
  }),
  setMatiereSelectionnee: (matiere) => set({ matiereSelectionnee: matiere }),
  setModeRevision: (mode) => set({ modeRevision: mode }),
  setChargement: (v) => set({ estChargement: v }),

  reinitialiserSession: () => set({
    cartesAReviser: [],
    carteActuelle: null,
    indexCarte: 0,
    sessionEnCours: null,
    notesSession: new Map(),
    cartesRevisees: 0,
    bonnesReponses: 0,
  }),
}));
