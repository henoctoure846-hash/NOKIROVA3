/**
 * NOKIROVA — Store Auth (Zustand)
 *
 * État global d'authentification :
 * - Utilisateur courant
 * - Token JWT
 * - Statut connexion
 * - Actions login/logout/refresh
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Utilisateur } from '@/types';

interface AuthState {
  utilisateur: Utilisateur | null;
  token: string | null;
  estConnecte: boolean;
  estChargement: boolean;

  // Actions
  setUtilisateur: (u: Utilisateur | null) => void;
  setToken: (t: string | null) => void;
  connexion: (token: string, utilisateur: Utilisateur) => void;
  deconnexion: () => void;
  setChargement: (v: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      utilisateur: null,
      token: null,
      estConnecte: false,
      estChargement: true,

      setUtilisateur: (u) => set({ utilisateur: u, estConnecte: !!u }),
      setToken: (t) => set({ token: t }),

      connexion: (token, utilisateur) => {
        localStorage.setItem('nk_token', token);
        set({ token, utilisateur, estConnecte: true, estChargement: false });
      },

      deconnexion: () => {
        localStorage.removeItem('nk_token');
        localStorage.removeItem('nk_user');
        set({ token: null, utilisateur: null, estConnecte: false });
      },

      setChargement: (v) => set({ estChargement: v }),
    }),
    {
      name: 'nk-auth',
      partialize: (state) => ({
        token: state.token,
        utilisateur: state.utilisateur,
      }),
    }
  )
);
