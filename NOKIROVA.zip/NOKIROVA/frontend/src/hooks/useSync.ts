/**
 * NOKIROVA — Hook useSync
 *
 * Hook pour la synchronisation hors-ligne/en-ligne.
 * Gère la file d'attente des opérations,
 * les conflits et la résolution automatique.
 */

'use client';

import { useCallback, useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import api from '@/lib/api';

/** État de synchronisation */
type EtatSync = 'en_ligne' | 'hors_ligne' | 'synchronisation' | 'erreur';

/** Opération en attente de synchronisation */
interface OperationEnAttente {
  id: string;
  methode: 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  url: string;
  corps?: Record<string, unknown>;
  horodatage: string;
  tentatives: number;
}

/** Conflit de synchronisation */
interface ConflitSync {
  id: string;
  ressource: string;
  ressourceId: string;
  versionLocale: Record<string, unknown>;
  versionServeur: Record<string, unknown>;
  horodatage: string;
}

const STOCKAGE_ATTENTE = 'nokirova_sync_queue';
const STOCKAGE_CONFLITS = 'nokirova_sync_conflicts';
const MAX_TENTATIVES = 5;

export function useSync() {
  const queryClient = useQueryClient();
  const [etat, setEtat] = useState<EtatSync>('en_ligne');
  const [operationsEnAttente, setOperationsEnAttente] = useState<OperationEnAttente[]>([]);
  const [conflits, setConflits] = useState<ConflitSync[]>([]);
  const [estSynchronise, setEstSynchronise] = useState(true);

  // ── Détection en-ligne/hors-ligne ───────────────────────────────
  useEffect(() => {
    const gestionEnLigne = () => {
      setEtat('en_ligne');
      synchroniser();
    };
    const gestionHorsLigne = () => {
      setEtat('hors_ligne');
      setEstSynchronise(false);
    };

    window.addEventListener('online', gestionEnLigne);
    window.addEventListener('offline', gestionHorsLigne);

    // État initial
    setEtat(navigator.onLine ? 'en_ligne' : 'hors_ligne');

    return () => {
      window.removeEventListener('online', gestionEnLigne);
      window.removeEventListener('offline', gestionHorsLigne);
    };
  }, []);

  // ── Charger la file d'attente depuis localStorage ───────────────
  useEffect(() => {
    try {
      const queue = localStorage.getItem(STOCKAGE_ATTENTE);
      if (queue) setOperationsEnAttente(JSON.parse(queue));

      const storedConflicts = localStorage.getItem(STOCKAGE_CONFLITS);
      if (storedConflicts) setConflits(JSON.parse(storedConflicts));
    } catch {
      // Corrompu — réinitialiser
      localStorage.removeItem(STOCKAGE_ATTENTE);
      localStorage.removeItem(STOCKAGE_CONFLITS);
    }
  }, []);

  // ── Ajouter une opération à la file ────────────────────────────
  const ajouterEnAttente = useCallback(
    (operation: Omit<OperationEnAttente, 'id' | 'horodatage' | 'tentatives'>) => {
      const nouvelleOp: OperationEnAttente = {
        ...operation,
        id: `sync_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        horodatage: new Date().toISOString(),
        tentatives: 0,
      };

      setOperationsEnAttente((prev) => {
        const updated = [...prev, nouvelleOp];
        localStorage.setItem(STOCKAGE_ATTENTE, JSON.stringify(updated));
        return updated;
      });
      setEstSynchronise(false);
    },
    []
  );

  // ── Synchroniser les opérations en attente ─────────────────────
  const synchroniser = useCallback(async () => {
    if (!navigator.onLine || operationsEnAttente.length === 0) return;

    setEtat('synchronisation');
    const echecs: OperationEnAttente[] = [];

    for (const op of operationsEnAttente) {
      if (op.tentatives >= MAX_TENTATIVES) {
        echecs.push(op);
        continue;
      }

      try {
        const options: Record<string, unknown> = {};
        if (op.corps) options['json'] = op.corps;

        switch (op.methode) {
          case 'POST':
            await api.create(op.url, op.corps ?? {});
            break;
          case 'PUT':
            await api.replace(op.url, op.corps ?? {});
            break;
          case 'PATCH':
            await api.update(op.url, op.corps ?? {});
            break;
          case 'DELETE':
            await api.remove(op.url);
            break;
        }
      } catch (erreur: unknown) {
        const err = erreur as { status?: number };
        // Conflit 409
        if (err?.status === 409) {
          // Stocker le conflit pour résolution manuelle
          const conflit: ConflitSync = {
            id: `conflit_${Date.now()}`,
            ressource: op.url,
            ressourceId: op.url.split('/').pop() ?? '',
            versionLocale: op.corps ?? {},
            versionServeur: {},
            horodatage: new Date().toISOString(),
          };
          setConflits((prev) => {
            const updated = [...prev, conflit];
            localStorage.setItem(STOCKAGE_CONFLITS, JSON.stringify(updated));
            return updated;
          });
        } else {
          echecs.push({ ...op, tentatives: op.tentatives + 1 });
        }
      }
    }

    // Mettre à jour la file (retirer les ops réussies)
    setOperationsEnAttente((prev) => {
      const updated = echecs;
      localStorage.setItem(STOCKAGE_ATTENTE, JSON.stringify(updated));
      return updated;
    });

    // Invalider les queries pour rafraîchir les données
    queryClient.invalidateQueries();

    setEtat(echecs.length === 0 ? 'en_ligne' : 'erreur');
    setEstSynchronise(echecs.length === 0 && conflits.length === 0);
  }, [operationsEnAttente, conflits, queryClient]);

  // ── Résoudre un conflit ────────────────────────────────────────
  const resoudreConflit = useCallback(
    (conflitId: string, choix: 'locale' | 'serveur' | 'fusion') => {
      setConflits((prev) => {
        const updated = prev.filter((c) => c.id !== conflitId);
        localStorage.setItem(STOCKAGE_CONFLITS, JSON.stringify(updated));
        return updated;
      });

      if (choix === 'locale' || choix === 'fusion') {
        // Re-soumettre l'opération
        synchroniser();
      } else {
        // Accepter la version serveur — rafraîchir
        queryClient.invalidateQueries();
      }
    },
    [synchroniser, queryClient]
  );

  // ── Vider la file d'attente ────────────────────────────────────
  const viderAttente = useCallback(() => {
    setOperationsEnAttente([]);
    localStorage.removeItem(STOCKAGE_ATTENTE);
  }, []);

  return {
    // État
    etat,
    estEnLigne: etat === 'en_ligne',
    estHorsLigne: etat === 'hors_ligne',
    estSynchronise,
    operationsEnAttente,
    nombreOperationsEnAttente: operationsEnAttente.length,
    conflits,
    nombreConflits: conflits.length,

    // Actions
    synchroniser,
    ajouterEnAttente,
    resoudreConflit,
    viderAttente,
  };
}

export default useSync;
