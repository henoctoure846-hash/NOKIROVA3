'use client';

/**
 * NOKIROVA — Hook Mission Control
 *
 * Récupère les données agrégées du backend en temps réel
 * pour le tableau de bord Mission Control.
 *
 * Principe BIBLE #10 Fiabilité : monitoring en temps réel.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import api from '@/lib/api';

// ─── Types ────────────────────────────────────────────────────────────────────

interface ComposantSante {
        ok: boolean;
        version?: string;
        latence_ms?: number;
}

interface EvenementBus {
        published?: number;
        processed?: number;
        failed?: number;
        dead_letter_count?: number;
        status?: string;
}

interface IncidentSelfHealing {
        id: string;
        category: string;
        severity: string;
        status: string;
        message: string;
        detected_at: number;
        resolved_at?: number;
        actions?: Array<{ action: string; timestamp: number; success: boolean }>;
}

interface StatistiquesSelfHealing {
        running: boolean;
        total_incidents: number;
        incidents_resolus: number;
        incidents_echoues: number;
        incidents_escalades: number;
        incidents_24h: number;
        auto_reparations_24h: number;
        strategies_actives: number;
}

interface MetriquesSysteme {
        cpu_pourcent: number;
        memoire_pourcent: number;
        disque_pourcent: number;
}

interface DonneesMissionControl {
        timestamp: number;
        sante: Record<string, ComposantSante>;
        event_bus: EvenementBus;
        self_healing: StatistiquesSelfHealing & { incidents_actifs?: IncidentSelfHealing[] };
        metriques: MetriquesSysteme;
}

interface EtatMissionControl {
        donnees: DonneesMissionControl | null;
        chargement: boolean;
        erreur: string | null;
        derniereMiseAJour: number | null;
        rafraichir: () => Promise<void>;
        declencherVerification: (categorie?: string) => Promise<void>;
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useMissionControl(
        intervalleMs: number = 5000
): EtatMissionControl {
        const [donnees, setDonnees] = useState<DonneesMissionControl | null>(null);
        const [chargement, setChargement] = useState(true);
        const [erreur, setErreur] = useState<string | null>(null);
        const [derniereMiseAJour, setDerniereMiseAJour] = useState<number | null>(null);
        const intervalRef = useRef<NodeJS.Timeout | null>(null);

        const rafraichir = useCallback(async () => {
                try {
                        const rep = await api.get<any>('/api/v1/health/mission-control');
                        if (rep.success) {
                                setDonnees(rep.data);
                                setDerniereMiseAJour(Date.now());
                                setErreur(null);
                        } else {
                                setErreur(rep.message || 'Erreur de récupération');
                        }
                } catch (err: any) {
                        setErreur(err.message || 'Erreur réseau');
                } finally {
                        setChargement(false);
                }
        }, []);

        const declencherVerification = useCallback(async (categorie?: string) => {
                try {
                        const params = categorie ? `?categorie=${categorie}` : '';
                        await api.create<any>(`/api/v1/health/self-healing/trigger${params}`, {});
                } catch (err: any) {
                        // Silencieux — l'erreur est visible dans les incidents
                }
        }, []);

        useEffect(() => {
                rafraichir();
                intervalRef.current = setInterval(rafraichir, intervalleMs);
                return () => {
                        if (intervalRef.current) clearInterval(intervalRef.current);
                };
        }, [intervalleMs, rafraichir]);

        return {
                donnees,
                chargement,
                erreur,
                derniereMiseAJour,
                rafraichir,
                declencherVerification,
        };
}

export default useMissionControl;
