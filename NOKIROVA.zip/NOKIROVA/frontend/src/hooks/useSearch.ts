/**
 * NOKIROVA — Hook useSearch
 *
 * Hook pour la recherche globale.
 * Autocomplétion, résultats, filtres,
 * facettes, historique.
 */

'use client';

import { useCallback, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchStore } from '@/stores/searchStore';
import api from '@/lib/api';
import type {
  ResultatRecherche,
  ReponseRecherche,
} from '@/types';

const CLES_QUERY = {
  recherche: (terme: string, filtres?: Record<string, unknown>) =>
    ['recherche', terme, filtres] as const,
  suggestions: (terme: string) => ['recherche', 'suggestions', terme] as const,
  historique: () => ['recherche', 'historique'] as const,
};

/** Filtres de recherche */
interface FiltresRecherche {
  types?: ('cours' | 'flashcard' | 'quiz' | 'document' | 'publication' | 'utilisateur')[];
  matiere?: string;
  niveau?: string;
  date_debut?: string;
  date_fin?: string;
  tri?: 'pertinence' | 'recent' | 'populaire';
}

export function useSearch() {
  const store = useSearchStore();
  const [filtresActifs, setFiltresActifs] = useState<FiltresRecherche>({});

  // ── Query : Résultats de recherche ──────────────────────────────
  const useResultats = useQuery({
    queryKey: CLES_QUERY.recherche(store.query, filtresActifs as Record<string, unknown>),
    queryFn: async () => {
      if (!store.query || store.query.trim().length < 2) return null;

      const params = new URLSearchParams();
      params.set('q', store.query);
      if (filtresActifs.types?.length) {
        params.set('types', filtresActifs.types.join(','));
      }
      if (filtresActifs.matiere) params.set('matiere', filtresActifs.matiere);
      if (filtresActifs.niveau) params.set('niveau', filtresActifs.niveau);
      if (filtresActifs.tri) params.set('tri', filtresActifs.tri);

      const reponse = await api.get<ReponseRecherche>(
        `/api/v1/recherche?${params.toString()}`
      );
      return reponse.data;
    },
    enabled: store.query.trim().length >= 2,
    staleTime: 30 * 1000,
  });

  // ── Query : Autocomplétion ─────────────────────────────────────
  const useSuggestions = useQuery({
    queryKey: CLES_QUERY.suggestions(store.query),
    queryFn: async () => {
      if (!store.query || store.query.trim().length < 2) return [];

      const reponse = await api.get<string[]>(
        `/api/v1/recherche/suggestions?q=${encodeURIComponent(store.query)}`
      );
      return reponse.data;
    },
    enabled: store.query.trim().length >= 2,
    staleTime: 10 * 1000,
  });

  // ── Query : Historique de recherche ────────────────────────────
  const useHistorique = useQuery({
    queryKey: CLES_QUERY.historique(),
    queryFn: async () => {
      const reponse = await api.get<string[]>(
        '/api/v1/recherche/historique'
      );
      return reponse.data;
    },
    staleTime: 5 * 60 * 1000,
  });

  // ── Déclencher une recherche ──────────────────────────────────
  const rechercher = useCallback(
    (terme: string, filtres?: FiltresRecherche) => {
      store.setQuery(terme);
      if (filtres) setFiltresActifs(filtres);
    },
    [store]
  );

  // ── Effacer la recherche ──────────────────────────────────────
  const effacerRecherche = useCallback(() => {
    store.reinitialiser();
    setFiltresActifs({});
  }, [store]);

  return {
    // Données
    requete: store.query,
    resultats: useResultats.data?.resultats ?? [],
    total: useResultats.data?.total ?? 0,
    facettes: useResultats.data?.facettes,
    suggestions: useSuggestions.data ?? [],
    historique: useHistorique.data ?? [],
    filtres: filtresActifs,
    estChargement: useResultats.isLoading,
    estRechercheActive: store.query.trim().length >= 2,

    // Actions
    rechercher,
    effacerRecherche,
    setFiltres: setFiltresActifs,

    // Rafraîchir
    rafraichir: () => store.reinitialiser(),
  };
}

export default useSearch;
