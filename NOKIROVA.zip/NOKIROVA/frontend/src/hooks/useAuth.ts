/**
 * NOKIROVA — Hook useAuth
 *
 * Hook d'authentification utilisant le store Zustand
 * et TanStack Query pour les opérations serveur.
 */

'use client';

import { useCallback, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/authStore';
import api from '@/lib/api';
import type { Utilisateur } from '@/types';

/** Réponse login/register */
interface ReponseAuth {
  access_token: string;
  refresh_token: string;
  token_type: string;
  utilisateur: Utilisateur;
}

/** Données login */
interface DonneesLogin {
  email: string;
  mot_de_passe: string;
}

/** Données inscription */
interface DonneesInscription extends DonneesLogin {
  nom: string;
  prenom: string;
  plan?: 'gratuit' | 'etudiant' | 'premium' | 'institution';
}

/**
 * Hook principal d'authentification.
 * Combine le store Zustand (état local) et les mutations serveur.
 */
export function useAuth() {
  const queryClient = useQueryClient();
  const {
    utilisateur,
    estConnecte,
    estChargement,
    setUtilisateur,
    setChargement,
    connexion,
    deconnexion,
  } = useAuthStore();

  // Erreur locale (le store n'expose pas erreur/setErreur)
  const [erreur, setErreur] = useState<string | null>(null);

  // ── Mutation : Connexion ────────────────────────────────────────
  const mutationConnexion = useMutation({
    mutationFn: async (donnees: DonneesLogin): Promise<ReponseAuth> => {
      const reponse = await api.create<ReponseAuth>(
        '/api/v1/auth/login',
        donnees
      );
      return reponse.data;
    },
    onMutate: () => {
      setChargement(true);
      setErreur(null);
    },
    onSuccess: (data) => {
      setUtilisateur(data.utilisateur);
      connexion(data.access_token, data.utilisateur);
      // Redirection automatique via middleware
      queryClient.invalidateQueries({ queryKey: ['profil'] });
    },
    onError: (err: Error) => {
      setErreur(err.message || 'Échec de connexion');
    },
    onSettled: () => {
      setChargement(false);
    },
  });

  // ── Mutation : Inscription ──────────────────────────────────────
  const mutationInscription = useMutation({
    mutationFn: async (donnees: DonneesInscription): Promise<ReponseAuth> => {
      const reponse = await api.create<ReponseAuth>(
        '/api/v1/auth/register',
        donnees
      );
      return reponse.data;
    },
    onMutate: () => {
      setChargement(true);
      setErreur(null);
    },
    onSuccess: (data) => {
      setUtilisateur(data.utilisateur);
      connexion(data.access_token, data.utilisateur);
    },
    onError: (err: Error) => {
      setErreur(err.message || 'Échec d\'inscription');
    },
    onSettled: () => {
      setChargement(false);
    },
  });

  // ── Mutation : Déconnexion ──────────────────────────────────────
  const mutationDeconnexion = useMutation({
    mutationFn: async () => {
      await api.create('/api/v1/auth/logout');
    },
    onSuccess: () => {
      deconnexion();
      queryClient.clear();
    },
  });

  // ── Query : Profil courant ──────────────────────────────────────
  const queryProfil = useQuery({
    queryKey: ['profil'],
    queryFn: async () => {
      const reponse = await api.get<Utilisateur>(
        '/api/v1/auth/me'
      );
      return reponse.data;
    },
    enabled: estConnecte,
    staleTime: 5 * 60 * 1000, // 5 min
  });

  // ── Mutation : Mise à jour profil ───────────────────────────────
  const mutationMiseAJourProfil = useMutation({
    mutationFn: async (donnees: Partial<Utilisateur>) => {
      const reponse = await api.update<Utilisateur>(
        '/api/v1/auth/me',
        donnees
      );
      return reponse.data;
    },
    onSuccess: (data) => {
      setUtilisateur(data);
      queryClient.setQueryData(['profil'], data);
    },
  });

  // ── Mutation : Rafraîchissement token ───────────────────────────
  const rafraichirToken = useCallback(async () => {
    try {
      const reponse = await api.create<{ access_token: string }>(
        '/api/v1/auth/refresh'
      );
      return reponse.data.access_token;
    } catch {
      deconnexion();
      return null;
    }
  }, [deconnexion]);

  // ── API publique du hook ────────────────────────────────────────
  return {
    // État
    utilisateur,
    estConnecte,
    estChargement,
    erreur,

    // Actions
    connexion: mutationConnexion.mutate,
    inscription: mutationInscription.mutate,
    deconnexion: mutationDeconnexion.mutate,
    miseAJourProfil: mutationMiseAJourProfil.mutate,
    rafraichirToken,

    // États des mutations
    estConnexionEnCours: mutationConnexion.isPending,
    estInscriptionEnCours: mutationInscription.isPending,
    estDeconnexionEnCours: mutationDeconnexion.isPending,
    estMiseAJourEnCours: mutationMiseAJourProfil.isPending,

    // Query profil
    profil: queryProfil.data,
    estProfilChargement: queryProfil.isLoading,
  };
}

export default useAuth;
