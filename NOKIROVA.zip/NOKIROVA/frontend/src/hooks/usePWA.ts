/**
 * usePWA — Hook d'enregistrement du Service Worker PWA
 *
 * Principe BIBLE #7 Hors connexion :
 * - Enregistre le service worker au montage
 * - Gère les mises à jour disponibles
 * - Expose l'état offline / en ligne
 * - Notification de nouvelle version disponible
 */

'use client';

import { useState, useEffect, useCallback } from 'react';

interface EtatPWA {
  /** Indique si l'app est installée en tant que PWA */
  estInstallee: boolean;
  /** Indique si une mise à jour est disponible */
  miseAJourDisponible: boolean;
  /** Indique si l'utilisateur est hors connexion */
  horsConnexion: boolean;
  /** Déclenche la mise à jour du SW */
  appliquerMiseAJour: () => void;
  /** Enregistre le service worker manuellement */
  enregistrer: () => Promise<void>;
}

export function usePWA(): EtatPWA {
  const [estInstallee, setEstInstallee] = useState(false);
  const [miseAJourDisponible, setMiseAJourDisponible] = useState(false);
  const [horsConnexion, setHorsConnexion] = useState(false);
  const [swEnAttente, setSwEnAttente] = useState<ServiceWorker | null>(null);

  // ═══════════════════════════════════════
  // Surveillance de la connexion
  // ═══════════════════════════════════════

  useEffect(() => {
    setHorsConnexion(!navigator.onLine);

    const handleEnLigne = () => setHorsConnexion(false);
    const handleHorsLigne = () => setHorsConnexion(true);

    window.addEventListener('online', handleEnLigne);
    window.addEventListener('offline', handleHorsLigne);

    return () => {
      window.removeEventListener('online', handleEnLigne);
      window.removeEventListener('offline', handleHorsLigne);
    };
  }, []);

  // ═══════════════════════════════════════
  // Enregistrement du Service Worker
  // ═══════════════════════════════════════

  const enregistrer = useCallback(async () => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
      return;
    }

    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/',
      });
      // Vérifier les mises à jour
      registration.addEventListener('updatefound', () => {
        const nouveauSW = registration.installing;
        if (!nouveauSW) return;

        nouveauSW.addEventListener('statechange', () => {
          if (
            nouveauSW.state === 'installed' &&
            navigator.serviceWorker.controller
          ) {
            // Une mise à jour est disponible
            setSwEnAttente(nouveauSW);
            setMiseAJourDisponible(true);
          }
        });
      });

      // Vérifier si l'app est déjà installée en PWA
      if (window.matchMedia('(display-mode: standalone)').matches) {
        setEstInstallee(true);
      }

      // Surveiller le mode d'affichage
      const mediaQuery = window.matchMedia('(display-mode: standalone)');
      const handleChange = (e: MediaQueryListEvent) => setEstInstallee(e.matches);
      mediaQuery.addEventListener('change', handleChange);
    } catch (erreur) {
      console.error('[NOKIROVA PWA] Erreur d\'enregistrement SW :', erreur);
    }
  }, []);

  // ═══════════════════════════════════════
  // Appliquer la mise à jour
  // ═══════════════════════════════════════

  const appliquerMiseAJour = useCallback(() => {
    if (swEnAttente) {
      swEnAttente.postMessage({ type: 'SKIP_WAITING' });
      setMiseAJourDisponible(false);
      setSwEnAttente(null);

      // Recharger la page après activation du nouveau SW
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        window.location.reload();
      });
    }
  }, [swEnAttente]);

  // ═══════════════════════════════════════
  // Auto-enregistrement au montage
  // ═══════════════════════════════════════

  useEffect(() => {
    enregistrer();
  }, [enregistrer]);

  return {
    estInstallee,
    miseAJourDisponible,
    horsConnexion,
    appliquerMiseAJour,
    enregistrer,
  };
}
