/**
 * NOKIROVA — Hook useCourses
 *
 * Hook pour la gestion des cours et chapitres.
 * Utilise TanStack Query pour le cache serveur
 * et le store Zustand pour l'état local.
 */

'use client';

import { useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useCoursesStore } from '@/stores/coursesStore';
import api from '@/lib/api';
import type {
  Cours,
  Chapitre,
  ReponsePaginee,
  ParamsPagination,
} from '@/types';

/** Clés de query pour les cours */
const CLES_QUERY = {
  tous: (filtres?: Record<string, unknown>) => ['cours', filtres] as const,
  detail: (id: string) => ['cours', id] as const,
  chapitres: (coursId: string) => ['cours', coursId, 'chapitres'] as const,
  chapitre: (id: string) => ['chapitre', id] as const,
  progression: (coursId: string) => ['cours', coursId, 'progression'] as const,
};

/** Filtres de recherche de cours */
interface FiltresCours {
  recherche?: string;
  matiere?: string;
  niveau?: string;
  statut?: 'publie' | 'brouillon' | 'archive';
  tri?: 'recent' | 'populaire' | 'progression';
}

export function useCourses(filtres?: FiltresCours) {
  const queryClient = useQueryClient();
  const store = useCoursesStore();

  // ── Query : Liste des cours ─────────────────────────────────────
  const queryListe = useQuery({
    queryKey: CLES_QUERY.tous(filtres as Record<string, unknown> | undefined),
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filtres?.recherche) params.set('q', filtres.recherche);
      if (filtres?.matiere) params.set('matiere', filtres.matiere);
      if (filtres?.niveau) params.set('niveau', filtres.niveau);
      if (filtres?.statut) params.set('statut', filtres.statut);
      if (filtres?.tri) params.set('tri', filtres.tri);

      const reponse = await api.get<ReponsePaginee<Cours>>(
        `/api/v1/cours?${params.toString()}`
      );
      return reponse.data;
    },
    staleTime: 2 * 60 * 1000,
  });

  // ── Query : Détail d'un cours ───────────────────────────────────
  const useDetail = (coursId: string) =>
    useQuery({
      queryKey: CLES_QUERY.detail(coursId),
      queryFn: async () => {
        const reponse = await api.get<Cours>(
          `/api/v1/cours/${coursId}`
        );
        return reponse.data;
      },
      enabled: !!coursId,
    });

  // ── Query : Chapitres d'un cours ───────────────────────────────
  const useChapitres = (coursId: string) =>
    useQuery({
      queryKey: CLES_QUERY.chapitres(coursId),
      queryFn: async () => {
        const reponse = await api.get<Chapitre[]>(
          `/api/v1/cours/${coursId}/chapitres`
        );
        return reponse.data;
      },
      enabled: !!coursId,
    });

  // ── Mutation : Inscription à un cours ──────────────────────────
  const mutationInscription = useMutation({
    mutationFn: async (coursId: string) => {
      const reponse = await api.create<Cours>(
        `/api/v1/cours/${coursId}/inscription`
      );
      return reponse.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cours'] });
    },
  });

  // ── Mutation : Désinscription ──────────────────────────────────
  const mutationDesinscription = useMutation({
    mutationFn: async (coursId: string) => {
      await api.remove(`/api/v1/cours/${coursId}/inscription`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cours'] });
    },
  });

  // ── Mutation : Marquer chapitre complété ───────────────────────
  const mutationCompleterChapitre = useMutation({
    mutationFn: async ({ coursId, chapitreId }: { coursId: string; chapitreId: string }) => {
      const reponse = await api.create<Chapitre>(
        `/api/v1/cours/${coursId}/chapitres/${chapitreId}/completer`
      );
      return reponse.data;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: CLES_QUERY.chapitres(variables.coursId) });
      queryClient.invalidateQueries({ queryKey: CLES_QUERY.detail(variables.coursId) });
    },
  });

  // ── Recherche de cours ─────────────────────────────────────────
  const rechercher = useCallback(
    async (terme: string) => {
      const reponse = await api.get<Cours[]>(
        `/api/v1/cours/recherche?q=${encodeURIComponent(terme)}`
      );
      return reponse.data;
    },
    []
  );

  return {
    // Données
    cours: queryListe.data?.items ?? store.cours,
    totalCours: queryListe.data?.total ?? 0,
    estChargement: queryListe.isLoading,
    erreur: queryListe.error,

    // Hooks détaillés
    useDetail,
    useChapitres,

    // Actions
    inscription: mutationInscription.mutate,
    desinscription: mutationDesinscription.mutate,
    completerChapitre: mutationCompleterChapitre.mutate,
    rechercher,

    // États mutations
    estInscriptionEnCours: mutationInscription.isPending,
    estDesinscriptionEnCours: mutationDesinscription.isPending,

    // Raffraîchir
    rafraichir: () => queryClient.invalidateQueries({ queryKey: ['cours'] }),
  };
}

export default useCourses;
