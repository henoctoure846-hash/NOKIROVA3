/**
 * NOKIROVA — Hook useRevision
 *
 * Hook pour le système de révision espacée.
 * Flashcards, quiz, sessions de révision,
 * algorithmes SM-2 et rappels.
 */

'use client';

import { useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useRevisionStore } from '@/stores/revisionStore';
import api from '@/lib/api';
import type {
  Flashcard,
  SessionRevision,
  Quiz,
  ReponsePaginee,
} from '@/types';

const CLES_QUERY = {
  flashcards: (paquetId: string) => ['flashcards', paquetId] as const,
  flashcard: (id: string) => ['flashcard', id] as const,
  sessions: (filtres?: Record<string, unknown>) => ['sessions-revision', filtres] as const,
  session: (id: string) => ['session-revision', id] as const,
  rappels: () => ['rappels-revision'] as const,
  quiz: (id: string) => ['quiz', id] as const,
  quizListe: (coursId?: string) => ['quiz', coursId] as const,
  statistiques: () => ['stats-revision'] as const,
};

/** Résultat d'évaluation SM-2 */
interface ResultatEvaluation {
  flashcard_id: string;
  qualite: number; // 0-5
  reponse: string;
  temps_ms: number;
}

export function useRevision() {
  const queryClient = useQueryClient();
  const store = useRevisionStore();

  // ── Query : Flashcards d'un paquet ──────────────────────────────
  const useFlashcards = (paquetId: string) =>
    useQuery({
      queryKey: CLES_QUERY.flashcards(paquetId),
      queryFn: async () => {
        const reponse = await api.get<Flashcard[]>(
          `/api/v1/flashcards/paquets/${paquetId}/cartes`
        );
        return reponse.data;
      },
      enabled: !!paquetId,
    });

  // ── Query : Sessions de révision ───────────────────────────────
  const useSessions = useQuery({
    queryKey: CLES_QUERY.sessions(),
    queryFn: async () => {
      const reponse = await api.get<SessionRevision[]>(
        '/api/v1/revision/sessions'
      );
      return reponse.data;
    },
    staleTime: 60 * 1000, // 1 min
  });

  // ── Query : Rappels de révision ────────────────────────────────
  const useRappels = useQuery({
    queryKey: CLES_QUERY.rappels(),
    queryFn: async () => {
      const reponse = await api.get<SessionRevision>(
        '/api/v1/revision/rappels'
      );
      return reponse.data;
    },
    staleTime: 30 * 1000, // 30 sec
  });

  // ── Query : Quiz ──────────────────────────────────────────────
  const useQuiz = (quizId: string) =>
    useQuery({
      queryKey: CLES_QUERY.quiz(quizId),
      queryFn: async () => {
        const reponse = await api.get<Quiz>(
          `/api/v1/quiz/${quizId}`
        );
        return reponse.data;
      },
      enabled: !!quizId,
    });

  // ── Query : Statistiques de révision ───────────────────────────
  const useStatistiques = useQuery({
    queryKey: CLES_QUERY.statistiques(),
    queryFn: async () => {
      const reponse = await api.get<Record<string, unknown>>(
        '/api/v1/revision/statistiques'
      );
      return reponse.data;
    },
    staleTime: 5 * 60 * 1000,
  });

  // ── Mutation : Créer session de révision ───────────────────────
  const mutationCreerSession = useMutation({
    mutationFn: async (donnees: { paquet_id: string; type: 'flashcard' | 'quiz' | 'mixte' }) => {
      const reponse = await api.create<SessionRevision>(
        '/api/v1/revision/sessions',
        donnees
      );
      return reponse.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions-revision'] });
      queryClient.invalidateQueries({ queryKey: ['rappels-revision'] });
    },
  });

  // ── Mutation : Évaluer une flashcard (SM-2) ────────────────────
  const mutationEvaluer = useMutation({
    mutationFn: async (donnees: ResultatEvaluation) => {
      const reponse = await api.create<Flashcard>(
        `/api/v1/flashcards/${donnees.flashcard_id}/evaluer`,
        {
          qualite: donnees.qualite,
          reponse: donnees.reponse,
          temps_ms: donnees.temps_ms,
        }
      );
      return reponse.data;
    },
  });

  // ── Mutation : Soumettre un quiz ───────────────────────────────
  const mutationSoumettreQuiz = useMutation({
    mutationFn: async (donnees: {
      quiz_id: string;
      reponses: Record<string, string | string[]>;
      temps_ms: number;
    }) => {
      const reponse = await api.create<Record<string, unknown>>(
        `/api/v1/quiz/${donnees.quiz_id}/soumettre`,
        donnees
      );
      return reponse.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['quiz'] });
      queryClient.invalidateQueries({ queryKey: ['stats-revision'] });
    },
  });

  // ── Raccourci : Démarrer révision rapide ────────────────────────
  const demarrerRevisionRapide = useCallback(
    async (paquetId: string) => {
      return mutationCreerSession.mutateAsync({
        paquet_id: paquetId,
        type: 'flashcard',
      });
    },
    [mutationCreerSession]
  );

  return {
    // Données
    sessions: useSessions.data ?? [],
    rappels: useRappels.data,
    statistiques: useStatistiques.data,

    // Hooks détaillés
    useFlashcards,
    useQuiz,

    // Actions
    creerSession: mutationCreerSession.mutate,
    evaluer: mutationEvaluer.mutate,
    soumettreQuiz: mutationSoumettreQuiz.mutate,
    demarrerRevisionRapide,

    // États
    estChargement: useSessions.isLoading,
    estCreationSession: mutationCreerSession.isPending,
    estEvaluation: mutationEvaluer.isPending,
    estSoumissionQuiz: mutationSoumettreQuiz.isPending,

    // Raffraîchir
    rafraichir: () => {
      queryClient.invalidateQueries({ queryKey: ['revision'] });
      queryClient.invalidateQueries({ queryKey: ['sessions-revision'] });
    },
  };
}

export default useRevision;
