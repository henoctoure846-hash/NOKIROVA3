/**
 * NOKIROVA — Hook useAI
 *
 * Hook pour l'interaction avec l'IA Studio.
 * Sessions, conversations, quotas, modèles.
 */

'use client';

import { useCallback, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAIStore } from '@/stores/aiStore';
import api from '@/lib/api';
import type {
  SessionIA,
  MessageIA,
  QuotaIA,
} from '@/types';

const CLES_QUERY = {
  sessions: () => ['ia-sessions'] as const,
  session: (id: string) => ['ia-session', id] as const,
  messages: (sessionId: string) => ['ia-messages', sessionId] as const,
  quota: () => ['ia-quota'] as const,
  modeles: () => ['ia-modeles'] as const,
  agents: () => ['ia-agents'] as const,
};

export function useAI() {
  const queryClient = useQueryClient();
  const store = useAIStore();
  const abortRef = useRef<AbortController | null>(null);

  // ── Query : Liste des sessions IA ──────────────────────────────
  const useSessions = useQuery({
    queryKey: CLES_QUERY.sessions(),
    queryFn: async () => {
      const reponse = await api.get<SessionIA[]>(
        '/api/v1/ia/sessions'
      );
      return reponse.data;
    },
    staleTime: 2 * 60 * 1000,
  });

  // ── Query : Détail session + messages ──────────────────────────
  const useSessionDetail = (sessionId: string) =>
    useQuery({
      queryKey: CLES_QUERY.session(sessionId),
      queryFn: async () => {
        const reponse = await api.get<SessionIA>(
          `/api/v1/ia/sessions/${sessionId}`
        );
        return reponse.data;
      },
      enabled: !!sessionId,
    });

  // ── Query : Messages d'une session ─────────────────────────────
  const useMessages = (sessionId: string) =>
    useQuery({
      queryKey: CLES_QUERY.messages(sessionId),
      queryFn: async () => {
        const reponse = await api.get<MessageIA[]>(
          `/api/v1/ia/sessions/${sessionId}/messages`
        );
        return reponse.data;
      },
      enabled: !!sessionId,
    });

  // ── Query : Quota IA ──────────────────────────────────────────
  const useQuota = useQuery({
    queryKey: CLES_QUERY.quota(),
    queryFn: async () => {
      const reponse = await api.get<QuotaIA>(
        '/api/v1/ia/quota'
      );
      return reponse.data;
    },
    staleTime: 60 * 1000, // 1 min
  });

  // ── Mutation : Créer session IA ────────────────────────────────
  const mutationCreerSession = useMutation({
    mutationFn: async (donnees: {
      type: 'chat' | 'generation' | 'analyse' | 'correction' | 'resume';
      modele?: string;
      contexte?: Record<string, unknown>;
    }) => {
      const reponse = await api.create<SessionIA>(
        '/api/v1/ia/sessions',
        donnees
      );
      return reponse.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ia-sessions'] });
    },
  });

  // ── Mutation : Envoyer un message (chat) ────────────────────────
  const mutationEnvoyerMessage = useMutation({
    mutationFn: async ({
      sessionId,
      contenu,
    }: {
      sessionId: string;
      contenu: string;
    }) => {
      // Annuler la requête précédente si streaming
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      const reponse = await api.create<MessageIA>(
        `/api/v1/ia/sessions/${sessionId}/messages`,
        { contenu },
        { signal: controller.signal }
      );
      return reponse.data;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: CLES_QUERY.messages(variables.sessionId),
      });
      queryClient.invalidateQueries({ queryKey: ['ia-quota'] });
    },
  });

  // ── Mutation : Supprimer session ───────────────────────────────
  const mutationSupprimerSession = useMutation({
    mutationFn: async (sessionId: string) => {
      await api.remove(`/api/v1/ia/sessions/${sessionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ia-sessions'] });
      store.reinitialiser();
    },
  });

  // ── Mutation : Feedback sur réponse IA ─────────────────────────
  const mutationFeedback = useMutation({
    mutationFn: async ({
      interactionId,
      positif,
      commentaire,
    }: {
      interactionId: string;
      positif: boolean;
      commentaire?: string;
    }) => {
      await api.create(`/api/v1/ia/interactions/${interactionId}/feedback`, {
        positif,
        commentaire,
      });
    },
  });

  // ── Annuler la génération en cours ─────────────────────────────
  const annulerGeneration = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
  }, []);

  return {
    // Données
    sessions: useSessions.data ?? [],
    quota: useQuota.data,

    // Hooks détaillés
    useSessionDetail,
    useMessages,

    // Actions
    creerSession: mutationCreerSession.mutate,
    envoyerMessage: mutationEnvoyerMessage.mutate,
    supprimerSession: mutationSupprimerSession.mutate,
    donnerFeedback: mutationFeedback.mutate,
    annulerGeneration,

    // États
    estChargement: useSessions.isLoading,
    estEnvoiMessage: mutationEnvoyerMessage.isPending,
    estCreationSession: mutationCreerSession.isPending,

    // Raffraîchir
    rafraichir: () => {
      queryClient.invalidateQueries({ queryKey: ['ia'] });
    },
  };
}

export default useAI;
