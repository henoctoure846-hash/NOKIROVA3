/**
 * NOKIROVA — Hook useWebSocket
 *
 * Re-export du hook fourni par WebSocketProvider.
 * L'implémentation Socket.IO se trouve dans
 * @/providers/WebSocketProvider.
 *
 * Ce fichier sert d'alias pratique pour les imports
 * depuis les composants qui préfèrent importer
 * depuis @/hooks plutôt que @/providers.
 */

'use client';

export { useWebSocket } from '@/providers/WebSocketProvider';
