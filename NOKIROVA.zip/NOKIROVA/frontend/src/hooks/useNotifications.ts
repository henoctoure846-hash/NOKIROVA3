/**
 * NOKIROVA — Hook useNotifications
 *
 * Hook pour la gestion des notifications.
 * Lecture, marquage, préférences,
 * temps réel via WebSocket.
 */

'use client';

import { useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNotificationsStore } from '@/stores/notificationsStore';
import api from '@/lib/api';
import type { Notification } from '@/types';

const CLES_QUERY = {
  toutes: () => ['notifications'] as const,
  nonLues: () => ['notifications', 'non-lues'] as const,
  preferences: () => ['notifications', 'preferences'] as const,
};

export function useNotifications() {
  const queryClient = useQueryClient();
  const store = useNotificationsStore();

  // ── Query : Toutes les notifications ────────────────────────────
  const useListe = useQuery({
    queryKey: CLES_QUERY.toutes(),
    queryFn: async () => {
      const reponse = await api.get<Notification[]>(
        '/api/v1/notifications'
      );
      return reponse.data;
    },
    staleTime: 30 * 1000, // 30 sec
  });

  // ── Query : Non lues ──────────────────────────────────────────
  const useNonLues = useQuery({
    queryKey: CLES_QUERY.nonLues(),
    queryFn: async () => {
      const reponse = await api.get<Notification[]>(
        '/api/v1/notifications/non-lues'
      );
      return reponse.data;
    },
    staleTime: 10 * 1000, // 10 sec
  });

  // ── Mutation : Marquer comme lue ──────────────────────────────
  const mutationMarquerLue = useMutation({
    mutationFn: async (id: string) => {
      await api.update(`/api/v1/notifications/${id}/lire`, {});
    },
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      store.marquerLue(id); // mise à jour optimiste
    },
  });

  // ── Mutation : Marquer toutes comme lues ──────────────────────
  const mutationToutMarquerLue = useMutation({
    mutationFn: async () => {
      await api.update('/api/v1/notifications/lire-tout', {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      store.marquerToutesLues();
    },
  });

  // ── Mutation : Supprimer (archiver) ────────────────────────────
  const mutationArchiver = useMutation({
    mutationFn: async (id: string) => {
      await api.remove(`/api/v1/notifications/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // ── Mutation : Mettre à jour préférences ───────────────────────
  const mutationPreferences = useMutation({
    mutationFn: async (prefs: Record<string, unknown>) => {
      const reponse = await api.update<Record<string, unknown>>(
        '/api/v1/notifications/preferences',
        prefs
      );
      return reponse.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', 'preferences'] });
    },
  });

  // ── Raccourci : Nombre de non lues ─────────────────────────────
  const nombreNonLues = store.nonLues;

  return {
    // Données
    notifications: useListe.data ?? store.notifications,
    nonLues: useNonLues.data ?? store.nonLues,
    nombreNonLues,
    estChargement: useListe.isLoading,

    // Actions
    marquerLue: mutationMarquerLue.mutate,
    toutMarquerLues: mutationToutMarquerLue.mutate,
    archiver: mutationArchiver.mutate,
    mettreAJourPreferences: mutationPreferences.mutate,

    // États
    estMarquageEnCours: mutationMarquerLue.isPending,

    // Rafraîchir
    rafraichir: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
  };
}

export default useNotifications;
