/**
 * NOKIROVA — Service Worker PWA
 *
 * Principe BIBLE #7 Hors connexion :
 * - Mise en cache des pages pour navigation offline
 * - Stratégie Network-First avec fallback cache
 * - Pré-cache des routes principales
 * - Nettoyage automatique des anciens caches
 * - Background sync pour les actions différées
 */

const NOM_CACHE = 'nokirova-v1';
const CACHE_STATIQUE = 'nokirova-statique-v1';
const CACHE_DYNAMIQUE = 'nokirova-dynamique-v1';

// Routes à pré-cacher au démarrage
const ROUTES_PRE_CACHE = [
  '/',
  '/apprendre',
  '/reviser',
  '/produire',
  '/ia-studio',
  '/communaute',
  '/progression',
  '/mission-control',
];

// ═══════════════════════════════════════
// Installation
// ═══════════════════════════════════════

self.addEventListener('install', (event) => {
  console.log('[NOKIROVA SW] Installation du service worker');

  event.waitUntil(
    caches.open(CACHE_STATIQUE).then((cache) => {
      console.log('[NOKIROVA SW] Pré-cache des routes principales');
      return cache.addAll(ROUTES_PRE_CACHE.map((route) =>
        new Request(route, { cache: 'reload' })
      )).catch((err) => {
        // Certaines routes peuvent ne pas être accessibles au démarrage
        console.warn('[NOKIROVA SW] Certaines routes non pré-cachées :', err);
      });
    })
  );

  // Activer immédiatement sans attendre la fermeture des onglets
  self.skipWaiting();
});

// ═══════════════════════════════════════
// Activation
// ═══════════════════════════════════════

self.addEventListener('activate', (event) => {
  console.log('[NOKIROVA SW] Activation du service worker');

  event.waitUntil(
    caches.keys().then((nomsCaches) => {
      return Promise.all(
        nomsCaches
          .filter((nom) => !nom.includes('v1'))
          .map((nom) => {
            console.log('[NOKIROVA SW] Suppression du cache obsolète :', nom);
            return caches.delete(nom);
          })
      );
    }).then(() => {
      // Contrôler tous les onglets immédiatement
      return self.clients.claim();
    })
  );
});

// ═══════════════════════════════════════
// Interception des requêtes
// ═══════════════════════════════════════

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Ignorer les requêtes non-GET
  if (request.method !== 'GET') return;

  // Ignorer les requêtes vers l'API (données dynamiques)
  if (url.pathname.startsWith('/api/')) return;

  // Ignorer les WebSocket
  if (url.protocol === 'ws:' || url.protocol === 'wss:') return;

  // Ignorer les requêtes Chrome extension / non-http
  if (!url.protocol.startsWith('http')) return;

  // Stratégie Network-First pour les pages HTML
  if (request.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      fetch(request)
        .then((reponse) => {
          // Mettre en cache la réponse fraîche
          if (reponse.ok) {
            const clone = reponse.clone();
            caches.open(CACHE_DYNAMIQUE).then((cache) => {
              cache.put(request, clone);
            });
          }
          return reponse;
        })
        .catch(() => {
          // Fallback : servir depuis le cache
          return caches.match(request).then((cached) => {
            return cached || caches.match('/').then((fallback) => {
              return fallback || new Response('Hors connexion', {
                status: 503,
                headers: { 'Content-Type': 'text/html; charset=utf-8' },
              });
            });
          });
        })
    );
    return;
  }

  // Stratégie Cache-First pour les ressources statiques (JS, CSS, images, fonts)
  if (
    url.pathname.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff2?|ttf|eot)$/) ||
    url.pathname.startsWith('/_next/static/')
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;

        return fetch(request).then((reponse) => {
          if (reponse.ok) {
            const clone = reponse.clone();
            caches.open(CACHE_STATIQUE).then((cache) => {
              cache.put(request, clone);
            });
          }
          return reponse;
        });
      })
    );
    return;
  }

  // Par défaut : Network-First
  event.respondWith(
    fetch(request)
      .then((reponse) => {
        if (reponse.ok) {
          const clone = reponse.clone();
          caches.open(CACHE_DYNAMIQUE).then((cache) => {
            cache.put(request, clone);
          });
        }
        return reponse;
      })
      .catch(() => {
        return caches.match(request);
      })
  );
});

// ═══════════════════════════════════════
// Background Sync
// ═══════════════════════════════════════

self.addEventListener('sync', (event) => {
  if (event.tag === 'nokirova-sync') {
    console.log('[NOKIROVA SW] Background sync déclenché');
    event.waitUntil(
      // Différer les actions en attente quand la connexion revient
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({
            type: 'BACKGROUND_SYNC',
            message: 'Connexion rétablie — synchronisation en cours',
          });
        });
      })
    );
  }
});

// ═══════════════════════════════════════
// Messages depuis le client
// ═══════════════════════════════════════

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data?.type === 'CLEAR_CACHE') {
    caches.keys().then((noms) => {
      noms.forEach((nom) => caches.delete(nom));
      console.log('[NOKIROVA SW] Tous les caches vidés');
    });
  }
});
