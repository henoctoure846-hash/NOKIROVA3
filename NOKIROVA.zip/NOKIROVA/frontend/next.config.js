/** @type {import('next').NextConfig} */
const nextConfig = {
  // NOKIROVA — Configuration Next.js
  reactStrictMode: true,

  // Proxy API vers le backend FastAPI
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'}/api/:path*`,
      },
      {
        source: '/ws/:path*',
        destination: `${process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:8000'}/ws/:path*`,
      },
    ];
  },

  // Images : domaines autorisés
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },

  // Internationalisation
  i18n: {
    locales: ['fr'],
    defaultLocale: 'fr',
  },

  // Optimisations
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
  },
};

module.exports = nextConfig;
