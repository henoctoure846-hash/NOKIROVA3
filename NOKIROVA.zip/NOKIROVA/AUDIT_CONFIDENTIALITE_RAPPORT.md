# NOKIROVA — Audit Confidentialité (BIBLE #8)

> Principe BIBLE #8 : **Confidentialité** — Les données sensibles doivent être
> chiffrées au repos, masquées dans les réponses, et les droits d'accès
> strictement contrôlés (RGPD, portabilité, effacement, consentement).

---

## 1. Fichiers créés (audit principal)

| # | Fichier | Lignes | Rôle |
|---|---------|--------|------|
| 1 | `backend/src/core/encryption.py` | 384 | Service de chiffrement Fernet (PBKDF2-HMAC-SHA256, 480k iters, SALT_FIXE) |
| 2 | `backend/src/core/config.py` | +4 | `AppSettings.encryption_key` avec `validation_alias="ENCRYPTION_KEY"` |
| 3 | `backend/src/api/v1/privacy.py` | 512 | 3 endpoints RGPD (export art.20, effacement art.17, consentement 5 types) |
| 4 | `backend/src/middleware/privacy.py` | 116 | PrivacyMiddleware (8 headers sécurité, cookie consent) |
| 5 | `backend/src/api/v1/__init__.py` | +2 | Import + export `privacy_router` |
| 6 | `backend/src/middleware/__init__.py` | +1 | Import `PrivacyMiddleware` |

## 2. Fichiers modifiés (câblage chiffrement IA)

| # | Fichier | Changement |
|---|---------|-----------|
| 7 | `backend/src/services/ai/dto.py` | CreateDTO/UpdateDTO : `api_key_encrypted` → `api_key` (entrée claire). ResponseDTO : `api_key_encrypted` toujours masqué (••••••••) |
| 8 | `backend/src/services/ai/service.py` | `create_model_config()`: chiffre `api_key` → `api_key_encrypted` avant stockage. `update_model_config()`: idem. `_model_config_to_response()`: masque via `masquer_token()`. Nouveau `resoudre_cle_api()`: déchiffre pour appels SDK internes |
| 9 | `backend/src/ai/orchestrator/orchestrator.py` | Stubs provider : commentaires explicatifs + exemple d'utilisation `AIService.resoudre_cle_api(config)` pour les futurs appels SDK réels |
| 10 | `backend/src/main.py` | Ajout `PrivacyMiddleware` dans la pile middleware (après GZipMiddleware) |
| 11 | `backend/src/api/router.py` | Ajout `privacy_router` dans les imports + `include_router` sous `/privacy` |

## 3. Architecture de chiffrement

```
┌─────────────────────────────────────────────────────────────────────┐
│  FLUX DE CRÉATION / MISE À JOUR                                    │
│                                                                     │
│  Admin ──► POST /ai/models  { api_key: "sk-abc..." }              │
│       │                                                             │
│       ▼                                                             │
│  AIService.create_model_config()                                    │
│       │  data.pop("api_key")                                        │
│       │  encryption_svc.chiffrer(cle_api) → Fernet token           │
│       ▼                                                             │
│  PostgreSQL: AIModelConfig.api_key_encrypted = "gAAAAA..."         │
│  (jamais de clé en clair en base — BIBLE #8)                       │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│  FLUX DE LECTURE (API)                                             │
│                                                                     │
│  Client ──► GET /ai/models/{id}                                   │
│       │                                                             │
│       ▼                                                             │
│  _model_config_to_response()                                        │
│       │  encryption_svc.masquer_token(config.api_key_encrypted)     │
│       │  → "••••••••" (MASQUE_DEFAUT)                               │
│       ▼                                                             │
│  Response: { api_key_encrypted: "••••••••" }                        │
│  (jamais la valeur réelle — ni claire, ni chiffrée — BIBLE #8)     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│  FLUX D'APPEL PROVIDER (interne)                                   │
│                                                                     │
│  Orchestrator._call_openai()                                        │
│       │  AIService.resoudre_cle_api(model_config)                  │
│       │  encryption_svc.dechiffrer(config.api_key_encrypted)        │
│       │  → "sk-abc..." (en mémoire uniquement, jamais loggué)     │
│       ▼                                                             │
│  openai.AsyncOpenAI(api_key=cle)                                   │
│  (clé déchiffrée uniquement en RAM — BIBLE #8)                     │
└─────────────────────────────────────────────────────────────────────┘
```

## 4. Endpoints RGPD

| Endpoint | Méthode | Article RGPD | Description |
|----------|---------|-------------|-------------|
| `/api/v1/privacy/export` | POST | Art. 20 | Portabilité — export JSON de toutes les données utilisateur |
| `/api/v1/privacy/data` | DELETE | Art. 17 | Effacement — suppression complète (confirmation "EFFACER" + mot de passe) |
| `/api/v1/privacy/consent` | POST | Art. 6-7 | Consentement — 5 types (analyse_utilisation, marketing, partage_donnees, cookies, profilage_ia) |

## 5. En-têtes de sécurité (PrivacyMiddleware)

| Header | Valeur |
|--------|--------|
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains; preload` |
| `Content-Security-Policy` | `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'` |
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `X-XSS-Protection` | `1; mode=block` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `camera=(), microphone=(), geolocation=()` |
| `X-NOKIROVA-Privacy` | `confidentialite-activee` |

## 6. Vérifications de conflit

- ✅ `BackupSettings.encryption_key` (env_prefix=`BACKUP_`) ≠ `AppSettings.encryption_key` (validation_alias=`ENCRYPTION_KEY`) — aucun conflit
- ✅ Tous les 11 fichiers compilent sans erreur de syntaxe
- ✅ Le router privacy est bien câblé dans `api_router.include_router()`
- ✅ PrivacyMiddleware est bien ajouté dans la pile middleware de main.py

## 7. Prochaines étapes

1. ✅ **Confidentialité audit** — TERMINÉ (6 créés + 5 modifiés)
2. 🔲 **Élégance audit** — À démarrer (Principe BIBLE #10)
3. 🔲 **Excellence audit** — À démarrer (Principe BIBLE #11)
4. 🔲 **Alembic migration gap** — 33 tables initiales vs 123 ORM
5. 🔲 **Tests d'intégration**
