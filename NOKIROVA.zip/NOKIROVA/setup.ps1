<#
.NOKIROVA — Script d'installation et démarrage Windows
.
Principe BIBLE #1 Simplicité : un seul script pour tout installer et lancer.
Principe BIBLE #3 Local-first : tout tourne en local sur PyCharm.
.
Prérequis :
  - Python 3.11+
  - Node.js 18+
  - PostgreSQL 15+ (service Windows installé)
  - Redis (via WSL ou service Windows)
  - Git
.
Utilisation :
  .\setup.ps1              # Installation complète
  .\setup.ps1 -Demarrer   # Démarrer les serveurs
  .\setup.ps1 -Arreter    # Arrêter les serveurs
  .\setup.ps1 -Verifier   # Vérifier les prérequis
#>

[CmdletBinding()]
param(
    [switch]$Demarrer,
    [switch]$Arreter,
    [switch]$Verifier,
    [switch]$Installer,
    [switch]$Migrer,
    [switch]$Reset,
    [switch]$SkipFrontend,
    [switch]$SkipBackend
)

# ═══════════════════════════════════════
# Configuration
# ═══════════════════════════════════════

$ErrorActionPreference = "Stop"
$ProjetRacine = Split-Path -Parent $MyInvocation.MyCommand.Path
$BackendDir = Join-Path $ProjetRacine "backend"
$FrontendDir = Join-Path $ProjetRacine "frontend"
$VenvDir = Join-Path $BackendDir ".venv"
$LogFile = Join-Path $ProjetRacine "nokirova-setup.log"

$PythonExe = if (Test-Path (Join-Path $VenvDir "Scripts\python.exe")) {
    Join-Path $VenvDir "Scripts\python.exe"
} else {
    "python"
}

# ═══════════════════════════════════════
# Fonctions utilitaires
# ═══════════════════════════════════════

function Ecrire-Log {
    param([string]$Message, [string]$Niveau = "INFO")
    $horodatage = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $ligne = "[$horodatage] [$Niveau] $Message"
    Write-Host $ligne
    Add-Content -Path $LogFile -Value $ligne
}

function Verifier-Commande {
    param([string]$Nom)
    try {
        $null = Get-Command $Nom -ErrorAction Stop
        Ecrire-Log "✅ $Nom trouvé"
        return $true
    } catch {
        Ecrire-Log "❌ $Nom non trouvé — veuillez l'installer" "ERREUR"
        return $false
    }
}

function Attendre-Service {
    param([string]$Nom, [string]$Url, [int]$MaxAttempts = 30, [int]$Delai = 2)
    Ecrire-Log "⏳ Attente de $Nom sur $Url..."
    for ($i = 1; $i -le $MaxAttempts; $i++) {
        try {
            $reponse = Invoke-WebRequest -Uri $Url -TimeoutSec 2 -UseBasicParsing -ErrorAction SilentlyContinue
            if ($reponse.StatusCode -eq 200) {
                Ecrire-Log "✅ $Nom est prêt !"
                return $true
            }
        } catch {
            # Service pas encore prêt
        }
        Start-Sleep -Seconds $Delai
        Ecrire-Log "  Tentative $i/$MaxAttempts..."
    }
    Ecrire-Log "❌ $Nom n'a pas démarré dans le temps imparti" "ERREUR"
    return $false
}

# ═══════════════════════════════════════
# Vérification des prérequis
# ═══════════════════════════════════════

function Verifier-Prerequis {
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Vérification des prérequis"
    Ecrire-Log "═══════════════════════════════════════"

    $tousOk = $true

    # Python
    if (Verifier-Commande "python") {
        $version = & python --version 2>&1
        Ecrire-Log "  Version : $version"
    } else { $tousOk = $false }

    # Node.js
    if (Verifier-Commande "node") {
        $version = & node --version 2>&1
        Ecrire-Log "  Version : $version"
    } else { $tousOk = $false }

    # npm
    if (Verifier-Commande "npm") { }
    else { $tousOk = $false }

    # PostgreSQL
    Ecrire-Log ""
    Ecrire-Log "Vérification de PostgreSQL..."
    try {
        $pgService = Get-Service -Name "postgresql*" -ErrorAction SilentlyContinue
        if ($pgService) {
            Ecrire-Log "✅ Service PostgreSQL trouvé : $($pgService.Name) — Statut : $($pgService.Status)"
            if ($pgService.Status -ne "Running") {
                Ecrire-Log "  ⚠️  Démarrage du service PostgreSQL..."
                Start-Service $pgService.Name
                Ecrire-Log "  ✅ Service PostgreSQL démarré"
            }
        } else {
            # Vérifier via pg_isready
            if (Verifier-Commande "pg_isready") {
                $result = & pg_isready 2>&1
                Ecrire-Log "  pg_isready : $result"
            } else {
                Ecrire-Log "❌ PostgreSQL non trouvé — installez PostgreSQL 15+" "ERREUR"
                $tousOk = $false
            }
        }
    } catch {
        Ecrire-Log "⚠️  Impossible de vérifier le service PostgreSQL" "AVERT"
    }

    # Redis
    Ecrire-Log ""
    Ecrire-Log "Vérification de Redis..."
    try {
        $redisExe = Get-Command "redis-server" -ErrorAction SilentlyContinue
        if ($redisExe) {
            Ecrire-Log "✅ redis-server trouvé"
        } else {
            Ecrire-Log "⚠️  redis-server non trouvé dans PATH"
            Ecrire-Log "  Si Redis est dans WSL, lancez : wsl redis-server"
            Ecrire-Log "  Ou installez : https://github.com/microsoftarchive/redis/releases"
        }
    } catch {
        Ecrire-Log "⚠️  Redis non vérifié"
    }

    # Git
    if (Verifier-Commande "git") { }
    else { $tousOk = $false }

    Ecrire-Log ""
    if ($tousOk) {
        Ecrire-Log "🎉 Tous les prérequis sont satisfaits !"
    } else {
        Ecrire-Log "⚠️  Certains prérequis sont manquants — corrigez-les avant de continuer" "AVERT"
    }

    return $tousOk
}

# ═══════════════════════════════════════
# Installation du backend
# ═══════════════════════════════════════

function Installer-Backend {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Installation du backend"
    Ecrire-Log "═══════════════════════════════════════"

    Push-Location $BackendDir

    # Créer le venv s'il n'existe pas
    if (-not (Test-Path $VenvDir)) {
        Ecrire-Log "🐍 Création de l'environnement virtuel..."
        & python -m venv .venv
        Ecrire-Log "✅ Environnement virtuel créé"
    } else {
        Ecrire-Log "✅ Environnement virtuel existant"
    }

    # Activer le venv
    Ecrire-Log "🔌 Activation de l'environnement virtuel..."
    & (Join-Path $VenvDir "Scripts\Activate.ps1")

    # Installer les dépendances
    Ecrire-Log "📦 Installation des dépendances Python..."
    if (Test-Path "requirements.txt") {
        & pip install -r requirements.txt --quiet
        Ecrire-Log "✅ Dépendances installées"
    } elseif (Test-Path "pyproject.toml") {
        & pip install -e "." --quiet
        Ecrire-Log "✅ Dépendances installées (pyproject.toml)"
    } else {
        Ecrire-Log "⚠️  Aucun fichier de dépendances trouvé" "AVERT"
    }

    # Fichier .env
    if (-not (Test-Path ".env")) {
        if (Test-Path ".env.example") {
            Copy-Item ".env.example" ".env"
            Ecrire-Log "✅ Fichier .env créé depuis .env.example"
            Ecrire-Log "⚠️  Vérifiez et modifiez les valeurs dans .env" "AVERT"
        } else {
            Ecrire-Log "⚠️  Pas de .env.example — créez .env manuellement" "AVERT"
        }
    } else {
        Ecrire-Log "✅ Fichier .env existant"
    }

    Pop-Location
}

# ═══════════════════════════════════════
# Installation du frontend
# ═══════════════════════════════════════

function Installer-Frontend {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Installation du frontend"
    Ecrire-Log "═══════════════════════════════════════"

    Push-Location $FrontendDir

    # Installer les dépendances
    Ecrire-Log "📦 Installation des dépendances npm..."
    & npm install
    Ecrire-Log "✅ Dépendances npm installées"

    # Fichier .env.local
    if (-not (Test-Path ".env.local")) {
        if (Test-Path ".env.example") {
            Copy-Item ".env.example" ".env.local"
            Ecrire-Log "✅ Fichier .env.local créé depuis .env.example"
        } else {
            Ecrire-Log "⚠️  Pas de .env.example frontend — configuration par défaut utilisée" "AVERT"
        }
    } else {
        Ecrire-Log "✅ Fichier .env.local existant"
    }

    Pop-Location
}

# ═══════════════════════════════════════
# Migrations base de données
# ═══════════════════════════════════════

function Executer-Migrations {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Migrations Alembic"
    Ecrire-Log "═══════════════════════════════════════"

    Push-Location $BackendDir

    # Vérifier que PostgreSQL est accessible
    Ecrire-Log "🔍 Vérification de la connexion PostgreSQL..."
    try {
        $result = & pg_isready 2>&1
        Ecrire-Log "  $result"
    } catch {
        Ecrire-Log "⚠️  PostgreSQL peut ne pas être démarré — les migrations échoueront" "AVERT"
    }

    # Exécuter les migrations
    Ecrire-Log "📈 Exécution de alembic upgrade head..."
    & (Join-Path $VenvDir "Scripts\alembic.exe") upgrade head
    if ($LASTEXITCODE -eq 0) {
        Ecrire-Log "✅ Migrations exécutées avec succès"
    } else {
        Ecrire-Log "❌ Erreur lors des migrations" "ERREUR"
        Ecrire-Log "  Vérifiez que PostgreSQL est démarré et que DATABASE_URL est correct dans .env"
    }

    Pop-Location
}

# ═══════════════════════════════════════
# Démarrage des services
# ═══════════════════════════════════════

$ProcessBackend = $null
$ProcessFrontend = $null
$ProcessCelery = $null
$ProcessRedis = $null

function Demarrer-Services {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Démarrage des services"
    Ecrire-Log "═══════════════════════════════════════"

    # Redis
    Ecrire-Log "🔴 Vérification de Redis..."
    try {
        $redisTest = & redis-cli ping 2>&1
        if ($redisTest -match "PONG") {
            Ecrire-Log "✅ Redis est déjà en cours d'exécution"
        } else {
            Ecrire-Log "⚠️  Redis ne répond pas — tentative de démarrage..."
            try {
                # Essayer WSL d'abord
                $ProcessRedis = Start-Process -FilePath "wsl" -ArgumentList "redis-server" -PassThru -NoNewWindow
                Ecrire-Log "✅ Redis démarré via WSL"
            } catch {
                # Sinon essayer le service Windows
                try {
                    $redisSvc = Get-Service -Name "Redis*" -ErrorAction SilentlyContinue
                    if ($redisSvc) {
                        Start-Service $redisSvc.Name
                        Ecrire-Log "✅ Service Redis démarré"
                    } else {
                        Ecrire-Log "❌ Impossible de démarrer Redis" "ERREUR"
                        Ecrire-Log "  Installez Redis : https://github.com/microsoftarchive/redis/releases"
                        Ecrire-Log "  Ou via WSL : wsl sudo apt install redis-server && wsl redis-server"
                    }
                } catch {
                    Ecrire-Log "❌ Erreur Redis : $_" "ERREUR"
                }
            }
        }
    } catch {
        Ecrire-Log "⚠️  redis-cli non trouvé — Redis peut être dans WSL" "AVERT"
    }

    # Backend (uvicorn)
    if (-not $SkipBackend) {
        Ecrire-Log "🚀 Démarrage du backend FastAPI..."
        Push-Location $BackendDir
        $env:PYTHONPATH = $BackendDir
        $ProcessBackend = Start-Process -FilePath (Join-Path $VenvDir "Scripts\python.exe") `
            -ArgumentList "-m", "uvicorn", "src.main:app", "--reload", "--host", "0.0.0.0", "--port", "8000" `
            -PassThru -NoNewWindow
        Ecrire-Log "✅ Backend démarré (PID: $($ProcessBackend.Id))"
        Ecrire-Log "  URL : http://localhost:8000"
        Ecrire-Log "  Docs : http://localhost:8000/docs"
        Pop-Location

        # Attendre que le backend soit prêt
        Attendre-Service "Backend FastAPI" "http://localhost:8000/api/v1/health/live" 30 2
    }

    # Celery worker
    if (-not $SkipBackend) {
        Ecrire-Log "⚡ Démarrage du worker Celery..."
        Push-Location $BackendDir
        $env:PYTHONPATH = $BackendDir
        $ProcessCelery = Start-Process -FilePath (Join-Path $VenvDir "Scripts\celery.exe") `
            -ArgumentList "-A", "src.celery_app", "worker", "--loglevel=info", "--concurrency=2" `
            -PassThru -NoNewWindow
        Ecrire-Log "✅ Worker Celery démarré (PID: $($ProcessCelery.Id))"
        Pop-Location
    }

    # Frontend (next.js)
    if (-not $SkipFrontend) {
        Ecrire-Log "🎨 Démarrage du frontend Next.js..."
        Push-Location $FrontendDir
        $ProcessFrontend = Start-Process -FilePath "npm" `
            -ArgumentList "run", "dev" `
            -PassThru -NoNewWindow
        Ecrire-Log "✅ Frontend démarré (PID: $($ProcessFrontend.Id))"
        Ecrire-Log "  URL : http://localhost:3000"
        Pop-Location

        # Attendre que le frontend soit prêt
        Attendre-Service "Frontend Next.js" "http://localhost:3000" 30 3
    }

    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "🎉 NOKIROVA est en cours d'exécution !"
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "  Frontend : http://localhost:3000"
    Ecrire-Log "  Backend  : http://localhost:8000"
    Ecrire-Log "  Docs API : http://localhost:8000/docs"
    Ecrire-Log ""
    Ecrire-Log "  Appuyez sur Ctrl+C pour arrêter,"
    Ecrire-Log "  ou exécutez : .\setup.ps1 -Arreter"
    Ecrire-Log "═══════════════════════════════════════"

    # Garder le script actif
    try {
        while ($true) {
            Start-Sleep -Seconds 5
        }
    } finally {
        Arreter-Services
    }
}

# ═══════════════════════════════════════
# Arrêt des services
# ═══════════════════════════════════════

function Arreter-Services {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Arrêt des services"
    Ecrire-Log "═══════════════════════════════════════"

    # Backend
    if ($ProcessBackend -and -not $ProcessBackend.HasExited) {
        Ecrire-Log "🛑 Arrêt du backend (PID: $($ProcessBackend.Id))..."
        Stop-Process -Id $ProcessBackend.Id -Force -ErrorAction SilentlyContinue
        Ecrire-Log "✅ Backend arrêté"
    }

    # Celery
    if ($ProcessCelery -and -not $ProcessCelery.HasExited) {
        Ecrire-Log "🛑 Arrêt du worker Celery (PID: $($ProcessCelery.Id))..."
        Stop-Process -Id $ProcessCelery.Id -Force -ErrorAction SilentlyContinue
        Ecrire-Log "✅ Worker Celery arrêté"
    }

    # Frontend
    if ($ProcessFrontend -and -not $ProcessFrontend.HasExited) {
        Ecrire-Log "🛑 Arrêt du frontend (PID: $($ProcessFrontend.Id))..."
        Stop-Process -Id $ProcessFrontend.Id -Force -ErrorAction SilentlyContinue
        Ecrire-Log "✅ Frontend arrêté"
    }

    Ecrire-Log ""
    Ecrire-Log "✅ Tous les services NOKIROVA sont arrêtés"
}

# ═══════════════════════════════════════
# Reset complet
# ═══════════════════════════════════════

function Reset-Complet {
    Ecrire-Log ""
    Ecrire-Log "═══════════════════════════════════════"
    Ecrire-Log "NOKIROVA — Réinitialisation complète"
    Ecrire-Log "═══════════════════════════════════════"

    $confirmation = Read-Host "⚠️  Cela supprimera les venv, node_modules et caches. Continuer ? (oui/non)"
    if ($confirmation -ne "oui") {
        Ecrire-Log "Opération annulée"
        return
    }

    # Supprimer le venv
    if (Test-Path $VenvDir) {
        Ecrire-Log "🗑️  Suppression de l'environnement virtuel..."
        Remove-Item $VenvDir -Recurse -Force
        Ecrire-Log "✅ Venv supprimé"
    }

    # Supprimer node_modules
    $nodeModules = Join-Path $FrontendDir "node_modules"
    if (Test-Path $nodeModules) {
        Ecrire-Log "🗑️  Suppression de node_modules..."
        Remove-Item $nodeModules -Recurse -Force
        Ecrire-Log "✅ node_modules supprimé"
    }

    # Supprimer .next
    $nextCache = Join-Path $FrontendDir ".next"
    if (Test-Path $nextCache) {
        Ecrire-Log "🗑️  Suppression du cache .next..."
        Remove-Item $nextCache -Recurse -Force
        Ecrire-Log "✅ Cache .next supprimé"
    }

    # Supprimer les caches Python
    Ecrire-Log "🗑️  Suppression des caches __pycache__..."
    Get-ChildItem -Path $BackendDir -Directory -Recurse -Filter "__pycache__" |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

    Ecrire-Log "✅ Réinitialisation complète"
    Ecrire-Log "Exécutez .\setup.ps1 pour réinstaller"
}

# ═══════════════════════════════════════
# Point d'entrée principal
# ═══════════════════════════════════════

Ecrire-Log ""
Ecrire-Log "╔══════════════════════════════════════╗"
Ecrire-Log "║   NOKIROVA — Écosystème Éducatif IA  ║"
Ecrire-Log "╚══════════════════════════════════════╝"
Ecrire-Log ""

# Si aucun paramètre, faire une installation complète + démarrage
if (-not ($Demarrer -or $Arreter -or $Verifier -or $Migrer -or $Reset)) {
    $Installer = $true
    $Demarrer = $true
}

if ($Verifier) {
    Verifier-Prerequis
} elseif ($Reset) {
    Reset-Complet
} elseif ($Arreter) {
    Arreter-Services
} else {
    # Installation + démarrage
    if ($Installer) {
        Verifier-Prerequis
        if (-not $SkipBackend) { Installer-Backend }
        if (-not $SkipFrontend) { Installer-Frontend }
    }

    if ($Migrer) {
        Executer-Migrations
    }

    if ($Demarrer) {
        # Migrations avant premier démarrage
        if ($Installer) {
            Executer-Migrations
        }
        Demarrer-Services
    }
}
