-- NOKIROVA — Script d'initialisation PostgreSQL
--
-- Crée les extensions, les schémas et les tables de base.
-- Exécuté automatiquement au premier démarrage du conteneur.

-- ─── Extensions ──────────────────────────────────────────────────────────────

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";     -- UUID v4 automatiques
CREATE EXTENSION IF NOT EXISTS "pg_trgm";       -- Recherche floue (trigrammes)
CREATE EXTENSION IF NOT EXISTS "unaccent";       -- Recherche sans accents

-- ─── Schémas ─────────────────────────────────────────────────────────────────

CREATE SCHEMA IF NOT EXISTS auth;       -- Authentification et utilisateurs
CREATE SCHEMA IF NOT EXISTS edu;        -- Contenu éducatif (cours, leçons)
CREATE SCHEMA IF NOT EXISTS revision;   -- Flashcards, quiz, sessions
CREATE SCHEMA IF NOT EXISTS prod;       -- Documents et production
CREATE SCHEMA IF NOT EXISTS ai;         -- Agents, conversations, quotas
CREATE SCHEMA IF NOT EXISTS social;      -- Forum, groupes, classement
CREATE SCHEMA IF NOT EXISTS gamify;     -- Badges, succès, objectifs, XP
CREATE SCHEMA IF NOT EXISTS notif;      -- Notifications
CREATE SCHEMA IF NOT EXISTS audit;      -- Journal d'audit

-- ─── Table commune : types énumérés ─────────────────────────────────────────

-- Rôles utilisateur
CREATE TYPE auth.role_utilisateur AS ENUM (
    'etudiant', 'enseignant', 'parent', 'administrateur'
);

-- Plans d'abonnement
CREATE TYPE auth.plan_abonnement AS ENUM (
    'gratuit', 'etudiant', 'premium', 'institution'
);

-- Types d'objectif
CREATE TYPE gamify.type_objectif AS ENUM (
    'quotidien', 'hebdomadaire', 'mensuel', 'personnalise'
);

-- Rareté des badges
CREATE TYPE gamify.rarete_badge AS ENUM (
    'commun', 'rare', 'epique', 'legendaire'
);

-- Types de notification
CREATE TYPE notif.type_notification AS ENUM (
    'info', 'succes', 'avertissement', 'erreur', 'badge', 'serie', 'objectif', 'social'
);

-- Statut de publication
CREATE TYPE social.statut_publication AS ENUM (
    'brouillon', 'publie', 'archive', 'signale'
);

-- ─── Tables principales ─────────────────────────────────────────────────────

-- Utilisateurs
CREATE TABLE IF NOT EXISTS auth.utilisateurs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    mot_de_passe    VARCHAR(255) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    nom             VARCHAR(100) NOT NULL,
    role            auth.role_utilisateur NOT NULL DEFAULT 'etudiant',
    plan            auth.plan_abonnement NOT NULL DEFAULT 'gratuit',
    niveau          INTEGER NOT NULL DEFAULT 1,
    xp              INTEGER NOT NULL DEFAULT 0,
    streak_jours    INTEGER NOT NULL DEFAULT 0,
    streak_max      INTEGER NOT NULL DEFAULT 0,
    avatar_url      VARCHAR(500),
    etablissement   VARCHAR(255),
    bio             TEXT,
    est_verifie     BOOLEAN NOT NULL DEFAULT FALSE,
    est_actif       BOOLEAN NOT NULL DEFAULT TRUE,
    dernier_acces   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_inscription TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    preferences     JSONB NOT NULL DEFAULT '{
        "theme": "clair",
        "langue": "fr",
        "notifications_email": true,
        "notifications_push": true,
        "notifications_sms": false,
        "rappels_revision": true,
        "rapport_hebdo": true
    }'::jsonb
);

-- Badges
CREATE TABLE IF NOT EXISTS gamify.badges (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code            VARCHAR(100) UNIQUE NOT NULL,
    nom             VARCHAR(200) NOT NULL,
    description     TEXT NOT NULL,
    categorie       VARCHAR(50) NOT NULL,
    icone           VARCHAR(10) NOT NULL,
    rarete          gamify.rarete_badge NOT NULL DEFAULT 'commun',
    xp_recompense   INTEGER NOT NULL DEFAULT 0,
    conditions      JSONB NOT NULL DEFAULT '{}'::jsonb,
    date_creation    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Badges débloqués par utilisateur
CREATE TABLE IF NOT EXISTS gamify.badges_utilisateur (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    badge_id        UUID NOT NULL REFERENCES gamify.badges(id) ON DELETE CASCADE,
    debloque_le     TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(utilisateur_id, badge_id)
);

-- Objectifs
CREATE TABLE IF NOT EXISTS gamify.objectifs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    titre           VARCHAR(200) NOT NULL,
    type            gamify.type_objectif NOT NULL DEFAULT 'personnalise',
    cible           NUMERIC NOT NULL,
    actuel          NUMERIC NOT NULL DEFAULT 0,
    unite           VARCHAR(20) NOT NULL,
    est_atteint     BOOLEAN NOT NULL DEFAULT FALSE,
    date_limite     TIMESTAMP WITH TIME ZONE,
    xp_recompense   INTEGER NOT NULL DEFAULT 0,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Événements de gamification
CREATE TABLE IF NOT EXISTS gamify.evenements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    type            VARCHAR(50) NOT NULL,
    description     TEXT NOT NULL,
    xp_gagne        INTEGER NOT NULL DEFAULT 0,
    metadata        JSONB NOT NULL DEFAULT '{}'::jsonb,
    date_evenement  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Cours
CREATE TABLE IF NOT EXISTS edu.cours (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    titre           VARCHAR(300) NOT NULL,
    description     TEXT,
    matiere         VARCHAR(100) NOT NULL,
    niveau          VARCHAR(50) NOT NULL,
    est_publie      BOOLEAN NOT NULL DEFAULT TRUE,
    ordre           INTEGER NOT NULL DEFAULT 0,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Leçons
CREATE TABLE IF NOT EXISTS edu.lecons (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cours_id        UUID NOT NULL REFERENCES edu.cours(id) ON DELETE CASCADE,
    titre           VARCHAR(300) NOT NULL,
    contenu         TEXT NOT NULL,
    ordre           INTEGER NOT NULL DEFAULT 0,
    duree_min       INTEGER NOT NULL DEFAULT 10,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Flashcards
CREATE TABLE IF NOT EXISTS revision.flashcards (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    question        TEXT NOT NULL,
    reponse         TEXT NOT NULL,
    matiere         VARCHAR(100),
    difficulte      INTEGER NOT NULL DEFAULT 1 CHECK (difficulte BETWEEN 1 AND 5),
    intervalle_jours INTEGER NOT NULL DEFAULT 1,
    prochain_rev    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    repetitions     INTEGER NOT NULL DEFAULT 0,
    facteur_facilite REAL NOT NULL DEFAULT 2.5,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Documents
CREATE TABLE IF NOT EXISTS prod.documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    titre           VARCHAR(300) NOT NULL,
    contenu         JSONB NOT NULL DEFAULT '{}'::jsonb,
    type_document   VARCHAR(50) NOT NULL DEFAULT 'dissertation',
    statut          VARCHAR(20) NOT NULL DEFAULT 'brouillon',
    nombre_mots     INTEGER NOT NULL DEFAULT 0,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations IA
CREATE TABLE IF NOT EXISTS ai.conversations (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    agent_id        VARCHAR(100) NOT NULL,
    titre           VARCHAR(300),
    est_archivee    BOOLEAN NOT NULL DEFAULT FALSE,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Messages IA
CREATE TABLE IF NOT EXISTS ai.messages (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversation_id UUID NOT NULL REFERENCES ai.conversations(id) ON DELETE CASCADE,
    role            VARCHAR(20) NOT NULL CHECK (role IN ('utilisateur', 'assistant', 'systeme')),
    contenu         TEXT NOT NULL,
    tokens_utilise  INTEGER NOT NULL DEFAULT 0,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Publications forum
CREATE TABLE IF NOT EXISTS social.publications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    auteur_id       UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    titre           VARCHAR(300) NOT NULL,
    contenu         TEXT NOT NULL,
    categorie       VARCHAR(100),
    statut          social.statut_publication NOT NULL DEFAULT 'publie',
    nombre_likes     INTEGER NOT NULL DEFAULT 0,
    nombre_commentaires INTEGER NOT NULL DEFAULT 0,
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    date_modification TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Notifications
CREATE TABLE IF NOT EXISTS notif.notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID NOT NULL REFERENCES auth.utilisateurs(id) ON DELETE CASCADE,
    type            notif.type_notification NOT NULL DEFAULT 'info',
    titre           VARCHAR(200) NOT NULL,
    message         TEXT NOT NULL,
    est_lue         BOOLEAN NOT NULL DEFAULT FALSE,
    lien            VARCHAR(500),
    date_creation   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Journal d'audit
CREATE TABLE IF NOT EXISTS audit.journal (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    utilisateur_id  UUID,
    action          VARCHAR(100) NOT NULL,
    entite          VARCHAR(100),
    entite_id       UUID,
    details         JSONB NOT NULL DEFAULT '{}'::jsonb,
    adresse_ip      VARCHAR(45),
    date_evenement  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ─── Index ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_utilisateurs_email ON auth.utilisateurs(email);
CREATE INDEX IF NOT EXISTS idx_flashcards_utilisateur ON revision.flashcards(utilisateur_id, prochain_rev);
CREATE INDEX IF NOT EXISTS idx_documents_utilisateur ON prod.documents(utilisateur_id);
CREATE INDEX IF NOT EXISTS idx_conversations_utilisateur ON ai.conversations(utilisateur_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON ai.messages(conversation_id, date_creation);
CREATE INDEX IF NOT EXISTS idx_publications_auteur ON social.publications(auteur_id);
CREATE INDEX IF NOT EXISTS idx_notifications_utilisateur ON notif.notifications(utilisateur_id, est_lue, date_creation);
CREATE INDEX IF NOT EXISTS idx_objectifs_utilisateur ON gamify.objectifs(utilisateur_id, est_atteint);
CREATE INDEX IF NOT EXISTS idx_evenements_utilisateur ON gamify.evenements(utilisateur_id, date_evenement);
CREATE INDEX IF NOT EXISTS idx_audit_utilisateur ON audit.journal(utilisateur_id, date_evenement);

-- ─── Données initiales ──────────────────────────────────────────────────────

-- Insertion des badges par défaut
INSERT INTO gamify.badges (code, nom, description, categorie, icone, rarete, xp_recompense) VALUES
    ('premier_pas', 'Premier pas', 'Complétez votre première leçon', 'apprentissage', '🌱', 'commun', 50),
    ('bosseur', 'Bosseur', '7 jours consécutifs de révision', 'streak', '🔥', 'commun', 100),
    ('quiz_master', 'Quiz Master', '10 quiz avec 100% de bonnes réponses', 'revision', '🎯', 'rare', 200),
    ('ecrivain', 'Écrivain', 'Rédigez 5 dissertations', 'production', '✍️', 'rare', 200),
    ('polyvalent', 'Polyvalent', 'Étudiez 5 matières différentes', 'apprentissage', '🌈', 'epique', 500),
    ('legende', 'Légende', 'Atteignez le niveau 10', 'special', '👑', 'legendaire', 1000),
    ('genereux', 'Généreux', 'Aidez 50 personnes sur le forum', 'communaute', '🤝', 'epique', 500),
    ('explorateur', 'Explorateur', 'Explorez tous les espaces NOKIROVA', 'special', '🧭', 'commun', 100)
ON CONFLICT (code) DO NOTHING;

-- ─── Fin ────────────────────────────────────────────────────────────────────