# NOKIROVA — Guide d'installation locale sur Windows (PyCharm)

> **Version** : 0.1.0  
> **Dernière mise à jour** : Août 2024  
> **Environnement cible** : Windows 10/11, PyCharm Professional/Community, Python 3.11+

---

## Table des matières

1. [Prérequis](#1-prérequis)
2. [Installation de PostgreSQL 16](#2-installation-de-postgresql-16)
3. [Installation de Redis (Memurai ou WSL)](#3-installation-de-redis)
4. [Installation de Python et du venv](#4-installation-de-python-et-du-venv)
5. [Installation des dépendances Python](#5-installation-des-dépendances-python)
6. [Configuration des variables d'environnement](#6-configuration-des-variables-denvironnement)
7. [Configuration de PyCharm](#7-configuration-de-pycharm)
8. [Base de données — Création et migrations](#8-base-de-données--création-et-migrations)
9. [Démarrage du backend](#9-démarrage-du-backend)
10. [Démarrage du frontend](#10-démarrage-du-frontend)
11. [Vérification de santé](#11-vérification-de-santé)
12. [Dépannage](#12-dépannage)
13. [Outils externes recommandés](#13-outils-externes-recommandés)

---

## 1. Prérequis

| Outil | Version minimale | Notes |
|-------|-----------------|-------|
| Python | 3.11+ | 3.12 recommandé |
| Node.js | 20+ | LTS recommandé |
| PostgreSQL | 16+ | Avec pgvector |
| Redis | 7+ | Memurai ou WSL sur Windows |
| Git | 2.40+ | |
| PyCharm | 2024.1+ | Professional pour le support FastAPI |
| Tesseract OCR | 5.3+ | Optionnel — pour le moteur OCR |
| Poppler | 23+ | Optionnel — pour pdf2image |

---

## 2. Installation de PostgreSQL 16

### 2.1 Téléchargement

1. Allez sur [https://www.postgresql.org/download/windows/](https://www.postgresql.org/download/windows/)
2. Téléchargez PostgreSQL 16 (ou supérieur)
3. Lancez l'installateur

### 2.2 Installation

- **Répertoire** : `C:\Program Files\PostgreSQL\16`
- **Port** : 5432 (par défaut)
- **Mot de passe superutilisateur** : choisissez un mot de passe sécurisé pour `postgres`
- **Composants** : cochez **Stack Builder** (pour installer pgvector plus tard)

### 2.3 Extension pgvector

pgvector est requis pour la recherche vectorielle.

**Option A — Via Stack Builder** :
1. Lancez Stack Builder après l'installation PostgreSQL
2. Sélectionnez votre serveur
3. Cherchez « pgvector » dans les extensions
4. Installez-le

**Option B — Compilation manuelle** :
```powershell
# Cloner et compiler pgvector
git clone https://github.com/pgvector/pgvector.git
cd pgvector
make
make install
```

**Option C — Via SQL** (si déjà installé) :
```sql
CREATE EXTENSION IF NOT EXISTS vector;
```

### 2.4 Création de la base et de l'utilisateur

Ouvrez `psql` (dans le menu démarrer ou via le terminal) :

```sql
-- Créer l'utilisateur
CREATE USER nokirova_admin WITH PASSWORD 'nokirova_dev_2024';

-- Créer la base
CREATE DATABASE nokirova_db OWNER nokirova_admin;

-- Activer pgvector
\c nokirova_db
CREATE EXTENSION IF NOT EXISTS vector;

-- Accorder les droits
GRANT ALL PRIVILEGES ON DATABASE nokirova_db TO nokirova_admin;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO nokirova_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO nokirova_admin;
```

---

## 3. Installation de Redis

Sur Windows, Redis n'a pas de version native officielle. Deux options :

### 3.1 Option A — Memurai (recommandé)

Memurai est un cache Redis compatible pour Windows.

1. Allez sur [https://www.memurai.com/](https://www.memurai.com/)
2. Téléchargez Memurai Developer Edition (gratuit)
3. Installez et lancez — il s'exécute comme service Windows
4. Par défaut : `localhost:6379`

Vérification :
```powershell
memurai-cli ping
# Doit retourner : PONG
```

### 3.2 Option B — Redis via WSL

1. Installez WSL : `wsl --install`
2. Dans le terminal WSL :
```bash
sudo apt update
sudo apt install redis-server
sudo service redis-server start
redis-cli ping  # PONG
```

3. Redis est accessible depuis Windows via `localhost:6379`

### 3.3 Option C — Redis dans Docker (si Docker installé)

```powershell
docker run -d --name nokirova-redis -p 6379:6379 redis:7-alpine
```

---

## 4. Installation de Python et du venv

### 4.1 Python

1. Téléchargez Python 3.11+ depuis [python.org](https://www.python.org/downloads/)
2. **Important** : cochez « Add Python to PATH » lors de l'installation
3. Vérifiez :
```powershell
python --version
# Python 3.11.x ou 3.12.x
```

### 4.2 Environnement virtuel

Dans PyCharm ou via le terminal :

```powershell
cd C:\chemin\vers\NOKIROVA\backend
python -m venv venv
.\venv\Scripts\activate
```

Ou dans PyCharm : `Settings → Project → Python Interpreter → Add Interpreter → Virtualenv Environment`

---

## 5. Installation des dépendances Python

### 5.1 Installation minimale (recommandé pour démarrer)

Installe uniquement les dépendances nécessaires au démarrage :

```powershell
cd backend
pip install -r requirements-minimal.txt
```

### 5.2 Installation complète (avec moteurs IA et OCR)

⚠️ Nécessite Microsoft C++ Build Tools pour certaines dépendances.

```powershell
pip install -r requirements.txt
```

### 5.3 Outils système optionnels

Pour les moteurs OCR :

- **Tesseract OCR** : [https://github.com/UB-Mannheim/tesseract/wiki](https://github.com/UB-Mannheim/tesseract/wiki)
  - Ajoutez Tesseract au PATH : `C:\Program Files\Tesseract-OCR`
  - Téléchargez les données French : [tessdata](https://github.com/tesseract-ocr/tessdata)

- **Poppler** (pour pdf2image) : [https://github.com/oschwartz10612/poppler-windows/releases](https://github.com/oschwartz10612/poppler-windows/releases)
  - Ajoutez `poppler-X.X\bin` au PATH

---

## 6. Configuration des variables d'environnement

### 6.1 Créer le fichier .env

```powershell
cd backend
copy .env.example .env
```

### 6.2 Modifier le fichier .env

Ouvrez `backend/.env` dans votre éditeur et adaptez les valeurs :

```env
# ── Base de données ──
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_NAME=nokirova_db
DATABASE_USER=nokirova_admin
DATABASE_PASSWORD=nokirova_dev_2024     # ← votre mot de passe PostgreSQL

# ── Redis ──
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=                            # ← vide si pas de mot de passe
REDIS_DB=0

# ── JWT ──
JWT_SECRET=dev_only_jwt_secret_nokirova_2024_changez_en_production_64chars
# ⚠️ Changez ce secret en production !

# ── IA ──
AI_PROVIDER=openai
AI_API_KEY=sk-...                          # ← votre clé API OpenAI (optionnel)
```

> **Note** : Le fichier `.env` est déjà ignoré par `.gitignore`. Ne le commitez jamais.

---

## 7. Configuration de PyCharm

### 7.1 Ouvrir le projet

1. `File → Open` → sélectionnez le dossier `NOKIROVA`
2. PyCharm détectera le `venv` automatiquement

### 7.2 Configurer l'interpréteur Python

1. `Settings → Project: NOKIROVA → Python Interpreter`
2. Sélectionnez le venv : `backend/venv/Scripts/python.exe`
3. Si absent, ajoutez-le via `Add Interpreter → Existing environment`

### 7.3 Configuration d'exécution FastAPI

1. `Run → Edit Configurations → + → Python`
2. Configurez :
   - **Name** : `NOKIROVA Backend`
   - **Script path** : `-m uvicorn`
   - **Parameters** : `src.main:app --reload --host 0.0.0.0 --port 8000`
   - **Working directory** : `C:\chemin\vers\NOKIROVA\backend`
   - **Python interpreter** : votre venv
   - **Environment variables** : (optionnel, le .env est chargé automatiquement)

### 7.4 Configuration d'exécution Alembic

1. `Run → Edit Configurations → + → Python`
2. Configurez :
   - **Name** : `Alembic Migrate`
   - **Script path** : `-m alembic`
   - **Parameters** : `upgrade head`
   - **Working directory** : `C:\chemin\vers\NOKIROVA\backend`

### 7.5 Configuration d'exécution du Frontend

1. `Run → Edit Configurations → + → npm`
2. Configurez :
   - **Name** : `NOKIROVA Frontend`
   - **package.json** : `C:\chemin\vers\NOKIROVA\frontend\package.json`
   - **Command** : `run`
   - **Scripts** : `dev`

### 7.6 Plugin recommandé

- **.env files support** — coloration syntaxique pour les fichiers `.env`
- **Database Navigator** — navigation SQL dans PyCharm

---

## 8. Base de données — Création et migrations

### 8.1 Vérifier la connexion

```powershell
cd backend
python start_local.py
```

Ce script vérifie :
- ✅ Version Python
- ✅ Fichier .env
- ✅ Dépendances Python
- ✅ Connexion PostgreSQL
- ✅ Connexion Redis
- ✅ Chargement de la configuration
- ✅ Import de l'application FastAPI
- ✅ Configuration Alembic

### 8.2 Appliquer les migrations

```powershell
cd backend
python -m alembic upgrade head
```

### 8.3 Créer une nouvelle migration (si modèle modifié)

```powershell
python -m alembic revision --autogenerate -m "description_de_la_migration"
python -m alembic upgrade head
```

---

## 9. Démarrage du backend

### 9.1 Via PyCharm

Utilisez la configuration `NOKIROVA Backend` créée en section 7.3.

Cliquez sur **Run** (▶) ou **Debug** (🐛).

### 9.2 Via le terminal

```powershell
cd backend
.venv\Scripts\activate
uvicorn src.main:app --reload --host 0.0.0.0 --port 8000
```

### 9.3 Vérification

Ouvrez votre navigateur :
- API : [http://localhost:8000/docs](http://localhost:8000/docs) (Swagger UI)
- Santé : [http://localhost:8000/sante](http://localhost:8000/sante)
- Santé : [http://localhost:8000/health](http://localhost:8000/health)

---

## 10. Démarrage du frontend

### 10.1 Installation

```powershell
cd frontend
npm install
```

### 10.2 Lancement

```powershell
npm run dev
```

Le frontend sera accessible sur [http://localhost:3000](http://localhost:3000).

---

## 11. Vérification de santé

| Service | URL | Résultat attendu |
|---------|-----|------------------|
| Backend API | `http://localhost:8000/docs` | Swagger UI |
| Backend Santé | `http://localhost:8000/sante` | `{"status": "ok"}` |
| Backend Santé EN | `http://localhost:8000/health` | `{"status": "ok"}` |
| Frontend | `http://localhost:3000` | Page d'accueil NOKIROVA |

---

## 12. Dépannage

### PostgreSQL

| Problème | Solution |
|----------|----------|
| `Connection refused` | Vérifiez que le service PostgreSQL est lancé (services.msc) |
| `database "nokirova_db" does not exist` | Créez la base (section 2.4) |
| `password authentication failed` | Vérifiez DATABASE_PASSWORD dans .env |
| `extension "vector" does not exist` | Installez pgvector (section 2.3) |

### Redis

| Problème | Solution |
|----------|----------|
| `Connection refused` | Vérifiez que Memurai ou Redis (WSL) est lancé |
| `NOAUTH` | Définissez REDIS_PASSWORD dans .env |

### Python / Dépendances

| Problème | Solution |
|----------|----------|
| `ModuleNotFoundError` | Activez le venv et installez les dépendances |
| `pydantic ValidationError` | Vérifiez les valeurs dans .env |
| `error: Microsoft Visual C++ 14.0 is required` | Installez [Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) |
| `aioredis` introuvable | ✅ Normal — aioredis est supprimé, redis>=5.0 inclut redis.asyncio |

### Alembic

| Problème | Solution |
|----------|----------|
| `Target database is not up to date` | Exécutez `alembic upgrade head` |
| `Can't locate revision` | `alembic stamp head` (si base déjà à jour) |
| `ImportError` dans env.py | Vérifiez que les modèles correspondent à `models/__init__.py` |

### Frontend

| Problème | Solution |
|----------|----------|
| `npm ERR! code ERESOLVE` | `npm install --legacy-peer-deps` |
| `Port 3000 already in use` | Changez le port : `npm run dev -- --port 3001` |

---

## 13. Outils externes recommandés

| Outil | Usage | Lien |
|-------|-------|------|
| pgAdmin | Administration PostgreSQL | Inclus avec PostgreSQL |
| DBeaver | Client SQL universel | [dbeaver.io](https://dbeaver.io/) |
| Redis Insight | Visualisation Redis | [redis.com/redis-enterprise/redis-insight](https://redis.com/redis-enterprise/redis-insight/) |
| Postman | Tests API | [postman.com](https://www.postman.com/) |
| Memurai | Redis pour Windows | [memurai.com](https://www.memurai.com/) |

---

> **Architecture NOKIROVA** : 8 espaces · 13 moteurs · Event Bus · Auto-guérison · Provider-agnostic
> 
> Chaque module est indépendant. Chaque service est remplaçable. Le bus d'événements orchestre tout.

---

*Bon développement ! 🚀*