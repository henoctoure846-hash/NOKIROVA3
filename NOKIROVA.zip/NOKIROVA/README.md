# 🎓 NOKIROVA — L'OS Éducatif

> Le système d'exploitation éducatif complet, intelligent et modulaire.

## 🌍 Vision

NOKIROVA n'est pas une simple application. C'est un **système d'exploitation dédié à l'apprentissage** qui donne l'impression que tout est connecté, intelligent, fluide et cohérent.

## 🏗️ Architecture

```
UTILISATEUR
    ↓
Frontend (React + Next.js + TypeScript)
    ↓
API Gateway
    ↓
Backend Core (FastAPI + Python)
    ↓
Micro-Services (13 moteurs indépendants)
    ↓
Database (PostgreSQL + Redis + Vector DB)
    ↓
Storage + AI Engine + Analytics
```

## 📦 Modules Principaux

| Espace | Description |
|--------|-------------|
| 🏠 Accueil | Dashboard intelligent, conseil IA |
| 📚 Apprendre | Cours, chapitres, exercices |
| 🧠 Réviser | Flashcards, quiz, répétition espacée |
| ✍ Produire | Éditeur, documents, notes |
| 🤖 IA Studio | Jumeau Pédagogique, orchestration IA |
| 👥 Communauté | Groupes, mentorat, marketplace |
| 📈 Progression | Statistiques, badges, objectifs |
| ⚙ Paramètres | Configuration, plugins, thèmes |

## 🧠 Innovations

- **Jumeau Pédagogique** : Clone numérique académique qui apprend de vous
- **Document Vivant** : Document avec mémoire pédagogique
- **SIO** : Système d'Intelligence Orchestée (multi-modèles)
- **Self-Healing** : Auto-réparation du système
- **Knowledge Graph** : Graphe de connaissances relationnel
- **Knowledge Lake** : Lac de connaissances multi-sources

## 🚀 Démarrage Rapide

```bash
# 1. Cloner le projet
git clone <repo-url> NOKIROVA
cd NOKIROVA

# 2. Copier la configuration
cp .env.example .env
# Remplir les variables dans .env

# 3. Lancer avec Docker
docker compose up --build

# 4. Accéder
# Frontend : http://localhost:3000
# Backend  : http://localhost:8000
# Docs API  : http://localhost:8000/docs
```

## 📁 Structure du Projet

```
NOKIROVA/
├── frontend/          # Application React + Next.js
├── backend/           # API FastAPI + Services
├── database/          # Schémas, migrations, seeds
├── docker/            # Configuration Docker
├── scripts/           # Scripts utilitaires
└── documentation/     # Documentation technique
```

## 📜 Les 12 Principes Fondamentaux

1. **Modularité absolue** — Chaque module est indépendant
2. **IA omniprésente** — Jamais directe, toujours orchestrée
3. **Provider-agnostic** — Aucun fournisseur verrouillé
4. **Zéro suppression** — Corbeille + rétention configurable
5. **Document Vivant** — Chaque document a une mémoire
6. **Self-Healing** — Le système se répare seul
7. **Event-Driven** — Tout passe par le Bus d'Événements
8. **Offline-First** — Fonctionne hors-ligne
9. **Adaptive UI** — L'interface évolue avec l'utilisateur
10. **Knowledge Graph** — Relations entre concepts, pas seulement documents
11. **Workflow Engine** — Toute action = un workflow
12. **Zero Surprise** — Avant de coder, documenter l'objectif

## 🛡️ Licence

Projet propriétaire — Tous droits réservés.
