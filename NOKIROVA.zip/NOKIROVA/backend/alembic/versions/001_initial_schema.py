"""Schema initial NOKIROVA

Revision ID: 001_initial
Revises: None
Create Date: 2025-01-01 00:00:00.000000

Crée toutes les tables du schéma NOKIROVA :
- Utilisateurs et profils
- Cours et leçons
- Flashcards et decks
- Quizzes et tentatives
- Documents et pages
- Révision et répétition espacée
- Communauté et modération
- Badges et achievements
- IA conversations
- Recherche et notifications
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
        # ── Utilisateurs ──────────────────────────────────────────
        op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("email", sa.String(255), unique=True, nullable=False, index=True),
        sa.Column("username", sa.String(50), unique=True, nullable=False, index=True),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(100)),
        sa.Column("role", sa.String(20), default="student"),
        sa.Column("tenant_id", sa.String(50), default="default", index=True),
        sa.Column("is_active", sa.Boolean(), default=True),
        sa.Column("is_verified", sa.Boolean(), default=False),
        sa.Column("is_premium", sa.Boolean(), default=False),
        sa.Column("avatar_url", sa.String(500)),
        sa.Column("locale", sa.String(5), default="fr"),
        sa.Column("timezone", sa.String(50), default="Europe/Paris"),
        sa.Column("last_login_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now()),
        )

        op.create_table(
        "user_profiles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), unique=True),
        sa.Column("bio", sa.Text),
        sa.Column("education_level", sa.String(50)),
        sa.Column("institution", sa.String(200)),
        sa.Column("learning_style", sa.String(20)),
        sa.Column("daily_study_minutes", sa.Integer, default=30),
        sa.Column("preferred_subjects", postgresql.JSONB(), default=list),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "user_preferences",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), unique=True),
        sa.Column("theme", sa.String(10), default="system"),
        sa.Column("font_size", sa.String(10), default="medium"),
        sa.Column("reduced_motion", sa.Boolean(), default=False),
        sa.Column("high_contrast", sa.Boolean(), default=False),
        sa.Column("language", sa.String(5), default="fr"),
        sa.Column("email_notifications", sa.Boolean(), default=True),
        sa.Column("push_notifications", sa.Boolean(), default=True),
        sa.Column("ai_assistance_level", sa.String(20), default="moderate"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        # ── Cours ─────────────────────────────────────────────────
        op.create_table(
        "courses",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("slug", sa.String(255), unique=True, index=True),
        sa.Column("subject", sa.String(100), index=True),
        sa.Column("level", sa.String(20)),
        sa.Column("thumbnail_url", sa.String(500)),
        sa.Column("is_published", sa.Boolean(), default=False),
        sa.Column("is_premium", sa.Boolean(), default=False),
        sa.Column("difficulty", sa.Integer, default=1),
        sa.Column("estimated_hours", sa.Integer),
        sa.Column("author_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id")),
        sa.Column("tenant_id", sa.String(50), default="default", index=True),
        sa.Column("enrollment_count", sa.Integer, default=0),
        sa.Column("rating_avg", sa.Float, default=0.0),
        sa.Column("tags", postgresql.JSONB(), default=list),
        sa.Column("metadata_json", postgresql.JSONB(), default=dict),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "lessons",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("course_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("courses.id", ondelete="CASCADE"), index=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("order_index", sa.Integer, nullable=False),
        sa.Column("content", postgresql.JSONB(), default=dict),
        sa.Column("content_type", sa.String(20), default="mixed"),
        sa.Column("duration_minutes", sa.Integer, default=15),
        sa.Column("is_published", sa.Boolean(), default=False),
        sa.Column("is_free", sa.Boolean(), default=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "course_enrollments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("course_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("courses.id", ondelete="CASCADE"), index=True),
        sa.Column("progress_pct", sa.Float, default=0.0),
        sa.Column("is_completed", sa.Boolean(), default=False),
        sa.Column("enrolled_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint("user_id", "course_id", name="uq_enrollment_user_course"),
        )

        op.create_table(
        "lesson_progress",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE")),
        sa.Column("lesson_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("lessons.id", ondelete="CASCADE")),
        sa.Column("is_completed", sa.Boolean(), default=False),
        sa.Column("progress_pct", sa.Float, default=0.0),
        sa.Column("time_spent_seconds", sa.Integer, default=0),
        sa.Column("last_position", postgresql.JSONB()),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint("user_id", "lesson_id", name="uq_lesson_progress_user_lesson"),
        )

        # ── Flashcards ─────────────────────────────────────────────
        op.create_table(
        "flashcard_decks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("is_public", sa.Boolean(), default=False),
        sa.Column("ai_generated", sa.Boolean(), default=False),
        sa.Column("card_count", sa.Integer, default=0),
        sa.Column("tags", postgresql.JSONB(), default=list),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "flashcards",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("deck_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("flashcard_decks.id", ondelete="CASCADE"), index=True),
        sa.Column("front", sa.Text, nullable=False),
        sa.Column("back", sa.Text, nullable=False),
        sa.Column("hint", sa.Text),
        sa.Column("media_url", sa.String(500)),
        sa.Column("media_type", sa.String(20)),
        sa.Column("difficulty", sa.Integer, default=3),
        sa.Column("order_index", sa.Integer, default=0),
        sa.Column("ai_generated", sa.Boolean(), default=False),
        sa.Column("source_document_id", postgresql.UUID(as_uuid=True)),
        sa.Column("tags", postgresql.JSONB(), default=list),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        # ── Quizzes ────────────────────────────────────────────────
        op.create_table(
        "quizzes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("course_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("courses.id", ondelete="SET NULL")),
        sa.Column("lesson_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("lessons.id", ondelete="SET NULL")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("quiz_type", sa.String(20), default="practice"),
        sa.Column("is_public", sa.Boolean(), default=False),
        sa.Column("ai_generated", sa.Boolean(), default=False),
        sa.Column("time_limit_seconds", sa.Integer),
        sa.Column("max_attempts", sa.Integer, default=3),
        sa.Column("passing_score_pct", sa.Float, default=60.0),
        sa.Column("question_count", sa.Integer, default=0),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "quiz_questions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("quiz_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quizzes.id", ondelete="CASCADE"), index=True),
        sa.Column("question_text", sa.Text, nullable=False),
        sa.Column("question_type", sa.String(20), default="multiple_choice"),
        sa.Column("explanation", sa.Text),
        sa.Column("hint", sa.Text),
        sa.Column("points", sa.Integer, default=1),
        sa.Column("order_index", sa.Integer, default=0),
        sa.Column("media_url", sa.String(500)),
        sa.Column("ai_generated", sa.Boolean(), default=False),
        sa.Column("metadata_json", postgresql.JSONB(), default=dict),
        )

        op.create_table(
        "quiz_answers",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("question_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quiz_questions.id", ondelete="CASCADE")),
        sa.Column("answer_text", sa.Text, nullable=False),
        sa.Column("is_correct", sa.Boolean(), default=False),
        sa.Column("order_index", sa.Integer, default=0),
        )

        op.create_table(
        "quiz_attempts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("quiz_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quizzes.id", ondelete="CASCADE"), index=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("score_pct", sa.Float, default=0.0),
        sa.Column("is_passed", sa.Boolean(), default=False),
        sa.Column("is_completed", sa.Boolean(), default=False),
        sa.Column("time_spent_seconds", sa.Integer, default=0),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        )

        op.create_table(
        "quiz_responses",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("attempt_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quiz_attempts.id", ondelete="CASCADE")),
        sa.Column("question_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("quiz_questions.id")),
        sa.Column("user_answer", sa.Text),
        sa.Column("is_correct", sa.Boolean(), default=False),
        sa.Column("time_spent_ms", sa.Integer, default=0),
        )

        # ── Documents ──────────────────────────────────────────────
        op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("original_filename", sa.String(255)),
        sa.Column("file_url", sa.String(500)),
        sa.Column("file_type", sa.String(20)),
        sa.Column("file_size_bytes", sa.BigInteger, default=0),
        sa.Column("page_count", sa.Integer, default=0),
        sa.Column("ocr_status", sa.String(20), default="pending"),
        sa.Column("ocr_text", sa.Text),
        sa.Column("summary", sa.Text),
        sa.Column("is_public", sa.Boolean(), default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        # ── Révision & Répétition espacée ─────────────────────────
        op.create_table(
        "revision_plans",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("course_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("courses.id", ondelete="SET NULL")),
        sa.Column("name", sa.String(255)),
        sa.Column("schedule", postgresql.JSONB(), default=dict),
        sa.Column("is_active", sa.Boolean(), default=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "revision_sessions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("plan_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("revision_plans.id", ondelete="SET NULL")),
        sa.Column("session_type", sa.String(20), default="spaced_rep"),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("ended_at", sa.DateTime(timezone=True)),
        sa.Column("duration_seconds", sa.Integer, default=0),
        sa.Column("items_reviewed", sa.Integer, default=0),
        sa.Column("score_pct", sa.Float),
        sa.Column("metadata_json", postgresql.JSONB(), default=dict),
        )

        op.create_table(
        "spaced_repetition_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("flashcard_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("flashcards.id", ondelete="CASCADE")),
        sa.Column("easiness_factor", sa.Float, default=2.5),
        sa.Column("interval_days", sa.Integer, default=1),
        sa.Column("repetition_count", sa.Integer, default=0),
        sa.Column("next_review_at", sa.DateTime(timezone=True)),
        sa.Column("last_reviewed_at", sa.DateTime(timezone=True)),
        sa.Column("quality_rating", sa.Integer),
        )

        # ── Communauté ─────────────────────────────────────────────
        op.create_table(
        "community_posts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("author_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("post_type", sa.String(20), default="discussion"),
        sa.Column("is_pinned", sa.Boolean(), default=False),
        sa.Column("is_locked", sa.Boolean(), default=False),
        sa.Column("view_count", sa.Integer, default=0),
        sa.Column("tags", postgresql.JSONB(), default=list),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "community_comments",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("post_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("community_posts.id", ondelete="CASCADE"), index=True),
        sa.Column("author_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE")),
        sa.Column("parent_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("community_comments.id")),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "community_likes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE")),
        sa.Column("target_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("target_type", sa.String(20), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("user_id", "target_id", "target_type", name="uq_like_user_target"),
        )

        # ── Badges & Achievements ─────────────────────────────────
        op.create_table(
        "badges",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("icon_url", sa.String(500)),
        sa.Column("category", sa.String(50)),
        sa.Column("rarity", sa.String(20), default="common"),
        sa.Column("criteria", postgresql.JSONB(), default=dict),
        )

        op.create_table(
        "user_badges",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("badge_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("badges.id")),
        sa.Column("awarded_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "achievements",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("category", sa.String(50)),
        sa.Column("threshold", sa.Integer, default=1),
        sa.Column("xp_reward", sa.Integer, default=0),
        )

        op.create_table(
        "user_achievements",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("achievement_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("achievements.id")),
        sa.Column("progress", sa.Integer, default=0),
        sa.Column("is_unlocked", sa.Boolean(), default=False),
        sa.Column("unlocked_at", sa.DateTime(timezone=True)),
        )

        op.create_table(
        "streaks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), unique=True),
        sa.Column("current_streak", sa.Integer, default=0),
        sa.Column("longest_streak", sa.Integer, default=0),
        sa.Column("last_activity_date", sa.Date()),
        )

        op.create_table(
        "daily_goals",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("target_minutes", sa.Integer, default=30),
        sa.Column("actual_minutes", sa.Integer, default=0),
        sa.Column("is_completed", sa.Boolean(), default=False),
        sa.UniqueConstraint("user_id", "date", name="uq_daily_goal_user_date"),
        )

        # ── IA Conversations ───────────────────────────────────────
        op.create_table(
        "ai_conversations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("title", sa.String(255)),
        sa.Column("space", sa.String(20)),
        sa.Column("provider", sa.String(20)),
        sa.Column("model", sa.String(50)),
        sa.Column("is_archived", sa.Boolean(), default=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "ai_messages",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("conversation_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("ai_conversations.id", ondelete="CASCADE"), index=True),
        sa.Column("role", sa.String(20), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("tokens_used", sa.Integer, default=0),
        sa.Column("model", sa.String(50)),
        sa.Column("provider", sa.String(20)),
        sa.Column("metadata_json", postgresql.JSONB(), default=dict),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        # ── Recherche & Notifications ──────────────────────────────
        op.create_table(
        "search_index",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("entity_type", sa.String(50), nullable=False, index=True),
        sa.Column("entity_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(255)),
        sa.Column("content", sa.Text),
        sa.Column("tags", postgresql.JSONB(), default=list),
        sa.Column("embedding_id", sa.String(100)),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "notifications",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), index=True),
        sa.Column("type", sa.String(50), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("message", sa.Text),
        sa.Column("data", postgresql.JSONB(), default=dict),
        sa.Column("is_read", sa.Boolean(), default=False),
        sa.Column("action_url", sa.String(500)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        )

        op.create_table(
        "notification_preferences",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), unique=True),
        sa.Column("email_enabled", sa.Boolean(), default=True),
        sa.Column("push_enabled", sa.Boolean(), default=True),
        sa.Column("in_app_enabled", sa.Boolean(), default=True),
        sa.Column("quiet_hours_start", sa.Time()),
        sa.Column("quiet_hours_end", sa.Time()),
        sa.Column("categories", postgresql.JSONB(), default=dict),
        )

        # ── Index supplémentaires ──────────────────────────────────
        op.create_index("ix_courses_subject_level", "courses", ["subject", "level"])
        op.create_index("ix_lessons_course_order", "lessons", ["course_id", "order_index"])
        op.create_index("ix_flashcards_deck_order", "flashcards", ["deck_id", "order_index"])
        op.create_index("ix_spaced_rep_next_review", "spaced_repetition_items", ["user_id", "next_review_at"])
        op.create_index("ix_notifications_user_unread", "notifications", ["user_id", "is_read"])
        op.create_index("ix_search_entity", "search_index", ["entity_type", "entity_id"], unique=True)


def downgrade() -> None:
        """Supprime toutes les tables (ordre inverse des dépendances)."""
        op.drop_table("notification_preferences")
        op.drop_table("notifications")
        op.drop_table("search_index")
        op.drop_table("ai_messages")
        op.drop_table("ai_conversations")
        op.drop_table("daily_goals")
        op.drop_table("streaks")
        op.drop_table("user_achievements")
        op.drop_table("achievements")
        op.drop_table("user_badges")
        op.drop_table("badges")
        op.drop_table("community_likes")
        op.drop_table("community_comments")
        op.drop_table("community_posts")
        op.drop_table("spaced_repetition_items")
        op.drop_table("revision_sessions")
        op.drop_table("revision_plans")
        op.drop_table("documents")
        op.drop_table("quiz_responses")
        op.drop_table("quiz_attempts")
        op.drop_table("quiz_answers")
        op.drop_table("quiz_questions")
        op.drop_table("quizzes")
        op.drop_table("flashcards")
        op.drop_table("flashcard_decks")
        op.drop_table("lesson_progress")
        op.drop_table("course_enrollments")
        op.drop_table("lessons")
        op.drop_table("courses")
        op.drop_table("user_preferences")
        op.drop_table("user_profiles")
        op.drop_table("users")
