"""
NOKIROVA — Configuration Alembic

Environnement de migration pour la base de données NOKIROVA.
Supporte les modes offline et online.
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# Ajouter le chemin du projet
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.core.config import settings
from src.database.base import Base

# Importer tous les modèles pour que Alembic les détecte automatiquement
from src.database.models import (  # noqa: F401
        # Core
        Setting, Translation, FeatureFlag, AuditLog,
        # Utilisateurs
        User, UserProfile, UserPreference, UserDevice,
        # Auth
        RefreshToken, PasswordReset, LoginHistory, OAuthConnection,
        # Université
        Course, Module, Lesson, Prerequisite, Enrollment, LessonProgress,
        # Documents
        Document, DocumentVersion, DocumentFolder, DocumentCollaborator, DocumentShare,
        # Stockage
        File, StorageQuota,
        # OCR
        OCRJob, OCRResult, OCRPage,
        # Indexation
        SearchIndex, VectorEmbedding, IndexJob,
        # Notes
        Note, NoteAnnotation, NoteLink,
        # Flashcards
        FlashcardDeck, Flashcard, FlashcardReview,
        # Quiz
        Quiz, QuizQuestion, QuizAnswer, QuizAttempt, QuizResponse,
        # Examens
        Exam, ExamSection, ExamSession, ExamProctoring,
        # IA
        AIAgent, AIConversation, AIMessage, AIReasoningChain, AIModelConfig, AIUsageLog,
        # Chat
        ChatRoom, ChatMessage, ChatMember, ChatAttachment,
        # Mémoire
        MemoryNode, MemoryEdge, MemoryContext, MemorySnapshot,
        # Révision
        RevisionPlan, RevisionSession, RevisionItem, RevisionAnalytics,
        # Communauté
        CommunityPost, CommunityComment, CommunityLike,
        CommunityGroup, CommunityEvent, CommunityReport, CommunityBadgeUser,
        # Marketplace
        MarketplaceCategory, MarketplaceItem, MarketplaceReview, MarketplacePurchase,
        # Gamification
        GamificationBadge, Achievement, UserXP, Streak, Leaderboard, Challenge, Reward,
        # Analytics
        AnalyticsEvent, AnalyticsDailyStats, AnalyticsUserActivity,
        AnalyticsCourseStats, AnalyticsAIUsageStats,
        # Notifications
        Notification, NotificationPreference, NotificationChannel,
        # Plugins
        Plugin, PluginConfig, PluginPermission, PluginHook,
        # Logs
        SystemLog, APILog, ErrorLog, AuditTrail,
        # Monitoring
        HealthCheck, ServiceMetric, Alert, AlertRule,
        # Administration
        AdminRole, AdminUserRole, AdminAction, SystemSetting, MaintenanceWindow,
        # Archive
        ArchiveRecord, ArchivePolicy,
        # Knowledge Graph
        KGConcept, KGRelationship, KGAttribute, KGLearningPath,
        # Knowledge Lake
        KLSource, KLDocument, KLEmbedding, KLCluster, KLSchema,
)

# Configuration Alembic
config = context.config

# Interpréter le fichier de config pour le logging Python
if config.config_file_name is not None:
        fileConfig(config.config_file_name)

# URL de la base de données depuis les settings (version synchrone pour Alembic)
config.set_main_option("sqlalchemy.url", settings.database.url_sync)

# Metadata cible pour auto-génération
target_metadata = Base.metadata


def run_migrations_offline() -> None:
        """
        Exécute les migrations en mode 'offline'.

        Génère les scripts SQL sans se connecter à la base.
        Utile pour les CI/CD ou les reviews de code.
        """
        url = config.get_main_option("sqlalchemy.url")
        context.configure(
                url=url,
                target_metadata=target_metadata,
                literal_binds=True,
                dialect_opts={"paramstyle": "named"},
        )

        with context.begin_transaction():
                context.run_migrations()


def run_migrations_online() -> None:
        """
        Exécute les migrations en mode 'online'.

        Se connecte à la base et applique les migrations.
        """
        connectable = engine_from_config(
                config.get_section(config.config_ini_section, {}),
                prefix="sqlalchemy.",
                poolclass=pool.NullPool,
        )

        with connectable.connect() as connection:
                context.configure(
                        connection=connection,
                        target_metadata=target_metadata,
                )

                with context.begin_transaction():
                        context.run_migrations()


if context.is_offline_mode():
        run_migrations_offline()
else:
        run_migrations_online()
