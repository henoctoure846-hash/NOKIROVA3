"""
NOKIROVA — Stratégie : Cache Redis corrompu

Détection et réparation du cache Redis corrompu.
Détection : taux de miss anormalement élevé, clés orphelines, erreurs de décodage.
Réparation : invalidation du cache corrompu + reconstruction progressive.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class CorruptedCacheStrategy(HealingStrategy):
	"""
	Détection et réparation du cache Redis corrompu.

	Détection : taux de miss anormalement élevé, clés orphelines, erreurs de décodage.
	Réparation : invalidation du cache corrompu + reconstruction progressive.
	"""

	name = "corrupted_cache"
	category = IncidentCategory.CORRUPTED_CACHE

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier l'intégrité du cache."""
		cache_hit_rate = context.get("cache_hit_rate", 1.0)
		cache_errors = context.get("cache_errors", 0)
		orphan_keys = context.get("orphan_keys", 0)

		if cache_hit_rate < 0.3 and cache_errors > 10:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.MEDIUM,
				title="Cache Redis dégradé",
				description=f"Taux de hit {cache_hit_rate:.0%}, {cache_errors} erreurs",
				component="redis_cache",
				error_details=f"hit_rate={cache_hit_rate}, errors={cache_errors}",
			)

		if orphan_keys > 100:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.LOW,
				title="Clés de cache orphelines",
				description=f"{orphan_keys} clés orphelines détectées dans Redis",
				component="redis_cache",
				error_details=f"orphan_keys={orphan_keys}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer la corruption du cache."""
		return {
			"cache_hit_rate": context.get("cache_hit_rate", 0),
			"cache_errors": context.get("cache_errors", 0),
			"orphan_keys": context.get("orphan_keys", 0),
			"action_requise": "flush_and_rebuild" if "dégradé" in incident.title else "clean_orphans",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Réparer le cache corrompu."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type=diagnosis.get("action_requise", "flush_and_rebuild"),
			target="redis_cache",
			parameters=diagnosis,
		)

		try:
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			await event_bus.publish(
				Event(
					event_type="cache.rebuild.requested",
					domain="cache",
					payload={
						"incident_id": incident.incident_id,
						"action": diagnosis.get("action_requise", "flush_and_rebuild"),
						"orphan_keys": diagnosis.get("orphan_keys", 0),
					},
					priority=EventPriority.HIGH,
					source="self_healing.corrupted_cache",
				)
			)

			action.success = True
			action.result_message = f"Reconstruction du cache demandée ({diagnosis.get('action_requise', 'flush_and_rebuild')})"
		except HEALING_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec de la reconstruction du cache : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que le cache est de nouveau fonctionnel."""
		return action.success
