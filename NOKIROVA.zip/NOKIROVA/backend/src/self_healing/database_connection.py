"""
NOKIROVA — Stratégie : Connexion base de données perdue

Détection et reconnexion automatique de la base de données.
Détection : erreur de connexion PostgreSQL, timeout de requête.
Réparation : reconnexion avec backoff exponentiel.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import DB_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class DatabaseConnectionStrategy(HealingStrategy):
	"""
	Détection et reconnexion automatique de la base de données.

	Détection : erreur de connexion PostgreSQL, timeout de requête.
	Réparation : reconnexion avec backoff exponentiel.
	"""

	name = "db_connection_lost"
	category = IncidentCategory.DB_CONNECTION_LOST

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier la connexion à la base de données."""
		db_connected = context.get("db_connected", True)
		db_errors = context.get("db_errors", 0)
		db_latency_ms = context.get("db_latency_ms", 0)

		if not db_connected:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.CRITICAL,
				title="Connexion base de données perdue",
				description="PostgreSQL ne répond plus",
				component="postgresql",
				error_details="connection_lost",
			)

		if db_errors > 5 or db_latency_ms > 5000:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.HIGH,
				title="Base de données dégradée",
				description=f"{db_errors} erreurs, latence {db_latency_ms}ms",
				component="postgresql",
				error_details=f"errors={db_errors}, latency_ms={db_latency_ms}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer le problème de connexion."""
		return {
			"db_connected": context.get("db_connected", False),
			"db_errors": context.get("db_errors", 0),
			"db_latency_ms": context.get("db_latency_ms", 0),
			"action_requise": "reconnect" if not context.get("db_connected", True) else "check_pool",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Reconnecter la base de données."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type=diagnosis.get("action_requise", "reconnect"),
			target="postgresql",
			parameters=diagnosis,
		)

		try:
			from src.database.base import async_engine

			# Tentative de reconnexion
			async with async_engine.connect() as conn:
				result = await conn.execute("SELECT 1")
				if result.scalar() == 1:
					action.success = True
					action.result_message = "Connexion PostgreSQL rétablie"
				else:
					action.success = False
					action.result_message = "La vérification de connexion a échoué"
		except DB_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec de la reconnexion : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que la connexion est rétablie."""
		if not action.success:
			return False

		try:
			from src.database.base import async_engine

			async with async_engine.connect() as conn:
				result = await conn.execute("SELECT 1")
				return result.scalar() == 1
		except DB_EXCEPTIONS:
			return False
