"""
NOKIROVA — Stratégie : Plugin défectueux

Détection et mise en quarantaine des plugins défectueux.
Détection : plugin qui crash en boucle, erreurs récurrentes.
Réparation : isolation du plugin (quarantaine) + notification admin.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class DefectivePluginStrategy(HealingStrategy):
	"""
	Détection et mise en quarantaine des plugins défectueux.

	Détection : plugin qui crash en boucle, erreurs récurrentes.
	Réparation : isolation du plugin (quarantaine) + notification admin.
	"""

	name = "defective_plugin"
	category = IncidentCategory.DEFECTIVE_PLUGIN

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier l'état des plugins."""
		defective_plugins = context.get("defective_plugins", [])

		if defective_plugins:
			plugin_names = ", ".join(p.get("name", "?") for p in defective_plugins)
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.MEDIUM,
				title="Plugin défectueux détecté",
				description=f"Plugins en erreur : {plugin_names}",
				component="plugins",
				error_details=f"count={len(defective_plugins)}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer le plugin défectueux."""
		return {
			"defective_plugins": context.get("defective_plugins", []),
			"action_requise": "quarantine_plugin",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Mettre le plugin en quarantaine."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type="quarantine_plugin",
			target="plugins",
			parameters=diagnosis,
		)

		try:
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			defective_plugins = diagnosis.get("defective_plugins", [])
			for plugin in defective_plugins:
				await event_bus.publish(
					Event(
						event_type="plugin.quarantine.requested",
						domain="plugins",
						payload={
							"incident_id": incident.incident_id,
							"plugin_name": plugin.get("name", ""),
							"plugin_id": plugin.get("id", ""),
							"error": plugin.get("error", ""),
						},
						priority=EventPriority.HIGH,
						source="self_healing.defective_plugin",
					)
				)

			action.success = True
			action.result_message = f"{len(defective_plugins)} plugin(s) mis en quarantaine"
		except HEALING_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec de la quarantaine : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que le plugin est bien isolé."""
		return action.success
