"""
NOKIROVA — Stratégie : Erreur IA

Détection et fallback des erreurs IA.
Détection : API IA injoignable, erreurs répétées, timeout.
Réparation : fallback vers modèle secondaire + mode dégradé.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class AIFailureStrategy(HealingStrategy):
	"""
	Détection et fallback des erreurs IA.

	Détection : API IA injoignable, erreurs répétées, timeout.
	Réparation : fallback vers modèle secondaire + mode dégradé.
	"""

	name = "ai_failure"
	category = IncidentCategory.AI_FAILURE

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier la disponibilité de l'IA."""
		ai_errors = context.get("ai_errors", 0)
		ai_timeout = context.get("ai_timeout", False)
		ai_provider_down = context.get("ai_provider_down", False)

		if ai_provider_down or ai_timeout:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.HIGH,
				title="Fournisseur IA indisponible",
				description="Le fournisseur IA principal ne répond pas",
				component="ai_provider",
				error_details=f"provider_down={ai_provider_down}, timeout={ai_timeout}",
			)

		if ai_errors > 10:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.MEDIUM,
				title="Erreurs IA récurrentes",
				description=f"{ai_errors} erreurs IA détectées récemment",
				component="ai_provider",
				error_details=f"errors={ai_errors}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer l'erreur IA."""
		return {
			"ai_provider": context.get("ai_provider", "openai"),
			"ai_errors": context.get("ai_errors", 0),
			"fallback_available": context.get("fallback_available", True),
			"action_requise": "fallback_modele_secondaire",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Basculer vers le modèle de fallback."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type="fallback_modele_secondaire",
			target="ai_provider",
			parameters=diagnosis,
		)

		try:
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			await event_bus.publish(
				Event(
					event_type="ai.fallback.requested",
					domain="ai",
					payload={
						"incident_id": incident.incident_id,
						"original_provider": diagnosis.get("ai_provider", "openai"),
						"action": "switch_to_fallback",
					},
					priority=EventPriority.CRITICAL,
					source="self_healing.ai_failure",
				)
			)

			action.success = True
			action.result_message = "Fallback vers modèle secondaire demandé"
		except HEALING_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec du fallback IA : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que le fallback est actif."""
		return action.success
