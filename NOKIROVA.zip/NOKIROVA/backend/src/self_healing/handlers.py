"""
NOKIROVA — Handlers Self-Healing pour l'Event Bus

Réagit aux événements publiés par les stratégies de self-healing :
- search.reindex.requested   → relance l'indexation de recherche
- cache.rebuild.requested    → reconstruit le cache
- worker.restart.requested   → redémarre un worker bloqué
- plugin.quarantine.requested → met un plugin défectueux en quarantaine
- ai.fallback.requested      → active le mode IA dégradé

Principe BIBLE #9 Automatisation : les réparations sont déclenchées
automatiquement via l'Event Bus, sans intervention humaine.
Principe BIBLE #3 Communication inter-moteurs : uniquement via l'Event Bus.
"""

from __future__ import annotations

import asyncio
from typing import Any

from src.core.health_exceptions import DB_EXCEPTIONS, HEALING_EXCEPTIONS

from ..core.logging import get_logger

logger = get_logger(__name__)


# ═══════════════════════════════════════
# Handlers individuels
# ═══════════════════════════════════════


async def handle_search_reindex_requested(event: Any) -> None:
	"""
	Handler pour search.reindex.requested.

	Déclenche une réindexation complète ou partielle du moteur
	de recherche quand une corruption est détectée.
	"""
	payload = event.payload if hasattr(event, "payload") else {}
	scope = payload.get("scope", "full")
	logger.info(f"🔍 Réindexation de recherche demandée (scope={scope})")

	try:
		from ..search.indexer import SearchIndexer

		indexer = SearchIndexer()
		if scope == "full":
			await indexer.full_reindex()
		else:
			collection = payload.get("collection", "all")
			await indexer.partial_reindex(collection=collection)
		logger.info(f"✅ Réindexation terminée (scope={scope})")
	except ImportError:
		logger.warning("⚠️ SearchIndexer non disponible — réindexation ignorée")
	except HEALING_EXCEPTIONS as e:
		logger.error(f"❌ Échec de réindexation : {e}")


async def handle_cache_rebuild_requested(event: Any) -> None:
	"""
	Handler pour cache.rebuild.requested.

	Reconstruit les entrées de cache corrompues ou
	purge le cache si nécessaire.
	"""
	payload = event.payload if hasattr(event, "payload") else {}
	action = payload.get("action", "purge")
	keys = payload.get("keys", [])
	logger.info(f"📦 Reconstruction de cache demandée (action={action}, clés={len(keys)})")

	try:
		import redis.asyncio as aioredis

		from ..core.config import get_settings

		r = aioredis.from_url(get_settings().redis.url)

		if action == "purge" and keys:
			# Supprimer les clés spécifiques
			deleted = await r.delete(*keys)
			logger.info(f"✅ {deleted} clés de cache purgées")
		elif action == "purge_all":
			# Purger tout le cache (dangereux — utilisé uniquement en cas de corruption massive)
			flushed = await r.flushdb()
			logger.warning(f"⚠️ Cache entièrement purgé : {flushed}")
		elif action == "rebuild" and keys:
			# Reconstruire les clés spécifiques
			for key in keys:
				await r.delete(key)
			logger.info(f"✅ {len(keys)} clés de cache reconstruites")
		else:
			logger.info(f"ℹ️ Action de cache non reconnue : {action}")

		await r.close()
	except HEALING_EXCEPTIONS as e:
		logger.error(f"❌ Échec de reconstruction de cache : {e}")


async def handle_worker_restart_requested(event: Any) -> None:
	"""
	Handler pour worker.restart.requested.

	Redémarre un worker Celery identifié comme bloqué.
	Utilise revoke + purge de la file d'attente.
	"""
	payload = event.payload if hasattr(event, "payload") else {}
	worker_name = payload.get("worker_name", "unknown")
	task_id = payload.get("task_id")
	logger.info(f"🔄 Redémarrage de worker demandé (worker={worker_name}, task={task_id})")

	try:
		from ..workers.celery_app import celery_app

		# Révoquer la tâche bloquée si spécifiée
		if task_id:
			celery_app.control.revoke(task_id, terminate=True, signal="SIGTERM")
			logger.info(f"✅ Tâche {task_id} révoquée")

		# Purger la file du worker
		try:
			celery_app.control.broadcast(
				"purge", destination=[worker_name] if worker_name != "unknown" else None
			)
			logger.info(f"✅ File du worker {worker_name} purgée")
		except HEALING_EXCEPTIONS:
			logger.warning(f"⚠️ Impossible de purger la file du worker {worker_name}")

	except ImportError:
		logger.warning("⚠️ Celery non disponible — redémarrage de worker ignoré")
	except HEALING_EXCEPTIONS as e:
		logger.error(f"❌ Échec de redémarrage de worker : {e}")


async def handle_plugin_quarantine_requested(event: Any) -> None:
	"""
	Handler pour plugin.quarantine.requested.

	Met un plugin défectueux en quarantaine : désactive ses
	fonctionnalités et marque son état comme "quarantaine".
	"""
	payload = event.payload if hasattr(event, "payload") else {}
	plugin_id = payload.get("plugin_id", "unknown")
	reason = payload.get("reason", "auto_detected")
	logger.info(f"🔒 Quarantaine de plugin demandée (plugin={plugin_id}, raison={reason})")

	try:
		from ..database.base import get_session
		from ..database.models import Plugin

		async with get_session() as session:
			await session.execute(
				Plugin.__table__.update()
				.where(Plugin.id == plugin_id)
				.values(
					status="quarantaine",
					quarantine_reason=reason,
					quarantined_at=asyncio.get_event_loop().time(),
				)
			)
			await session.commit()
			logger.info(f"✅ Plugin {plugin_id} mis en quarantaine")
	except ImportError:
		logger.warning("⚠️ Modèle Plugin non disponible — quarantaine ignorée")
	except DB_EXCEPTIONS as e:
		logger.error(f"❌ Échec de mise en quarantaine du plugin {plugin_id} : {e}")


async def handle_ai_fallback_requested(event: Any) -> None:
	"""
	Handler pour ai.fallback.requested.

	Active le mode IA dégradé : bascule vers un fournisseur
	de secours ou désactive les fonctionnalités IA avancées.
	"""
	payload = event.payload if hasattr(event, "payload") else {}
	original_provider = payload.get("original_provider", "unknown")
	error_type = payload.get("error_type", "timeout")
	logger.info(f"🤖 Mode IA dégradé demandé (provider={original_provider}, erreur={error_type})")

	try:
		from ..ai.fallback import AIFallbackManager

		fallback = AIFallbackManager()
		await fallback.activate_fallback(
			original_provider=original_provider,
			error_type=error_type,
		)
		logger.info(f"✅ Mode IA dégradé activé (fallback depuis {original_provider})")
	except ImportError:
		# Fallback manager non disponible — basculer manuellement
		try:
			from ..core.config import get_settings

			get_settings()
			logger.warning(
				f"⚠️ AIFallbackManager non disponible — "
				f"IA désactivée manuellement (provider={original_provider})"
			)
		except HEALING_EXCEPTIONS:
			logger.warning("⚠️ Impossible de désactiver l'IA manuellement")
	except HEALING_EXCEPTIONS as e:
		logger.error(f"❌ Échec d'activation du mode IA dégradé : {e}")


# ═══════════════════════════════════════
# Enregistrement des handlers
# ═══════════════════════════════════════

# Mapping événement → handler
SELF_HEALING_HANDLERS: dict[str, Any] = {
	"search.reindex.requested": handle_search_reindex_requested,
	"cache.rebuild.requested": handle_cache_rebuild_requested,
	"worker.restart.requested": handle_worker_restart_requested,
	"plugin.quarantine.requested": handle_plugin_quarantine_requested,
	"ai.fallback.requested": handle_ai_fallback_requested,
}


async def register_self_healing_handlers() -> None:
	"""
	Enregistrer tous les handlers self-healing sur l'Event Bus.

	Appelé au démarrage de l'application.
	Principe BIBLE #3 Communication inter-moteurs.
	"""
	try:
		from ..events.bus import event_bus

		for event_type, handler in SELF_HEALING_HANDLERS.items():
			await event_bus.subscribe(event_type, handler)
			logger.info(f"✅ Handler self-healing enregistré : {event_type}")

		logger.info(f"🛡️ {len(SELF_HEALING_HANDLERS)} handlers self-healing enregistrés sur l'Event Bus")
	except HEALING_EXCEPTIONS as e:
		logger.error(f"❌ Impossible d'enregistrer les handlers self-healing : {e}")
