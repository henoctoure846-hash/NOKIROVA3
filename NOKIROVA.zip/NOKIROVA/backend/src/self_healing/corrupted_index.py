"""
NOKIROVA — Stratégie : Index de recherche corrompu

Détection et réparation des index de recherche corrompus.
Détection : erreur de recherche, index introuvable, checksum invalide.
Réparation : re-indexation complète des documents affectés.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class CorruptedIndexStrategy(HealingStrategy):
	"""
	Détection et réparation des index de recherche corrompus.

	Détection : erreur de recherche, index introuvable, checksum invalide.
	Réparation : re-indexation complète des documents affectés.
	"""

	name = "corrupted_index"
	category = IncidentCategory.CORRUPTED_INDEX

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier l'intégrité de l'index de recherche."""
		search_errors = context.get("search_errors", 0)
		index_checksum = context.get("index_checksum", "")
		expected_checksum = context.get("expected_checksum", "")

		if search_errors > 5:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.HIGH,
				title="Index de recherche corrompu",
				description=f"{search_errors} erreurs de recherche détectées",
				component="search_index",
				error_details=f"search_errors={search_errors}",
			)

		if index_checksum and expected_checksum and index_checksum != expected_checksum:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.HIGH,
				title="Checksum de l'index invalide",
				description="Le checksum de l'index ne correspond pas à la valeur attendue",
				component="search_index",
				error_details=f"attendu={expected_checksum}, obtenu={index_checksum}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer la corruption de l'index."""
		total_docs = context.get("total_documents", 0)
		indexed_docs = context.get("indexed_documents", 0)

		return {
			"total_documents": total_docs,
			"indexed_documents": indexed_docs,
			"missing_documents": max(0, total_docs - indexed_docs),
			"corruption_type": "checksum_mismatch"
			if "Checksum" in incident.error_details
			else "search_errors",
			"action_requise": "reindexation_complete" if total_docs > 0 else "reconstruction_index",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Re-indexer les documents."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type="reindexation_complete",
			target="search_index",
			parameters=diagnosis,
		)

		try:
			# Publier un événement de re-indexation via l'Event Bus
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			await event_bus.publish(
				Event(
					event_type="search.reindex.requested",
					domain="search",
					payload={
						"incident_id": incident.incident_id,
						"action": diagnosis.get("action_requise", "reindexation_complete"),
						"total_documents": diagnosis.get("total_documents", 0),
						"missing_documents": diagnosis.get("missing_documents", 0),
					},
					priority=EventPriority.HIGH,
					source="self_healing.corrupted_index",
				)
			)

			action.success = True
			action.result_message = (
				f"Re-indexation lancée : {diagnosis.get('missing_documents', 0)} "
				f"documents manquants à ré-indexer"
			)
		except HEALING_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec de la re-indexation : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que l'index est de nouveau fonctionnel."""
		if not action.success:
			return False

		# Vérification via Event Bus : attendre la confirmation de re-indexation
		# En pratique, le handler search.reindex.completed mettra à jour le statut
		logger.info("Vérification de la re-indexation en cours...")

		# Pour l'instant, on considère que la publication de l'événement suffit
		# La vérification asynchrone est faite par le handler de réponse
		return action.success
