"""
NOKIROVA — Modèles du Self-Healing

Suivi des incidents et des actions d'auto-réparation.
Chaque incident est tracé pour audit et amélioration continue.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum


class IncidentSeverity(StrEnum):
	"""Sévérité d'un incident."""

	LOW = "low"
	MEDIUM = "medium"
	HIGH = "high"
	CRITICAL = "critical"


class IncidentStatus(StrEnum):
	"""Statut d'un incident."""

	DETECTED = "detected"
	DIAGNOSING = "diagnosing"
	HEALING = "healing"
	RESOLVED = "resolved"
	FAILED = "failed"
	ESCALATED = "escalated"


class IncidentCategory(StrEnum):
	"""Catégorie d'incident."""

	CORRUPTED_INDEX = "corrupted_index"
	CORRUPTED_CACHE = "corrupted_cache"
	BLOCKED_WORKER = "blocked_worker"
	DEFECTIVE_PLUGIN = "defective_plugin"
	AI_FAILURE = "ai_failure"
	DB_CONNECTION_LOST = "db_connection_lost"
	DISK_SPACE_LOW = "disk_space_low"
	MEMORY_PRESSURE = "memory_pressure"
	RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
	SYNC_CONFLICT = "sync_conflict"


@dataclass
class SelfHealingIncident:
	"""Incident détecté par le système de self-healing."""

	incident_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	category: IncidentCategory = IncidentCategory.CORRUPTED_INDEX
	severity: IncidentSeverity = IncidentSeverity.MEDIUM
	status: IncidentStatus = IncidentStatus.DETECTED

	# Description
	title: str = ""
	description: str = ""
	component: str = ""  # Composant affecté (ex: "search_index", "redis_cache")
	error_details: str = ""  # Message d'erreur original

	# Traçabilité
	detected_at: float = field(default_factory=time.time)
	resolved_at: float | None = None
	healing_started_at: float | None = None
	resolution_time_ms: float | None = None  # Temps de résolution

	# Stratégie
	strategy_name: str = ""
	retry_count: int = 0
	max_retries: int = 3

	# Résultat
	healing_result: dict | None = None
	escalation_reason: str = ""

	# Métadonnées
	metadata: dict = field(default_factory=dict)

	def mark_healing_started(self) -> None:
		"""Marquer le début de la réparation."""
		self.status = IncidentStatus.HEALING
		self.healing_started_at = time.time()

	def mark_resolved(self, result: dict | None = None) -> None:
		"""Marquer l'incident comme résolu."""
		self.status = IncidentStatus.RESOLVED
		self.resolved_at = time.time()
		self.healing_result = result or {}
		if self.healing_started_at:
			self.resolution_time_ms = (self.resolved_at - self.healing_started_at) * 1000

	def mark_failed(self, reason: str = "") -> None:
		"""Marquer l'incident comme échoué."""
		self.status = IncidentStatus.FAILED
		self.escalation_reason = reason

	def mark_escalated(self, reason: str = "") -> None:
		"""Escalader l'incident vers une intervention manuelle."""
		self.status = IncidentStatus.ESCALATED
		self.escalation_reason = reason

	def to_dict(self) -> dict:
		"""Sérialiser l'incident."""
		return {
			"incident_id": self.incident_id,
			"category": self.category.value,
			"severity": self.severity.value,
			"status": self.status.value,
			"title": self.title,
			"description": self.description,
			"component": self.component,
			"error_details": self.error_details,
			"detected_at": self.detected_at,
			"resolved_at": self.resolved_at,
			"healing_started_at": self.healing_started_at,
			"resolution_time_ms": self.resolution_time_ms,
			"strategy_name": self.strategy_name,
			"retry_count": self.retry_count,
			"max_retries": self.max_retries,
			"healing_result": self.healing_result,
			"escalation_reason": self.escalation_reason,
			"metadata": self.metadata,
		}


@dataclass
class SelfHealingAction:
	"""Action de réparation exécutée par le self-healing."""

	action_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	incident_id: str = ""
	action_type: str = ""  # ex: "reindex", "clear_cache", "restart_worker"
	target: str = ""  # Cible de l'action
	parameters: dict = field(default_factory=dict)
	started_at: float = field(default_factory=time.time)
	completed_at: float | None = None
	success: bool = False
	result_message: str = ""

	def to_dict(self) -> dict:
		"""Sérialiser l'action."""
		return {
			"action_id": self.action_id,
			"incident_id": self.incident_id,
			"action_type": self.action_type,
			"target": self.target,
			"parameters": self.parameters,
			"started_at": self.started_at,
			"completed_at": self.completed_at,
			"success": self.success,
			"result_message": self.result_message,
		}
