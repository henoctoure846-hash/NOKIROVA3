"""
NOKIROVA — Module Self-Healing

Système d'auto-réparation NOKIROVA :
- Moteur de surveillance continue
- 6 stratégies de détection/réparation
- Handlers Event Bus pour actions de réparation
- Modèles d'incidents et d'actions

Principe BIBLE #10 Fiabilité : le système se répare lui-même.
Principe BIBLE #9 Automatisation : cycle de surveillance continu.
"""

from .ai_failure import AIFailureStrategy
from .base import HealingStrategy
from .blocked_worker import BlockedWorkerStrategy
from .corrupted_cache import CorruptedCacheStrategy
from .corrupted_index import CorruptedIndexStrategy
from .database_connection import DatabaseConnectionStrategy
from .defective_plugin import DefectivePluginStrategy
from .engine import SelfHealingEngine, self_healing_engine
from .handlers import (
	SELF_HEALING_HANDLERS,
	register_self_healing_handlers,
)
from .models import (
	IncidentCategory,
	IncidentSeverity,
	IncidentStatus,
	SelfHealingAction,
	SelfHealingIncident,
)

__all__ = [
	# Moteur
	"SelfHealingEngine",
	"self_healing_engine",
	# Modèles
	"SelfHealingIncident",
	"SelfHealingAction",
	"IncidentCategory",
	"IncidentSeverity",
	"IncidentStatus",
	# Stratégies
	"HealingStrategy",
	"CorruptedIndexStrategy",
	"CorruptedCacheStrategy",
	"BlockedWorkerStrategy",
	"DefectivePluginStrategy",
	"AIFailureStrategy",
	"DatabaseConnectionStrategy",
	# Handlers
	"SELF_HEALING_HANDLERS",
	"register_self_healing_handlers",
]
