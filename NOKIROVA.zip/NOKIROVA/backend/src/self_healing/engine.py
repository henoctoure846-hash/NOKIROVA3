"""
NOKIROVA — Moteur de Self-Healing

Orchestrateur central qui :
1. Collecte les métriques vitales périodiquement
2. Exécute chaque stratégie de détection
3. Trace les incidents et leurs résolutions
4. Publie des événements de monitoring
5. Fournit les données pour Mission Control

Principe BIBLE #10 Fiabilité : le système se répare lui-même.
Principe BIBLE #9 Automatisation : cycle de surveillance continu.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from typing import Any

from src.core.health_exceptions import DB_EXCEPTIONS, HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .ai_failure import AIFailureStrategy
from .base import HealingStrategy
from .blocked_worker import BlockedWorkerStrategy
from .corrupted_cache import CorruptedCacheStrategy
from .corrupted_index import CorruptedIndexStrategy
from .database_connection import DatabaseConnectionStrategy
from .defective_plugin import DefectivePluginStrategy
from .models import SelfHealingIncident

logger = get_logger(__name__)


# ═══════════════════════════════════════
# Moteur de Self-Healing
# ═══════════════════════════════════════


class SelfHealingEngine:
	"""
	Moteur de self-healing NOKIROVA.

	Exécute un cycle de surveillance périodique :
	1. Collecte des métriques depuis chaque composant
	2. Passage de chaque stratégie de détection
	3. Exécution de la réparation si un incident est détecté
	4. Journalisation de tous les incidents
	5. Publication vers Mission Control via Event Bus

	Fonctionnalités :
	- Surveillance continue (toutes les 30s par défaut)
	- Historique complet des incidents
	- Statistiques de résolution
	- Mode dégradé si le moteur lui-même est en difficulté
	"""

	def __init__(self, check_interval: float = 30.0):
		self._strategies: list[HealingStrategy] = []
		self._incidents: list[SelfHealingIncident] = []
		self._running = False
		self._check_interval = check_interval
		self._task: asyncio.Task | None = None

		# Statistiques globales
		self._stats = {
			"total_incidents": 0,
			"incidents_resolus": 0,
			"incidents_echoues": 0,
			"incidents_escalades": 0,
			"dernier_check": None,
			"uptime_seconds": 0,
			"started_at": None,
		}

		# Enregistrement des stratégies par défaut
		self._register_default_strategies()

	def _register_default_strategies(self) -> None:
		"""Enregistrer les stratégies de self-healing par défaut."""
		self._strategies = [
			CorruptedIndexStrategy(),
			CorruptedCacheStrategy(),
			BlockedWorkerStrategy(),
			DefectivePluginStrategy(),
			AIFailureStrategy(),
			DatabaseConnectionStrategy(),
		]

	def register_strategy(self, strategy: HealingStrategy) -> None:
		"""
		Ajouter une stratégie de self-healing.

		Principe BIBLE #5 Évolutivité : nouvelles stratégies sans modifier le moteur.
		"""
		self._strategies.append(strategy)
		logger.info(f"Stratégie de self-healing enregistrée : {strategy.name}")

	# ─── Cycle de surveillance ─────────────────────────────────────────

	async def start(self) -> None:
		"""Démarrer le cycle de surveillance continue."""
		if self._running:
			return

		self._running = True
		self._stats["started_at"] = time.time()
		self._task = asyncio.create_task(self._surveillance_loop())
		logger.info(f"🛡️ Moteur de self-healing démarré (intervalle : {self._check_interval}s)")

	async def stop(self) -> None:
		"""Arrêter le cycle de surveillance."""
		self._running = False
		if self._task:
			self._task.cancel()
			with contextlib.suppress(asyncio.CancelledError):
				await self._task
		logger.info("🛡️ Moteur de self-healing arrêté")

	async def _surveillance_loop(self) -> None:
		"""Boucle principale de surveillance."""
		while self._running:
			try:
				await self._run_check_cycle()
				self._stats["dernier_check"] = time.time()
				self._stats["uptime_seconds"] = time.time() - (self._stats["started_at"] or time.time())
			except asyncio.CancelledError:
				break
			except HEALING_EXCEPTIONS as e:
				logger.error(f"Erreur dans le cycle de surveillance : {e}")

			await asyncio.sleep(self._check_interval)

	async def _run_check_cycle(self) -> None:
		"""Exécuter un cycle complet de vérification."""
		# Collecter le contexte actuel du système
		context = await self._collect_context()

		# Exécuter chaque stratégie
		for strategy in self._strategies:
			try:
				incident = await strategy.execute(context)
				if incident:
					self._record_incident(incident)
					await self._publish_incident_event(incident)
			except HEALING_EXCEPTIONS as e:
				logger.error(f"Erreur stratégie {strategy.name} : {e}")

	async def _collect_context(self) -> dict:
		"""Collecter les métriques vitales depuis chaque composant."""
		context: dict[str, Any] = {}

		# Event Bus stats
		try:
			from src.events.bus import event_bus

			bus_stats = await event_bus.get_stats()
			context["event_bus"] = bus_stats
		except HEALING_EXCEPTIONS:
			context["event_bus"] = {"error": "non_disponible"}

		# Base de données
		try:
			from src.database.base import async_engine

			async with async_engine.connect() as conn:
				result = await conn.execute("SELECT 1")
				context["db_connected"] = result.scalar() == 1
				context["db_errors"] = 0
				context["db_latency_ms"] = 0
		except DB_EXCEPTIONS:
			context["db_connected"] = False
			context["db_errors"] = 1
			context["db_latency_ms"] = -1

		# Cache Redis
		try:
			import redis.asyncio as aioredis

			from src.core.config import get_settings

			r = aioredis.from_url(get_settings().redis.url)
			info = await r.info("stats")
			hits = info.get("keyspace_hits", 0)
			misses = info.get("keyspace_misses", 0)
			context["cache_hit_rate"] = hits / (hits + misses) if (hits + misses) > 0 else 1.0
			context["cache_errors"] = 0
			context["orphan_keys"] = 0
			await r.close()
		except HEALING_EXCEPTIONS:
			context["cache_hit_rate"] = 0.0
			context["cache_errors"] = 0
			context["orphan_keys"] = 0

		# IA — vérifier si l'API est accessible
		try:
			from src.core.config import get_settings

			settings = get_settings()
			context["ai_provider"] = settings.ai.provider
			context["ai_errors"] = 0
			context["ai_timeout"] = False
			context["ai_provider_down"] = not bool(settings.ai.api_key)
			context["fallback_available"] = True
		except HEALING_EXCEPTIONS:
			context["ai_errors"] = 0
			context["ai_timeout"] = False
			context["ai_provider_down"] = False

		# Search index
		context["search_errors"] = 0
		context["index_checksum"] = ""
		context["expected_checksum"] = ""
		context["total_documents"] = 0
		context["indexed_documents"] = 0

		# Celery workers
		context["stuck_tasks"] = []
		context["queue_depth"] = 0

		# Plugins
		context["defective_plugins"] = []

		return context

	# ─── Gestion des incidents ───────────────────────────────────────────

	def _record_incident(self, incident: SelfHealingIncident) -> None:
		"""Enregistrer un incident dans l'historique."""
		self._incidents.append(incident)
		self._stats["total_incidents"] += 1

		if incident.status.value == "resolved":
			self._stats["incidents_resolus"] += 1
		elif incident.status.value == "failed":
			self._stats["incidents_echoues"] += 1
		elif incident.status.value == "escalated":
			self._stats["incidents_escalades"] += 1

	async def _publish_incident_event(self, incident: SelfHealingIncident) -> None:
		"""Publier un événement d'incident via l'Event Bus."""
		try:
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			priority = (
				EventPriority.CRITICAL if incident.severity.value == "critical" else EventPriority.HIGH
			)

			await event_bus.publish(
				Event(
					event_type=f"self_healing.incident.{incident.status.value}",
					domain="self_healing",
					payload=incident.to_dict(),
					priority=priority,
					source="self_healing.engine",
				)
			)
		except HEALING_EXCEPTIONS as e:
			logger.error(f"Impossible de publier l'événement d'incident : {e}")

	# ─── API de consultation ────────────────────────────────────────────

	def get_stats(self) -> dict:
		"""Récupérer les statistiques du moteur de self-healing."""
		return {
			**self._stats,
			"strategies_actives": len(self._strategies),
			"strategies": [s.name for s in self._strategies],
			"incidents_24h": sum(
				1 for i in self._incidents if i.detected_at and (time.time() - i.detected_at) < 86400
			),
			"auto_reparations_24h": sum(
				1
				for i in self._incidents
				if i.status.value == "resolved"
				and i.detected_at
				and (time.time() - i.detected_at) < 86400
			),
			"running": self._running,
		}

	def get_active_incidents(self) -> list[dict]:
		"""Récupérer les incidents actifs (non résolus)."""
		return [i.to_dict() for i in self._incidents if i.status.value not in ("resolved", "failed")]

	def get_incident_history(self, limit: int = 50) -> list[dict]:
		"""Récupérer l'historique des incidents."""
		incidents = sorted(self._incidents, key=lambda i: i.detected_at, reverse=True)
		return [i.to_dict() for i in incidents[:limit]]

	def get_strategies_status(self) -> list[dict]:
		"""Récupérer le statut de chaque stratégie."""
		return [
			{
				"name": s.name,
				"category": s.category.value,
				"max_retries": s.max_retries,
				"backoff_base": s.backoff_base,
				"backoff_max": s.backoff_max,
			}
			for s in self._strategies
		]

	async def trigger_manual_check(self, category: str | None = None) -> list[dict]:
		"""
		Déclencher une vérification manuelle.

		Utile pour Mission Control : l'admin peut forcer un check.
		"""
		context = await self._collect_context()
		results = []

		for strategy in self._strategies:
			if category and strategy.category.value != category:
				continue
			try:
				incident = await strategy.execute(context)
				if incident:
					self._record_incident(incident)
					results.append(incident.to_dict())
			except HEALING_EXCEPTIONS as e:
				logger.error(f"Erreur vérification manuelle {strategy.name} : {e}")

		return results


# ═══════════════════════════════════════
# Instance singleton
# ═══════════════════════════════════════

self_healing_engine = SelfHealingEngine()
