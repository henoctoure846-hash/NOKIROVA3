"""
NOKIROVA — Stratégie de base (Self-Healing)

Interface abstraite pour toutes les stratégies de self-healing.
Chaque stratégie implémente le cycle : detect → diagnose → heal → verify.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .models import IncidentCategory, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


# ═══════════════════════════════════════
# Interface de base
# ═══════════════════════════════════════


class HealingStrategy(ABC):
	"""
	Interface abstraite pour toutes les stratégies de self-healing.

	Chaque stratégie implémente le cycle :
	detect() → diagnose() → heal() → verify()
	"""

	name: str = "base"
	category: IncidentCategory = IncidentCategory.CORRUPTED_INDEX
	max_retries: int = 3
	backoff_base: float = 1.0  # secondes
	backoff_max: float = 60.0  # secondes

	@abstractmethod
	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Détecter une anomalie. Retourne un incident ou None."""
		...

	@abstractmethod
	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer la cause racine. Retourne les infos de diagnostic."""
		...

	@abstractmethod
	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Exécuter la réparation. Retourne l'action effectuée."""
		...

	@abstractmethod
	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que la réparation a fonctionné."""
		...

	async def execute(self, context: dict) -> SelfHealingIncident | None:
		"""Exécuter le cycle complet : detect → diagnose → heal → verify."""
		# 1. Détection
		incident = await self.detect(context)
		if not incident:
			return None

		incident.strategy_name = self.name
		logger.warning(
			f"🔍 Incident détecté : {incident.title} [{incident.category.value}]",
			extra={"incident_id": incident.incident_id},
		)

		# 2. Diagnostic
		try:
			diagnosis = await self.diagnose(incident, context)
			incident.metadata["diagnosis"] = diagnosis
		except HEALING_EXCEPTIONS as e:
			logger.error(f"Erreur diagnostic : {e}")
			incident.mark_failed(f"Diagnostic échoué : {e}")
			return incident

		# 3. Réparation avec retry
		backoff = self.backoff_base
		last_action = None

		for attempt in range(1, self.max_retries + 1):
			incident.retry_count = attempt
			incident.mark_healing_started()

			try:
				action = await self.heal(incident, diagnosis)
				last_action = action

				# 4. Vérification
				verified = await self.verify(incident, action)
				if verified:
					incident.mark_resolved({"action": action.to_dict()})
					logger.info(
						f"✅ Incident résolu : {incident.title} "
						f"(tentative {attempt}/{self.max_retries}, "
						f"{incident.resolution_time_ms:.0f}ms)",
						extra={"incident_id": incident.incident_id},
					)
					return incident

				logger.warning(f"⚠️ Vérification échouée, tentative {attempt}/{self.max_retries}")

			except HEALING_EXCEPTIONS as e:
				logger.error(f"Erreur réparation tentative {attempt}: {e}")

			# Backoff exponentiel avant retry
			if attempt < self.max_retries:
				await asyncio.sleep(backoff)
				backoff = min(backoff * 2, self.backoff_max)

		# 5. Escalade si toutes les tentatives ont échoué
		incident.mark_escalated(
			f"{self.max_retries} tentatives échouées. Dernière action : "
			f"{last_action.result_message if last_action else 'aucune'}"
		)
		logger.error(
			f"🚨 Incident escaladé : {incident.title} — {incident.escalation_reason}",
			extra={"incident_id": incident.incident_id},
		)

		return incident
