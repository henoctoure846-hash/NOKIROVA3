"""
NOKIROVA — Stratégie : Worker Celery bloqué

Détection et réparation des workers Celery bloqués.
Détection : tâche en cours depuis trop longtemps, queue saturée.
Réparation : annulation de la tâche bloquée + redémarrage du worker.
"""

from __future__ import annotations

import time

from src.core.health_exceptions import HEALING_EXCEPTIONS
from src.core.logging import get_logger

from .base import HealingStrategy
from .models import IncidentCategory, IncidentSeverity, SelfHealingAction, SelfHealingIncident

logger = get_logger(__name__)


class BlockedWorkerStrategy(HealingStrategy):
	"""
	Détection et réparation des workers Celery bloqués.

	Détection : tâche en cours depuis trop longtemps, queue saturée.
	Réparation : annulation de la tâche bloquée + redémarrage du worker.
	"""

	name = "blocked_worker"
	category = IncidentCategory.BLOCKED_WORKER

	async def detect(self, context: dict) -> SelfHealingIncident | None:
		"""Vérifier l'état des workers."""
		stuck_tasks = context.get("stuck_tasks", [])
		queue_depth = context.get("queue_depth", 0)

		if stuck_tasks:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.HIGH,
				title="Worker Celery bloqué",
				description=f"{len(stuck_tasks)} tâches bloquées détectées",
				component="celery_worker",
				error_details=f"stuck_tasks={len(stuck_tasks)}, queue_depth={queue_depth}",
			)

		if queue_depth > 1000:
			return SelfHealingIncident(
				category=self.category,
				severity=IncidentSeverity.MEDIUM,
				title="Queue Celery saturée",
				description=f"Queue à {queue_depth} tâches en attente",
				component="celery_queue",
				error_details=f"queue_depth={queue_depth}",
			)

		return None

	async def diagnose(self, incident: SelfHealingIncident, context: dict) -> dict:
		"""Diagnostiquer le blocage du worker."""
		return {
			"stuck_tasks": context.get("stuck_tasks", []),
			"queue_depth": context.get("queue_depth", 0),
			"action_requise": "cancel_and_restart"
			if incident.title == "Worker Celery bloqué"
			else "scale_workers",
		}

	async def heal(self, incident: SelfHealingIncident, diagnosis: dict) -> SelfHealingAction:
		"""Réparer le worker bloqué."""
		action = SelfHealingAction(
			incident_id=incident.incident_id,
			action_type=diagnosis.get("action_requise", "cancel_and_restart"),
			target="celery_worker",
			parameters=diagnosis,
		)

		try:
			from src.events.bus import event_bus
			from src.events.models import Event, EventPriority

			await event_bus.publish(
				Event(
					event_type="worker.restart.requested",
					domain="worker",
					payload={
						"incident_id": incident.incident_id,
						"action": diagnosis.get("action_requise", "cancel_and_restart"),
						"stuck_tasks": diagnosis.get("stuck_tasks", []),
					},
					priority=EventPriority.CRITICAL,
					source="self_healing.blocked_worker",
				)
			)

			action.success = True
			action.result_message = "Redémarrage du worker demandé via Event Bus"
		except HEALING_EXCEPTIONS as e:
			action.success = False
			action.result_message = f"Échec du redémarrage : {e}"

		action.completed_at = time.time()
		return action

	async def verify(self, incident: SelfHealingIncident, action: SelfHealingAction) -> bool:
		"""Vérifier que le worker est de nouveau actif."""
		return action.success
