"""
NOKIROVA — Gestionnaire de cache Redis

Système de cache avec auto-guérison :
- Cache corrompu → rebuild automatique
- Connexion perdue → fallback mémoire
- TTL configurable par namespace

Principe : jamais bloquant, toujours dégradé gracieux.
"""

from __future__ import annotations

import hashlib
import json
import time
from typing import Any

import redis.asyncio as aioredis

from src.core.config import get_settings
from src.core.health_exceptions import CACHE_EXCEPTIONS
from src.core.logging import logger

# Cache mémoire de secours (fallback)
_memory_cache: dict[str, tuple[Any, float]] = {}


# TTL par défaut par namespace
_DEFAULT_TTLS: dict[str, int] = {
	"user_session": 3600,  # 1h
	"course_data": 1800,  # 30min
	"flashcard_deck": 900,  # 15min
	"quiz_result": 600,  # 10min
	"search_index": 3600,  # 1h
	"ai_response": 1800,  # 30min
	"analytics": 300,  # 5min
	"workflow_state": 900,  # 15min
	"revision_plan": 1800,  # 30min
	"community_feed": 120,  # 2min
}


class CacheManager:
	"""
	Gestionnaire de cache Redis avec auto-guérison.

	Fonctionnalités :
	- Get/Set/Delete avec TTL par namespace
	- Invalidation par namespace ou pattern
	- Rebuild automatique du cache corrompu
	- Fallback mémoire si Redis indisponible
	- Statistiques du cache
	"""

	def __init__(self):
		self._redis: aioredis.Redis | None = None
		self._connected = False
		self._stats = {"hits": 0, "misses": 0, "sets": 0, "deletes": 0, "errors": 0, "rebuilds": 0}

	# ── Connexion ──────────────────────────────────────────────

	async def connect(self):
		"""Établit la connexion Redis."""
		try:
			self._redis = aioredis.from_url(
				get_settings().redis.url,
				decode_responses=True,
				socket_timeout=5,
				socket_connect_timeout=5,
				retry_on_timeout=True,
			)
			await self._redis.ping()
			self._connected = True
			logger.info("Cache Redis connecté")
		except CACHE_EXCEPTIONS as e:
			logger.warning(f"Redis indisponible, fallback mémoire : {e}")
			self._connected = False
			self._redis = None

	async def disconnect(self):
		"""Ferme la connexion Redis."""
		if self._redis:
			await self._redis.close()
			self._connected = False
			logger.info("Cache Redis déconnecté")

	async def health_check(self) -> bool:
		"""Vérifie la santé du cache."""
		if not self._redis:
			return False
		try:
			await self._redis.ping()
			return True
		except CACHE_EXCEPTIONS:
			self._connected = False
			return False

	# ── Opérations de base ─────────────────────────────────────

	def _key(self, namespace: str, key: str) -> str:
		"""Construit la clé complète avec namespace."""
		return f"nokirova:cache:{namespace}:{key}"

	def _hash_key(self, data: Any) -> str:
		"""Hash les données complexes en clé courte."""
		raw = json.dumps(data, sort_keys=True, default=str)
		return hashlib.sha256(raw.encode()).hexdigest()[:16]

	async def get(self, namespace: str, key: str) -> Any | None:
		"""Récupère une valeur du cache."""
		full_key = self._key(namespace, key)
		try:
			if self._connected and self._redis:
				raw = await self._redis.get(full_key)
				if raw is not None:
					self._stats["hits"] += 1
					return json.loads(raw)
			# Fallback mémoire
			if full_key in _memory_cache:
				value, expires = _memory_cache[full_key]
				if time.time() < expires:
					self._stats["hits"] += 1
					return value
				else:
					del _memory_cache[full_key]
			self._stats["misses"] += 1
			return None
		except CACHE_EXCEPTIONS as e:
			self._stats["errors"] += 1
			logger.warning(f"Erreur cache get : {e}")
			return None

	async def set(
		self,
		namespace: str,
		key: str,
		value: Any,
		ttl: int | None = None,
	) -> bool:
		"""Stocke une valeur dans le cache."""
		full_key = self._key(namespace, key)
		effective_ttl = ttl or _DEFAULT_TTLS.get(namespace, 600)
		try:
			serialized = json.dumps(value, default=str)
			if self._connected and self._redis:
				await self._redis.setex(full_key, effective_ttl, serialized)
			# Aussi dans le fallback mémoire
			_memory_cache[full_key] = (value, time.time() + effective_ttl)
			self._stats["sets"] += 1
			return True
		except CACHE_EXCEPTIONS as e:
			self._stats["errors"] += 1
			logger.warning(f"Erreur cache set : {e}")
			# Fallback mémoire uniquement
			_memory_cache[full_key] = (value, time.time() + effective_ttl)
			return True

	async def delete(self, namespace: str, key: str) -> bool:
		"""Supprime une valeur du cache."""
		full_key = self._key(namespace, key)
		try:
			if self._connected and self._redis:
				await self._redis.delete(full_key)
			_memory_cache.pop(full_key, None)
			self._stats["deletes"] += 1
			return True
		except CACHE_EXCEPTIONS as e:
			self._stats["errors"] += 1
			logger.warning(f"Erreur cache delete : {e}")
			return False

	# ── Invalidation ───────────────────────────────────────────

	async def invalidate_namespace(self, namespace: str) -> int:
		"""Invalide toutes les clés d'un namespace."""
		pattern = self._key(namespace, "*")
		count = 0
		try:
			if self._connected and self._redis:
				keys = []
				async for key in self._redis.scan_iter(match=pattern):
					keys.append(key)
				if keys:
					count = await self._redis.delete(*keys)
			# Nettoyer le fallback mémoire
			prefix = f"nokirova:cache:{namespace}:"
			to_remove = [k for k in _memory_cache if k.startswith(prefix)]
			for k in to_remove:
				del _memory_cache[k]
				count += 1
			logger.info(f"Namespace '{namespace}' invalidé : {count} clés")
			return count
		except CACHE_EXCEPTIONS as e:
			self._stats["errors"] += 1
			logger.warning(f"Erreur invalidation namespace : {e}")
			return 0

	async def invalidate_pattern(self, namespace: str, pattern: str) -> int:
		"""Invalide les clés correspondant à un pattern."""
		full_pattern = self._key(namespace, pattern)
		count = 0
		try:
			if self._connected and self._redis:
				keys = []
				async for key in self._redis.scan_iter(match=full_pattern):
					keys.append(key)
				if keys:
					count = await self._redis.delete(*keys)
			logger.info(f"Pattern '{pattern}' invalidé dans '{namespace}' : {count} clés")
			return count
		except CACHE_EXCEPTIONS as e:
			self._stats["errors"] += 1
			logger.warning(f"Erreur invalidation pattern : {e}")
			return 0

	# ── Auto-guérison ──────────────────────────────────────────

	async def rebuild_if_corrupted(self, namespace: str, rebuild_fn) -> bool:
		"""
		Reconstruit le cache d'un namespace si corrompu.

		Principe d'auto-guérison : cache corrompu → rebuild.
		rebuild_fn est une coroutine async qui retourne les données fraîches.
		"""
		try:
			# Vérifier si le cache est corrompu
			test_key = f"__health__{namespace}"
			full_key = self._key(namespace, test_key)
			if self._connected and self._redis:
				try:
					await self._redis.get(full_key)
				except CACHE_EXCEPTIONS:
					logger.warning(f"Cache corrompu pour '{namespace}', rebuild en cours...")
					self._stats["rebuilds"] += 1
					# Invalider le namespace
					await self.invalidate_namespace(namespace)
					# Reconstruire
					fresh_data = await rebuild_fn()
					if isinstance(fresh_data, dict):
						for k, v in fresh_data.items():
							await self.set(namespace, k, v)
					# Marquer comme sain
					await self.set(
						namespace, test_key, {"healthy": True, "rebuilt_at": time.time()}
					)
					logger.info(f"Cache '{namespace}' reconstruit avec succès")
					return True
			return False
		except CACHE_EXCEPTIONS as e:
			logger.error(f"Échec rebuild cache '{namespace}' : {e}")
			return False

	async def reconnect(self):
		"""
		Auto-guérison : tentative de reconnexion Redis.
		"""
		try:
			if self._redis:
				await self._redis.ping()
				self._connected = True
				logger.info("Redis reconnecté avec succès")
			else:
				await self.connect()
		except CACHE_EXCEPTIONS as e:
			logger.warning(f"Tentative de reconnexion Redis échouée : {e}")
			self._connected = False

	# ── Statistiques ───────────────────────────────────────────

	async def get_stats(self) -> dict:
		"""Retourne les statistiques du cache."""
		stats = dict(self._stats)
		total = stats["hits"] + stats["misses"]
		stats["hit_rate"] = round(stats["hits"] / total, 4) if total > 0 else 0.0
		stats["backend"] = "redis" if self._connected else "memory_fallback"
		stats["memory_entries"] = len(_memory_cache)
		if self._connected and self._redis:
			try:
				info = await self._redis.info("memory")
				stats["redis_used_memory_human"] = info.get("used_memory_human", "N/A")
				stats["redis_keys"] = await self._redis.dbsize()
			except CACHE_EXCEPTIONS:
				pass
		return stats

	async def flush_all(self):
		"""Vide tout le cache (Redis + mémoire)."""
		global _memory_cache
		try:
			if self._connected and self._redis:
				await self._redis.flushdb()
			_memory_cache = {}
			logger.info("Cache entièrement vidé")
		except CACHE_EXCEPTIONS as e:
			logger.error(f"Erreur flush cache : {e}")


# Singleton du gestionnaire de cache
cache_manager = CacheManager()
