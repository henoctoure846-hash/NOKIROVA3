"""NOKIROVA — Module Cache"""

from .manager import cache_manager as cache_manager
