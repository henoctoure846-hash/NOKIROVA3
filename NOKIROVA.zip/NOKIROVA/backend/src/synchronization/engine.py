"""
NOKIROVA — Moteur de synchronisation hors-ligne

Synchronisation bidirectionnelle entre client et serveur :
- Mode hors-ligne : opérations locales en file d'attente
- Reconnexion : synchronisation incrémentale (delta)
- Résolution de conflits : dernier-écriture-gagne + stratégies personnalisées
- Integrity check : hash des données pour détecter les divergences

Principe : l'éducation ne doit jamais s'arrêter, même sans internet.
"""

from __future__ import annotations

import hashlib
import json
import time
from enum import StrEnum
from uuid import uuid4

from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.core.logging import logger
from src.events.bus import event_bus


class SyncStatus(StrEnum):
	"""Statut de synchronisation."""

	PENDING = "pending"
	SYNCING = "syncing"
	SYNCED = "synced"
	CONFLICT = "conflict"
	FAILED = "failed"


class ConflictStrategy(StrEnum):
	"""Stratégies de résolution de conflits."""

	SERVER_WINS = "server_wins"  # Le serveur a priorité
	CLIENT_WINS = "client_wins"  # Le client a priorité
	LATEST_WINS = "latest_wins"  # Le plus récent gagne
	MERGE = "merge"  # Fusion intelligente
	MANUAL = "manual"  # Résolution manuelle


class SyncOperation:
	"""Représente une opération locale en attente de sync."""

	def __init__(
		self,
		entity_type: str,
		entity_id: str,
		action: str,  # CREATE, UPDATE, DELETE
		data: dict,
		timestamp: float | None = None,
		operation_id: str | None = None,
	):
		self.operation_id = operation_id or uuid4().hex
		self.entity_type = entity_type
		self.entity_id = entity_id
		self.action = action
		self.data = data
		self.timestamp = timestamp or time.time()
		self.status = SyncStatus.PENDING
		self.retries = 0
		self.max_retries = 3

	def to_dict(self) -> dict:
		return {
			"operation_id": self.operation_id,
			"entity_type": self.entity_type,
			"entity_id": self.entity_id,
			"action": self.action,
			"data": self.data,
			"timestamp": self.timestamp,
			"status": self.status.value,
			"retries": self.retries,
		}

	@classmethod
	def from_dict(cls, d: dict) -> SyncOperation:
		op = cls(
			entity_type=d["entity_type"],
			entity_id=d["entity_id"],
			action=d["action"],
			data=d["data"],
			timestamp=d["timestamp"],
			operation_id=d["operation_id"],
		)
		op.status = SyncStatus(d["status"])
		op.retries = d.get("retries", 0)
		return op


class SyncEngine:
	"""
	Moteur de synchronisation hors-ligne.

	Fonctionnalités :
	- File d'attente d'opérations (queue)
	- Synchronisation incrémentale par delta
	- Résolution de conflits configurable
	- Checksum d'intégrité
	- Événements de cycle de vie
	- Auto-retry avec backoff exponentiel
	"""

	def __init__(self):
		self._queue: list[SyncOperation] = []
		self._last_sync: float | None = None
		self._conflict_strategy = ConflictStrategy.LATEST_WINS
		self._entity_strategies: dict[str, ConflictStrategy] = {
			# Les flashcards et quizzes : le client gagne (travail étudiant)
			"flashcard": ConflictStrategy.CLIENT_WINS,
			"quiz": ConflictStrategy.CLIENT_WINS,
			"revision_session": ConflictStrategy.CLIENT_WINS,
			# Les cours : le serveur gagne (contenu officiel)
			"course": ConflictStrategy.SERVER_WINS,
			"lesson": ConflictStrategy.SERVER_WINS,
			# La progression : fusion
			"progress": ConflictStrategy.MERGE,
			"analytics": ConflictStrategy.SERVER_WINS,
		}
		self._is_syncing = False
		self._stats = {
			"total_operations": 0,
			"synced": 0,
			"conflicts": 0,
			"failed": 0,
			"last_sync_at": None,
		}

	# ── Gestion de la file d'attente ──────────────────────────

	def enqueue(self, operation: SyncOperation) -> str:
		"""
		Ajoute une opération à la file d'attente.
		Retourne l'ID de l'opération.
		"""
		self._queue.append(operation)
		self._stats["total_operations"] += 1
		logger.debug(f"Operation en file : {operation.action} {operation.entity_type}/{operation.entity_id}")
		return operation.operation_id

	def enqueue_batch(self, operations: list[SyncOperation]) -> list[str]:
		"""Ajoute plusieurs opérations en lot."""
		return [self.enqueue(op) for op in operations]

	def get_pending(self) -> list[SyncOperation]:
		"""Retourne les opérations en attente."""
		return [op for op in self._queue if op.status == SyncStatus.PENDING]

	def get_queue_size(self) -> int:
		"""Retourne la taille de la file d'attente."""
		return len(self._queue)

	# ── Synchronisation ───────────────────────────────────────

	async def sync(self, api_client=None) -> dict:
		"""
		Lance la synchronisation de toutes les opérations en attente.

		Retourne un résumé de la synchronisation.
		"""
		if self._is_syncing:
			logger.warning("Synchronisation déjà en cours")
			return {"status": "already_syncing"}

		self._is_syncing = True
		result = {"synced": 0, "conflicts": 0, "failed": 0, "operations": []}

		try:
			pending = self.get_pending()
			if not pending:
				logger.info("Aucune opération en attente de synchronisation")
				return result

			logger.info(f"Synchronisation de {len(pending)} opérations...")

			for op in pending:
				op.status = SyncStatus.SYNCING
				try:
					# Tenter l'envoi au serveur
					if api_client:
						server_response = await self._send_to_server(api_client, op)

						if server_response.get("conflict"):
							# Résoudre le conflit
							resolved = await self._resolve_conflict(op, server_response)
							if resolved:
								op.status = SyncStatus.SYNCED
								result["synced"] += 1
							else:
								op.status = SyncStatus.CONFLICT
								result["conflicts"] += 1
						else:
							op.status = SyncStatus.SYNCED
							result["synced"] += 1
					else:
						# Mode simulation (pas de client API)
						op.status = SyncStatus.SYNCED
						result["synced"] += 1

				except DB_OPERATION_EXCEPTIONS as e:
					op.retries += 1
					if op.retries >= op.max_retries:
						op.status = SyncStatus.FAILED
						result["failed"] += 1
						logger.error(
							f"Opération {op.operation_id} échouée définitivement : {e}"
						)
					else:
						op.status = SyncStatus.PENDING
						logger.warning(
							f"Opération {op.operation_id} échouée (tentative {op.retries}/{op.max_retries}) : {e}"
						)

				result["operations"].append(
					{
						"operation_id": op.operation_id,
						"status": op.status.value,
						"action": op.action,
						"entity_type": op.entity_type,
						"entity_id": op.entity_id,
					}
				)

			# Nettoyer les opérations synchronisées
			self._queue = [op for op in self._queue if op.status != SyncStatus.SYNCED]

			# Mettre à jour les stats
			self._stats["synced"] += result["synced"]
			self._stats["conflicts"] += result["conflicts"]
			self._stats["failed"] += result["failed"]
			self._last_sync = time.time()
			self._stats["last_sync_at"] = self._last_sync

			# Publier l'événement de synchronisation
			await event_bus.publish(
				"sync.completed",
				{
					"synced": result["synced"],
					"conflicts": result["conflicts"],
					"failed": result["failed"],
					"timestamp": self._last_sync,
				},
			)

			logger.info(
				f"Synchronisation terminée : {result['synced']} OK, "
				f"{result['conflicts']} conflits, {result['failed']} échecs"
			)
			return result

		finally:
			self._is_syncing = False

	async def _send_to_server(self, api_client, operation: SyncOperation) -> dict:
		"""
		Envoie une opération au serveur via le client API.
		"""
		endpoint = f"/api/v1/sync/{operation.entity_type}/{operation.entity_id}"
		payload = {
			"action": operation.action,
			"data": operation.data,
			"client_timestamp": operation.timestamp,
			"operation_id": operation.operation_id,
		}
		try:
			response = await api_client.post(endpoint, json=payload)
			return response
		except DB_OPERATION_EXCEPTIONS as e:
			logger.error(f"Erreur envoi serveur : {e}")
			raise

	# ── Résolution de conflits ────────────────────────────────

	async def _resolve_conflict(self, operation: SyncOperation, server_data: dict) -> bool:
		"""
		Résout un conflit entre données client et serveur.

		Retourne True si le conflit est résolu.
		"""
		strategy = self._entity_strategies.get(operation.entity_type, self._conflict_strategy)

		logger.info(
			f"Conflit détecté : {operation.entity_type}/{operation.entity_id} "
			f"— stratégie : {strategy.value}"
		)

		if strategy == ConflictStrategy.SERVER_WINS:
			# Le serveur gagne, on abandonne les modifications locales
			return True

		elif strategy == ConflictStrategy.CLIENT_WINS:
			# Le client gagne, on force les données locales
			operation.data["_force"] = True
			return True

		elif strategy == ConflictStrategy.LATEST_WINS:
			# Le plus récent gagne
			server_ts = server_data.get("server_timestamp", 0)
			if operation.timestamp >= server_ts:
				operation.data["_force"] = True
			return True

		elif strategy == ConflictStrategy.MERGE:
			# Fusion : on combine les champs non conflictuels
			server_fields = server_data.get("data", {})
			client_fields = operation.data
			merged = {**server_fields}
			for key, value in client_fields.items():
				if key not in merged or key.startswith("_"):
					merged[key] = value
			operation.data = merged
			return True

		elif strategy == ConflictStrategy.MANUAL:
			# Résolution manuelle requise
			operation.status = SyncStatus.CONFLICT
			await event_bus.publish(
				"sync.conflict",
				{
					"operation_id": operation.operation_id,
					"entity_type": operation.entity_type,
					"entity_id": operation.entity_id,
					"client_data": operation.data,
					"server_data": server_data,
				},
			)
			return False

		return False

	# ── Checksum d'intégrité ──────────────────────────────────

	def compute_checksum(self, data: dict) -> str:
		"""Calcule le hash SHA-256 des données pour vérification d'intégrité."""
		raw = json.dumps(data, sort_keys=True, default=str)
		return hashlib.sha256(raw.encode()).hexdigest()

	def verify_integrity(self, data: dict, expected_checksum: str) -> bool:
		"""Vérifie l'intégrité des données par rapport au checksum attendu."""
		return self.compute_checksum(data) == expected_checksum

	# ── Delta sync ────────────────────────────────────────────

	async def compute_delta(self, local_state: dict, server_state: dict) -> dict:
		"""
		Calcule le delta entre l'état local et serveur.
		Retourne les différences {added, modified, deleted}.
		"""
		delta = {"added": {}, "modified": {}, "deleted": {}}

		local_ids = set(local_state.keys())
		server_ids = set(server_state.keys())

		# Ajoutés côté serveur (nouveaux pour le client)
		for eid in server_ids - local_ids:
			delta["added"][eid] = server_state[eid]

		# Supprimés côté serveur (plus sur le client)
		for eid in local_ids - server_ids:
			delta["deleted"][eid] = local_state[eid]

		# Modifiés (comparaison des checksums)
		for eid in local_ids & server_ids:
			local_checksum = self.compute_checksum(local_state[eid])
			server_checksum = self.compute_checksum(server_state[eid])
			if local_checksum != server_checksum:
				delta["modified"][eid] = {
					"local": local_state[eid],
					"server": server_state[eid],
					"local_checksum": local_checksum,
					"server_checksum": server_checksum,
				}

		return delta

	# ── Statistiques ──────────────────────────────────────────

	def get_stats(self) -> dict:
		"""Retourne les statistiques de synchronisation."""
		return {
			**self._stats,
			"queue_size": self.get_queue_size(),
			"pending_operations": len(self.get_pending()),
			"is_syncing": self._is_syncing,
			"conflict_strategy": self._conflict_strategy.value,
		}

	def clear_completed(self):
		"""Nettoie les opérations terminées de la file."""
		before = len(self._queue)
		self._queue = [op for op in self._queue if op.status in (SyncStatus.PENDING, SyncStatus.CONFLICT)]
		removed = before - len(self._queue)
		logger.info(f"File nettoyée : {removed} opérations retirées")
		return removed


# Singleton du moteur de synchronisation
sync_engine = SyncEngine()
