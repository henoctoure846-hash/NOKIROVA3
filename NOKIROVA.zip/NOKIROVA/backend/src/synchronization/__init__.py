"""NOKIROVA — Module Synchronisation hors-ligne"""

from .engine import sync_engine as sync_engine
