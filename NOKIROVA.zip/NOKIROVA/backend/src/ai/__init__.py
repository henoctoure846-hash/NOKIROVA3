"""
NOKIROVA — Module IA

Système d'Intelligence Orchestrateur (SIO) :
- 8 étapes de raisonnement
- 16+ agents spécialistes
- Multi-provider (OpenAI, Anthropic, Mistral, etc.)
- Self-healing avec fallback
"""
