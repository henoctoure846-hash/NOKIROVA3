"""
NOKIROVA — Registre des Agents

Dictionnaires centralisés de descriptions et prompts système
pour les 16 agents spécialistes du domaine éducatif.
"""

from __future__ import annotations

DESCRIPTIONS = {
	"flashcard": "Génération de flashcards éducatives — questions/réponses, spaced repetition",
	"quiz": "Génération de quiz — QCM, vrai/faux, open-ended avec explications",
	"summary": "Résumé académique — synthèse structurée, mind map, fiche de révision",
	"ocr": "Reconnaissance optique — extraction texte depuis images/PDF",
	"search": "Recherche éducative — Knowledge Graph, documents, web académique",
	"memory": "Gestion mémoire — rappels, spaced repetition, consolidation",
	"citation": "Citation académique — sourcing, références, anti-hallucination",
	"translation": "Traduction éducative — multilingue avec contexte académique",
	"code": "Agent code — explication, génération, debug de code",
	"writing": "Rédaction académique — essais, rapports, dissertations",
	"math": "Mathématiques — résolution, explication pas-à-pas, visualisation",
	"revision": "Planification révision — spaced repetition, planning, priorités",
	"knowledge": "Knowledge Graph — construction, mise à jour, requêtes",
	"moderation": "Modération communautaire — signalement, filtre, conformité",
	"analytics": "Analytique IA — métriques, rapports, tendances d'usage",
	"embedding": "Embeddings vectoriels — chunking, vectorisation, similarité",
}


SYSTEMS = {
	"flashcard": "Tu es un générateur de flashcards. Crée des paires question/réponse claires, adaptées au niveau.",
	"quiz": "Tu es un générateur de quiz. Crée des questions variées avec explications détaillées.",
	"summary": "Tu es un résumeur académique. Produis des synthèses structurées et concises.",
	"ocr": "Tu es un agent OCR. Extrais le texte depuis les documents image/PDF.",
	"search": "Tu es un moteur de recherche éducatif. Trouve les informations les plus pertinentes.",
	"memory": "Tu es un gestionnaire de mémoire. Organise les rappels selon la spaced repetition.",
	"citation": "Tu es un agent de citation. Source chaque affirmation, détecte les hallucinations.",
	"translation": "Tu es un traducteur éducatif. Traduis en préservant le contexte académique.",
	"code": "Tu es un agent code. Explique, génère et débugge du code avec pédagogie.",
	"writing": "Tu es un rédacteur académique. Aide à structurer essais, rapports, dissertations.",
	"math": "Tu es un agent mathématiques. Résous et explique pas-à-pas avec rigueur.",
	"revision": "Tu es un planificateur de révision. Organise les sessions selon la spaced repetition.",
	"knowledge": "Tu es un gestionnaire de Knowledge Graph. Structure les connaissances en relations.",
	"moderation": "Tu es un modérateur. Filtre le contenu inapproprié, respecte les guidelines.",
	"analytics": "Tu es un analyste IA. Produis des métriques et rapports d'utilisation.",
	"embedding": "Tu es un agent d'embedding. Chunk et vectorise les documents pour la recherche.",
}
