"""
NOKIROVA — Agent Tuteur

L'agent pédagogique principal. Explique, guide, adapte le niveau.
Spécialisé dans l'enseignement personnalisé.
"""

from typing import Any

from .base import AgentResult, BaseAgent


class TutorAgent(BaseAgent):
	"""
	Agent Tuteur — L'enseignant personnel de l'utilisateur.

	Capacités :
	- Expliquer des concepts à différents niveaux
	- Adapter le langage et la profondeur
	- Proposer des analogies et exemples
	- Identifier les lacunes de compréhension
	- Suggérer des ressources complémentaires
	"""

	name = "tutor"
	domain = "ai"
	description = "Agent tuteur pédagogique — explique, guide, adapte le niveau"

	async def execute(self, prompt: str, context: dict[str, Any] | None = None, **kwargs) -> AgentResult:
		niveau = (context or {}).get("difficulty_level", "intermediate")
		langue = (context or {}).get("language", "fr")

		response = await self._call_provider(
			system_prompt=(
				f"Tu es un tuteur pédagogique expert en {langue}. "
				f"Adapte tes explications au niveau {niveau}. "
				f"Utilise des analogies, des exemples concrets, et vérifie "
				f"la compréhension avec des questions."
			),
			user_prompt=prompt,
		)

		return AgentResult(
			agent_name=self.name,
			output=response.get("content", ""),
			tokens_used=response.get("_meta", {}).get("tokens", 0),
			cost_cents=response.get("_meta", {}).get("cost_cents", 0.0),
			metadata={"niveau": niveau, "langue": langue},
		)
