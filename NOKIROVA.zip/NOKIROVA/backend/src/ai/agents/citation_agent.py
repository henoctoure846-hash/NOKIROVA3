"""
NOKIROVA — Agent Citation
Agent spécialiste du domaine citation.
"""

from typing import Any

from .base import AgentResult, BaseAgent
from .registry import DESCRIPTIONS, SYSTEMS


class CitationAgent(BaseAgent):
	name = "citation"
	domain = "ai"
	description = DESCRIPTIONS.get("citation", "Agent spécialiste")

	async def execute(self, prompt: str, context: dict[str, Any] | None = None, **kwargs) -> AgentResult:
		niveau = (context or {}).get("difficulty_level", "intermediate")
		langue = (context or {}).get("language", "fr")

		response = await self._call_provider(
			system_prompt=f"{SYSTEMS.get('citation', 'Tu es un agent IA spécialiste.')} Niveau : {niveau}. Langue : {langue}.",
			user_prompt=prompt,
		)

		return AgentResult(
			agent_name=self.name,
			output=response.get("content", ""),
			tokens_used=response.get("_meta", {}).get("tokens", 0),
			cost_cents=response.get("_meta", {}).get("cost_cents", 0.0),
			metadata={"niveau": niveau, "langue": langue},
		)
