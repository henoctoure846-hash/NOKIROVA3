"""
NOKIROVA — Agents Spécialistes IA

16+ agents autonomes, chacun expert dans un domaine.
Tous communiquent via l'Event Bus.
Aucune dépendance directe entre agents.
"""

from .analytics_agent import AnalyticsAgent
from .base import AgentResult, BaseAgent
from .citation_agent import CitationAgent
from .code_agent import CodeAgent
from .embedding_agent import EmbeddingAgent
from .flashcard_agent import FlashcardAgent
from .knowledge_agent import KnowledgeAgent
from .math_agent import MathAgent
from .memory_agent import MemoryAgent
from .moderation_agent import ModerationAgent
from .ocr_agent import OcrAgent
from .quiz_agent import QuizAgent
from .revision_agent import RevisionAgent
from .search_agent import SearchAgent
from .summary_agent import SummaryAgent
from .translation_agent import TranslationAgent
from .tutor_agent import TutorAgent
from .writing_agent import WritingAgent

# Registre de tous les agents
ALL_AGENTS: dict[str, type[BaseAgent]] = {
	"tutor": TutorAgent,
	"flashcard": FlashcardAgent,
	"quiz": QuizAgent,
	"summary": SummaryAgent,
	"ocr": OcrAgent,
	"search": SearchAgent,
	"memory": MemoryAgent,
	"citation": CitationAgent,
	"translation": TranslationAgent,
	"code": CodeAgent,
	"writing": WritingAgent,
	"math": MathAgent,
	"revision": RevisionAgent,
	"knowledge": KnowledgeAgent,
	"moderation": ModerationAgent,
	"analytics": AnalyticsAgent,
	"embedding": EmbeddingAgent,
}

__all__ = ["BaseAgent", "AgentResult", "ALL_AGENTS"]
