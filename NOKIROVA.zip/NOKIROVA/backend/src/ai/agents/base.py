"""
NOKIROVA — Agent de Base

Classe abstraite pour tous les agents spécialistes.
Chaque agent hérite de BaseAgent et implémente execute().

Principes :
- Statelessness : chaque appel est indépendant
- Provider independence : bascule entre providers
- Self-healing : retry + fallback en cas d'erreur
- Traçabilité : chaque exécution est journalisée
- Communication via Event Bus uniquement
"""

from __future__ import annotations

import asyncio
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from ...core.health_exceptions import AGENT_EXCEPTIONS
from ...core.logging import get_logger
from ...events.bus import Event, event_bus

logger = get_logger(__name__)


class AgentStatus(StrEnum):
	"""Statut d'un agent."""

	IDLE = "idle"
	RUNNING = "running"
	COMPLETED = "completed"
	FAILED = "failed"
	FALLBACK = "fallback"


@dataclass
class AgentResult:
	"""Résultat d'une exécution d'agent."""

	agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	agent_name: str = ""
	status: AgentStatus = AgentStatus.IDLE
	output: Any = None
	error: str | None = None
	duration_ms: float = 0.0
	tokens_used: int = 0
	cost_cents: float = 0.0
	metadata: dict[str, Any] = field(default_factory=dict)


class BaseAgent(ABC):
	"""
	Classe abstraite pour tous les agents NOKIROVA.

	Chaque agent doit :
	1. Définir son nom (name) et son domaine (domain)
	2. Implémenter execute() avec la logique métier
	3. Utiliser _call_provider() pour les appels IA
	4. Publier les événements via _publish_event()

	L'agent est stateless : pas d'état entre les appels.
	"""

	name: str = "base"
	domain: str = "ai"
	description: str = "Agent de base"
	version: str = "1.0.0"
	max_retries: int = 2

	def __init__(self):
		self._status = AgentStatus.IDLE
		logger.info(f"Agent [{self.name}] initialisé — {self.description}")

	@abstractmethod
	async def execute(
		self,
		prompt: str,
		context: dict[str, Any] | None = None,
		**kwargs: Any,
	) -> AgentResult:
		"""
		Exécuter la tâche de l'agent.

		Args:
			prompt: Instruction principale
			context: Contexte additionnel
			**kwargs: Paramètres spécifiques à l'agent

		Returns:
			AgentResult avec le résultat et les métriques
		"""
		...

	async def run(
		self,
		prompt: str,
		context: dict[str, Any] | None = None,
		**kwargs: Any,
	) -> AgentResult:
		"""
		Point d'entrée principal avec gestion d'erreur et retry.

		Ne pas surcharger — utiliser execute() pour la logique métier.
		"""
		result = AgentResult(agent_name=self.name)
		start_time = time.time()

		for attempt in range(self.max_retries + 1):
			try:
				self._status = AgentStatus.RUNNING
				result = await self.execute(prompt, context, **kwargs)
				result.status = AgentStatus.COMPLETED
				self._status = AgentStatus.COMPLETED
				break
			except AGENT_EXCEPTIONS as e:
				logger.warning(f"Agent [{self.name}] tentative {attempt + 1} échouée : {e}")
				if attempt < self.max_retries:
					await asyncio.sleep(0.5 * (attempt + 1))
					continue
				else:
					result.status = AgentStatus.FAILED
					result.error = str(e)
					self._status = AgentStatus.FAILED

		result.duration_ms = (time.time() - start_time) * 1000

		# Publier l'événement
		await self._publish_event(result)

		return result

	async def _call_provider(self, system_prompt: str, user_prompt: str, **kwargs: Any) -> dict[str, Any]:
		"""Appeler un provider IA — à implémenter avec les vrais SDK."""
		# Stub — remplacé par les appels réels
		return {
			"content": f"[Réponse simulée de {self.name}]",
			"_meta": {"tokens": 50, "cost_cents": 0.1},
		}

	async def _publish_event(self, result: AgentResult) -> None:
		"""Publier un événement via le bus."""
		event = Event(
			event_type=f"agent.{self.name}.{result.status.value}",
			domain=self.domain,
			source=f"agent.{self.name}",
			payload={
				"agent_id": result.agent_id,
				"agent_name": result.agent_name,
				"status": result.status.value,
				"duration_ms": result.duration_ms,
				"tokens_used": result.tokens_used,
				"error": result.error,
			},
		)
		await event_bus.publish(event)

		# asyncio déjà importé en haut du fichier
