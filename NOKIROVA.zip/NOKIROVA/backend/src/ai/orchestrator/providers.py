"""
NOKIROVA — Providers IA du SIO

Dispatch des appels IA vers les différents providers :
- OpenAI (GPT-4o, GPT-4o-mini)
- Anthropic (Claude 3.5 Sonnet)
- Google (Gemini Pro)
- Mistral (Mistral Large)
- Local (modèle on-premise via Ollama)

Chaque provider implémente la même interface asynchrone.
Le dispatch centralisé permet de :
1. Basculer de provider sans modifier le pipeline
2. Appliquer des fallbacks automatiques
3. Tracer les coûts et la latence
4. Respecter les rate limits
"""

from __future__ import annotations

import time
from typing import Any

from ...core.logging import get_logger
from .models import AIProvider, SIOStepName

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Interface commune — call_provider
# ---------------------------------------------------------------------------


async def call_provider(
	provider: AIProvider,
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	step_name: SIOStepName | None = None,
	temperature: float = 0.3,
	max_tokens: int = 4096,
) -> dict[str, Any]:
	"""
	Dispatch centralisé vers le provider sélectionné.

	Args:
		provider:        Le provider IA à utiliser
		system_prompt:        Le prompt système
		user_prompt:        Le prompt utilisateur
		context:        Le contexte accumulé du pipeline
		step_name:        L'étape appelante (pour le logging)
		temperature:        Température de génération (0-1)
		max_tokens:        Maximum de tokens en sortie

	Returns:
		Dictionnaire de résultats parsés depuis la réponse IA
	"""
	start_time = time.time()
	step_label = step_name.value if step_name else "unknown"

	try:
		if provider == AIProvider.OPENAI:
			result = await _call_openai(
				system_prompt,
				user_prompt,
				context,
				temperature,
				max_tokens,
			)
		elif provider == AIProvider.ANTHROPIC:
			result = await _call_anthropic(
				system_prompt,
				user_prompt,
				context,
				temperature,
				max_tokens,
			)
		elif provider == AIProvider.GOOGLE:
			result = await _call_google(
				system_prompt,
				user_prompt,
				context,
				temperature,
				max_tokens,
			)
		elif provider == AIProvider.MISTRAL:
			result = await _call_mistral(
				system_prompt,
				user_prompt,
				context,
				temperature,
				max_tokens,
			)
		elif provider == AIProvider.LOCAL:
			result = await _call_local(
				system_prompt,
				user_prompt,
				context,
				temperature,
				max_tokens,
			)
		else:
			raise ValueError(f"Provider non supporté : {provider}")

		elapsed = time.time() - start_time
		logger.info(f"[SIO] Provider {provider.value} | étape {step_label} | latence {elapsed:.2f}s")

		# Injecter les métadonnées de performance
		result.setdefault("_meta", {})
		result["_meta"]["provider"] = provider.value
		result["_meta"]["latency_ms"] = int(elapsed * 1000)
		result["_meta"]["step"] = step_label

		return result

	except Exception as exc:
		elapsed = time.time() - start_time
		logger.error(
			f"[SIO] Erreur provider {provider.value} | étape {step_label} | "
			f"latence {elapsed:.2f}s | erreur {exc}"
		)
		# Retourner un résultat minimal pour ne pas bloquer le pipeline
		return {
			"error": str(exc),
			"provider": provider.value,
			"_meta": {
				"provider": provider.value,
				"latency_ms": int(elapsed * 1000),
				"step": step_label,
				"error": True,
			},
		}


# ---------------------------------------------------------------------------
# Stubs des providers — à connecter aux SDK réels
# ---------------------------------------------------------------------------


async def _call_openai(
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	temperature: float,
	max_tokens: int,
) -> dict[str, Any]:
	"""Appel OpenAI (GPT-4o / GPT-4o-mini). Stub — à connecter au SDK."""
	# TODO:        Connecter au SDK OpenAI via settings.OPENAI_API_KEY
	logger.debug("[SIO] Appel OpenAI — stub")
	return {"content": f"[OpenAI stub] {user_prompt[:100]}", "raw": None}


async def _call_anthropic(
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	temperature: float,
	max_tokens: int,
) -> dict[str, Any]:
	"""Appel Anthropic (Claude 3.5 Sonnet). Stub — à connecter au SDK."""
	# TODO:        Connecter au SDK Anthropic via settings.ANTHROPIC_API_KEY
	logger.debug("[SIO] Appel Anthropic — stub")
	return {"content": f"[Anthropic stub] {user_prompt[:100]}", "raw": None}


async def _call_google(
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	temperature: float,
	max_tokens: int,
) -> dict[str, Any]:
	"""Appel Google (Gemini Pro). Stub — à connecter au SDK."""
	# TODO:        Connecter au SDK Google via settings.GOOGLE_API_KEY
	logger.debug("[SIO] Appel Google — stub")
	return {"content": f"[Google stub] {user_prompt[:100]}", "raw": None}


async def _call_mistral(
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	temperature: float,
	max_tokens: int,
) -> dict[str, Any]:
	"""Appel Mistral (Mistral Large). Stub — à connecter au SDK."""
	# TODO:        Connecter au SDK Mistral via settings.MISTRAL_API_KEY
	logger.debug("[SIO] Appel Mistral — stub")
	return {"content": f"[Mistral stub] {user_prompt[:100]}", "raw": None}


async def _call_local(
	system_prompt: str,
	user_prompt: str,
	context: dict[str, Any],
	temperature: float,
	max_tokens: int,
) -> dict[str, Any]:
	"""Appel local (Ollama). Stub — à connecter au SDK."""
	# TODO:        Connecter à Ollama via settings.OLLAMA_BASE_URL
	logger.debug("[SIO] Appel Local/Ollama — stub")
	return {"content": f"[Local stub] {user_prompt[:100]}", "raw": None}
