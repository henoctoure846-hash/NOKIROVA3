"""
NOKIROVA — Routes API du SIO

Points d'entrée pour l'orchestrateur IA :
- POST /api/v1/ai/sio/process   — Traiter une requête via le pipeline SIO
- POST /api/v1/ai/sio/stream     — Streaming SSE du pipeline
- GET  /api/v1/ai/sio/status    — Statut de l'orchestrateur
- GET  /api/v1/ai/sio/metrics    — Métriques d'utilisation
- POST /api/v1/ai/sio/feedback  — Feedback utilisateur
"""

from typing import Any

from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel, Field

from ...api.deps import ActiveUser, DBSession, RedisClient
from ...api.response import (
	nokirova_error,
	nokirova_success,
)
from .models import AIProvider, SIOResult
from .orchestrator import sio_orchestrator

router = APIRouter(prefix="/sio", tags=["SIO — Système d'Intelligence Orchestrateur"])


# ---------------------------------------------------------------------------
# Schémas de requête/réponse
# ---------------------------------------------------------------------------


class SIORequest(BaseModel):
	"""Requête envoyée au pipeline SIO."""

	prompt: str = Field(..., min_length=1, max_length=10000, description="Question ou instruction")
	task_type: str = Field(default="general", description="Type de tâche")
	language: str = Field(default="fr", description="Langue de sortie")
	difficulty_level: str = Field(default="intermediate", description="Niveau")
	preferred_provider: str | None = Field(default=None, description="Provider IA préféré")
	context: dict[str, Any] | None = Field(default=None, description="Contexte additionnel")


class SIOFeedback(BaseModel):
	"""Feedback utilisateur sur un résultat SIO."""

	request_id: str
	rating: int = Field(..., ge=1, le=5, description="Note de 1 à 5")
	comment: str | None = Field(default=None, description="Commentaire")
	helpful: bool = Field(default=True, description="La réponse était-elle utile ?")


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/process", summary="Traiter une requête via le pipeline SIO")
async def process_sio_request(
	request: SIORequest,
	bg: BackgroundTasks,
	user: ActiveUser,
	db: DBSession,
):
	"""
	Traiter une requête via les 8 étapes du pipeline SIO.

	Le pipeline exécute séquentiellement :
	Comprendre → Chercher → Comparer → Raisonner → Produire → Vérifier → Citer → Mémoriser
	"""
	provider = None
	if request.preferred_provider:
		try:
			provider = AIProvider(request.preferred_provider)
		except ValueError:
			return nokirova_error(f"Provider '{request.preferred_provider}' non supporté")

	result: SIOResult = await sio_orchestrator.process(
		prompt=request.prompt,
		user_id=str(user.id),
		context=request.context,
		task_type=request.task_type,
		language=request.language,
		difficulty_level=request.difficulty_level,
		preferred_provider=provider,
	)

	return nokirova_success(
		message="Requête SIO traitée",
		data={
			"request_id": result.request_id,
			"status": result.status.value,
			"output": result.final_output,
			"confidence": result.confidence_score,
			"citations": result.citations,
			"metrics": {
				"total_tokens": result.total_tokens,
				"total_cost_cents": result.total_cost_cents,
				"total_duration_ms": result.total_duration_ms,
				"providers_used": [p.value for p in result.providers_used],
				"steps": [
					{
						"name": step.step_name.value,
						"status": step.status.value,
						"duration_ms": step.duration_ms,
						"provider": step.provider.value,
					}
					for step in result.steps
				],
			},
		},
	)


@router.get("/status", summary="Statut de l'orchestrateur SIO")
async def get_sio_status(
	user: ActiveUser,
):
	"""Récupérer le statut actuel de l'orchestrateur SIO."""
	return nokirova_success(
		message="Statut SIO",
		data={
			"status": "operational",
			"providers": {
				"openai": "available",
				"anthropic": "available",
				"mistral": "available",
				"google": "available",
				"local": "available",
			},
			"pipeline_steps": 8,
			"version": "1.0.0",
		},
	)


@router.get("/metrics", summary="Métriques d'utilisation du SIO")
async def get_sio_metrics(
	user: ActiveUser,
	redis: RedisClient,
):
	"""Récupérer les métriques d'utilisation de l'orchestrateur."""
	# À implémenter : Implémenter avec les vraies métriques Redis
	return nokirova_success(
		message="Métriques SIO",
		data={
			"total_requests": 0,
			"avg_duration_ms": 0,
			"avg_confidence": 0,
			"provider_distribution": {},
			"error_rate": 0,
		},
	)


@router.post("/feedback", summary="Feedback sur un résultat SIO")
async def submit_sio_feedback(
	feedback: SIOFeedback,
	user: ActiveUser,
	db: DBSession,
):
	"""
	Soumettre un feedback sur un résultat SIO.

	Ce feedback est utilisé pour :
	- Améliorer la qualité du pipeline
	- Ajuster les seuils de confiance
	- Entraîner le système de mémoire
	"""
	# À implémenter : Stocker le feedback en base
	return nokirova_success(
		message="Feedback enregistré — merci de votre contribution",
		data={"feedback_id": feedback.request_id, "recorded": True},
	)
