"""
NOKIROVA — Système d'Intelligence Orchestrateur (SIO)

Le cœur cognitif de NOKIROVA.
Pipeline en 8 étapes de raisonnement, inspiré de la méthode scientifique :

1. COMPRENDRE  — Analyser l'intention, le contexte, la langue, le niveau
2. CHERCHER    — Récupérer les connaissances pertinentes (KG, mémoire, web)
3. COMPARER    — Confronter les sources, détecter les contradictions
4. RAISONNER   — Synthétiser, déduire, inférer
5. PRODUIRE    — Générer le contenu (texte, flashcard, quiz, résumé...)
6. VÉRIFIER    — Valider la qualité, cohérence, exactitude
7. CITER       — Sourcer chaque affirmation, éviter les hallucinations
8. MÉMORISER   — Stocker pour l'apprentissage continu

Architecture modulaire :
- models.py   → énumérations et structures de données
- steps.py    → les 8 fonctions d'étapes du pipeline
- providers.py → dispatch des providers IA
- orchestrator.py → cœur : process(), _execute_step(), événements
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from ...core.health_exceptions import HEALING_EXCEPTIONS
from ...core.logging import get_logger
from ...events.bus import Event, event_bus
from .models import (
	AIProvider,
	SIOResult,
	SIOStatus,
	SIOStep,
	SIOStepName,
)
from .steps import STEP_REGISTRY

logger = get_logger(__name__)


class SIOOrchestrator:
	"""
	Système d'Intelligence Orchestrateur.

	Exécute le pipeline en 8 étapes de raisonnement.
	Chaque étape peut :
	- Réussir → passer à la suivante
	- Échouer → self-healing (retry, fallback, skip)
	- Être sautée → si non pertinente

	L'orchestrateur est stateless : chaque requête est indépendante.
	La persistance est assurée par le système de mémoire et le Knowledge Graph.
	"""

	# Ordre des étapes
	PIPELINE = [
		SIOStepName.COMPRENDRE,
		SIOStepName.CHERCHER,
		SIOStepName.COMPARER,
		SIOStepName.RAISONNER,
		SIOStepName.PRODUIRE,
		SIOStepName.VERIFIER,
		SIOStepName.CITER,
		SIOStepName.MEMORISER,
	]

	# Fallback en cas d'échec total
	FALLBACK_RESPONSE = {
		"content": "Je suis actuellement en maintenance. Veuillez réessayer dans quelques instants.",
		"confidence": 0.0,
		"citations": [],
	}

	def __init__(self):
		self._provider_priority: list[AIProvider] = [
			AIProvider.OPENAI,
			AIProvider.ANTHROPIC,
			AIProvider.MISTRAL,
			AIProvider.GOOGLE,
			AIProvider.LOCAL,
		]
		self._max_retries_per_step = 2
		self._confidence_threshold = 0.6
		logger.info("SIOOrchestrator initialisé — 8 étapes, multi-provider")

	# -----------------------------------------------------------------------
	# Point d'entrée principal
	# -----------------------------------------------------------------------

	async def process(
		self,
		prompt: str,
		user_id: str,
		context: dict[str, Any] | None = None,
		task_type: str = "general",
		language: str = "fr",
		difficulty_level: str = "intermediate",
		preferred_provider: AIProvider | None = None,
	) -> SIOResult:
		"""
		Traiter une requête via le pipeline SIO complet.

		Args:
			prompt:        La question ou instruction de l'utilisateur
			user_id:        Identifiant de l'utilisateur
			context:        Contexte additionnel (documents, historique, etc.)
			task_type:        Type de tâche (general, flashcard, quiz, summary, etc.)
			language:        Langue de sortie
			difficulty_level:        Niveau de difficulté
			preferred_provider:        Fournisseur IA préféré

		Returns:
			SIOResult avec le résultat complet et les métriques
		"""
		result = SIOResult(user_id=user_id)
		start_time = time.time()

		# Si un provider préféré est spécifié, le mettre en tête
		providers = list(self._provider_priority)
		if preferred_provider and preferred_provider in providers:
			providers.remove(preferred_provider)
			providers.insert(0, preferred_provider)

		try:
			# Exécuter chaque étape séquentiellement
			accumulated_context = {
				"prompt": prompt,
				"user_id": user_id,
				"task_type": task_type,
				"language": language,
				"difficulty_level": difficulty_level,
				"user_context": context or {},
				"providers": providers,
				"step_outputs": {},
			}

			for step_name in self.PIPELINE:
				step = SIOStep(step_name=step_name, provider=providers[0])
				step = await self._execute_step(step, accumulated_context, providers)
				result.steps.append(step)
				result.total_tokens += step.tokens_used
				result.total_cost_cents += step.cost_cents

				if step.status == SIOStatus.COMPLETED:
					accumulated_context["step_outputs"][step_name.value] = step.output_data
				elif step.status == SIOStatus.FALLBACK:
					accumulated_context["step_outputs"][step_name.value] = step.output_data
					result.providers_used.append(step.provider)
				elif step.status == SIOStatus.FAILED:
					# Self-healing : marquer l'étape mais continuer si possible
					logger.warning(f"Étape {step_name.value} échouée, self-healing activé")
					if step_name in (SIOStepName.COMPRENDRE, SIOStepName.PRODUIRE):
						# Étapes critiques : on ne peut pas continuer
						result.status = SIOStatus.FAILED
						result.final_output = self.FALLBACK_RESPONSE
						break

			# Si on est arrivé au bout, construire le résultat final
			if result.status != SIOStatus.FAILED:
				result.status = SIOStatus.COMPLETED
				result.final_output = accumulated_context["step_outputs"].get(
					SIOStepName.PRODUIRE.value, {}
				)
				result.confidence_score = (
					accumulated_context["step_outputs"]
					.get(SIOStepName.VERIFIER.value, {})
					.get("confidence", 0.0)
				)
				result.citations = (
					accumulated_context["step_outputs"]
					.get(SIOStepName.CITER.value, {})
					.get("citations", [])
				)
				result.memory_stored = (
					SIOStepName.MEMORISER.value in accumulated_context["step_outputs"]
				)

		except HEALING_EXCEPTIONS as e:
			logger.error(f"Erreur fatale SIO : {e}")
			result.status = SIOStatus.FAILED
			result.final_output = self.FALLBACK_RESPONSE

		result.total_duration_ms = (time.time() - start_time) * 1000

		# Publier l'événement de résultat
		await self._publish_result_event(result)

		return result

	# -----------------------------------------------------------------------
	# Exécution d'une étape individuelle
	# -----------------------------------------------------------------------

	async def _execute_step(
		self,
		step: SIOStep,
		context: dict[str, Any],
		providers: list[AIProvider],
	) -> SIOStep:
		"""Exécuter une étape avec retry et fallback via le registre."""
		step.status = SIOStatus.RUNNING
		step.started_at = time.time()

		# Récupérer la fonction d'étape depuis le registre
		executor = STEP_REGISTRY.get(step.step_name)
		if not executor:
			step.status = SIOStatus.SKIPPED
			step.completed_at = time.time()
			step.duration_ms = (step.completed_at - step.started_at) * 1000
			return step

		# Tentatives avec retry
		for attempt in range(self._max_retries_per_step + 1):
			try:
				# Essayer chaque provider dans l'ordre
				for provider in providers:
					step.provider = provider
					try:
						output = await executor(context, provider)
						step.output_data = output
						step.status = SIOStatus.COMPLETED
						step.completed_at = time.time()
						step.duration_ms = (step.completed_at - step.started_at) * 1000
						step.tokens_used = output.get("_meta", {}).get("tokens", 0)
						step.cost_cents = output.get("_meta", {}).get("cost_cents", 0.0)
						return step
					except HEALING_EXCEPTIONS as provider_err:
						logger.warning(
							f"Provider {provider.value} a échoué pour "
							f"{step.step_name.value}: {provider_err}"
						)
						continue

				# Tous les providers ont échoué → fallback
				logger.warning(f"Tous providers échoués pour {step.step_name.value}, fallback activé")
				step.output_data = await executor(context, AIProvider.FALLBACK)
				step.status = SIOStatus.FALLBACK
				step.completed_at = time.time()
				step.duration_ms = (step.completed_at - step.started_at) * 1000
				return step

			except HEALING_EXCEPTIONS as e:
				if attempt < self._max_retries_per_step:
					logger.info(f"Retry {attempt + 1} pour {step.step_name.value}")
					await asyncio.sleep(0.5 * (attempt + 1))
					continue
				else:
					step.status = SIOStatus.FAILED
					step.error = str(e)
					step.completed_at = time.time()
					step.duration_ms = (step.completed_at - step.started_at) * 1000
					return step

	# -----------------------------------------------------------------------
	# Publication d'événements
	# -----------------------------------------------------------------------

	async def _publish_result_event(self, result: SIOResult) -> None:
		"""Publier l'événement de résultat SIO."""
		event = Event(
			event_type=(
				"ai.generation.completed"
				if result.status == SIOStatus.COMPLETED
				else "ai.generation.failed"
			),
			domain="ai",
			source="sio.orchestrator",
			payload={
				"request_id": result.request_id,
				"user_id": result.user_id,
				"status": result.status.value,
				"total_tokens": result.total_tokens,
				"total_cost_cents": result.total_cost_cents,
				"total_duration_ms": result.total_duration_ms,
				"confidence_score": result.confidence_score,
				"providers_used": [p.value for p in result.providers_used],
			},
		)
		await event_bus.publish(event)


# ---------------------------------------------------------------------------
# Instance singleton
# ---------------------------------------------------------------------------

sio_orchestrator = SIOOrchestrator()
