"""
NOKIROVA — Étapes du pipeline SIO

Les 8 étapes de raisonnement du Système d'Intelligence Orchestrateur :
1. Comprendre — analyser l'intention
2. Chercher — récupérer le contexte
3. Comparer — confronter les sources
4. Raisonner — synthétiser
5. Produire — générer le contenu
6. Vérifier — valider la qualité
7. Citer — sourcer les affirmations
8. Mémoriser — stocker pour l'apprentissage

Chaque étape est une coroutine indépendante qui reçoit le contexte accumulé
et un provider IA, et retourne un dictionnaire de résultats.
"""

from __future__ import annotations

import uuid
from typing import Any

from ...core.logging import get_logger
from ...events.bus import Event, event_bus
from .models import AIProvider, SIOStepName
from .providers import call_provider

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Étape 1 : COMPRENDRE
# ---------------------------------------------------------------------------


async def step_comprendre(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Analyser l'intention de l'utilisateur :
	- Extraire le sujet principal
	- Détecter la langue
	- Évaluer le niveau de difficulté
	- Identifier le type de tâche (question, résumé, flashcard, quiz...)
	- Détecter les entités clés
	- Déterminer le ton et le style
	"""
	prompt = context["prompt"]
	language = context.get("language", "fr")

	understanding = await call_provider(
		provider=provider,
		system_prompt=(
			f"Tu es un analyseur d'intention éducative. "
			f"Analyse la demande suivante en {language}. "
			f"Retourne un JSON avec : intention, sujet, niveau, type_tache, "
			f"entites, ton, urgence."
		),
		user_prompt=prompt,
		context=context,
	)

	return {
		"intention": understanding.get("intention", "information"),
		"sujet": understanding.get("sujet", prompt[:100]),
		"niveau": understanding.get("niveau", context.get("difficulty_level", "intermediate")),
		"type_tache": understanding.get("type_tache", context.get("task_type", "general")),
		"entites": understanding.get("entites", []),
		"ton": understanding.get("ton", "neutre"),
		"urgence": understanding.get("urgence", "normal"),
		"_meta": understanding.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 2 : CHERCHER
# ---------------------------------------------------------------------------


async def step_chercher(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Récupérer les connaissances pertinentes :
	- Knowledge Graph (relations, concepts)
	- Mémoire de l'utilisateur (sessions précédentes)
	- Documents de l'utilisateur (notes, cours)
	- Sources externes (web, bases académiques)
	- Flashcards et quiz existants
	"""
	understanding = context["step_outputs"].get("comprendre", {})
	sujet = understanding.get("sujet", "")
	entites = understanding.get("entites", [])

	search_results = await call_provider(
		provider=provider,
		system_prompt=(
			f"Tu es un moteur de recherche éducatif. "
			f"Pour le sujet '{sujet}', génère les informations clés, "
			f"les concepts liés, et les sources pertinentes."
		),
		user_prompt=f"Cherche des informations sur : {sujet}. Entités : {entites}",
		context=context,
	)

	return {
		"knowledge_graph": search_results.get("concepts", []),
		"user_memory": [],
		"user_documents": [],
		"external_sources": search_results.get("sources", []),
		"existing_content": search_results.get("existing", []),
		"relevance_score": search_results.get("relevance", 0.5),
		"_meta": search_results.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 3 : COMPARER
# ---------------------------------------------------------------------------


async def step_comparer(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Confronter les sources, détecter les contradictions :
	- Comparer les informations issues de différentes sources
	- Identifier les conflits et contradictions
	- Évaluer la fiabilité de chaque source
	- Pondérer les sources selon leur crédibilité
	"""
	search_data = context["step_outputs"].get("chercher", {})
	understanding = context["step_outputs"].get("comprendre", {})

	comparison = await call_provider(
		provider=provider,
		system_prompt=(
			"Tu es un analyste de sources. Compare les informations "
			"issues de différentes sources, identifie les contradictions "
			"et évalue la fiabilité de chaque source."
		),
		user_prompt=(
			f"Sujet : {understanding.get('sujet', '')}\n"
			f"Sources : {search_data.get('external_sources', [])}\n"
			f"Knowledge Graph : {search_data.get('knowledge_graph', [])}"
		),
		context=context,
	)

	return {
		"conflicts": comparison.get("conflicts", []),
		"agreements": comparison.get("agreements", []),
		"source_reliability": comparison.get("reliability", {}),
		"synthesis": comparison.get("synthesis", ""),
		"_meta": comparison.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 4 : RAISONNER
# ---------------------------------------------------------------------------


async def step_raisonner(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Synthétiser, déduire, inférer :
	- Construire un raisonnement logique
	- Identifier les conclusions
	- Évaluer la force du raisonnement
	- Déterminer les limites et incertitudes
	"""
	understanding = context["step_outputs"].get("comprendre", {})
	search_data = context["step_outputs"].get("chercher", {})
	comparison = context["step_outputs"].get("comparer", {})

	reasoning = await call_provider(
		provider=provider,
		system_prompt=(
			"Tu es un raisonneur logique. À partir des informations "
			"collectées, construis un raisonnement structuré, identifie "
			"les conclusions et évalue leur force."
		),
		user_prompt=(
			f"Intention : {understanding.get('intention', '')}\n"
			f"Synthèse comparative : {comparison.get('synthesis', '')}\n"
			f"Connaissances : {search_data.get('knowledge_graph', [])}"
		),
		context=context,
	)

	return {
		"reasoning_chain": reasoning.get("reasoning", []),
		"conclusions": reasoning.get("conclusions", []),
		"confidence": reasoning.get("confidence", 0.5),
		"limitations": reasoning.get("limitations", []),
		"_meta": reasoning.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 5 : PRODUIRE
# ---------------------------------------------------------------------------


async def step_produire(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Générer le contenu final :
	- Adapter le format au type de tâche (texte, flashcard, quiz, résumé...)
	- Structurer la réponse selon les standards pédagogiques
	- Intégrer les résultats du raisonnement
	- Personnaliser le niveau et la langue
	"""
	understanding = context["step_outputs"].get("comprendre", {})
	reasoning = context["step_outputs"].get("raisonner", {})
	language = context.get("language", "fr")
	task_type = context.get("task_type", "general")
	difficulty_level = context.get("difficulty_level", "intermediate")

	production = await call_provider(
		provider=provider,
		system_prompt=(
			f"Tu es un générateur de contenu éducatif en {language}. "
			f"Type de tâche : {task_type}. Niveau : {difficulty_level}. "
			f"Produis un contenu structuré, pédagogique et adapté."
		),
		user_prompt=(
			f"Conclusions : {reasoning.get('conclusions', [])}\n"
			f"Intention : {understanding.get('intention', '')}\n"
			f"Raisonnement : {reasoning.get('reasoning_chain', [])}"
		),
		context=context,
	)

	return {
		"content": production.get("content", ""),
		"format": task_type,
		"language": language,
		"difficulty_level": difficulty_level,
		"structure": production.get("structure", {}),
		"_meta": production.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 6 : VÉRIFIER
# ---------------------------------------------------------------------------


async def step_verifier(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Valider la qualité, cohérence, exactitude :
	- Vérifier la cohérence interne du contenu
	- Valider l'exactitude factuelle
	- Évaluer la complétude par rapport à l'intention
	- Mesurer la pertinence
	- Calculer le score de confiance global
	"""
	production = context["step_outputs"].get("produire", {})
	understanding = context["step_outputs"].get("comprendre", {})

	verification = await call_provider(
		provider=provider,
		system_prompt=(
			"Tu es un vérificateur de qualité éducative. "
			"Évalue le contenu suivant sur 5 critères : "
			"confiance (0-1), cohérence, exactitude, complétude, pertinence."
		),
		user_prompt=(
			f"Contenu : {production.get('content', '')}\nIntention : {understanding.get('intention', '')}"
		),
		context=context,
	)

	return {
		"confidence": verification.get("confidence", 0.5),
		"coherence": verification.get("coherence", True),
		"accuracy": verification.get("accuracy", True),
		"completeness": verification.get("completeness", True),
		"relevance": verification.get("relevance", True),
		"issues": verification.get("issues", []),
		"_meta": verification.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 7 : CITER
# ---------------------------------------------------------------------------


async def step_citer(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Sourcer chaque affirmation :
	- Identifier les affirmations qui nécessitent une source
	- Attribuer les sources disponibles
	- Marquer les affirmations non sourcées (hallucination risk)
	- Générer les références formatées
	"""
	production = context["step_outputs"].get("produire", {})
	search_data = context["step_outputs"].get("chercher", {})

	citation = await call_provider(
		provider=provider,
		system_prompt=(
			"Tu es un citeur académique. Pour chaque affirmation du contenu, "
			"identifie si une source est disponible, et génère les références."
		),
		user_prompt=(
			f"Contenu : {production.get('content', '')}\n"
			f"Sources : {search_data.get('external_sources', [])}"
		),
		context=context,
	)

	return {
		"citations": citation.get("citations", []),
		"unsourced_claims": citation.get("unsourced", []),
		"references": citation.get("references", []),
		"_meta": citation.get("_meta", {}),
	}


# ---------------------------------------------------------------------------
# Étape 8 : MÉMORISER
# ---------------------------------------------------------------------------


async def step_memoriser(
	context: dict[str, Any],
	provider: AIProvider,
) -> dict[str, Any]:
	"""
	Stocker pour l'apprentissage continu :
	- Sauvegarder dans la mémoire utilisateur
	- Mettre à jour le Knowledge Graph
	- Créer les embeddings vectoriels
	- Publier l'événement de mémorisation
	"""
	production = context["step_outputs"].get("produire", {})
	verification = context["step_outputs"].get("verifier", {})
	understanding = context["step_outputs"].get("comprendre", {})
	user_id = context.get("user_id", "")

	# Publier l'événement de mémorisation via le bus
	memory_event = Event(
		event_type="ai.memory.updated",
		domain="ai",
		source="sio.orchestrator",
		payload={
			"user_id": user_id,
			"content": production.get("content", ""),
			"task_type": understanding.get("type_tache", "general"),
			"confidence": verification.get("confidence", 0.0),
		},
	)
	await event_bus.publish(memory_event)

	return {
		"memory_id": str(uuid.uuid4()),
		"stored": True,
		"knowledge_graph_updated": True,
		"embeddings_created": True,
		"_meta": {"tokens": 0, "cost_cents": 0.0},
	}


# ---------------------------------------------------------------------------
# Registre des étapes — mapping nom → fonction
# ---------------------------------------------------------------------------

STEP_REGISTRY: dict[SIOStepName, Any] = {
	SIOStepName.COMPRENDRE: step_comprendre,
	SIOStepName.CHERCHER: step_chercher,
	SIOStepName.COMPARER: step_comparer,
	SIOStepName.RAISONNER: step_raisonner,
	SIOStepName.PRODUIRE: step_produire,
	SIOStepName.VERIFIER: step_verifier,
	SIOStepName.CITER: step_citer,
	SIOStepName.MEMORISER: step_memoriser,
}
