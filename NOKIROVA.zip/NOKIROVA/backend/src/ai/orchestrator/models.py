"""
NOKIROVA — Modèles de données du SIO

Structures de données pour le pipeline SIO (Système d'Intelligence Orchestrateur).
Énumérations des étapes, statuts, providers et dataclasses de résultats.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class SIOStepName(StrEnum):
	"""Les 8 étapes du pipeline SIO."""

	COMPRENDRE = "comprendre"
	CHERCHER = "chercher"
	COMPARER = "comparer"
	RAISONNER = "raisonner"
	PRODUIRE = "produire"
	VERIFIER = "verifier"
	CITER = "citer"
	MEMORISER = "memoriser"


class SIOStatus(StrEnum):
	"""Statut d'une étape ou du pipeline."""

	PENDING = "pending"
	RUNNING = "running"
	COMPLETED = "completed"
	FAILED = "failed"
	SKIPPED = "skipped"
	FALLBACK = "fallback"


class AIProvider(StrEnum):
	"""Fournisseurs IA supportés (provider independence)."""

	OPENAI = "openai"
	ANTHROPIC = "anthropic"
	MISTRAL = "mistral"
	GOOGLE = "google"
	LOCAL = "local"
	FALLBACK = "fallback"


@dataclass
class SIOStep:
	"""Résultat d'une étape individuelle du pipeline."""

	step_name: SIOStepName
	status: SIOStatus = SIOStatus.PENDING
	started_at: float = 0.0
	completed_at: float = 0.0
	duration_ms: float = 0.0
	input_data: dict[str, Any] = field(default_factory=dict)
	output_data: dict[str, Any] = field(default_factory=dict)
	provider: AIProvider = AIProvider.OPENAI
	tokens_used: int = 0
	cost_cents: float = 0.0
	error: str | None = None
	metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SIOResult:
	"""Résultat complet du pipeline SIO."""

	request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	user_id: str | None = None
	status: SIOStatus = SIOStatus.PENDING
	steps: list[SIOStep] = field(default_factory=list)
	final_output: Any = None
	total_tokens: int = 0
	total_cost_cents: float = 0.0
	total_duration_ms: float = 0.0
	providers_used: list[AIProvider] = field(default_factory=list)
	confidence_score: float = 0.0
	citations: list[dict[str, str]] = field(default_factory=list)
	memory_stored: bool = False
	metadata: dict[str, Any] = field(default_factory=dict)
