"""NOKIROVA — Module Services

Couche métier : pas de SQL dans les services, pas de logique métier dans les contrôleurs.
Toute la logique métier réside ici.
Communication via Event Bus uniquement.
"""
