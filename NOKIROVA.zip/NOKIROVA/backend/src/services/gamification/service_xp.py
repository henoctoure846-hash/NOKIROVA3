"""NOKIROVA — Service Gamification : XP Utilisateur

Logique métier pour les points d'expérience :
- Consultation du profil XP
- Ajustement administrateur
- Attribution d'XP par d'autres services
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ValidationException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	UserXPResponseDTO,
	XPAdjustDTO,
)
from src.services.gamification.repository import UserXPRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_XP = "gamification:xp"
CACHE_NS_LEADERBOARDS = "gamification:leaderboards"
EVENT_DOMAIN = "gamification"


# ─── Service XP ──────────────────────────────────────────────────────────────


class GamificationXPService:
	"""Service métier pour les points d'expérience."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.xp_repo = UserXPRepository(session)

	# ─── Consultation ────────────────────────────────────────────────────

	async def get_user_xp(self, user_id: str) -> UserXPResponseDTO:
		"""Récupère le profil XP d'un utilisateur."""
		cached = await cache_manager.get(CACHE_NS_XP, user_id)
		if cached:
			return UserXPResponseDTO(**cached)

		xp = await self.xp_repo.get_or_create(user_id)

		response = self._xp_to_response(xp)
		await cache_manager.set(CACHE_NS_XP, user_id, response.model_dump(mode="json"), ttl=60)
		return response

	# ─── Ajustement administrateur ────────────────────────────────────────

	async def adjust_xp(
		self,
		user_id: str,
		dto: XPAdjustDTO,
	) -> UserXPResponseDTO:
		"""Ajuste l'XP d'un utilisateur (administrateur)."""
		xp = await self.xp_repo.add_xp(user_id, dto.amount)

		await cache_manager.delete(CACHE_NS_XP, user_id)
		await cache_manager.invalidate_namespace(CACHE_NS_LEADERBOARDS)

		await event_bus.publish(
			Event(
				event_type="xp_adjusted",
				domain=EVENT_DOMAIN,
				payload={"user_id": user_id, "amount": dto.amount, "reason": dto.reason},
			)
		)

		return self._xp_to_response(xp)

	# ─── Attribution par d'autres services ─────────────────────────────────

	async def award_xp(
		self,
		user_id: str,
		amount: int,
		source: str,
		source_id: str | None = None,
	) -> UserXPResponseDTO:
		"""Attribue de l'XP à un utilisateur (appelé par d'autres services)."""
		if amount <= 0:
			raise ValidationException("amount", "Le montant XP doit être positif")

		xp = await self.xp_repo.add_xp(user_id, amount)

		await cache_manager.delete(CACHE_NS_XP, user_id)
		await cache_manager.invalidate_namespace(CACHE_NS_LEADERBOARDS)

		await event_bus.publish(
			Event(
				event_type="xp_awarded",
				domain=EVENT_DOMAIN,
				payload={
					"user_id": user_id,
					"amount": amount,
					"source": source,
					"source_id": source_id,
				},
			)
		)

		return self._xp_to_response(xp)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _xp_to_response(xp) -> UserXPResponseDTO:
		"""Convertit un modèle GamificationUserXP en DTO de réponse."""
		return UserXPResponseDTO(
			id=xp.id,
			user_id=xp.user_id,
			total_xp=xp.total_xp,
			level=xp.level,
			current_level_xp=xp.current_level_xp,
			next_level_xp=xp.next_level_xp,
			weekly_xp=xp.weekly_xp,
			monthly_xp=xp.monthly_xp,
			xp_history=xp.xp_history,
			created_at=xp.created_at,
			updated_at=xp.updated_at,
		)
