"""NOKIROVA — Service Gamification : Achievements

Logique métier pour les achievements de gamification :
- Octroi d'achievements
- Consultation des achievements utilisateur
- Dépendance croisée : l'octroi d'un achievement crédite du XP
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	AchievementCreateDTO,
	AchievementResponseDTO,
)
from src.services.gamification.repository import (
	AchievementRepository,
	UserXPRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_ACHIEVEMENTS = "gamification:achievements"
CACHE_NS_XP = "gamification:xp"
CACHE_NS_LEADERBOARDS = "gamification:leaderboards"
EVENT_DOMAIN = "gamification"


# ─── Service Achievements ────────────────────────────────────────────────────


class GamificationAchievementService:
	"""Service métier pour les achievements de gamification."""

	def __init__(
		self,
		session: AsyncSession,
		xp_repo: UserXPRepository | None = None,
	) -> None:
		self.session = session
		self.achievement_repo = AchievementRepository(session)
		# Dépendance croisée : créditer le XP lors d'un achievement
		self.xp_repo = xp_repo or UserXPRepository(session)

	# ─── Octroi ──────────────────────────────────────────────────────────

	async def award_achievement(
		self,
		dto: AchievementCreateDTO,
	) -> AchievementResponseDTO:
		"""Attribue un succès à un utilisateur."""
		# Vérifier si le succès n'existe pas déjà
		existing = await self.achievement_repo.get_by_user_and_type(dto.user_id, dto.achievement_type)
		if existing is not None:
			# Mettre à jour la progression si déjà existant
			update_data = {"progress": dto.progress}
			if dto.progress >= 1.0:
				update_data["xp_earned"] = dto.xp_earned
			updated = await self.achievement_repo.update(existing.id, update_data)
			return self._achievement_to_response(updated)

		data = dto.model_dump(exclude_none=True)
		data["earned_at"] = datetime.now(UTC).isoformat()
		achievement = await self.achievement_repo.create(data)

		# Ajouter l'XP du succès au profil utilisateur
		if dto.xp_earned > 0:
			await self.xp_repo.add_xp(dto.user_id, dto.xp_earned)

		await cache_manager.invalidate_namespace(CACHE_NS_ACHIEVEMENTS)

		await event_bus.publish(
			Event(
				event_type="achievement_unlocked",
				domain=EVENT_DOMAIN,
				payload={
					"achievement_id": achievement.id,
					"user_id": dto.user_id,
					"achievement_type": dto.achievement_type,
					"xp_earned": dto.xp_earned,
				},
			)
		)

		return self._achievement_to_response(achievement)

	# ─── Consultation ────────────────────────────────────────────────────

	async def get_user_achievements(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[AchievementResponseDTO]:
		"""Récupère les succès d'un utilisateur."""
		achievements = await self.achievement_repo.get_by_user(user_id, limit, offset)
		return [self._achievement_to_response(a) for a in achievements]

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _achievement_to_response(achievement) -> AchievementResponseDTO:
		"""Convertit un modèle GamificationAchievement en DTO de réponse."""
		return AchievementResponseDTO(
			id=achievement.id,
			user_id=achievement.user_id,
			badge_id=achievement.badge_id,
			achievement_type=achievement.achievement_type,
			title=achievement.title,
			description=achievement.description,
			xp_earned=achievement.xp_earned,
			earned_at=achievement.earned_at,
			progress=achievement.progress,
			metadata_json=achievement.metadata_json,
			created_at=achievement.created_at,
			updated_at=achievement.updated_at,
		)
