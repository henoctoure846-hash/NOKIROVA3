"""NOKIROVA — Depot Gamification

Acces aux donnees pour les badges, succes, XP, series, classements,
defis et recompenses.
Utilise les modeles SQLAlchemy reels de gamification.py.

Refactorisation :
    Badge, Leaderboard, Challenge — Categorie (b) : heritage + soft_delete -> bool
    UserXP, Streak — Categorie (c) : cle user_id, pas de soft_delete
    Achievement, Reward — Categorie (e) : pas de soft_delete
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime, timedelta

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.gamification import (
	GamificationAchievement,
	GamificationBadge,
	GamificationChallenge,
	GamificationLeaderboard,
	GamificationReward,
	GamificationStreak,
	GamificationUserXP,
)

# ─── Badges — Categorie (b) ──────────────────────────────────────────────────


class BadgeRepository(BaseRepository[GamificationBadge]):
	"""Depot pour les badges de gamification.

	Herite de BaseRepository[GamificationBadge].
	get_by_id surcharge pour filtrer par is_active=True.
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationBadge, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, badge_id: str) -> GamificationBadge | None:
		"""Recupere un badge actif par son identifiant."""
		return await self.get_by_id_active(badge_id)

	async def soft_delete(self, badge_id: str) -> bool:
		"""Suppression logique d'un badge."""
		result = await super().soft_delete(badge_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_category(
		self,
		category: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[GamificationBadge]:
		"""Liste les badges actifs par categorie."""
		stmt = (
			select(GamificationBadge)
			.where(
				and_(
					GamificationBadge.category == category,
					GamificationBadge.is_active == True,  # noqa: E712
				)
			)
			.order_by(GamificationBadge.order_index.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Succes (Achievements) — Categorie (e) ────────────────────────────────────


class AchievementRepository(BaseRepository[GamificationAchievement]):
	"""Depot pour les succes de gamification.

	Herite de BaseRepository[GamificationAchievement] pour create/get/update.
	Pas de soft_delete — les succes sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationAchievement, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[GamificationAchievement]:
		"""Recupere les succes d'un utilisateur."""
		stmt = (
			select(GamificationAchievement)
			.where(GamificationAchievement.user_id == user_id)
			.order_by(GamificationAchievement.earned_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_by_user_and_type(
		self,
		user_id: str,
		achievement_type: str,
	) -> GamificationAchievement | None:
		"""Recupere un succes specifique d'un utilisateur."""
		stmt = select(GamificationAchievement).where(
			and_(
				GamificationAchievement.user_id == user_id,
				GamificationAchievement.achievement_type == achievement_type,
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()


# ─── XP Utilisateur — Categorie (c) : cle user_id ────────────────────────────


class UserXPRepository(BaseRepository[GamificationUserXP]):
	"""Depot pour les points d'experience utilisateur.

	Herite de BaseRepository[GamificationUserXP] pour create.
	Cle primaire d'acces : user_id (pas entity_id).
	Pas de soft_delete — l'XP est permanente.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationUserXP, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(self, user_id: str) -> GamificationUserXP | None:
		"""Recupere le profil XP d'un utilisateur."""
		stmt = select(GamificationUserXP).where(GamificationUserXP.user_id == user_id)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def get_or_create(self, user_id: str) -> GamificationUserXP:
		"""Recupere ou cree le profil XP d'un utilisateur."""
		xp = await self.get_by_user(user_id)
		if xp is not None:
			return xp
		return await self.create({"user_id": user_id})

	async def add_xp(self, user_id: str, amount: int) -> GamificationUserXP | None:
		"""Ajoute de l'XP a un utilisateur et gere le passage de niveau."""
		xp = await self.get_or_create(user_id)
		xp.total_xp += amount
		xp.weekly_xp += amount
		xp.monthly_xp += amount
		xp.current_level_xp += amount

		# Verifier le passage de niveau
		while xp.current_level_xp >= xp.next_level_xp:
			xp.current_level_xp -= xp.next_level_xp
			xp.level += 1
			xp.next_level_xp = int(xp.next_level_xp * 1.5)

		await self.session.flush()
		return xp

	async def update(self, user_id: str, data: dict) -> GamificationUserXP | None:
		"""Met a jour le profil XP (par user_id, pas par entity_id)."""
		xp = await self.get_by_user(user_id)
		if xp is None:
			return None
		for key, value in data.items():
			if value is not None and hasattr(xp, key):
				setattr(xp, key, value)
		await self.session.flush()
		return xp


# ─── Series (Streaks) — Categorie (c) : cle user_id ──────────────────────────


class StreakRepository(BaseRepository[GamificationStreak]):
	"""Depot pour les series de jours consecutifs.

	Herite de BaseRepository[GamificationStreak] pour create.
	Cle primaire d'acces : user_id (pas entity_id).
	Pas de soft_delete — les series sont permanentes.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationStreak, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(self, user_id: str) -> GamificationStreak | None:
		"""Recupere la serie d'un utilisateur."""
		stmt = select(GamificationStreak).where(GamificationStreak.user_id == user_id)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def get_or_create(self, user_id: str, streak_type: str = "daily") -> GamificationStreak:
		"""Recupere ou cree la serie d'un utilisateur."""
		streak = await self.get_by_user(user_id)
		if streak is not None:
			return streak
		return await self.create(
			{
				"user_id": user_id,
				"streak_type": streak_type,
				"last_activity_date": datetime.now(UTC).isoformat(),
			}
		)

	async def update_activity(self, user_id: str) -> GamificationStreak | None:
		"""Met a jour la serie apres une activite."""
		streak = await self.get_or_create(user_id)
		today = datetime.now(UTC).strftime("%Y-%m-%d")
		yesterday = (datetime.now(UTC) - timedelta(days=1)).strftime("%Y-%m-%d")

		if streak.last_activity_date == today:
			return streak

		if streak.last_activity_date == yesterday:
			streak.current_streak += 1
		else:
			streak.current_streak = 1

		streak.longest_streak = max(streak.longest_streak, streak.current_streak)
		streak.last_activity_date = datetime.now(UTC).isoformat()

		await self.session.flush()
		return streak

	async def use_freeze(self, user_id: str) -> GamificationStreak | None:
		"""Utilise un gel de serie."""
		streak = await self.get_by_user(user_id)
		if streak is None or streak.freezes_available <= 0:
			return None
		streak.is_frozen = True
		streak.freezes_available -= 1
		await self.session.flush()
		return streak

	async def update(self, user_id: str, data: dict) -> GamificationStreak | None:
		"""Met a jour la serie (par user_id, pas par entity_id)."""
		streak = await self.get_by_user(user_id)
		if streak is None:
			return None
		for key, value in data.items():
			if value is not None and hasattr(streak, key):
				setattr(streak, key, value)
		await self.session.flush()
		return streak


# ─── Classements (Leaderboards) — Categorie (b) ───────────────────────────────


class LeaderboardRepository(BaseRepository[GamificationLeaderboard]):
	"""Depot pour les classements.

	Herite de BaseRepository[GamificationLeaderboard].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationLeaderboard, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, leaderboard_id: str) -> bool:
		"""Suppression logique d'un classement."""
		result = await super().soft_delete(leaderboard_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_type(
		self,
		leaderboard_type: str,
		scope_id: str | None = None,
		period: str | None = None,
	) -> GamificationLeaderboard | None:
		"""Recupere un classement par type et portee."""
		conditions = [
			GamificationLeaderboard.leaderboard_type == leaderboard_type,
			GamificationLeaderboard.is_active == True,  # noqa: E712
		]
		if scope_id is not None:
			conditions.append(GamificationLeaderboard.scope_id == scope_id)
		if period is not None:
			conditions.append(GamificationLeaderboard.period == period)

		stmt = select(GamificationLeaderboard).where(and_(*conditions))
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def list_active(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[GamificationLeaderboard]:
		"""Liste les classements actifs."""
		stmt = (
			select(GamificationLeaderboard)
			.where(GamificationLeaderboard.is_active == True)  # noqa: E712
			.order_by(GamificationLeaderboard.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Defis (Challenges) — Categorie (b) ───────────────────────────────────────


class ChallengeRepository(BaseRepository[GamificationChallenge]):
	"""Depot pour les defis de gamification.

	Herite de BaseRepository[GamificationChallenge].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationChallenge, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, challenge_id: str) -> bool:
		"""Suppression logique d'un defi."""
		result = await super().soft_delete(challenge_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_active(
		self,
		challenge_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[GamificationChallenge]:
		"""Liste les defis actifs, eventuellement filtres par type."""
		conditions = [GamificationChallenge.is_active == True]  # noqa: E712
		if challenge_type:
			conditions.append(GamificationChallenge.challenge_type == challenge_type)

		stmt = (
			select(GamificationChallenge)
			.where(and_(*conditions))
			.order_by(GamificationChallenge.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Recompenses (Rewards) — Categorie (e) ────────────────────────────────────


class RewardRepository(BaseRepository[GamificationReward]):
	"""Depot pour les recompenses de gamification.

	Herite de BaseRepository[GamificationReward] pour create/get/update.
	Pas de soft_delete — les recompenses sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(GamificationReward, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(
		self,
		user_id: str,
		claimed: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[GamificationReward]:
		"""Recupere les recompenses d'un utilisateur."""
		conditions = [GamificationReward.user_id == user_id]
		if claimed is not None:
			conditions.append(GamificationReward.is_claimed == claimed)

		stmt = (
			select(GamificationReward)
			.where(and_(*conditions))
			.order_by(GamificationReward.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def claim(self, reward_id: str) -> GamificationReward | None:
		"""Reclame une recompense."""
		reward = await self.get_by_id(reward_id)
		if reward is None:
			return None
		reward.is_claimed = True
		reward.claimed_at = datetime.now(UTC).isoformat()
		await self.session.flush()
		return reward
