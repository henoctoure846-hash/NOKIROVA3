"""NOKIROVA — Service Gamification : Défis (Challenges)

Logique métier pour les défis :
- CRUD défis
- Suppression logique
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	ChallengeCreateDTO,
	ChallengeResponseDTO,
)
from src.services.gamification.repository import ChallengeRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_CHALLENGES = "gamification:challenges"
EVENT_DOMAIN = "gamification"


# ─── Service Défis ──────────────────────────────────────────────────────────


class GamificationChallengeService:
	"""Service métier pour les défis de gamification."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.challenge_repo = ChallengeRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_challenge(
		self,
		dto: ChallengeCreateDTO,
	) -> ChallengeResponseDTO:
		"""Crée un nouveau défi."""
		data = dto.model_dump(exclude_none=True)
		challenge = await self.challenge_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_CHALLENGES)

		await event_bus.publish(
			Event(
				event_type="challenge_created",
				domain=EVENT_DOMAIN,
				payload={"challenge_id": challenge.id, "title": challenge.title},
			)
		)

		return self._challenge_to_response(challenge)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_challenge(self, challenge_id: str) -> ChallengeResponseDTO:
		"""Récupère un défi par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_CHALLENGES, challenge_id)
		if cached:
			return ChallengeResponseDTO(**cached)

		challenge = await self.challenge_repo.get_by_id(challenge_id)
		if challenge is None:
			raise NotFoundException("Défi introuvable")

		response = self._challenge_to_response(challenge)
		await cache_manager.set(CACHE_NS_CHALLENGES, challenge_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_challenges(
		self,
		challenge_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ChallengeResponseDTO]:
		"""Liste les défis actifs."""
		challenges = await self.challenge_repo.list_active(challenge_type, limit, offset)
		return [self._challenge_to_response(c) for c in challenges]

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_challenge(self, challenge_id: str) -> bool:
		"""Supprime logiquement un défi."""
		success = await self.challenge_repo.soft_delete(challenge_id)
		if success:
			await cache_manager.delete(CACHE_NS_CHALLENGES, challenge_id)
			await event_bus.publish(
				Event(
					event_type="challenge_deleted",
					domain=EVENT_DOMAIN,
					payload={"challenge_id": challenge_id},
				)
			)
		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _challenge_to_response(challenge) -> ChallengeResponseDTO:
		"""Convertit un modèle GamificationChallenge en DTO de réponse."""
		return ChallengeResponseDTO(
			id=challenge.id,
			title=challenge.title,
			description=challenge.description,
			challenge_type=challenge.challenge_type,
			objective=challenge.objective,
			target_value=challenge.target_value,
			xp_reward=challenge.xp_reward,
			badge_id=challenge.badge_id,
			starts_at=challenge.starts_at,
			ends_at=challenge.ends_at,
			is_active=challenge.is_active,
			participant_count=challenge.participant_count,
			completion_count=challenge.completion_count,
			created_at=challenge.created_at,
			updated_at=challenge.updated_at,
		)
