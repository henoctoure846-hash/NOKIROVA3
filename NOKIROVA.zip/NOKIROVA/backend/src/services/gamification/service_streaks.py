"""NOKIROVA — Service Gamification : Séries (Streaks)

Logique métier pour les séries d'activité :
- Consultation de la série
- Enregistrement d'activité
- Gel de série
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ValidationException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	StreakFreezeDTO,
	StreakResponseDTO,
)
from src.services.gamification.repository import StreakRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_STREAKS = "gamification:streaks"
EVENT_DOMAIN = "gamification"


# ─── Service Séries ──────────────────────────────────────────────────────────


class GamificationStreakService:
	"""Service métier pour les séries d'activité."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.streak_repo = StreakRepository(session)

	# ─── Consultation ────────────────────────────────────────────────────

	async def get_streak(self, user_id: str) -> StreakResponseDTO:
		"""Récupère la série d'un utilisateur."""
		cached = await cache_manager.get(CACHE_NS_STREAKS, user_id)
		if cached:
			return StreakResponseDTO(**cached)

		streak = await self.streak_repo.get_or_create(user_id)

		response = self._streak_to_response(streak)
		await cache_manager.set(CACHE_NS_STREAKS, user_id, response.model_dump(mode="json"), ttl=120)
		return response

	# ─── Enregistrement d'activité ────────────────────────────────────────

	async def record_activity(self, user_id: str) -> StreakResponseDTO:
		"""Enregistre une activité pour mettre à jour la série."""
		streak = await self.streak_repo.update_activity(user_id)

		await cache_manager.delete(CACHE_NS_STREAKS, user_id)

		await event_bus.publish(
			Event(
				event_type="streak_updated",
				domain=EVENT_DOMAIN,
				payload={"user_id": user_id, "current_streak": streak.current_streak},
			)
		)

		return self._streak_to_response(streak)

	# ─── Gel de série ────────────────────────────────────────────────────

	async def freeze_streak(
		self,
		user_id: str,
		dto: StreakFreezeDTO,
	) -> StreakResponseDTO:
		"""Utilise un gel de série."""
		streak = await self.streak_repo.use_freeze(user_id)
		if streak is None:
			raise ValidationException("freeze", "Aucun gel de série disponible")

		await cache_manager.delete(CACHE_NS_STREAKS, user_id)

		return self._streak_to_response(streak)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _streak_to_response(streak) -> StreakResponseDTO:
		"""Convertit un modèle GamificationStreak en DTO de réponse."""
		return StreakResponseDTO(
			id=streak.id,
			user_id=streak.user_id,
			current_streak=streak.current_streak,
			longest_streak=streak.longest_streak,
			last_activity_date=streak.last_activity_date,
			streak_type=streak.streak_type,
			is_frozen=streak.is_frozen,
			freezes_available=streak.freezes_available,
			history=streak.history,
			created_at=streak.created_at,
			updated_at=streak.updated_at,
		)
