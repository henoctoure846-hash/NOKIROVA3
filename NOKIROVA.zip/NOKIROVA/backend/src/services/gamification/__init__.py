"""NOKIROVA — Service Gamification

Exports :
- Façade : GamificationService
- Sous-services : Badge, Achievement, XP, Streak, Leaderboard, Challenge, Reward
- Repositories : Badge, Achievement, UserXP, Streak, Leaderboard, Challenge, Reward
"""

from .repository import (
	AchievementRepository,
	BadgeRepository,
	ChallengeRepository,
	LeaderboardRepository,
	RewardRepository,
	StreakRepository,
	UserXPRepository,
)
from .service import GamificationService
from .service_achievements import GamificationAchievementService
from .service_badges import GamificationBadgeService
from .service_challenges import GamificationChallengeService
from .service_leaderboards import GamificationLeaderboardService
from .service_rewards import GamificationRewardService
from .service_streaks import GamificationStreakService
from .service_xp import GamificationXPService

__all__ = [
	"GamificationService",
	"GamificationBadgeService",
	"GamificationAchievementService",
	"GamificationXPService",
	"GamificationStreakService",
	"GamificationLeaderboardService",
	"GamificationChallengeService",
	"GamificationRewardService",
	"BadgeRepository",
	"AchievementRepository",
	"UserXPRepository",
	"StreakRepository",
	"LeaderboardRepository",
	"ChallengeRepository",
	"RewardRepository",
]
