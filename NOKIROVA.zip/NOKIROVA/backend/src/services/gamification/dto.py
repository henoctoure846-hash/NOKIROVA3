"""NOKIROVA — DTOs du service Gamification

Modèles Pydantic pour la validation des requêtes et réponses
du module Gamification : badges, succès, XP, séries, classements,
défis et récompenses.
Alignés sur les modèles SQLAlchemy réels (gamification.py).
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class BadgeCategoryEnum(StrEnum):
	"""Catégories de badges."""

	learning = "learning"
	social = "social"
	productivity = "productivity"
	mastery = "mastery"
	special = "special"


class BadgeRarityEnum(StrEnum):
	"""Rareté des badges."""

	common = "common"
	rare = "rare"
	epic = "epic"
	legendary = "legendary"


class AchievementTypeEnum(StrEnum):
	"""Types de succès."""

	first_quiz = "first_quiz"
	streak_7 = "streak_7"
	mastery_course = "mastery_course"
	first_post = "first_post"
	study_hours_10 = "study_hours_10"
	perfect_score = "perfect_score"
	contributor = "contributor"
	pioneer = "pioneer"


class LeaderboardTypeEnum(StrEnum):
	"""Types de classement."""

	global_lb = "global"
	course = "course"
	group = "group"
	weekly = "weekly"
	monthly = "monthly"


class LeaderboardPeriodEnum(StrEnum):
	"""Périodes de classement."""

	weekly = "weekly"
	monthly = "monthly"
	all_time = "all_time"


class StreakTypeEnum(StrEnum):
	"""Types de série."""

	daily = "daily"
	study = "study"
	review = "review"


class ChallengeTypeEnum(StrEnum):
	"""Types de défi."""

	daily = "daily"
	weekly = "weekly"
	monthly = "monthly"
	special = "special"


class ChallengeObjectiveEnum(StrEnum):
	"""Objectifs de défi."""

	quiz_count = "quiz_count"
	study_minutes = "study_minutes"
	streak_days = "streak_days"


class RewardTypeEnum(StrEnum):
	"""Types de récompense."""

	xp = "xp"
	badge = "badge"
	title = "title"
	feature_unlock = "feature_unlock"
	discount = "discount"


class RewardSourceEnum(StrEnum):
	"""Sources de récompense."""

	challenge = "challenge"
	achievement = "achievement"
	streak = "streak"
	admin = "admin"


# ─── Badges ────────────────────────────────────────────────────────────────────


class BadgeCreateDTO(BaseModel):
	"""Création d'un badge."""

	name: str = Field(..., min_length=1, max_length=100)
	description: str = Field(..., min_length=1)
	icon: str = Field(..., max_length=100)
	category: BadgeCategoryEnum = BadgeCategoryEnum.learning
	rarity: BadgeRarityEnum = BadgeRarityEnum.common
	xp_reward: int = Field(0, ge=0)
	criteria: dict = Field(default_factory=dict)
	is_secret: bool = False
	order_index: int = Field(0, ge=0)


class BadgeUpdateDTO(BaseModel):
	"""Mise à jour d'un badge."""

	name: str | None = Field(None, min_length=1, max_length=100)
	description: str | None = None
	icon: str | None = Field(None, max_length=100)
	category: BadgeCategoryEnum | None = None
	rarity: BadgeRarityEnum | None = None
	xp_reward: int | None = Field(None, ge=0)
	criteria: dict | None = None
	is_active: bool | None = None
	is_secret: bool | None = None
	order_index: int | None = Field(None, ge=0)


class BadgeResponseDTO(BaseModel):
	"""Réponse badge."""

	id: str
	name: str
	description: str
	icon: str
	category: str = "learning"
	rarity: str = "common"
	xp_reward: int = 0
	criteria: dict = Field(default_factory=dict)
	is_active: bool = True
	is_secret: bool = False
	order_index: int = 0
	created_at: datetime
	updated_at: datetime


# ─── Succès (Achievements) ────────────────────────────────────────────────────


class AchievementCreateDTO(BaseModel):
	"""Création / déclenchement d'un succès."""

	user_id: str
	badge_id: str | None = None
	achievement_type: AchievementTypeEnum
	title: str = Field(..., min_length=1, max_length=255)
	description: str | None = None
	xp_earned: int = Field(0, ge=0)
	progress: float = Field(1.0, ge=0.0, le=1.0)
	metadata_json: dict | None = None


class AchievementResponseDTO(BaseModel):
	"""Réponse succès."""

	id: str
	user_id: str
	badge_id: str | None = None
	achievement_type: str
	title: str
	description: str | None = None
	xp_earned: int = 0
	earned_at: str
	progress: float = 1.0
	metadata_json: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── XP Utilisateur ───────────────────────────────────────────────────────────


class UserXPResponseDTO(BaseModel):
	"""Réponse XP utilisateur."""

	id: str
	user_id: str
	total_xp: int = 0
	level: int = 1
	current_level_xp: int = 0
	next_level_xp: int = 100
	weekly_xp: int = 0
	monthly_xp: int = 0
	xp_history: dict | None = None
	created_at: datetime
	updated_at: datetime


class XPAdjustDTO(BaseModel):
	"""Ajustement manuel d'XP."""

	amount: int = Field(..., description="Montant XP positif ou négatif")
	reason: str = Field(..., min_length=1, max_length=500)


# ─── Séries (Streaks) ────────────────────────────────────────────────────────


class StreakResponseDTO(BaseModel):
	"""Réponse série."""

	id: str
	user_id: str
	current_streak: int = 0
	longest_streak: int = 0
	last_activity_date: str | None = None
	streak_type: str = "daily"
	is_frozen: bool = False
	freezes_available: int = 3
	history: dict | None = None
	created_at: datetime
	updated_at: datetime


class StreakFreezeDTO(BaseModel):
	"""Utilisation d'un gel de série."""

	freeze: bool = Field(True, description="Activer un gel de série")


# ─── Classements (Leaderboards) ────────────────────────────────────────────────


class LeaderboardCreateDTO(BaseModel):
	"""Création d'un classement."""

	name: str = Field(..., min_length=1, max_length=255)
	leaderboard_type: LeaderboardTypeEnum = LeaderboardTypeEnum.global_lb
	scope_id: str | None = None
	period: LeaderboardPeriodEnum | None = None


class LeaderboardResponseDTO(BaseModel):
	"""Réponse classement."""

	id: str
	name: str
	leaderboard_type: str
	scope_id: str | None = None
	period: str | None = None
	entries: list[dict] | None = None
	last_updated_at: str | None = None
	is_active: bool = True
	created_at: datetime
	updated_at: datetime


class LeaderboardEntryDTO(BaseModel):
	"""Entrée de classement (utilisé dans entries JSON)."""

	user_id: str
	xp: int = 0
	rank: int = 0
	display_name: str | None = None


# ─── Défis (Challenges) ────────────────────────────────────────────────────────


class ChallengeCreateDTO(BaseModel):
	"""Création d'un défi."""

	title: str = Field(..., min_length=1, max_length=255)
	description: str | None = None
	challenge_type: ChallengeTypeEnum = ChallengeTypeEnum.daily
	objective: ChallengeObjectiveEnum = ChallengeObjectiveEnum.quiz_count
	target_value: int = Field(..., gt=0)
	xp_reward: int = Field(0, ge=0)
	badge_id: str | None = None
	starts_at: str | None = None
	ends_at: str | None = None


class ChallengeResponseDTO(BaseModel):
	"""Réponse défi."""

	id: str
	title: str
	description: str | None = None
	challenge_type: str = "daily"
	objective: str
	target_value: int
	xp_reward: int = 0
	badge_id: str | None = None
	starts_at: str | None = None
	ends_at: str | None = None
	is_active: bool = True
	participant_count: int = 0
	completion_count: int = 0
	created_at: datetime
	updated_at: datetime


# ─── Récompenses (Rewards) ────────────────────────────────────────────────────


class RewardCreateDTO(BaseModel):
	"""Création d'une récompense."""

	user_id: str
	reward_type: RewardTypeEnum
	reward_value: str = Field(..., min_length=1, max_length=255)
	source: RewardSourceEnum
	source_id: str | None = None
	expires_at: str | None = None


class RewardResponseDTO(BaseModel):
	"""Réponse récompense."""

	id: str
	user_id: str
	reward_type: str
	reward_value: str
	source: str
	source_id: str | None = None
	claimed_at: str | None = None
	expires_at: str | None = None
	is_claimed: bool = False
	created_at: datetime
	updated_at: datetime


class RewardClaimDTO(BaseModel):
	"""Réclamation d'une récompense."""

	reward_id: str
