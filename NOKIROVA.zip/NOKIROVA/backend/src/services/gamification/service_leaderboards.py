"""NOKIROVA — Service Gamification : Classements (Leaderboards)

Logique métier pour les classements :
- CRUD classements
- Mise à jour des entrées avec tri et rangs
- Cache et événements
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	LeaderboardCreateDTO,
	LeaderboardEntryDTO,
	LeaderboardResponseDTO,
)
from src.services.gamification.repository import LeaderboardRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_LEADERBOARDS = "gamification:leaderboards"
EVENT_DOMAIN = "gamification"


# ─── Service Classements ─────────────────────────────────────────────────────


class GamificationLeaderboardService:
	"""Service métier pour les classements."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.leaderboard_repo = LeaderboardRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_leaderboard(
		self,
		dto: LeaderboardCreateDTO,
	) -> LeaderboardResponseDTO:
		"""Crée un nouveau classement."""
		# Vérifier l'unicité du type + portée
		existing = await self.leaderboard_repo.get_by_type(dto.leaderboard_type, dto.scope_id, dto.period)
		if existing is not None:
			raise ValidationException("leaderboard_type", "Un classement de ce type existe déjà")

		data = dto.model_dump(exclude_none=True)
		data["entries"] = []  # Classement vide initialement
		leaderboard = await self.leaderboard_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_LEADERBOARDS)

		await event_bus.publish(
			Event(
				event_type="leaderboard_created",
				domain=EVENT_DOMAIN,
				payload={"leaderboard_id": leaderboard.id},
			)
		)

		return self._leaderboard_to_response(leaderboard)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_leaderboard(
		self,
		leaderboard_type: str,
		scope_id: str | None = None,
		period: str | None = None,
	) -> LeaderboardResponseDTO:
		"""Récupère un classement par type."""
		cache_key = f"{leaderboard_type}:{scope_id or 'all'}:{period or 'all'}"
		cached = await cache_manager.get(CACHE_NS_LEADERBOARDS, cache_key)
		if cached:
			return LeaderboardResponseDTO(**cached)

		leaderboard = await self.leaderboard_repo.get_by_type(leaderboard_type, scope_id, period)
		if leaderboard is None:
			raise NotFoundException("Classement introuvable")

		response = self._leaderboard_to_response(leaderboard)
		await cache_manager.set(CACHE_NS_LEADERBOARDS, cache_key, response.model_dump(mode="json"), ttl=120)
		return response

	async def list_leaderboards(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[LeaderboardResponseDTO]:
		"""Liste les classements actifs."""
		leaderboards = await self.leaderboard_repo.list_active(limit, offset)
		return [self._leaderboard_to_response(lb) for lb in leaderboards]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_leaderboard_entries(
		self,
		leaderboard_id: str,
		entries: list[LeaderboardEntryDTO],
	) -> LeaderboardResponseDTO:
		"""Met à jour les entrées d'un classement."""
		leaderboard = await self.leaderboard_repo.get_by_id(leaderboard_id)
		if leaderboard is None:
			raise NotFoundException("Classement introuvable")

		# Trier les entrées par XP décroissant et assigner les rangs
		sorted_entries = sorted(entries, key=lambda e: e.xp, reverse=True)
		entries_data = []
		for rank, entry in enumerate(sorted_entries, start=1):
			entries_data.append(
				{
					"user_id": entry.user_id,
					"xp": entry.xp,
					"rank": rank,
					"display_name": entry.display_name,
				}
			)

		update_data = {
			"entries": entries_data,
			"last_updated_at": datetime.now(UTC).isoformat(),
		}
		updated = await self.leaderboard_repo.update(leaderboard_id, update_data)

		await cache_manager.invalidate_namespace(CACHE_NS_LEADERBOARDS)

		return self._leaderboard_to_response(updated)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _leaderboard_to_response(leaderboard) -> LeaderboardResponseDTO:
		"""Convertit un modèle GamificationLeaderboard en DTO de réponse."""
		return LeaderboardResponseDTO(
			id=leaderboard.id,
			name=leaderboard.name,
			leaderboard_type=leaderboard.leaderboard_type,
			scope_id=leaderboard.scope_id,
			period=leaderboard.period,
			entries=leaderboard.entries,
			last_updated_at=leaderboard.last_updated_at,
			is_active=leaderboard.is_active,
			created_at=leaderboard.created_at,
			updated_at=leaderboard.updated_at,
		)
