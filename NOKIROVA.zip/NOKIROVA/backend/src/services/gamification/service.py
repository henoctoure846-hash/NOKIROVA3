"""NOKIROVA — Service Gamification (Façade)

Façade de délégation pour le domaine gamification.
Délègue chaque sous-domaine à un service spécialisé :
- GamificationBadgeService       → badges
- GamificationAchievementService → achievements
- GamificationXPService          → points d'expérience
- GamificationStreakService       → séries d'activité
- GamificationLeaderboardService  → classements
- GamificationChallengeService   → défis
- GamificationRewardService       → récompenses

Corrections clés :
- event_bus.publish(Event(event_type=, domain=, payload=))
- cache_manager.get(ns, key) / .set(ns, key, value, ttl) / .delete(ns, key) / .invalidate_namespace(ns)
- Exceptions : NotFoundException, ForbiddenException, ValidationException
- Pas de uuid4() manuel ni de created_at/updated_at manuels
- Repos instanciés dans les sous-services via __init__(session)
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.gamification.dto import (
	AchievementCreateDTO,
	AchievementResponseDTO,
	BadgeCreateDTO,
	BadgeResponseDTO,
	BadgeUpdateDTO,
	ChallengeCreateDTO,
	ChallengeResponseDTO,
	LeaderboardCreateDTO,
	LeaderboardEntryDTO,
	LeaderboardResponseDTO,
	RewardCreateDTO,
	RewardResponseDTO,
	StreakFreezeDTO,
	StreakResponseDTO,
	UserXPResponseDTO,
	XPAdjustDTO,
)
from src.services.gamification.service_achievements import GamificationAchievementService
from src.services.gamification.service_badges import GamificationBadgeService
from src.services.gamification.service_challenges import GamificationChallengeService
from src.services.gamification.service_leaderboards import GamificationLeaderboardService
from src.services.gamification.service_rewards import GamificationRewardService
from src.services.gamification.service_streaks import GamificationStreakService
from src.services.gamification.service_xp import GamificationXPService

# ─── Service Façade ──────────────────────────────────────────────────────────


class GamificationService:
	"""Façade de délégation pour la gamification.

	Chaque appel est délégué au sous-service correspondant.
	Les sous-services sont instanciés une seule fois dans __init__.
	"""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		# Sous-services spécialisés
		self.badges = GamificationBadgeService(session)
		self.achievements = GamificationAchievementService(session)
		self.xp = GamificationXPService(session)
		self.streaks = GamificationStreakService(session)
		self.leaderboards = GamificationLeaderboardService(session)
		self.challenges = GamificationChallengeService(session)
		self.rewards = GamificationRewardService(session)

	# ─── Badges ───────────────────────────────────────────────────────────

	async def create_badge(
		self,
		user_id: str,
		dto: BadgeCreateDTO,
	) -> BadgeResponseDTO:
		"""Délègue la création de badge."""
		return await self.badges.create_badge(user_id, dto)

	async def get_badge(self, badge_id: str) -> BadgeResponseDTO:
		"""Délègue la récupération de badge."""
		return await self.badges.get_badge(badge_id)

	async def list_badges(
		self,
		category: str | None = None,
		limit: int = 100,
		offset: int = 0,
	) -> list[BadgeResponseDTO]:
		"""Délègue le listage des badges."""
		return await self.badges.list_badges(category, limit, offset)

	async def update_badge(
		self,
		badge_id: str,
		user_id: str,
		dto: BadgeUpdateDTO,
	) -> BadgeResponseDTO:
		"""Délègue la mise à jour de badge."""
		return await self.badges.update_badge(badge_id, user_id, dto)

	async def delete_badge(self, badge_id: str, user_id: str) -> bool:
		"""Délègue la suppression de badge."""
		return await self.badges.delete_badge(badge_id, user_id)

	# ─── Achievements ────────────────────────────────────────────────────

	async def award_achievement(
		self,
		dto: AchievementCreateDTO,
	) -> AchievementResponseDTO:
		"""Délègue l'octroi d'un achievement."""
		return await self.achievements.award_achievement(dto)

	async def get_user_achievements(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[AchievementResponseDTO]:
		"""Délègue la récupération des achievements."""
		return await self.achievements.get_user_achievements(user_id, limit, offset)

	# ─── XP ──────────────────────────────────────────────────────────────

	async def get_user_xp(self, user_id: str) -> UserXPResponseDTO:
		"""Délègue la consultation du profil XP."""
		return await self.xp.get_user_xp(user_id)

	async def adjust_xp(
		self,
		user_id: str,
		dto: XPAdjustDTO,
	) -> UserXPResponseDTO:
		"""Délègue l'ajustement administrateur de XP."""
		return await self.xp.adjust_xp(user_id, dto)

	async def award_xp(
		self,
		user_id: str,
		amount: int,
		source: str,
		source_id: str | None = None,
	) -> UserXPResponseDTO:
		"""Délègue l'attribution d'XP."""
		return await self.xp.award_xp(user_id, amount, source, source_id)

	# ─── Séries (Streaks) ────────────────────────────────────────────────

	async def get_streak(self, user_id: str) -> StreakResponseDTO:
		"""Délègue la consultation de la série."""
		return await self.streaks.get_streak(user_id)

	async def record_activity(self, user_id: str) -> StreakResponseDTO:
		"""Délègue l'enregistrement d'activité."""
		return await self.streaks.record_activity(user_id)

	async def freeze_streak(
		self,
		user_id: str,
		dto: StreakFreezeDTO,
	) -> StreakResponseDTO:
		"""Délègue le gel de série."""
		return await self.streaks.freeze_streak(user_id, dto)

	# ─── Classements (Leaderboards) ───────────────────────────────────────

	async def create_leaderboard(
		self,
		dto: LeaderboardCreateDTO,
	) -> LeaderboardResponseDTO:
		"""Délègue la création de classement."""
		return await self.leaderboards.create_leaderboard(dto)

	async def get_leaderboard(
		self,
		leaderboard_type: str,
		scope_id: str | None = None,
		period: str | None = None,
	) -> LeaderboardResponseDTO:
		"""Délègue la consultation de classement."""
		return await self.leaderboards.get_leaderboard(leaderboard_type, scope_id, period)

	async def list_leaderboards(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[LeaderboardResponseDTO]:
		"""Délègue le listage des classements."""
		return await self.leaderboards.list_leaderboards(limit, offset)

	async def update_leaderboard_entries(
		self,
		leaderboard_id: str,
		entries: list[LeaderboardEntryDTO],
	) -> LeaderboardResponseDTO:
		"""Délègue la mise à jour des entrées de classement."""
		return await self.leaderboards.update_leaderboard_entries(leaderboard_id, entries)

	# ─── Défis (Challenges) ──────────────────────────────────────────────

	async def create_challenge(
		self,
		dto: ChallengeCreateDTO,
	) -> ChallengeResponseDTO:
		"""Délègue la création de défi."""
		return await self.challenges.create_challenge(dto)

	async def get_challenge(self, challenge_id: str) -> ChallengeResponseDTO:
		"""Délègue la consultation de défi."""
		return await self.challenges.get_challenge(challenge_id)

	async def list_challenges(
		self,
		challenge_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ChallengeResponseDTO]:
		"""Délègue le listage des défis."""
		return await self.challenges.list_challenges(challenge_type, limit, offset)

	async def delete_challenge(self, challenge_id: str) -> bool:
		"""Délègue la suppression de défi."""
		return await self.challenges.delete_challenge(challenge_id)

	# ─── Récompenses (Rewards) ────────────────────────────────────────────

	async def create_reward(
		self,
		dto: RewardCreateDTO,
	) -> RewardResponseDTO:
		"""Délègue la création de récompense."""
		return await self.rewards.create_reward(dto)

	async def get_reward(self, reward_id: str) -> RewardResponseDTO:
		"""Délègue la consultation de récompense."""
		return await self.rewards.get_reward(reward_id)

	async def list_user_rewards(
		self,
		user_id: str,
		claimed: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[RewardResponseDTO]:
		"""Délègue le listage des récompenses utilisateur."""
		return await self.rewards.list_user_rewards(user_id, claimed, limit, offset)

	async def claim_reward(
		self,
		reward_id: str,
		user_id: str,
	) -> RewardResponseDTO:
		"""Délègue la réclamation de récompense."""
		return await self.rewards.claim_reward(reward_id, user_id)
