"""NOKIROVA — Service Gamification : Badges

Logique métier pour les badges de gamification :
- CRUD badges
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	BadgeCreateDTO,
	BadgeResponseDTO,
	BadgeUpdateDTO,
)
from src.services.gamification.repository import BadgeRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_BADGES = "gamification:badges"
EVENT_DOMAIN = "gamification"


# ─── Service Badges ───────────────────────────────────────────────────────────


class GamificationBadgeService:
	"""Service métier pour les badges de gamification."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.badge_repo = BadgeRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_badge(
		self,
		user_id: str,
		dto: BadgeCreateDTO,
	) -> BadgeResponseDTO:
		"""Crée un nouveau badge (réservé aux administrateurs)."""
		data = dto.model_dump(exclude_none=True)
		badge = await self.badge_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_BADGES)

		await event_bus.publish(
			Event(
				event_type="badge_created",
				domain=EVENT_DOMAIN,
				payload={"badge_id": badge.id, "name": badge.name},
			)
		)

		return self._badge_to_response(badge)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_badge(self, badge_id: str) -> BadgeResponseDTO:
		"""Récupère un badge par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_BADGES, badge_id)
		if cached:
			return BadgeResponseDTO(**cached)

		badge = await self.badge_repo.get_by_id(badge_id)
		if badge is None:
			raise NotFoundException("Badge introuvable")

		response = self._badge_to_response(badge)
		await cache_manager.set(CACHE_NS_BADGES, badge_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_badges(
		self,
		category: str | None = None,
		limit: int = 100,
		offset: int = 0,
	) -> list[BadgeResponseDTO]:
		"""Liste les badges, éventuellement filtrés par catégorie."""
		if category:
			badges = await self.badge_repo.list_by_category(category, limit, offset)
		else:
			badges = await self.badge_repo.list_all(limit, offset)
		return [self._badge_to_response(b) for b in badges]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_badge(
		self,
		badge_id: str,
		user_id: str,
		dto: BadgeUpdateDTO,
	) -> BadgeResponseDTO:
		"""Met à jour un badge (réservé aux administrateurs)."""
		badge = await self.badge_repo.get_by_id(badge_id)
		if badge is None:
			raise NotFoundException("Badge introuvable")

		data = dto.model_dump(exclude_none=True)
		updated = await self.badge_repo.update(badge_id, data)

		await cache_manager.delete(CACHE_NS_BADGES, badge_id)

		await event_bus.publish(
			Event(
				event_type="badge_updated",
				domain=EVENT_DOMAIN,
				payload={"badge_id": badge_id},
			)
		)

		return self._badge_to_response(updated)

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_badge(self, badge_id: str, user_id: str) -> bool:
		"""Supprime logiquement un badge."""
		success = await self.badge_repo.soft_delete(badge_id)
		if success:
			await cache_manager.delete(CACHE_NS_BADGES, badge_id)
			await event_bus.publish(
				Event(
					event_type="badge_deleted",
					domain=EVENT_DOMAIN,
					payload={"badge_id": badge_id},
				)
			)
		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _badge_to_response(badge) -> BadgeResponseDTO:
		"""Convertit un modèle GamificationBadge en DTO de réponse."""
		return BadgeResponseDTO(
			id=badge.id,
			name=badge.name,
			description=badge.description,
			icon=badge.icon,
			category=badge.category,
			rarity=badge.rarity,
			xp_reward=badge.xp_reward,
			criteria=badge.criteria,
			is_active=badge.is_active,
			is_secret=badge.is_secret,
			order_index=badge.order_index,
			created_at=badge.created_at,
			updated_at=badge.updated_at,
		)
