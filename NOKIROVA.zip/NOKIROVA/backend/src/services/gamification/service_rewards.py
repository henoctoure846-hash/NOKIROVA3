"""NOKIROVA — Service Gamification : Récompenses (Rewards)

Logique métier pour les récompenses :
- CRUD récompenses
- Réclamation de récompense
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.gamification.dto import (
	RewardCreateDTO,
	RewardResponseDTO,
)
from src.services.gamification.repository import RewardRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_REWARDS = "gamification:rewards"
EVENT_DOMAIN = "gamification"


# ─── Service Récompenses ────────────────────────────────────────────────────


class GamificationRewardService:
	"""Service métier pour les récompenses de gamification."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.reward_repo = RewardRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_reward(
		self,
		dto: RewardCreateDTO,
	) -> RewardResponseDTO:
		"""Crée une nouvelle récompense."""
		data = dto.model_dump(exclude_none=True)
		reward = await self.reward_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_REWARDS)

		await event_bus.publish(
			Event(
				event_type="reward_created",
				domain=EVENT_DOMAIN,
				payload={"reward_id": reward.id, "user_id": dto.user_id},
			)
		)

		return self._reward_to_response(reward)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_reward(self, reward_id: str) -> RewardResponseDTO:
		"""Récupère une récompense par son identifiant."""
		reward = await self.reward_repo.get_by_id(reward_id)
		if reward is None:
			raise NotFoundException("Récompense introuvable")

		return self._reward_to_response(reward)

	async def list_user_rewards(
		self,
		user_id: str,
		claimed: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[RewardResponseDTO]:
		"""Liste les récompenses d'un utilisateur."""
		rewards = await self.reward_repo.get_by_user(user_id, claimed, limit, offset)
		return [self._reward_to_response(r) for r in rewards]

	# ─── Réclamation ─────────────────────────────────────────────────────

	async def claim_reward(
		self,
		reward_id: str,
		user_id: str,
	) -> RewardResponseDTO:
		"""Réclame une récompense."""
		reward = await self.reward_repo.get_by_id(reward_id)
		if reward is None:
			raise NotFoundException("Récompense introuvable")
		if reward.user_id != user_id:
			raise ForbiddenException("Seul le destinataire peut réclamer cette récompense")
		if reward.is_claimed:
			raise ValidationException("reward_id", "Récompense déjà réclamée")

		claimed = await self.reward_repo.claim(reward_id)

		await cache_manager.delete(CACHE_NS_REWARDS, reward_id)

		await event_bus.publish(
			Event(
				event_type="reward_claimed",
				domain=EVENT_DOMAIN,
				payload={"reward_id": reward_id, "user_id": user_id},
			)
		)

		return self._reward_to_response(claimed)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _reward_to_response(reward) -> RewardResponseDTO:
		"""Convertit un modèle GamificationReward en DTO de réponse."""
		return RewardResponseDTO(
			id=reward.id,
			user_id=reward.user_id,
			reward_type=reward.reward_type,
			reward_value=reward.reward_value,
			source=reward.source,
			source_id=reward.source_id,
			claimed_at=reward.claimed_at,
			expires_at=reward.expires_at,
			is_claimed=reward.is_claimed,
			created_at=reward.created_at,
			updated_at=reward.updated_at,
		)
