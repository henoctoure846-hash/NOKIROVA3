"""NOKIROVA — DTOs du service Quiz

Modèles Pydantic pour la validation des requêtes et réponses
du module Quiz : quiz, questions, réponses et tentatives.
Alignés sur les modèles SQLAlchemy réels (quiz.py).

Corrections clés :
- Quiz : created_by (pas author_id), passing_score (Float, pas passing_score_percent)
- QuizQuestion : points (Float), hint, explanation, image_url, sort_order, difficulty, metadata_json
- QuizAnswer : modèle SÉPARÉ (pas embarqué dans QuizQuestion)
- QuizAttempt : attempt_number, status, score/max_score/percentage (Float), passed (bool),
  responses (JSONB), time_spent_seconds
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class QuizTypeEnum(StrEnum):
	"""Types de quiz."""

	practice = "practice"
	assessment = "assessment"
	placement = "placement"
	diagnostic = "diagnostic"
	adaptive = "adaptive"


class DifficultyEnum(StrEnum):
	"""Niveaux de difficulté."""

	beginner = "beginner"
	elementary = "elementary"
	intermediate = "intermediate"
	advanced = "advanced"
	expert = "expert"


class QuestionTypeEnum(StrEnum):
	"""Types de question."""

	multiple_choice = "multiple_choice"
	true_false = "true_false"
	short_answer = "short_answer"
	fill_blank = "fill_blank"
	matching = "matching"
	ordering = "ordering"
	essay = "essay"


class AttemptStatusEnum(StrEnum):
	"""Statuts d'une tentative."""

	not_started = "not_started"
	in_progress = "in_progress"
	completed = "completed"
	abandoned = "abandoned"
	timed_out = "timed_out"


# ─── Quiz ──────────────────────────────────────────────────────────────────────


class QuizCreateDTO(BaseModel):
	"""Création d'un quiz."""

	title: str = Field(..., min_length=1, max_length=255)
	description: str | None = None
	course_id: str | None = None
	module_id: str | None = None
	created_by: str
	quiz_type: QuizTypeEnum = QuizTypeEnum.practice
	difficulty: DifficultyEnum = DifficultyEnum.intermediate
	time_limit_seconds: int | None = Field(None, ge=0)
	max_attempts: int = Field(1, ge=1)
	is_published: bool = False
	is_adaptive: bool = False
	shuffle_questions: bool = False
	shuffle_answers: bool = False
	show_correct_answers: bool = False
	show_explanation: bool = False
	passing_score: float | None = Field(None, ge=0.0, le=100.0)
	total_points: float = Field(0.0, ge=0.0)
	tags: list[str] | None = None
	metadata_json: dict | None = None


class QuizUpdateDTO(BaseModel):
	"""Mise à jour d'un quiz."""

	title: str | None = Field(None, min_length=1, max_length=255)
	description: str | None = None
	course_id: str | None = None
	module_id: str | None = None
	quiz_type: QuizTypeEnum | None = None
	difficulty: DifficultyEnum | None = None
	time_limit_seconds: int | None = Field(None, ge=0)
	max_attempts: int | None = Field(None, ge=1)
	is_published: bool | None = None
	is_adaptive: bool | None = None
	shuffle_questions: bool | None = None
	shuffle_answers: bool | None = None
	show_correct_answers: bool | None = None
	show_explanation: bool | None = None
	passing_score: float | None = Field(None, ge=0.0, le=100.0)
	total_points: float | None = Field(None, ge=0.0)
	tags: list[str] | None = None
	metadata_json: dict | None = None


class QuizResponseDTO(BaseModel):
	"""Réponse quiz."""

	id: str
	title: str
	description: str | None = None
	course_id: str | None = None
	module_id: str | None = None
	created_by: str
	quiz_type: str = "practice"
	difficulty: str = "intermediate"
	time_limit_seconds: int | None = None
	max_attempts: int = 1
	is_published: bool = False
	is_adaptive: bool = False
	shuffle_questions: bool = False
	shuffle_answers: bool = False
	show_correct_answers: bool = False
	show_explanation: bool = False
	passing_score: float | None = None
	total_points: float = 0.0
	question_count: int = 0
	tags: list[str] | None = None
	metadata_json: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Questions ─────────────────────────────────────────────────────────────────


class QuestionCreateDTO(BaseModel):
	"""Création d'une question."""

	quiz_id: str
	question_text: str = Field(..., min_length=1)
	question_type: QuestionTypeEnum = QuestionTypeEnum.multiple_choice
	points: float = Field(1.0, ge=0.0)
	hint: str | None = None
	explanation: str | None = None
	image_url: str | None = None
	sort_order: int = Field(0, ge=0)
	difficulty: DifficultyEnum | None = None
	metadata_json: dict | None = None


class QuestionUpdateDTO(BaseModel):
	"""Mise à jour d'une question."""

	question_text: str | None = Field(None, min_length=1)
	question_type: QuestionTypeEnum | None = None
	points: float | None = Field(None, ge=0.0)
	hint: str | None = None
	explanation: str | None = None
	image_url: str | None = None
	sort_order: int | None = Field(None, ge=0)
	difficulty: DifficultyEnum | None = None
	metadata_json: dict | None = None


class QuestionResponseDTO(BaseModel):
	"""Réponse question."""

	id: str
	quiz_id: str
	question_text: str
	question_type: str = "multiple_choice"
	points: float = 1.0
	hint: str | None = None
	explanation: str | None = None
	image_url: str | None = None
	sort_order: int = 0
	difficulty: str | None = None
	metadata_json: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Réponses (Answer) ─────────────────────────────────────────────────────────


class AnswerCreateDTO(BaseModel):
	"""Création d'une réponse."""

	question_id: str
	answer_text: str = Field(..., min_length=1)
	is_correct: bool = False
	sort_order: int = Field(0, ge=0)
	explanation: str | None = None
	feedback: str | None = None


class AnswerUpdateDTO(BaseModel):
	"""Mise à jour d'une réponse."""

	answer_text: str | None = Field(None, min_length=1)
	is_correct: bool | None = None
	sort_order: int | None = Field(None, ge=0)
	explanation: str | None = None
	feedback: str | None = None


class AnswerResponseDTO(BaseModel):
	"""Réponse réponse."""

	id: str
	question_id: str
	answer_text: str
	is_correct: bool = False
	sort_order: int = 0
	explanation: str | None = None
	feedback: str | None = None
	created_at: datetime
	updated_at: datetime


# ─── Tentatives (Attempts) ─────────────────────────────────────────────────────


class AttemptCreateDTO(BaseModel):
	"""Démarrage d'une tentative."""

	quiz_id: str
	user_id: str


class AttemptSubmitDTO(BaseModel):
	"""Soumission d'une tentative."""

	responses: dict = Field(..., description="Réponses de l'utilisateur par question_id")
	time_spent_seconds: int | None = Field(None, ge=0)


class AttemptResponseDTO(BaseModel):
	"""Réponse tentative."""

	id: str
	quiz_id: str
	user_id: str
	attempt_number: int = 1
	status: str = "not_started"
	score: float = 0.0
	max_score: float = 0.0
	percentage: float = 0.0
	passed: bool = False
	responses: dict | None = None
	started_at: str | None = None
	completed_at: str | None = None
	time_spent_seconds: int | None = None
	created_at: datetime
	updated_at: datetime


class AttemptDetailDTO(AttemptResponseDTO):
	"""Réponse tentative avec détails (questions et réponses correctes)."""

	questions: list[QuestionResponseDTO] | None = None
	correct_answers: dict | None = None
