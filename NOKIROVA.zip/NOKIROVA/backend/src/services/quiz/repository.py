"""NOKIROVA — Depot Quiz

Acces aux donnees pour les quiz, questions, reponses et tentatives.
Utilise les modeles SQLAlchemy reels de quiz.py.

Refactorisation :
    Quiz — Categorie (c) : soft_delete personnalise (is_published=False -> bool)
    Question, Answer — Categorie (d) : suppression dure
    Attempt — Categorie (e) : pas de soft_delete
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.quiz import (
	Quiz,
	QuizAnswer,
	QuizAttempt,
	QuizQuestion,
)

# ─── Quiz — Categorie (c) : soft_delete personnalise ──────────────────────────


class QuizRepository(BaseRepository[Quiz]):
	"""Depot pour les quiz.

	Herite de BaseRepository[Quiz] pour create/get/update.
	soft_delete surcharge : utilise is_published=False (pas is_active).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(Quiz, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, quiz_id: str) -> bool:
		"""Suppression logique d'un quiz (is_published=False).

		Note : Contrairement a BaseRepository.soft_delete qui met
		is_active=False, ici on depublie le quiz (is_published=False).
		"""
		quiz = await self.get_by_id(quiz_id)
		if quiz is None:
			return False
		quiz.is_published = False
		await self.session.flush()
		return True

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_published(
		self,
		course_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Quiz]:
		"""Liste les quiz publies, eventuellement filtres par cours."""
		conditions = [Quiz.is_published == True]  # noqa: E712
		if course_id is not None:
			conditions.append(Quiz.course_id == course_id)

		stmt = (
			select(Quiz)
			.where(and_(*conditions))
			.order_by(Quiz.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def list_by_creator(
		self,
		created_by: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Quiz]:
		"""Liste les quiz crees par un utilisateur."""
		stmt = (
			select(Quiz)
			.where(Quiz.created_by == created_by)
			.order_by(Quiz.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Questions — Categorie (d) : suppression dure ─────────────────────────────


class QuestionRepository(BaseRepository[QuizQuestion]):
	"""Depot pour les questions de quiz.

	Herite de BaseRepository[QuizQuestion] pour create/get/update.
	Utilise une suppression dure — ne pas utiliser soft_delete/restore.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(QuizQuestion, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_quiz(
		self,
		quiz_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[QuizQuestion]:
		"""Liste les questions d'un quiz."""
		stmt = (
			select(QuizQuestion)
			.where(QuizQuestion.quiz_id == quiz_id)
			.order_by(QuizQuestion.sort_order.asc(), QuizQuestion.created_at.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count_by_quiz(self, quiz_id: str) -> int:
		"""Compte le nombre de questions dans un quiz."""
		stmt = select(func.count(QuizQuestion.id)).where(QuizQuestion.quiz_id == quiz_id)
		result = await self.session.execute(stmt)
		return result.scalar_one()

	async def delete(self, question_id: str) -> bool:
		"""Supprime une question (suppression dure)."""
		question = await self.get_by_id(question_id)
		if question is None:
			return False
		await self.session.delete(question)
		await self.session.flush()
		return True


# ─── Reponses (Answers) — Categorie (d) : suppression dure ────────────────────


class AnswerRepository(BaseRepository[QuizAnswer]):
	"""Depot pour les reponses de quiz.

	Herite de BaseRepository[QuizAnswer] para create/get/update.
	Utilise une suppression dure — ne pas utiliser soft_delete/restore.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(QuizAnswer, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_question(
		self,
		question_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[QuizAnswer]:
		"""Liste les reponses d'une question."""
		stmt = (
			select(QuizAnswer)
			.where(QuizAnswer.question_id == question_id)
			.order_by(QuizAnswer.sort_order.asc(), QuizAnswer.created_at.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_correct_answers(self, question_id: str) -> Sequence[QuizAnswer]:
		"""Recupere les reponses correctes d'une question."""
		stmt = select(QuizAnswer).where(
			and_(
				QuizAnswer.question_id == question_id,
				QuizAnswer.is_correct == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def delete(self, answer_id: str) -> bool:
		"""Supprime une reponse (suppression dure)."""
		answer = await self.get_by_id(answer_id)
		if answer is None:
			return False
		await self.session.delete(answer)
		await self.session.flush()
		return True


# ─── Tentatives (Attempts) — Categorie (e) ────────────────────────────────────


class AttemptRepository(BaseRepository[QuizAttempt]):
	"""Depot pour les tentatives de quiz.

	Herite de BaseRepository[QuizAttempt] pour create/get/update.
	Pas de soft_delete — les tentatives sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(QuizAttempt, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user_and_quiz(
		self,
		user_id: str,
		quiz_id: str,
		limit: int = 10,
		offset: int = 0,
	) -> Sequence[QuizAttempt]:
		"""Recupere les tentatives d'un utilisateur pour un quiz."""
		stmt = (
			select(QuizAttempt)
			.where(
				and_(
					QuizAttempt.user_id == user_id,
					QuizAttempt.quiz_id == quiz_id,
				)
			)
			.order_by(QuizAttempt.attempt_number.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_latest_attempt(
		self,
		user_id: str,
		quiz_id: str,
	) -> QuizAttempt | None:
		"""Recupere la tentative la plus recente d'un utilisateur."""
		stmt = (
			select(QuizAttempt)
			.where(
				and_(
					QuizAttempt.user_id == user_id,
					QuizAttempt.quiz_id == quiz_id,
				)
			)
			.order_by(QuizAttempt.attempt_number.desc())
			.limit(1)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def count_by_user_and_quiz(
		self,
		user_id: str,
		quiz_id: str,
	) -> int:
		"""Compte les tentatives d'un utilisateur pour un quiz."""
		stmt = select(func.count(QuizAttempt.id)).where(
			and_(
				QuizAttempt.user_id == user_id,
				QuizAttempt.quiz_id == quiz_id,
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one()

	async def count_by_quiz(self, quiz_id: str) -> int:
		"""Compte le nombre total de tentatives pour un quiz."""
		stmt = select(func.count(QuizAttempt.id)).where(QuizAttempt.quiz_id == quiz_id)
		result = await self.session.execute(stmt)
		return result.scalar_one()

	async def average_score_by_quiz(self, quiz_id: str) -> float:
		"""Calcule la moyenne des scores pour un quiz."""
		stmt = select(func.avg(QuizAttempt.percentage)).where(
			and_(
				QuizAttempt.quiz_id == quiz_id,
				QuizAttempt.status == "completed",
			)
		)
		result = await self.session.execute(stmt)
		val = result.scalar_one_or_none()
		return float(val) if val is not None else 0.0

	async def pass_rate_by_quiz(self, quiz_id: str) -> float:
		"""Calcule le taux de reussite pour un quiz."""
		total = await self.count_by_quiz(quiz_id)
		if total == 0:
			return 0.0
		stmt = select(func.count(QuizAttempt.id)).where(
			and_(
				QuizAttempt.quiz_id == quiz_id,
				QuizAttempt.passed == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		passed = result.scalar_one()
		return (passed / total) * 100.0
