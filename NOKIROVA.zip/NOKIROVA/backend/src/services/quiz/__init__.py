"""NOKIROVA — Service Quiz

Exports :
- QuizQuizService    : CRUD quiz
- QuizQuestionService : questions + réponses
- QuizAttemptService  : tentatives + statistiques
- QuizService         : façade délégatrice
- Repositories        : Quiz, Question, Answer, Attempt
"""

from .repository import (
	AnswerRepository,
	AttemptRepository,
	QuestionRepository,
	QuizRepository,
)
from .service import QuizService
from .service_attempts import QuizAttemptService
from .service_questions import QuizQuestionService
from .service_quizzes import QuizQuizService

__all__ = [
	"QuizService",
	"QuizQuizService",
	"QuizQuestionService",
	"QuizAttemptService",
	"QuizRepository",
	"QuestionRepository",
	"AnswerRepository",
	"AttemptRepository",
]
