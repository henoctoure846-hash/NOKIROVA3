"""NOKIROVA — Service Quiz : Façade

Façade qui délègue aux 3 sous-services :
- QuizQuizService   : CRUD quiz
- QuizQuestionService : questions + réponses
- QuizAttemptService  : tentatives + statistiques

Conforme au Principe 5 (Séparation des préoccupations) et
au Principe 3 (Cohésion modulaire) de la BIBLE.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.quiz.dto import (
	AnswerCreateDTO,
	AnswerResponseDTO,
	AnswerUpdateDTO,
	AttemptResponseDTO,
	QuestionCreateDTO,
	QuestionResponseDTO,
	QuestionUpdateDTO,
	QuizCreateDTO,
	QuizResponseDTO,
	QuizUpdateDTO,
	SubmitAttemptDTO,
)
from src.services.quiz.repository import (
	AnswerRepository,
	AttemptRepository,
	QuestionRepository,
	QuizRepository,
)
from src.services.quiz.service_attempts import QuizAttemptService
from src.services.quiz.service_questions import QuizQuestionService
from src.services.quiz.service_quizzes import QuizQuizService

# ─── Façade QuizService ─────────────────────────────────────────────────────


class QuizService:
	"""Façade pour le service Quiz — délègue aux sous-services."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		# Repositories exposés pour les routes et les tests
		self.quiz_repo = QuizRepository(session)
		self.question_repo = QuestionRepository(session)
		self.answer_repo = AnswerRepository(session)
		self.attempt_repo = AttemptRepository(session)

		# Sous-services
		self._quizzes = QuizQuizService(session)
		self._questions = QuizQuestionService(session)
		self._attempts = QuizAttemptService(session)

	# ─── Quiz CRUD ─────────────────────────────────────────────────────

	async def create_quiz(self, dto: QuizCreateDTO) -> QuizResponseDTO:
		"""Crée un nouveau quiz."""
		return await self._quizzes.create_quiz(dto)

	async def get_quiz(self, quiz_id: str) -> QuizResponseDTO:
		"""Récupère un quiz par son identifiant."""
		return await self._quizzes.get_quiz(quiz_id)

	async def list_quizzes(
		self,
		course_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[QuizResponseDTO]:
		"""Liste les quiz publiés."""
		return await self._quizzes.list_quizzes(course_id, limit, offset)

	async def list_my_quizzes(
		self,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[QuizResponseDTO]:
		"""Liste les quiz créés par l'utilisateur."""
		return await self._quizzes.list_my_quizzes(user_id, limit, offset)

	async def update_quiz(
		self,
		quiz_id: str,
		user_id: str,
		dto: QuizUpdateDTO,
	) -> QuizResponseDTO:
		"""Met à jour un quiz."""
		return await self._quizzes.update_quiz(quiz_id, user_id, dto)

	async def delete_quiz(self, quiz_id: str, user_id: str) -> bool:
		"""Supprime logiquement un quiz."""
		return await self._quizzes.delete_quiz(quiz_id, user_id)

	# ─── Questions CRUD ────────────────────────────────────────────────

	async def add_question(
		self,
		quiz_id: str,
		user_id: str,
		dto: QuestionCreateDTO,
	) -> QuestionResponseDTO:
		"""Ajoute une question à un quiz."""
		return await self._questions.add_question(quiz_id, user_id, dto)

	async def get_question(self, question_id: str) -> QuestionResponseDTO:
		"""Récupère une question par son identifiant."""
		return await self._questions.get_question(question_id)

	async def list_questions(
		self,
		quiz_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[QuestionResponseDTO]:
		"""Liste les questions d'un quiz."""
		return await self._questions.list_questions(quiz_id, limit, offset)

	async def update_question(
		self,
		question_id: str,
		user_id: str,
		dto: QuestionUpdateDTO,
	) -> QuestionResponseDTO:
		"""Met à jour une question."""
		return await self._questions.update_question(question_id, user_id, dto)

	async def delete_question(
		self,
		question_id: str,
		user_id: str,
	) -> bool:
		"""Supprime une question."""
		return await self._questions.delete_question(question_id, user_id)

	# ─── Réponses CRUD ─────────────────────────────────────────────────

	async def add_answer(
		self,
		question_id: str,
		user_id: str,
		dto: AnswerCreateDTO,
	) -> AnswerResponseDTO:
		"""Ajoute une réponse à une question."""
		return await self._questions.add_answer(question_id, user_id, dto)

	async def list_answers(
		self,
		question_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[AnswerResponseDTO]:
		"""Liste les réponses d'une question."""
		return await self._questions.list_answers(question_id, limit, offset)

	async def update_answer(
		self,
		answer_id: str,
		user_id: str,
		dto: AnswerUpdateDTO,
	) -> AnswerResponseDTO:
		"""Met à jour une réponse."""
		return await self._questions.update_answer(answer_id, user_id, dto)

	async def delete_answer(
		self,
		answer_id: str,
		user_id: str,
	) -> bool:
		"""Supprime une réponse."""
		return await self._questions.delete_answer(answer_id, user_id)

	# ─── Tentatives ────────────────────────────────────────────────────

	async def start_attempt(
		self,
		quiz_id: str,
		user_id: str,
	) -> AttemptResponseDTO:
		"""Démarre une nouvelle tentative pour un quiz."""
		return await self._attempts.start_attempt(quiz_id, user_id)

	async def submit_attempt(
		self,
		attempt_id: str,
		user_id: str,
		dto: SubmitAttemptDTO,
	) -> AttemptResponseDTO:
		"""Soumet une tentative et calcule le score."""
		return await self._attempts.submit_attempt(attempt_id, user_id, dto)

	async def get_attempt(
		self,
		attempt_id: str,
		user_id: str,
	) -> AttemptResponseDTO:
		"""Récupère une tentative par son identifiant."""
		return await self._attempts.get_attempt(attempt_id, user_id)

	async def get_user_attempts(
		self,
		user_id: str,
		quiz_id: str,
		limit: int = 10,
		offset: int = 0,
	) -> list[AttemptResponseDTO]:
		"""Récupère les tentatives d'un utilisateur pour un quiz."""
		return await self._attempts.get_user_attempts(user_id, quiz_id, limit, offset)

	async def list_user_attempts(
		self,
		user_id: str,
		quiz_id: str,
		limit: int = 10,
		offset: int = 0,
	) -> list[AttemptResponseDTO]:
		"""Alias pour get_user_attempts."""
		return await self._attempts.list_user_attempts(user_id, quiz_id, limit, offset)

	async def get_quiz_stats(self, quiz_id: str) -> dict:
		"""Récupère les statistiques d'un quiz."""
		return await self._attempts.get_quiz_stats(quiz_id)
