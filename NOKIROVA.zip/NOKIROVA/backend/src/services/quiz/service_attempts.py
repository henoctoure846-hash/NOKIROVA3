"""NOKIROVA — Service Quiz : Tentatives

Logique métier pour les tentatives de quiz :
- Démarrer une tentative
- Soumettre une tentative (calcul du score)
- Récupérer les tentatives
- Statistiques

Dépendances cross-domain :
- QuizRepository : validation d'existence / configuration du quiz
- QuestionRepository : questions pour le calcul du score
- AnswerRepository : bonnes réponses pour le calcul du score
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.quiz.dto import (
	AttemptResponseDTO,
	SubmitAttemptDTO,
)
from src.services.quiz.repository import (
	AnswerRepository,
	AttemptRepository,
	QuestionRepository,
	QuizRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_ATTEMPTS = "quiz:attempts"
CACHE_NS_QUIZ = "quiz:quizzes"
EVENT_DOMAIN = "quiz"


# ─── Service Tentatives ─────────────────────────────────────────────────────


class QuizAttemptService:
	"""Service métier pour les tentatives de quiz."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.attempt_repo = AttemptRepository(session)
		# Dépendances cross-domain : même session → mêmes repos
		self.quiz_repo = QuizRepository(session)
		self.question_repo = QuestionRepository(session)
		self.answer_repo = AnswerRepository(session)

	# ─── Démarrer une tentative ──────────────────────────────────────────

	async def start_attempt(
		self,
		quiz_id: str,
		user_id: str,
	) -> AttemptResponseDTO:
		"""Démarre une nouvelle tentative pour un quiz."""
		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")
		if not quiz.is_published:
			raise NotFoundException("Quiz non publié")

		# Vérifier la limite de tentatives
		attempt_count = await self.attempt_repo.count_by_user_and_quiz(user_id, quiz_id)
		if quiz.max_attempts > 0 and attempt_count >= quiz.max_attempts:
			raise NotFoundException("Nombre maximum de tentatives atteint")

		attempt = await self.attempt_repo.create(
			{
				"quiz_id": quiz_id,
				"user_id": user_id,
				"attempt_number": attempt_count + 1,
				"status": "in_progress",
				"max_score": quiz.total_points,
				"responses": {},
			}
		)

		await cache_manager.invalidate_namespace(CACHE_NS_ATTEMPTS)

		await event_bus.publish(
			Event(
				event_type="attempt_started",
				domain=EVENT_DOMAIN,
				payload={"quiz_id": quiz_id, "user_id": user_id, "attempt_id": attempt.id},
			)
		)

		return self._attempt_to_response(attempt)

	# ─── Soumettre une tentative ────────────────────────────────────────

	async def submit_attempt(
		self,
		attempt_id: str,
		user_id: str,
		dto: SubmitAttemptDTO,
	) -> AttemptResponseDTO:
		"""Soumet une tentative et calcule le score."""
		attempt = await self.attempt_repo.get_by_id(attempt_id)
		if attempt is None:
			raise NotFoundException("Tentative introuvable")
		if attempt.user_id != user_id:
			raise NotFoundException("Tentative non autorisée")
		if attempt.status != "in_progress":
			raise NotFoundException("Tentative déjà soumise")

		quiz = await self.quiz_repo.get_by_id(attempt.quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")

		# Récupérer les questions et les bonnes réponses pour le calcul
		questions = await self.question_repo.list_by_quiz(quiz.id)
		correct_answers: dict[str, list[str]] = {}
		for q in questions:
			answers = await self.answer_repo.list_by_question(q.id)
			correct_answers[q.id] = [a.id for a in answers if a.is_correct]

		# Calculer le score
		score = 0.0
		for q in questions:
			user_answer_ids = dto.responses.get(q.id, [])
			correct_ids = correct_answers.get(q.id, [])
			if set(user_answer_ids) == set(correct_ids):
				score += q.points

		percentage = (score / quiz.total_points * 100) if quiz.total_points > 0 else 0.0
		passed = percentage >= quiz.passing_score

		# Mettre à jour la tentative
		updated = await self.attempt_repo.update(
			attempt_id,
			{
				"status": "completed",
				"score": score,
				"percentage": percentage,
				"passed": passed,
				"responses": dto.responses,
			},
		)

		await cache_manager.delete(CACHE_NS_ATTEMPTS, attempt_id)
		await cache_manager.delete(CACHE_NS_QUIZ, quiz.id)

		await event_bus.publish(
			Event(
				event_type="attempt_submitted",
				domain=EVENT_DOMAIN,
				payload={
					"quiz_id": quiz.id,
					"user_id": user_id,
					"attempt_id": attempt_id,
					"score": score,
					"percentage": percentage,
					"passed": passed,
				},
			)
		)

		return self._attempt_to_response(updated)

	# ─── Lecture des tentatives ─────────────────────────────────────────

	async def get_attempt(
		self,
		attempt_id: str,
		user_id: str,
	) -> AttemptResponseDTO:
		"""Récupère une tentative par son identifiant."""
		attempt = await self.attempt_repo.get_by_id(attempt_id)
		if attempt is None:
			raise NotFoundException("Tentative introuvable")
		if attempt.user_id != user_id:
			raise NotFoundException("Tentative non autorisée")

		return self._attempt_to_response(attempt)

	async def get_user_attempts(
		self,
		user_id: str,
		quiz_id: str,
		limit: int = 10,
		offset: int = 0,
	) -> list[AttemptResponseDTO]:
		"""Récupère les tentatives d'un utilisateur pour un quiz."""
		attempts = await self.attempt_repo.get_by_user_and_quiz(user_id, quiz_id, limit, offset)
		return [self._attempt_to_response(a) for a in attempts]

	# Alias conforme à la BIBLE
	async def list_user_attempts(
		self,
		user_id: str,
		quiz_id: str,
		limit: int = 10,
		offset: int = 0,
	) -> list[AttemptResponseDTO]:
		"""Alias pour get_user_attempts — liste les tentatives d'un utilisateur."""
		return await self.get_user_attempts(user_id, quiz_id, limit, offset)

	# ─── Statistiques ───────────────────────────────────────────────────

	async def get_quiz_stats(
		self,
		quiz_id: str,
	) -> dict:
		"""Récupère les statistiques d'un quiz."""
		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")

		total_attempts = await self.attempt_repo.count_by_quiz(quiz_id)
		avg_score = await self.attempt_repo.average_score_by_quiz(quiz_id)
		pass_rate = await self.attempt_repo.pass_rate_by_quiz(quiz_id)

		return {
			"quiz_id": quiz_id,
			"title": quiz.title,
			"total_attempts": total_attempts,
			"average_score": avg_score,
			"pass_rate": pass_rate,
			"total_points": quiz.total_points,
			"passing_score": quiz.passing_score,
			"question_count": quiz.question_count,
		}

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _attempt_to_response(attempt) -> AttemptResponseDTO:
		"""Convertit un modèle QuizAttempt en DTO de réponse."""
		return AttemptResponseDTO(
			id=attempt.id,
			quiz_id=attempt.quiz_id,
			user_id=attempt.user_id,
			attempt_number=attempt.attempt_number,
			status=attempt.status,
			score=attempt.score,
			max_score=attempt.max_score,
			percentage=attempt.percentage,
			passed=attempt.passed,
			responses=attempt.responses,
			started_at=attempt.started_at,
			completed_at=attempt.completed_at,
			time_spent_seconds=attempt.time_spent_seconds,
			created_at=attempt.created_at,
			updated_at=attempt.updated_at,
		)
