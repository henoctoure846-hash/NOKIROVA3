"""NOKIROVA — Service Quiz : Quiz

Logique métier pour les quiz :
- CRUD quiz
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException
from src.events.bus import Event, event_bus
from src.services.quiz.dto import (
	QuizCreateDTO,
	QuizResponseDTO,
	QuizUpdateDTO,
)
from src.services.quiz.repository import QuizRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_QUIZ = "quiz:quizzes"
EVENT_DOMAIN = "quiz"


# ─── Service Quiz ────────────────────────────────────────────────────────────


class QuizQuizService:
	"""Service métier pour les quiz."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.quiz_repo = QuizRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_quiz(
		self,
		dto: QuizCreateDTO,
	) -> QuizResponseDTO:
		"""Crée un nouveau quiz."""
		data = dto.model_dump(exclude_none=True)
		quiz = await self.quiz_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_QUIZ)

		await event_bus.publish(
			Event(
				event_type="quiz_created",
				domain=EVENT_DOMAIN,
				payload={"quiz_id": quiz.id, "title": quiz.title, "created_by": quiz.created_by},
			)
		)

		return self._quiz_to_response(quiz)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_quiz(self, quiz_id: str) -> QuizResponseDTO:
		"""Récupère un quiz par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_QUIZ, quiz_id)
		if cached:
			return QuizResponseDTO(**cached)

		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")

		response = self._quiz_to_response(quiz)
		await cache_manager.set(CACHE_NS_QUIZ, quiz_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_quizzes(
		self,
		course_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[QuizResponseDTO]:
		"""Liste les quiz publiés."""
		quizzes = await self.quiz_repo.list_published(course_id, limit, offset)
		return [self._quiz_to_response(q) for q in quizzes]

	async def list_my_quizzes(
		self,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[QuizResponseDTO]:
		"""Liste les quiz créés par l'utilisateur."""
		quizzes = await self.quiz_repo.list_by_creator(user_id, limit, offset)
		return [self._quiz_to_response(q) for q in quizzes]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_quiz(
		self,
		quiz_id: str,
		user_id: str,
		dto: QuizUpdateDTO,
	) -> QuizResponseDTO:
		"""Met à jour un quiz."""
		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")
		if quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur peut modifier ce quiz")

		data = dto.model_dump(exclude_none=True)
		updated = await self.quiz_repo.update(quiz_id, data)

		await cache_manager.delete(CACHE_NS_QUIZ, quiz_id)

		await event_bus.publish(
			Event(
				event_type="quiz_updated",
				domain=EVENT_DOMAIN,
				payload={"quiz_id": quiz_id},
			)
		)

		return self._quiz_to_response(updated)

	# ─── Suppression ──────────────────────────────────────────────────────

	async def delete_quiz(self, quiz_id: str, user_id: str) -> bool:
		"""Supprime logiquement un quiz."""
		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")
		if quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur peut supprimer ce quiz")

		success = await self.quiz_repo.soft_delete(quiz_id)
		if success:
			await cache_manager.delete(CACHE_NS_QUIZ, quiz_id)
			await event_bus.publish(
				Event(
					event_type="quiz_deleted",
					domain=EVENT_DOMAIN,
					payload={"quiz_id": quiz_id},
				)
			)
		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _quiz_to_response(quiz) -> QuizResponseDTO:
		"""Convertit un modèle Quiz en DTO de réponse."""
		return QuizResponseDTO(
			id=quiz.id,
			title=quiz.title,
			description=quiz.description,
			course_id=quiz.course_id,
			module_id=quiz.module_id,
			created_by=quiz.created_by,
			quiz_type=quiz.quiz_type,
			difficulty=quiz.difficulty,
			time_limit_seconds=quiz.time_limit_seconds,
			max_attempts=quiz.max_attempts,
			is_published=quiz.is_published,
			is_adaptive=quiz.is_adaptive,
			shuffle_questions=quiz.shuffle_questions,
			shuffle_answers=quiz.shuffle_answers,
			show_correct_answers=quiz.show_correct_answers,
			show_explanation=quiz.show_explanation,
			passing_score=quiz.passing_score,
			total_points=quiz.total_points,
			question_count=quiz.question_count,
			tags=quiz.tags,
			metadata_json=quiz.metadata_json,
			created_at=quiz.created_at,
			updated_at=quiz.updated_at,
		)
