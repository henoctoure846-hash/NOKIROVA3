"""NOKIROVA — Service Quiz : Questions et Réponses

Logique métier pour les questions et réponses de quiz :
- CRUD questions
- CRUD réponses
- Mise à jour des compteurs du quiz parent
- Cache et événements

Dépendances cross-domain :
- QuizRepository : validation d'existence / autorisation + mise à jour compteurs
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException
from src.events.bus import Event, event_bus
from src.services.quiz.dto import (
	AnswerCreateDTO,
	AnswerResponseDTO,
	AnswerUpdateDTO,
	QuestionCreateDTO,
	QuestionResponseDTO,
	QuestionUpdateDTO,
)
from src.services.quiz.repository import (
	AnswerRepository,
	QuestionRepository,
	QuizRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_QUESTIONS = "quiz:questions"
CACHE_NS_ANSWERS = "quiz:answers"
CACHE_NS_QUIZ = "quiz:quizzes"
EVENT_DOMAIN = "quiz"


# ─── Service Questions et Réponses ───────────────────────────────────────────


class QuizQuestionService:
	"""Service métier pour les questions et réponses de quiz."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.question_repo = QuestionRepository(session)
		self.answer_repo = AnswerRepository(session)
		# Dépendance cross-domain : injectée par la façade ou autocréée
		self.quiz_repo = QuizRepository(session)

	# ─── Questions : Création ──────────────────────────────────────────────

	async def add_question(
		self,
		quiz_id: str,
		user_id: str,
		dto: QuestionCreateDTO,
	) -> QuestionResponseDTO:
		"""Ajoute une question à un quiz."""
		quiz = await self.quiz_repo.get_by_id(quiz_id)
		if quiz is None:
			raise NotFoundException("Quiz introuvable")
		if quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur peut ajouter des questions")

		data = dto.model_dump(exclude_none=True)
		data["quiz_id"] = quiz_id
		question = await self.question_repo.create(data)

		# Mettre à jour le compteur de questions et le total des points
		question_count = await self.question_repo.count_by_quiz(quiz_id)
		await self.quiz_repo.update(
			quiz_id,
			{
				"question_count": question_count,
				"total_points": quiz.total_points + question.points,
			},
		)

		await cache_manager.invalidate_namespace(CACHE_NS_QUESTIONS)
		await cache_manager.delete(CACHE_NS_QUIZ, quiz_id)

		await event_bus.publish(
			Event(
				event_type="question_added",
				domain=EVENT_DOMAIN,
				payload={"quiz_id": quiz_id, "question_id": question.id},
			)
		)

		return self._question_to_response(question)

	# ─── Questions : Lecture ───────────────────────────────────────────────

	async def get_question(self, question_id: str) -> QuestionResponseDTO:
		"""Récupère une question par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_QUESTIONS, question_id)
		if cached:
			return QuestionResponseDTO(**cached)

		question = await self.question_repo.get_by_id(question_id)
		if question is None:
			raise NotFoundException("Question introuvable")

		response = self._question_to_response(question)
		await cache_manager.set(CACHE_NS_QUESTIONS, question_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_questions(
		self,
		quiz_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[QuestionResponseDTO]:
		"""Liste les questions d'un quiz."""
		questions = await self.question_repo.list_by_quiz(quiz_id, limit, offset)
		return [self._question_to_response(q) for q in questions]

	# ─── Questions : Mise à jour ───────────────────────────────────────────

	async def update_question(
		self,
		question_id: str,
		user_id: str,
		dto: QuestionUpdateDTO,
	) -> QuestionResponseDTO:
		"""Met à jour une question."""
		question = await self.question_repo.get_by_id(question_id)
		if question is None:
			raise NotFoundException("Question introuvable")

		# Vérifier que l'utilisateur est le créateur du quiz
		quiz = await self.quiz_repo.get_by_id(question.quiz_id)
		if quiz is None or quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur du quiz peut modifier les questions")

		data = dto.model_dump(exclude_none=True)
		updated = await self.question_repo.update(question_id, data)

		await cache_manager.delete(CACHE_NS_QUESTIONS, question_id)

		return self._question_to_response(updated)

	# ─── Questions : Suppression ────────────────────────────────────────────

	async def delete_question(
		self,
		question_id: str,
		user_id: str,
	) -> bool:
		"""Supprime une question."""
		question = await self.question_repo.get_by_id(question_id)
		if question is None:
			raise NotFoundException("Question introuvable")

		quiz = await self.quiz_repo.get_by_id(question.quiz_id)
		if quiz is None or quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur du quiz peut supprimer les questions")

		# Mettre à jour le compteur et le total des points
		new_total_points = quiz.total_points - question.points
		success = await self.question_repo.delete(question_id)
		if success:
			question_count = await self.question_repo.count_by_quiz(quiz.id)
			await self.quiz_repo.update(
				quiz.id,
				{
					"question_count": question_count,
					"total_points": max(0.0, new_total_points),
				},
			)
			await cache_manager.delete(CACHE_NS_QUESTIONS, question_id)
			await cache_manager.delete(CACHE_NS_QUIZ, quiz.id)

		return success

	# ─── Réponses : Création ────────────────────────────────────────────────

	async def add_answer(
		self,
		question_id: str,
		user_id: str,
		dto: AnswerCreateDTO,
	) -> AnswerResponseDTO:
		"""Ajoute une réponse à une question."""
		question = await self.question_repo.get_by_id(question_id)
		if question is None:
			raise NotFoundException("Question introuvable")

		# Vérifier que l'utilisateur est le créateur du quiz
		quiz = await self.quiz_repo.get_by_id(question.quiz_id)
		if quiz is None or quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur du quiz peut ajouter des réponses")

		data = dto.model_dump(exclude_none=True)
		data["question_id"] = question_id
		answer = await self.answer_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_ANSWERS)

		return self._answer_to_response(answer)

	# ─── Réponses : Lecture ────────────────────────────────────────────────

	async def list_answers(
		self,
		question_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[AnswerResponseDTO]:
		"""Liste les réponses d'une question."""
		answers = await self.answer_repo.list_by_question(question_id, limit, offset)
		return [self._answer_to_response(a) for a in answers]

	# ─── Réponses : Mise à jour ────────────────────────────────────────────

	async def update_answer(
		self,
		answer_id: str,
		user_id: str,
		dto: AnswerUpdateDTO,
	) -> AnswerResponseDTO:
		"""Met à jour une réponse."""
		answer = await self.answer_repo.get_by_id(answer_id)
		if answer is None:
			raise NotFoundException("Réponse introuvable")

		question = await self.question_repo.get_by_id(answer.question_id)
		quiz = await self.quiz_repo.get_by_id(question.quiz_id) if question else None
		if quiz is None or quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur du quiz peut modifier les réponses")

		data = dto.model_dump(exclude_none=True)
		updated = await self.answer_repo.update(answer_id, data)

		await cache_manager.delete(CACHE_NS_ANSWERS, answer_id)

		return self._answer_to_response(updated)

	# ─── Réponses : Suppression ────────────────────────────────────────────

	async def delete_answer(
		self,
		answer_id: str,
		user_id: str,
	) -> bool:
		"""Supprime une réponse."""
		answer = await self.answer_repo.get_by_id(answer_id)
		if answer is None:
			raise NotFoundException("Réponse introuvable")

		question = await self.question_repo.get_by_id(answer.question_id)
		quiz = await self.quiz_repo.get_by_id(question.quiz_id) if question else None
		if quiz is None or quiz.created_by != user_id:
			raise ForbiddenException("Seul le créateur du quiz peut supprimer les réponses")

		success = await self.answer_repo.delete(answer_id)
		if success:
			await cache_manager.delete(CACHE_NS_ANSWERS, answer_id)

		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _question_to_response(question) -> QuestionResponseDTO:
		"""Convertit un modèle QuizQuestion en DTO de réponse."""
		return QuestionResponseDTO(
			id=question.id,
			quiz_id=question.quiz_id,
			question_text=question.question_text,
			question_type=question.question_type,
			points=question.points,
			hint=question.hint,
			explanation=question.explanation,
			image_url=question.image_url,
			sort_order=question.sort_order,
			difficulty=question.difficulty,
			metadata_json=question.metadata_json,
			created_at=question.created_at,
			updated_at=question.updated_at,
		)

	@staticmethod
	def _answer_to_response(answer) -> AnswerResponseDTO:
		"""Convertit un modèle QuizAnswer en DTO de réponse."""
		return AnswerResponseDTO(
			id=answer.id,
			question_id=answer.question_id,
			answer_text=answer.answer_text,
			is_correct=answer.is_correct,
			sort_order=answer.sort_order,
			explanation=answer.explanation,
			feedback=answer.feedback,
			created_at=answer.created_at,
			updated_at=answer.updated_at,
		)
