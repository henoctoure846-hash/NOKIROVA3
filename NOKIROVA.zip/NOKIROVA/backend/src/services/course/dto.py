"""NOKIROVA — DTOs Cours

Schémas de validation pour les cours, modules, leçons et inscriptions.
Alignés sur les modèles réels de university.py.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

# --- Requêtes Cours ---


class CourseCreateRequest(BaseModel):
	"""DTO de création de cours"""

	title: str = Field(min_length=3, max_length=300)
	code: str = Field(min_length=1, max_length=20, pattern=r"^[A-Z]{2,4}\d{2,4}$")
	description: str | None = Field(None, max_length=5000)
	instructor_id: str | None = None
	department: str | None = Field(None, max_length=100)
	credits: int = Field(default=3, ge=1, le=30)
	level: str = Field(default="undergraduate", pattern=r"^(undergraduate|graduate|doctoral|open)$")
	language: str = Field(default="fr", pattern=r"^[a-z]{2}$")
	semester: str | None = Field(None, max_length=20)
	year: int | None = Field(None, ge=2000, le=2100)
	is_enrollable: bool = Field(default=True)
	max_enrollment: int | None = Field(None, ge=1)
	cover_image: str | None = None
	syllabus: str | None = None
	tags: list[str] | None = None


class CourseUpdateRequest(BaseModel):
	"""DTO de mise à jour de cours"""

	title: str | None = Field(None, min_length=3, max_length=300)
	description: str | None = Field(None, max_length=5000)
	instructor_id: str | None = None
	department: str | None = Field(None, max_length=100)
	credits: int | None = Field(None, ge=1, le=30)
	level: str | None = Field(None, pattern=r"^(undergraduate|graduate|doctoral|open)$")
	language: str | None = Field(None, pattern=r"^[a-z]{2}$")
	semester: str | None = Field(None, max_length=20)
	year: int | None = Field(None, ge=2000, le=2100)
	is_published: bool | None = None
	is_enrollable: bool | None = None
	max_enrollment: int | None = Field(None, ge=1)
	cover_image: str | None = None
	syllabus: str | None = None
	tags: list[str] | None = None


# --- Requêtes Module ---


class ModuleCreateRequest(BaseModel):
	"""DTO de création de module"""

	title: str = Field(min_length=3, max_length=300)
	description: str | None = Field(None, max_length=2000)
	module_type: str = Field(default="content", pattern=r"^(content|lab|project|exam_prep|workshop)$")
	sort_order: int = Field(default=0, ge=0)
	is_required: bool = Field(default=True)
	estimated_hours: float = Field(default=1.0, ge=0.1, le=500.0)
	icon: str | None = Field(None, max_length=50)


class ModuleUpdateRequest(BaseModel):
	"""DTO de mise à jour de module"""

	title: str | None = Field(None, min_length=3, max_length=300)
	description: str | None = Field(None, max_length=2000)
	module_type: str | None = Field(None, pattern=r"^(content|lab|project|exam_prep|workshop)$")
	sort_order: int | None = Field(None, ge=0)
	is_published: bool | None = None
	is_required: bool | None = None
	estimated_hours: float | None = Field(None, ge=0.1, le=500.0)
	icon: str | None = Field(None, max_length=50)


# --- Requêtes Leçon ---


class LessonCreateRequest(BaseModel):
	"""DTO de création de leçon"""

	title: str = Field(min_length=3, max_length=300)
	content: str | None = None
	lesson_type: str = Field(default="video", pattern=r"^(video|article|interactive|live|lab)$")
	duration_minutes: int | None = Field(None, ge=1, le=300)
	sort_order: int = Field(default=0, ge=0)
	is_published: bool = Field(default=False)
	is_free: bool = Field(default=False)
	video_url: str | None = None
	attachment_urls: list[str] | None = None
	transcript: str | None = None


class LessonUpdateRequest(BaseModel):
	"""DTO de mise à jour de leçon"""

	title: str | None = Field(None, min_length=3, max_length=300)
	content: str | None = None
	lesson_type: str | None = Field(None, pattern=r"^(video|article|interactive|live|lab)$")
	duration_minutes: int | None = Field(None, ge=1, le=300)
	sort_order: int | None = Field(None, ge=0)
	is_published: bool | None = None
	is_free: bool | None = None
	video_url: str | None = None
	attachment_urls: list[str] | None = None
	transcript: str | None = None


# --- Requête Inscription ---


class EnrollmentRequest(BaseModel):
	"""DTO d'inscription à un cours"""

	course_id: str
	role: str = Field(default="student", pattern=r"^(student|teaching_assistant|auditor)$")


# --- Réponses ---


class LessonResponse(BaseModel):
	"""DTO de réponse leçon"""

	id: str
	module_id: str
	title: str
	content: str | None = None
	lesson_type: str = "video"
	sort_order: int = 0
	duration_minutes: int | None = None
	is_published: bool = False
	is_free: bool = False
	video_url: str | None = None
	attachment_urls: list | None = None
	transcript: str | None = None
	created_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class ModuleResponse(BaseModel):
	"""DTO de réponse module"""

	id: str
	course_id: str
	title: str
	description: str | None = None
	module_type: str = "content"
	sort_order: int = 0
	is_published: bool = False
	is_required: bool = True
	estimated_hours: float = 1.0
	icon: str | None = None
	lessons: list[LessonResponse] | None = None
	created_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class CourseResponse(BaseModel):
	"""DTO de réponse cours"""

	id: str
	title: str
	code: str
	description: str | None = None
	instructor_id: str | None = None
	department: str | None = None
	credits: int = 3
	level: str = "undergraduate"
	language: str = "fr"
	semester: str | None = None
	year: int | None = None
	is_published: bool = False
	is_enrollable: bool = True
	max_enrollment: int | None = None
	enrollment_count: int = 0
	cover_image: str | None = None
	syllabus: str | None = None
	tags: list | None = None
	modules: list[ModuleResponse] | None = None
	created_at: datetime | None = None
	updated_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class EnrollmentResponse(BaseModel):
	"""DTO de réponse inscription"""

	id: str
	student_id: str
	course_id: str
	role: str = "student"
	status: str = "active"
	enrolled_at: str = ""
	completed_at: str | None = None
	progress: float = 0.0
	final_grade: str | None = None
	created_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class CourseListResponse(BaseModel):
	"""DTO de réponse liste de cours"""

	courses: list[CourseResponse]
	total: int
	offset: int
	limit: int
