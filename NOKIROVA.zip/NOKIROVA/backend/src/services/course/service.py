"""NOKIROVA — Service Cours

Logique métier pour les cours, modules, leçons et inscriptions.
- Pas de SQL direct
- Communication via Event Bus
- Cache par namespace course_data
- Aligné sur les modèles réels de university.py
"""

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ConflictError, ForbiddenError, NotFoundError
from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.database.models.university import Course, Module, UniversityEnrollment, UniversityLesson
from src.events.bus import Event, event_bus
from src.services.course.dto import (
	CourseCreateRequest,
	CourseListResponse,
	CourseResponse,
	CourseUpdateRequest,
	EnrollmentRequest,
	EnrollmentResponse,
	LessonCreateRequest,
	LessonResponse,
	LessonUpdateRequest,
	ModuleCreateRequest,
	ModuleResponse,
	ModuleUpdateRequest,
)
from src.services.course.repository import CourseRepository


class CourseService:
	"""Service métier Cours"""

	def __init__(self):
		self.repo = CourseRepository()

	# --- Cours ---

	async def create_course(
		self, db: AsyncSession, instructor_id: str, data: CourseCreateRequest
	) -> CourseResponse:
		"""Créer un nouveau cours"""
		# Vérifier unicité du code
		existing = await self.repo.get_by_code(db, data.code)
		if existing:
			raise ConflictError(f"Un cours avec le code '{data.code}' existe déjà")

		course = Course(
			title=data.title,
			code=data.code,
			description=data.description,
			instructor_id=instructor_id,
			department=data.department,
			credits=data.credits,
			level=data.level,
			language=data.language,
			semester=data.semester,
			year=data.year,
			is_enrollable=data.is_enrollable,
			max_enrollment=data.max_enrollment,
			cover_image=data.cover_image,
			syllabus=data.syllabus,
			tags=data.tags or [],
			is_published=False,  # Brouillon par défaut
		)
		course = await self.repo.create(db, course)

		await event_bus.publish(
			Event(
				event_type="course.created",
				domain="course",
				payload={"course_id": course.id, "instructor_id": instructor_id, "title": course.title},
			)
		)

		# Invalider le cache des cours
		await cache_manager.invalidate_namespace("course_data")

		return CourseResponse.model_validate(course)

	async def get_course(self, db: AsyncSession, course_id: str) -> CourseResponse:
		"""Récupérer un cours — avec cache"""
		cached = await cache_manager.get("course_data", f"course:{course_id}")
		if cached:
			return CourseResponse(**cached)

		course = await self.repo.get_by_id(db, course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")

		response = CourseResponse.model_validate(course)
		await cache_manager.set("course_data", f"course:{course_id}", response.model_dump(), ttl=1800)

		return response

	async def update_course(
		self, db: AsyncSession, course_id: str, user_id: str, data: CourseUpdateRequest
	) -> CourseResponse:
		"""Mettre à jour un cours"""
		course = await self.repo.get_by_id(db, course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")

		# Vérifier que l'utilisateur est l'instructeur ou admin
		if course.instructor_id != user_id:
			raise ForbiddenError("Vous n'êtes pas l'instructeur de ce cours")

		update_data = data.model_dump(exclude_unset=True)
		course = await self.repo.update(db, course_id, update_data)

		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.updated",
				domain="course",
				payload={"course_id": course_id, "fields": list(update_data.keys())},
			)
		)

		return CourseResponse.model_validate(course)

	async def publish_course(self, db: AsyncSession, course_id: str, user_id: str) -> CourseResponse:
		"""Publier un cours"""
		course = await self.repo.get_by_id(db, course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")

		if course.instructor_id != user_id:
			raise ForbiddenError("Vous n'êtes pas l'instructeur de ce cours")

		course = await self.repo.update(db, course_id, {"is_published": True})

		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.published",
				domain="course",
				payload={"course_id": course_id},
			)
		)

		return CourseResponse.model_validate(course)

	async def archive_course(self, db: AsyncSession, course_id: str, user_id: str) -> bool:
		"""Archiver un cours (suppression douce)"""
		course = await self.repo.get_by_id(db, course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")

		if course.instructor_id != user_id:
			raise ForbiddenError("Vous n'êtes pas l'instructeur de ce cours")

		await self.repo.soft_delete(db, course_id)
		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.archived",
				domain="course",
				payload={"course_id": course_id},
			)
		)

		return True

	async def list_courses(
		self,
		db: AsyncSession,
		offset: int = 0,
		limit: int = 20,
		department: str | None = None,
		level: str | None = None,
		is_published: bool | None = None,
		instructor_id: str | None = None,
		search: str | None = None,
	) -> CourseListResponse:
		"""Lister les cours avec filtres et pagination"""
		courses = await self.repo.list_courses(
			db,
			offset=offset,
			limit=limit,
			department=department,
			level=level,
			is_published=is_published,
			instructor_id=instructor_id,
			search=search,
		)
		total = await self.repo.count_courses(db, department=department, level=level, is_published=is_published)
		return CourseListResponse(
			courses=[CourseResponse.model_validate(c) for c in courses],
			total=total,
			offset=offset,
			limit=limit,
		)

	# --- Modules ---

	async def create_module(
		self, db: AsyncSession, course_id: str, user_id: str, data: ModuleCreateRequest
	) -> ModuleResponse:
		"""Ajouter un module à un cours"""
		course = await self.repo.get_by_id(db, course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")
		if course.instructor_id != user_id:
			raise ForbiddenError("Vous n'êtes pas l'instructeur de ce cours")

		module = Module(
			course_id=course_id,
			title=data.title,
			description=data.description,
			module_type=data.module_type,
			sort_order=data.sort_order,
			is_required=data.is_required,
			estimated_hours=data.estimated_hours,
			icon=data.icon,
		)
		module = await self.repo.create_module(db, module)

		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.module_created",
				domain="course",
				payload={"course_id": course_id, "module_id": module.id},
			)
		)

		return ModuleResponse.model_validate(module)

	async def update_module(
		self, db: AsyncSession, module_id: str, course_id: str, user_id: str, data: ModuleUpdateRequest
	) -> ModuleResponse:
		"""Mettre à jour un module"""
		course = await self.repo.get_by_id(db, course_id)
		if not course or course.instructor_id != user_id:
			raise ForbiddenError("Accès refusé")

		update_data = data.model_dump(exclude_unset=True)
		module = await self.repo.update_module(db, module_id, update_data)

		await cache_manager.delete("course_data", f"course:{course_id}")

		return ModuleResponse.model_validate(module)

	async def delete_module(self, db: AsyncSession, module_id: str, course_id: str, user_id: str) -> bool:
		"""Supprimer un module (suppression douce)"""
		course = await self.repo.get_by_id(db, course_id)
		if not course or course.instructor_id != user_id:
			raise ForbiddenError("Accès refusé")

		await self.repo.delete_module(db, module_id)
		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.module_deleted",
				domain="course",
				payload={"course_id": course_id, "module_id": module_id},
			)
		)

		return True

	# --- Leçons ---

	async def create_lesson(
		self, db: AsyncSession, module_id: str, course_id: str, user_id: str, data: LessonCreateRequest
	) -> LessonResponse:
		"""Ajouter une leçon à un module"""
		course = await self.repo.get_by_id(db, course_id)
		if not course or course.instructor_id != user_id:
			raise ForbiddenError("Accès refusé")

		lesson = UniversityLesson(
			module_id=module_id,
			title=data.title,
			content=data.content,
			lesson_type=data.lesson_type,
			sort_order=data.sort_order,
			duration_minutes=data.duration_minutes,
			is_published=data.is_published,
			is_free=data.is_free,
			video_url=data.video_url,
			attachment_urls=data.attachment_urls or [],
			transcript=data.transcript,
		)
		lesson = await self.repo.create_lesson(db, lesson)

		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.lesson_created",
				domain="course",
				payload={"course_id": course_id, "module_id": module_id, "lesson_id": lesson.id},
			)
		)

		return LessonResponse.model_validate(lesson)

	async def update_lesson(
		self, db: AsyncSession, lesson_id: str, course_id: str, user_id: str, data: LessonUpdateRequest
	) -> LessonResponse:
		"""Mettre à jour une leçon"""
		course = await self.repo.get_by_id(db, course_id)
		if not course or course.instructor_id != user_id:
			raise ForbiddenError("Accès refusé")

		update_data = data.model_dump(exclude_unset=True)
		lesson = await self.repo.update_lesson(db, lesson_id, update_data)

		await cache_manager.delete("course_data", f"course:{course_id}")

		return LessonResponse.model_validate(lesson)

	async def delete_lesson(self, db: AsyncSession, lesson_id: str, course_id: str, user_id: str) -> bool:
		"""Supprimer une leçon (suppression douce)"""
		course = await self.repo.get_by_id(db, course_id)
		if not course or course.instructor_id != user_id:
			raise ForbiddenError("Accès refusé")

		await self.repo.delete_lesson(db, lesson_id)
		await cache_manager.delete("course_data", f"course:{course_id}")

		await event_bus.publish(
			Event(
				event_type="course.lesson_deleted",
				domain="course",
				payload={"course_id": course_id, "lesson_id": lesson_id},
			)
		)

		return True

	# --- Inscription ---

	async def enroll(self, db: AsyncSession, student_id: str, data: EnrollmentRequest) -> EnrollmentResponse:
		"""Inscrire un utilisateur à un cours"""
		course = await self.repo.get_by_id(db, data.course_id)
		if not course:
			raise NotFoundError("Cours non trouvé")
		if not course.is_published:
			raise ForbiddenError("Ce cours n'est pas encore publié")
		if not course.is_enrollable:
			raise ForbiddenError("Les inscriptions sont fermées pour ce cours")

		# Vérifier si déjà inscrit
		existing = await self.repo.get_enrollment(db, student_id, data.course_id)
		if existing:
			raise ConflictError("Vous êtes déjà inscrit à ce cours")

		enrollment = UniversityEnrollment(
			student_id=student_id,
			course_id=data.course_id,
			role=data.role,
			status="active",
			progress=0.0,
		)
		enrollment = await self.repo.create_enrollment(db, enrollment)

		# Incrémenter le compteur
		await self.repo.increment_enrollment_count(db, data.course_id)

		await cache_manager.invalidate_namespace("course_data")

		await event_bus.publish(
			Event(
				event_type="course.enrolled",
				domain="course",
				payload={"course_id": data.course_id, "student_id": student_id},
			)
		)

		return EnrollmentResponse.model_validate(enrollment)

	async def unenroll(self, db: AsyncSession, student_id: str, course_id: str) -> bool:
		"""Désinscrire un utilisateur d'un cours"""
		enrollment = await self.repo.get_enrollment(db, student_id, course_id)
		if not enrollment:
			raise NotFoundError("Inscription non trouvée")

		# Marquer comme annulée — pas de deleted_at, on utilise is_active=False
		await self.repo.update_enrollment_progress(
			db,
			enrollment.id,
			{
				"status": "dropped",
				"is_active": False,
			},
		)

		await cache_manager.invalidate_namespace("course_data")

		await event_bus.publish(
			Event(
				event_type="course.unenrolled",
				domain="course",
				payload={"course_id": course_id, "student_id": student_id},
			)
		)

		return True

	async def update_progress(
		self, db: AsyncSession, student_id: str, course_id: str, progress: float
	) -> EnrollmentResponse:
		"""Mettre à jour la progression d'une inscription"""
		enrollment = await self.repo.get_enrollment(db, student_id, course_id)
		if not enrollment:
			raise NotFoundError("Inscription non trouvée")

		update_data = {"progress": progress}
		if progress >= 100.0:
			update_data["status"] = "completed"
			update_data["completed_at"] = datetime.now(UTC).isoformat()

		enrollment = await self.repo.update_enrollment_progress(db, enrollment.id, update_data)

		await event_bus.publish(
			Event(
				event_type="course.progress_updated",
				domain="course",
				payload={
					"student_id": student_id,
					"course_id": course_id,
					"progress": progress,
				},
			)
		)

		return EnrollmentResponse.model_validate(enrollment)

	async def list_enrollments(self, db: AsyncSession, student_id: str, offset: int = 0, limit: int = 20):
		"""Lister les inscriptions d'un étudiant"""
		enrollments = await self.repo.list_enrollments(db, student_id, offset=offset, limit=limit)
		return [EnrollmentResponse.model_validate(e) for e in enrollments]

	# --- Auto-guérison ---

	async def heal_course_cache(self, course_id: str) -> bool:
		"""Auto-guérison : reconstruire le cache d'un cours"""
		try:
			await cache_manager.delete("course_data", f"course:{course_id}")
			return True
		except DB_OPERATION_EXCEPTIONS:
			return False
