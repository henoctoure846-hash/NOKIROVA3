"""NOKIROVA — Depot Cours

Acces aux donnees pour les cours, modules, lecons et inscriptions.
Patron Style B : session (db) passee en argument a chaque methode.

Ce depot ne peut PAS heriter de BaseRepository car chaque methode
accepte sa propre session AsyncSession — in Compatible avec le
stockage de session dans BaseRepository.__init__.

Operations disponibles :
    - CRUD cours (get_by_id, get_by_code, list_courses, count_courses,
      create, update, soft_delete)
    - Gestion des modules (get_module, create_module, update_module,
      delete_module)
    - Gestion des lecons (get_lesson, create_lesson, update_lesson,
      delete_lesson)
    - Gestion des inscriptions (get_enrollment, create_enrollment,
      list_enrollments, increment_enrollment_count,
      update_enrollment_progress)

Suppression douce : is_active=False + is_published=False sur Course,
is_active=False sur Module et UniversityLesson.
Pas de deleted_at sur les modeles (convention NOKIROVA).
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.database.models.university import Course, Module, UniversityEnrollment, UniversityLesson

# ─── Depot Cours ──────────────────────────────────────────────────────


class CourseRepository:
	"""Depot pour les cours universitaires — requetes DB uniquement.

	Patron Style B : chaque methode recoit sa session AsyncSession.
	Aucune logique metier, aucun SQL direct — SQLAlchemy ORM uniquement.
	"""

	# ── Recherche ──────────────────────────────────────────────────

	async def get_by_id(self, db: AsyncSession, course_id: str) -> Course | None:
		"""Recupere un cours par son identifiant avec ses modules."""
		result = await db.execute(
			select(Course).options(selectinload(Course.modules)).where(Course.id == course_id)
		)
		return result.scalars().first()

	async def get_by_code(self, db: AsyncSession, code: str) -> Course | None:
		"""Recherche un cours par son code (ex : CS101)."""
		result = await db.execute(select(Course).where(Course.code == code))
		return result.scalars().first()

	# ── Listing ────────────────────────────────────────────────────

	async def list_courses(
		self,
		db: AsyncSession,
		offset: int = 0,
		limit: int = 20,
		department: str | None = None,
		level: str | None = None,
		is_published: bool | None = None,
		instructor_id: str | None = None,
		search: str | None = None,
	) -> Sequence[Course]:
		"""Liste les cours avec filtres optionnels."""
		query = select(Course)
		conditions: list = []
		if department:
			conditions.append(Course.department == department)
		if level:
			conditions.append(Course.level == level)
		if is_published is not None:
			conditions.append(Course.is_published == is_published)
		if instructor_id:
			conditions.append(Course.instructor_id == instructor_id)
		if search:
			conditions.append(Course.title.ilike(f"%{search}%"))
		if conditions:
			query = query.where(and_(*conditions))
		query = query.offset(offset).limit(limit).order_by(Course.created_at.desc())
		result = await db.execute(query)
		return result.scalars().all()

	async def count_courses(
		self,
		db: AsyncSession,
		department: str | None = None,
		level: str | None = None,
		is_published: bool | None = None,
	) -> int:
		"""Compte les cours selon les filtres."""
		query = select(func.count(Course.id))
		conditions: list = []
		if department:
			conditions.append(Course.department == department)
		if level:
			conditions.append(Course.level == level)
		if is_published is not None:
			conditions.append(Course.is_published == is_published)
		if conditions:
			query = query.where(and_(*conditions))
		result = await db.execute(query)
		return result.scalar() or 0

	# ── Ecriture ───────────────────────────────────────────────────

	async def create(self, db: AsyncSession, course: Course) -> Course:
		"""Cree un nouveau cours."""
		db.add(course)
		await db.flush()
		await db.refresh(course)
		return course

	async def update(self, db: AsyncSession, course_id: str, data: dict) -> Course | None:
		"""Met a jour les champs d'un cours."""
		await db.execute(update(Course).where(Course.id == course_id).values(**data))
		return await self.get_by_id(db, course_id)

	async def soft_delete(self, db: AsyncSession, course_id: str) -> bool:
		"""Suppression douce — desactivation + depublication.
		Met is_published=False ET is_active=False simultanement.
		Pas de deleted_at (convention NOKIROVA).
		"""
		await db.execute(
			update(Course).where(Course.id == course_id).values(is_published=False, is_active=False)
		)
		return True

	# ── Modules ────────────────────────────────────────────────────

	async def get_module(self, db: AsyncSession, module_id: str) -> Module | None:
		"""Recupere un module avec ses lecons."""
		result = await db.execute(
			select(Module).options(selectinload(Module.lessons)).where(Module.id == module_id)
		)
		return result.scalars().first()

	async def create_module(self, db: AsyncSession, module: Module) -> Module:
		"""Cree un nouveau module."""
		db.add(module)
		await db.flush()
		await db.refresh(module)
		return module

	async def update_module(self, db: AsyncSession, module_id: str, data: dict) -> Module | None:
		"""Met a jour les champs d'un module."""
		await db.execute(update(Module).where(Module.id == module_id).values(**data))
		result = await db.execute(select(Module).where(Module.id == module_id))
		return result.scalars().first()

	async def delete_module(self, db: AsyncSession, module_id: str) -> bool:
		"""Suppression douce d'un module — is_active=False."""
		await db.execute(update(Module).where(Module.id == module_id).values(is_active=False))
		return True

	# ── Lecons ─────────────────────────────────────────────────────

	async def get_lesson(self, db: AsyncSession, lesson_id: str) -> UniversityLesson | None:
		"""Recupere une lecon par son identifiant."""
		result = await db.execute(select(UniversityLesson).where(UniversityLesson.id == lesson_id))
		return result.scalars().first()

	async def create_lesson(self, db: AsyncSession, lesson: UniversityLesson) -> UniversityLesson:
		"""Cree une nouvelle lecon."""
		db.add(lesson)
		await db.flush()
		await db.refresh(lesson)
		return lesson

	async def update_lesson(self, db: AsyncSession, lesson_id: str, data: dict) -> UniversityLesson | None:
		"""Met a jour les champs d'une lecon."""
		await db.execute(update(UniversityLesson).where(UniversityLesson.id == lesson_id).values(**data))
		result = await db.execute(select(UniversityLesson).where(UniversityLesson.id == lesson_id))
		return result.scalars().first()

	async def delete_lesson(self, db: AsyncSession, lesson_id: str) -> bool:
		"""Suppression douce d'une lecon — is_active=False."""
		await db.execute(
			update(UniversityLesson).where(UniversityLesson.id == lesson_id).values(is_active=False)
		)
		return True

	# ── Inscriptions ───────────────────────────────────────────────

	async def get_enrollment(
		self, db: AsyncSession, student_id: str, course_id: str
	) -> UniversityEnrollment | None:
		"""Recupere l'inscription d'un etudiant a un cours."""
		result = await db.execute(
			select(UniversityEnrollment).where(
				and_(
					UniversityEnrollment.student_id == student_id,
					UniversityEnrollment.course_id == course_id,
				)
			)
		)
		return result.scalars().first()

	async def create_enrollment(self, db: AsyncSession, enrollment: UniversityEnrollment) -> UniversityEnrollment:
		"""Cree une nouvelle inscription."""
		db.add(enrollment)
		await db.flush()
		await db.refresh(enrollment)
		return enrollment

	async def list_enrollments(
		self, db: AsyncSession, student_id: str, offset: int = 0, limit: int = 20
	) -> Sequence[UniversityEnrollment]:
		"""Liste les inscriptions d'un etudiant."""
		result = await db.execute(
			select(UniversityEnrollment)
			.where(UniversityEnrollment.student_id == student_id)
			.offset(offset)
			.limit(limit)
			.order_by(UniversityEnrollment.created_at.desc())
		)
		return result.scalars().all()

	async def increment_enrollment_count(self, db: AsyncSession, course_id: str) -> None:
		"""Incremente le compteur d'inscriptions d'un cours."""
		await db.execute(
			update(Course)
			.where(Course.id == course_id)
			.values(enrollment_count=Course.enrollment_count + 1)
		)

	async def update_enrollment_progress(
		self, db: AsyncSession, enrollment_id: str, data: dict
	) -> UniversityEnrollment | None:
		"""Met a jour la progression d'une inscription."""
		await db.execute(
			update(UniversityEnrollment).where(UniversityEnrollment.id == enrollment_id).values(**data)
		)
		result = await db.execute(select(UniversityEnrollment).where(UniversityEnrollment.id == enrollment_id))
		return result.scalars().first()
