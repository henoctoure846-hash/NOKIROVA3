"""NOKIROVA — Service Cours"""

from .repository import CourseRepository as CourseRepository
from .service import CourseService as CourseService
