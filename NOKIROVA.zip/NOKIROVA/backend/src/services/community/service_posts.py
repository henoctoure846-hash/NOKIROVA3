"""NOKIROVA — Service Communauté : Publications

Logique métier pour les publications (posts) communautaires :
- CRUD publications
- Compteur de vues
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException
from src.events.bus import Event, event_bus
from src.services.community.dto import (
	PostCreateDTO,
	PostResponseDTO,
	PostUpdateDTO,
)
from src.services.community.repository import (
	GroupRepository,
	PostRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_POSTS = "community:posts"
EVENT_DOMAIN = "community"


# ─── Service Publications ─────────────────────────────────────────────────────


class PostService:
	"""Service métier pour les publications communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.post_repo = PostRepository(session)
		self.group_repo = GroupRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_post(self, dto: PostCreateDTO) -> PostResponseDTO:
		"""Crée une publication."""
		if dto.group_id:
			group = await self.group_repo.get_by_id(dto.group_id)
			if group is None:
				raise NotFoundException("Groupe introuvable")

		data = dto.model_dump(exclude_none=True)
		post = await self.post_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_POSTS)

		await event_bus.publish(
			Event(
				event_type="post_created",
				domain=EVENT_DOMAIN,
				payload={"post_id": post.id, "author_id": post.author_id},
			)
		)

		return await self._post_to_response(post)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_post(self, post_id: str) -> PostResponseDTO:
		"""Récupère une publication."""
		cached = await cache_manager.get(CACHE_NS_POSTS, post_id)
		if cached:
			return PostResponseDTO(**cached)

		post = await self.post_repo.get_by_id(post_id)
		if post is None:
			raise NotFoundException("Publication introuvable")

		await self.post_repo.increment_view_count(post_id)

		response = await self._post_to_response(post)
		await cache_manager.set(CACHE_NS_POSTS, post_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_posts(
		self,
		category: str | None = None,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[PostResponseDTO]:
		"""Liste les publications."""
		posts = await self.post_repo.list_posts(category, group_id, limit, offset)
		return [await self._post_to_response(p) for p in posts]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_post(
		self,
		post_id: str,
		user_id: str,
		dto: PostUpdateDTO,
	) -> PostResponseDTO:
		"""Met à jour une publication."""
		post = await self.post_repo.get_by_id(post_id)
		if post is None:
			raise NotFoundException("Publication introuvable")
		if post.author_id != user_id:
			raise ForbiddenException("Seul l'auteur peut modifier cette publication")

		data = dto.model_dump(exclude_none=True)
		updated = await self.post_repo.update(post_id, data)

		await cache_manager.delete(CACHE_NS_POSTS, post_id)

		await event_bus.publish(
			Event(
				event_type="post_updated",
				domain=EVENT_DOMAIN,
				payload={"post_id": post_id},
			)
		)

		return await self._post_to_response(updated)

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_post(self, post_id: str, user_id: str) -> bool:
		"""Supprime une publication."""
		post = await self.post_repo.get_by_id(post_id)
		if post is None:
			raise NotFoundException("Publication introuvable")
		if post.author_id != user_id:
			raise ForbiddenException("Seul l'auteur peut supprimer cette publication")

		success = await self.post_repo.soft_delete(post_id)
		if success:
			await cache_manager.delete(CACHE_NS_POSTS, post_id)
			await event_bus.publish(
				Event(
					event_type="post_deleted",
					domain=EVENT_DOMAIN,
					payload={"post_id": post_id},
				)
			)
		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	async def _post_to_response(self, post) -> PostResponseDTO:
		"""Convertit un modèle CommunityPost en DTO de réponse."""
		comment_count = await self.post_repo.count_comments(post.id)
		like_count = await self.post_repo.count_likes(post.id)
		return PostResponseDTO(
			id=post.id,
			author_id=post.author_id,
			title=post.title,
			content=post.content,
			category=post.category,
			tags=post.tags,
			is_pinned=post.is_pinned,
			is_locked=post.is_locked,
			view_count=post.view_count,
			group_id=post.group_id,
			metadata_json=post.metadata_json,
			comment_count=comment_count,
			like_count=like_count,
			created_at=post.created_at,
			updated_at=post.updated_at,
		)
