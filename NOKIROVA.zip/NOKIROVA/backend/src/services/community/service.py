"""NOKIROVA — Service Communauté : Façade

Façade principale qui délègue aux sous-services métier :
- PostService         → publications
- CommentService      → commentaires
- LikeService         → likes
- GroupService        → groupes
- EventService        → événements
- ReportService       → signalements
- BadgeService        → badges

Toute la logique métier est dans les sous-services.
Ce module expose une API unifiée pour le routeur.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.community.dto import (
	CommentCreateDTO,
	CommentResponseDTO,
	CommentUpdateDTO,
	EventCreateDTO,
	EventResponseDTO,
	EventUpdateDTO,
	GroupCreateDTO,
	GroupMemberResponseDTO,
	GroupResponseDTO,
	GroupUpdateDTO,
	LikeResponseDTO,
	PostCreateDTO,
	PostResponseDTO,
	PostUpdateDTO,
	ReportCreateDTO,
	ReportResolveDTO,
	ReportResponseDTO,
	RSVPResponseDTO,
	UserBadgeResponseDTO,
)
from src.services.community.service_badges import BadgeService
from src.services.community.service_comments import CommentService
from src.services.community.service_events import EventService
from src.services.community.service_groups import GroupService
from src.services.community.service_likes import LikeService
from src.services.community.service_posts import PostService
from src.services.community.service_reports import ReportService

# ─── Façade Communauté ────────────────────────────────────────────────────────


class CommunityService:
	"""Façade principale du domaine Communauté.

	Délègue chaque opération au sous-service correspondant.
	Le routeur importe UNIQUEMENT cette classe.
	"""

	def __init__(self, session: AsyncSession) -> None:
		self.posts = PostService(session)
		self.comments = CommentService(session)
		self.likes = LikeService(session)
		self.groups = GroupService(session)
		self.events = EventService(session)
		self.reports = ReportService(session)
		self.badges = BadgeService(session)

	# ─── Publications ─────────────────────────────────────────────────────

	async def create_post(self, dto: PostCreateDTO) -> PostResponseDTO:
		"""Crée une publication."""
		return await self.posts.create_post(dto)

	async def get_post(self, post_id: str) -> PostResponseDTO:
		"""Récupère une publication."""
		return await self.posts.get_post(post_id)

	async def list_posts(
		self,
		category: str | None = None,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[PostResponseDTO]:
		"""Liste les publications."""
		return await self.posts.list_posts(category, group_id, limit, offset)

	async def update_post(
		self,
		post_id: str,
		user_id: str,
		dto: PostUpdateDTO,
	) -> PostResponseDTO:
		"""Met à jour une publication."""
		return await self.posts.update_post(post_id, user_id, dto)

	async def delete_post(self, post_id: str, user_id: str) -> bool:
		"""Supprime une publication."""
		return await self.posts.delete_post(post_id, user_id)

	# ─── Commentaires ────────────────────────────────────────────────────

	async def create_comment(self, dto: CommentCreateDTO) -> CommentResponseDTO:
		"""Crée un commentaire."""
		return await self.comments.create_comment(dto)

	async def list_comments(
		self,
		post_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[CommentResponseDTO]:
		"""Liste les commentaires d'une publication."""
		return await self.comments.list_comments(post_id, limit, offset)

	async def update_comment(
		self,
		comment_id: str,
		user_id: str,
		dto: CommentUpdateDTO,
	) -> CommentResponseDTO:
		"""Met à jour un commentaire."""
		return await self.comments.update_comment(comment_id, user_id, dto)

	async def delete_comment(self, comment_id: str, user_id: str) -> bool:
		"""Supprime un commentaire."""
		return await self.comments.delete_comment(comment_id, user_id)

	# ─── Likes ───────────────────────────────────────────────────────────

	async def toggle_like(self, post_id: str, user_id: str) -> LikeResponseDTO:
		"""Ajoute ou retire un like."""
		return await self.likes.toggle_like(post_id, user_id)

	async def is_liked(self, post_id: str, user_id: str) -> bool:
		"""Vérifie si l'utilisateur a liké la publication."""
		return await self.likes.is_liked(post_id, user_id)

	# ─── Groupes ─────────────────────────────────────────────────────────

	async def create_group(self, dto: GroupCreateDTO) -> GroupResponseDTO:
		"""Crée un groupe."""
		return await self.groups.create_group(dto)

	async def get_group(self, group_id: str) -> GroupResponseDTO:
		"""Récupère un groupe."""
		return await self.groups.get_group(group_id)

	async def list_groups(
		self,
		visibility: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[GroupResponseDTO]:
		"""Liste les groupes."""
		return await self.groups.list_groups(visibility, limit, offset)

	async def update_group(
		self,
		group_id: str,
		user_id: str,
		dto: GroupUpdateDTO,
	) -> GroupResponseDTO:
		"""Met à jour un groupe."""
		return await self.groups.update_group(group_id, user_id, dto)

	async def delete_group(self, group_id: str, user_id: str) -> bool:
		"""Supprime un groupe."""
		return await self.groups.delete_group(group_id, user_id)

	async def join_group(
		self,
		group_id: str,
		user_id: str,
	) -> GroupMemberResponseDTO:
		"""Rejoint un groupe."""
		return await self.groups.join_group(group_id, user_id)

	async def leave_group(self, group_id: str, user_id: str) -> bool:
		"""Quitte un groupe."""
		return await self.groups.leave_group(group_id, user_id)

	# ─── Événements ──────────────────────────────────────────────────────

	async def create_event(self, dto: EventCreateDTO) -> EventResponseDTO:
		"""Crée un événement."""
		return await self.events.create_event(dto)

	async def get_event(self, event_id: str) -> EventResponseDTO:
		"""Récupère un événement."""
		return await self.events.get_event(event_id)

	async def list_events(
		self,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[EventResponseDTO]:
		"""Liste les événements."""
		return await self.events.list_events(group_id, limit, offset)

	async def update_event(
		self,
		event_id: str,
		user_id: str,
		dto: EventUpdateDTO,
	) -> EventResponseDTO:
		"""Met à jour un événement."""
		return await self.events.update_event(event_id, user_id, dto)

	async def delete_event(self, event_id: str, user_id: str) -> bool:
		"""Supprime un événement."""
		return await self.events.delete_event(event_id, user_id)

	async def rsvp(
		self,
		event_id: str,
		user_id: str,
		status: str,
	) -> RSVPResponseDTO:
		"""Inscrit un utilisateur à un événement."""
		return await self.events.rsvp(event_id, user_id, status)

	# ─── Signalements ────────────────────────────────────────────────────

	async def create_report(self, dto: ReportCreateDTO) -> ReportResponseDTO:
		"""Crée un signalement."""
		return await self.reports.create_report(dto)

	async def get_report(self, report_id: str) -> ReportResponseDTO:
		"""Récupère un signalement."""
		return await self.reports.get_report(report_id)

	async def list_reports(
		self,
		status: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ReportResponseDTO]:
		"""Liste les signalements."""
		return await self.reports.list_reports(status, limit, offset)

	async def resolve_report(
		self,
		report_id: str,
		moderator_id: str,
		dto: ReportResolveDTO,
	) -> ReportResponseDTO:
		"""Résout un signalement."""
		return await self.reports.resolve_report(report_id, moderator_id, dto)

	# ─── Badges ──────────────────────────────────────────────────────────

	async def award_badge(
		self,
		user_id: str,
		badge_id: str,
	) -> UserBadgeResponseDTO:
		"""Attribue un badge."""
		return await self.badges.award_badge(user_id, badge_id)

	async def list_user_badges(
		self,
		user_id: str,
	) -> list[UserBadgeResponseDTO]:
		"""Liste les badges d'un utilisateur."""
		return await self.badges.list_user_badges(user_id)
