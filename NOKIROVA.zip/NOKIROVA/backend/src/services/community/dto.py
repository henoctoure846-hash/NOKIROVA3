"""NOKIROVA — DTOs du service Community

Modèles Pydantic pour la validation des requêtes et réponses
du module Communauté : posts, commentaires, likes, groupes,
événements, signalements et badges utilisateur.
Alignés sur les modèles SQLAlchemy réels (community.py).

Corrections clés :
- CommunityPost : author_id (pas user_id), is_pinned, is_locked, view_count,
  group_id, tags (JSONB), metadata_json
- CommunityComment : post_id, author_id, parent_id, is_edited
- CommunityLike : post_id, user_id, reaction_type
- CommunityGroup : group_type, icon, owner_id, member_count, rules
- CommunityEvent : event_type, starts_at, ends_at, location, max_participants,
  organizer_id, group_id
- CommunityReport : reporter_id, target_type, target_id, reason, description,
  status, reviewed_by
- CommunityBadgeUser : user_id, badge_name, awarded_at, awarded_by
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class PostCategoryEnum(StrEnum):
	"""Catégories de publication."""

	discussion = "discussion"
	question = "question"
	sharing = "sharing"
	announcement = "announcement"
	feedback = "feedback"
	help = "help"


class ReactionTypeEnum(StrEnum):
	"""Types de réaction."""

	like = "like"
	love = "love"
	applaud = "applaud"
	thinking = "thinking"
	celebrate = "celebrate"


class GroupTypeEnum(StrEnum):
	"""Types de groupe."""

	public = "public"
	private = "private"
	hidden = "hidden"


class EventTypeEnum(StrEnum):
	"""Types d'événement."""

	meetup = "meetup"
	workshop = "workshop"
	study_session = "study_session"
	webinar = "webinar"
	competition = "competition"


class TargetTypeEnum(StrEnum):
	"""Types de cible de signalement."""

	post = "post"
	comment = "comment"
	user = "user"


class ReportStatusEnum(StrEnum):
	"""Statuts de signalement."""

	pending = "pending"
	reviewing = "reviewing"
	resolved = "resolved"
	dismissed = "dismissed"


class ReportReasonEnum(StrEnum):
	"""Raisons de signalement."""

	spam = "spam"
	harassment = "harassment"
	inappropriate = "inappropriate"
	misinformation = "misinformation"
	other = "other"


# ─── Publications (Posts) ────────────────────────────────────────────────────


class PostCreateDTO(BaseModel):
	"""Création d'une publication."""

	author_id: str
	title: str = Field(..., min_length=1, max_length=255)
	content: str = Field(..., min_length=1)
	category: PostCategoryEnum = PostCategoryEnum.discussion
	tags: list[str] | None = None
	is_pinned: bool = False
	group_id: str | None = None
	metadata_json: dict | None = None


class PostUpdateDTO(BaseModel):
	"""Mise à jour d'une publication."""

	title: str | None = Field(None, min_length=1, max_length=255)
	content: str | None = Field(None, min_length=1)
	category: PostCategoryEnum | None = None
	tags: list[str] | None = None
	is_pinned: bool | None = None
	is_locked: bool | None = None
	metadata_json: dict | None = None


class PostResponseDTO(BaseModel):
	"""Réponse publication."""

	id: str
	author_id: str
	title: str
	content: str
	category: str
	tags: list[str] | None = None
	is_pinned: bool = False
	is_locked: bool = False
	view_count: int = 0
	group_id: str | None = None
	metadata_json: dict | None = None
	comment_count: int | None = 0
	like_count: int | None = 0
	created_at: datetime
	updated_at: datetime


# ─── Commentaires ─────────────────────────────────────────────────────────────


class CommentCreateDTO(BaseModel):
	"""Création d'un commentaire."""

	post_id: str
	author_id: str
	parent_id: str | None = None
	content: str = Field(..., min_length=1)


class CommentUpdateDTO(BaseModel):
	"""Mise à jour d'un commentaire."""

	content: str = Field(..., min_length=1)


class CommentResponseDTO(BaseModel):
	"""Réponse commentaire."""

	id: str
	post_id: str
	author_id: str
	parent_id: str | None = None
	content: str
	is_edited: bool = False
	created_at: datetime
	updated_at: datetime


# ─── Likes / Réactions ────────────────────────────────────────────────────────


class LikeCreateDTO(BaseModel):
	"""Création d'un like/réaction."""

	post_id: str
	user_id: str
	reaction_type: ReactionTypeEnum = ReactionTypeEnum.like


class LikeResponseDTO(BaseModel):
	"""Réponse like/réaction."""

	id: str
	post_id: str
	user_id: str
	reaction_type: str
	created_at: datetime
	updated_at: datetime


# ─── Groupes ───────────────────────────────────────────────────────────────────


class GroupCreateDTO(BaseModel):
	"""Création d'un groupe."""

	name: str = Field(..., min_length=1, max_length=100)
	description: str | None = None
	group_type: GroupTypeEnum = GroupTypeEnum.public
	icon: str | None = None
	owner_id: str
	rules: str | None = None


class GroupUpdateDTO(BaseModel):
	"""Mise à jour d'un groupe."""

	name: str | None = Field(None, min_length=1, max_length=100)
	description: str | None = None
	group_type: GroupTypeEnum | None = None
	icon: str | None = None
	rules: str | None = None


class GroupResponseDTO(BaseModel):
	"""Réponse groupe."""

	id: str
	name: str
	description: str | None = None
	group_type: str
	icon: str | None = None
	owner_id: str
	member_count: int = 0
	rules: str | None = None
	created_at: datetime
	updated_at: datetime


# ─── Événements ────────────────────────────────────────────────────────────────


class EventCreateDTO(BaseModel):
	"""Création d'un événement."""

	title: str = Field(..., min_length=1, max_length=255)
	description: str | None = None
	event_type: EventTypeEnum = EventTypeEnum.meetup
	starts_at: str
	ends_at: str | None = None
	location: str | None = None
	max_participants: int | None = None
	organizer_id: str
	group_id: str | None = None


class EventUpdateDTO(BaseModel):
	"""Mise à jour d'un événement."""

	title: str | None = Field(None, min_length=1, max_length=255)
	description: str | None = None
	event_type: EventTypeEnum | None = None
	starts_at: str | None = None
	ends_at: str | None = None
	location: str | None = None
	max_participants: int | None = None
	group_id: str | None = None


class EventResponseDTO(BaseModel):
	"""Réponse événement."""

	id: str
	title: str
	description: str | None = None
	event_type: str
	starts_at: str
	ends_at: str | None = None
	location: str | None = None
	max_participants: int | None = None
	organizer_id: str
	group_id: str | None = None
	created_at: datetime
	updated_at: datetime


# ─── Signalements (Reports) ───────────────────────────────────────────────────


class ReportCreateDTO(BaseModel):
	"""Création d'un signalement."""

	reporter_id: str
	target_type: TargetTypeEnum
	target_id: str
	reason: ReportReasonEnum
	description: str | None = None


class ReportUpdateDTO(BaseModel):
	"""Mise à jour du statut d'un signalement (modération)."""

	status: ReportStatusEnum
	reviewed_by: str | None = None


class ReportResponseDTO(BaseModel):
	"""Réponse signalement."""

	id: str
	reporter_id: str
	target_type: str
	target_id: str
	reason: str
	description: str | None = None
	status: str
	reviewed_by: str | None = None
	created_at: datetime
	updated_at: datetime


# ─── Badges utilisateur ───────────────────────────────────────────────────────


class BadgeUserCreateDTO(BaseModel):
	"""Attribution d'un badge à un utilisateur."""

	user_id: str
	badge_name: str = Field(..., min_length=1, max_length=100)
	awarded_by: str | None = None


class BadgeUserResponseDTO(BaseModel):
	"""Réponse badge utilisateur."""

	id: str
	user_id: str
	badge_name: str
	awarded_at: str | None = None
	awarded_by: str | None = None
	created_at: datetime
	updated_at: datetime
