"""NOKIROVA — Service Communauté : Likes

Logique métier pour les réactions (likes) sur les publications :
- Toggle like (ajouter / retirer)
- Compteur de likes
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.community.dto import LikeResponseDTO
from src.services.community.repository import (
	LikeRepository,
	PostRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_LIKES = "community:likes"
CACHE_NS_POSTS = "community:posts"
EVENT_DOMAIN = "community"


# ─── Service Likes ────────────────────────────────────────────────────────────


class LikeService:
	"""Service métier pour les likes communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.post_repo = PostRepository(session)
		self.like_repo = LikeRepository(session)

	# ─── Toggle like ─────────────────────────────────────────────────────

	async def toggle_like(self, post_id: str, user_id: str) -> LikeResponseDTO:
		"""Ajoute ou retire un like sur une publication."""
		post = await self.post_repo.get_by_id(post_id)
		if post is None:
			raise NotFoundException("Publication introuvable")

		existing = await self.like_repo.find_by_user_and_post(user_id, post_id)
		liked: bool

		if existing:
			await self.like_repo.delete(existing.id)
			liked = False
			event_type = "post_unliked"
		else:
			await self.like_repo.create({"post_id": post_id, "user_id": user_id})
			liked = True
			event_type = "post_liked"

		await cache_manager.delete(CACHE_NS_LIKES, f"{user_id}:{post_id}")
		await cache_manager.delete(CACHE_NS_POSTS, post_id)

		await event_bus.publish(
			Event(
				event_type=event_type,
				domain=EVENT_DOMAIN,
				payload={"post_id": post_id, "user_id": user_id},
			)
		)

		return LikeResponseDTO(
			post_id=post_id,
			user_id=user_id,
			liked=liked,
		)

	# ─── Vérification ────────────────────────────────────────────────────

	async def is_liked(self, post_id: str, user_id: str) -> bool:
		"""Vérifie si l'utilisateur a liké la publication."""
		cached = await cache_manager.get(CACHE_NS_LIKES, f"{user_id}:{post_id}")
		if cached is not None:
			return bool(cached)

		result = await self.like_repo.find_by_user_and_post(user_id, post_id)
		liked = result is not None

		await cache_manager.set(CACHE_NS_LIKES, f"{user_id}:{post_id}", liked, ttl=300)
		return liked
