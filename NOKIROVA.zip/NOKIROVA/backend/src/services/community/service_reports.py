"""NOKIROVA — Service Communauté : Signalements

Logique métier pour les signalements de contenu :
- Signalement de publications/commentaires
- Résolution (approuver/rejeter)
- Historique et cache
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.community.dto import (
	ReportCreateDTO,
	ReportResolveDTO,
	ReportResponseDTO,
)
from src.services.community.repository import ReportRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_REPORTS = "community:reports"
EVENT_DOMAIN = "community"


# ─── Service Signalements ────────────────────────────────────────────────────


class ReportService:
	"""Service métier pour les signalements communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.report_repo = ReportRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_report(self, dto: ReportCreateDTO) -> ReportResponseDTO:
		"""Crée un signalement."""
		data = dto.model_dump(exclude_none=True)
		report = await self.report_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_REPORTS)

		await event_bus.publish(
			Event(
				event_type="content_reported",
				domain=EVENT_DOMAIN,
				payload={"report_id": report.id},
			)
		)

		return self._report_to_response(report)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_report(self, report_id: str) -> ReportResponseDTO:
		"""Récupère un signalement."""
		report = await self.report_repo.get_by_id(report_id)
		if report is None:
			raise NotFoundException("Signalement introuvable")

		return self._report_to_response(report)

	async def list_reports(
		self,
		status: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ReportResponseDTO]:
		"""Liste les signalements."""
		reports = await self.report_repo.list_reports(status, limit, offset)
		return [self._report_to_response(r) for r in reports]

	# ─── Résolution ──────────────────────────────────────────────────────

	async def resolve_report(
		self,
		report_id: str,
		moderator_id: str,
		dto: ReportResolveDTO,
	) -> ReportResponseDTO:
		"""Résout un signalement."""
		report = await self.report_repo.get_by_id(report_id)
		if report is None:
			raise NotFoundException("Signalement introuvable")

		data = {
			"status": dto.resolution,
			"resolved_by": moderator_id,
			"resolution_note": dto.note,
		}
		updated = await self.report_repo.update(report_id, data)

		await cache_manager.delete(CACHE_NS_REPORTS, report_id)

		await event_bus.publish(
			Event(
				event_type="report_resolved",
				domain=EVENT_DOMAIN,
				payload={"report_id": report_id, "resolution": dto.resolution},
			)
		)

		return self._report_to_response(updated)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _report_to_response(report) -> ReportResponseDTO:
		"""Convertit un modèle ContentReport en DTO de réponse."""
		return ReportResponseDTO(
			id=report.id,
			reporter_id=report.reporter_id,
			target_type=report.target_type,
			target_id=report.target_id,
			reason=report.reason,
			description=report.description,
			status=report.status,
			resolved_by=report.resolved_by,
			resolution_note=report.resolution_note,
			created_at=report.created_at,
			resolved_at=report.resolved_at,
		)
