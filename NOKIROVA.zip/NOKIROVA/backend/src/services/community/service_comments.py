"""NOKIROVA — Service Communauté : Commentaires

Logique métier pour les commentaires sur les publications :
- CRUD commentaires
- Réponses imbriquées (parent_id)
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.community.dto import (
	CommentCreateDTO,
	CommentResponseDTO,
	CommentUpdateDTO,
)
from src.services.community.repository import (
	CommentRepository,
	PostRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_COMMENTS = "community:comments"
CACHE_NS_POSTS = "community:posts"
EVENT_DOMAIN = "community"


# ─── Service Commentaires ─────────────────────────────────────────────────────


class CommentService:
	"""Service métier pour les commentaires communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.post_repo = PostRepository(session)
		self.comment_repo = CommentRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_comment(self, dto: CommentCreateDTO) -> CommentResponseDTO:
		"""Crée un commentaire."""
		post = await self.post_repo.get_by_id(dto.post_id)
		if post is None:
			raise NotFoundException("Publication introuvable")
		if post.is_locked:
			raise ValidationException("post_id", "Cette publication est verrouillée")

		if dto.parent_id:
			parent = await self.comment_repo.get_by_id(dto.parent_id)
			if parent is None or parent.post_id != dto.post_id:
				raise NotFoundException("Commentaire parent introuvable")

		data = dto.model_dump(exclude_none=True)
		comment = await self.comment_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_COMMENTS)

		await event_bus.publish(
			Event(
				event_type="comment_created",
				domain=EVENT_DOMAIN,
				payload={"comment_id": comment.id, "post_id": dto.post_id},
			)
		)

		return self._comment_to_response(comment)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def list_comments(
		self,
		post_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[CommentResponseDTO]:
		"""Liste les commentaires d'une publication."""
		comments = await self.comment_repo.list_by_post(post_id, limit, offset)
		return [self._comment_to_response(c) for c in comments]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_comment(
		self,
		comment_id: str,
		user_id: str,
		dto: CommentUpdateDTO,
	) -> CommentResponseDTO:
		"""Met à jour un commentaire."""
		comment = await self.comment_repo.get_by_id(comment_id)
		if comment is None:
			raise NotFoundException("Commentaire introuvable")
		if comment.author_id != user_id:
			raise ForbiddenException("Seul l'auteur peut modifier ce commentaire")

		data = dto.model_dump()
		data["is_edited"] = True
		updated = await self.comment_repo.update(comment_id, data)

		await cache_manager.delete(CACHE_NS_COMMENTS, comment_id)

		return self._comment_to_response(updated)

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_comment(
		self,
		comment_id: str,
		user_id: str,
	) -> bool:
		"""Supprime un commentaire."""
		comment = await self.comment_repo.get_by_id(comment_id)
		if comment is None:
			raise NotFoundException("Commentaire introuvable")
		if comment.author_id != user_id:
			raise ForbiddenException("Seul l'auteur peut supprimer ce commentaire")

		success = await self.comment_repo.delete(comment_id)
		if success:
			await cache_manager.delete(CACHE_NS_COMMENTS, comment_id)
			await cache_manager.delete(CACHE_NS_POSTS, comment.post_id)

		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _comment_to_response(comment) -> CommentResponseDTO:
		"""Convertit un modèle CommunityComment en DTO de réponse."""
		return CommentResponseDTO(
			id=comment.id,
			post_id=comment.post_id,
			author_id=comment.author_id,
			parent_id=comment.parent_id,
			content=comment.content,
			is_edited=comment.is_edited,
			created_at=comment.created_at,
			updated_at=comment.updated_at,
		)
