"""NOKIROVA — Depot Community

Acces aux donnees pour les publications, commentaires, likes,
groupes, evenements, signalements et badges utilisateur.
Utilise les modeles SQLAlchemy reels de community.py.

Refactorisation :
    Post, Group — Categorie (b) : heritage + soft_delete -> bool
    Comment, Like, Event, BadgeUser — Categorie (d) : suppression dure
    Report — Categorie (e) : pas de soft_delete
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.community import (
	CommunityBadgeUser,
	CommunityComment,
	CommunityEvent,
	CommunityGroup,
	CommunityLike,
	CommunityPost,
	CommunityReport,
)

# ─── Publications (Posts) — Categorie (b) ──────────────────────────────────────


class PostRepository(BaseRepository[CommunityPost]):
	"""Depot pour les publications.

	Herite de BaseRepository[CommunityPost].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityPost, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, post_id: str) -> bool:
		"""Suppression logique d'une publication."""
		result = await super().soft_delete(post_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_posts(
		self,
		category: str | None = None,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityPost]:
		"""Liste les publications avec filtres."""
		conditions = []
		if category:
			conditions.append(CommunityPost.category == category)
		if group_id:
			conditions.append(CommunityPost.group_id == group_id)

		stmt = (
			select(CommunityPost)
			.where(and_(*conditions) if conditions else True)
			.order_by(
				CommunityPost.is_pinned.desc(),
				CommunityPost.created_at.desc(),
			)
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def list_by_author(
		self,
		author_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityPost]:
		"""Liste les publications d'un auteur."""
		stmt = (
			select(CommunityPost)
			.where(CommunityPost.author_id == author_id)
			.order_by(CommunityPost.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def increment_view_count(self, post_id: str) -> None:
		"""Incremente le compteur de vues."""
		post = await self.get_by_id(post_id)
		if post is not None:
			post.view_count = (post.view_count or 0) + 1
			await self.session.flush()

	async def count_comments(self, post_id: str) -> int:
		"""Compte les commentaires d'une publication."""
		stmt = select(func.count(CommunityComment.id)).where(CommunityComment.post_id == post_id)
		result = await self.session.execute(stmt)
		return result.scalar_one()

	async def count_likes(self, post_id: str) -> int:
		"""Compte les likes d'une publication."""
		stmt = select(func.count(CommunityLike.id)).where(CommunityLike.post_id == post_id)
		result = await self.session.execute(stmt)
		return result.scalar_one()


# ─── Commentaires — Categorie (d) : suppression dure ──────────────────────────


class CommentRepository(BaseRepository[CommunityComment]):
	"""Depot pour les commentaires.

	Herite de BaseRepository[CommunityComment] pour create/get/update.
	Utilise une suppression dure (session.delete) — ne pas utiliser
	soft_delete/restore herites.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityComment, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_post(
		self,
		post_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityComment]:
		"""Liste les commentaires d'une publication."""
		stmt = (
			select(CommunityComment)
			.where(CommunityComment.post_id == post_id)
			.order_by(CommunityComment.created_at.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def update(self, comment_id: str, data: dict) -> CommunityComment | None:
		"""Met a jour un commentaire (autorise les valeurs None)."""
		comment = await self.get_by_id(comment_id)
		if comment is None:
			return None
		for key, value in data.items():
			if hasattr(comment, key):
				setattr(comment, key, value)
		await self.session.flush()
		return comment

	async def delete(self, comment_id: str) -> bool:
		"""Supprime un commentaire (suppression dure)."""
		comment = await self.get_by_id(comment_id)
		if comment is None:
			return False
		await self.session.delete(comment)
		await self.session.flush()
		return True


# ─── Likes / Reactions — Categorie (d) : suppression dure ─────────────────────


class LikeRepository(BaseRepository[CommunityLike]):
	"""Depot pour les likes/reactions.

	Herite de BaseRepository[CommunityLike] pour create/get.
	Utilise une suppression dure — ne pas utiliser soft_delete/restore.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityLike, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_post_and_user(
		self,
		post_id: str,
		user_id: str,
	) -> CommunityLike | None:
		"""Recupere un like par publication et utilisateur."""
		stmt = select(CommunityLike).where(
			and_(
				CommunityLike.post_id == post_id,
				CommunityLike.user_id == user_id,
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def list_by_post(
		self,
		post_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[CommunityLike]:
		"""Liste les likes d'une publication."""
		stmt = (
			select(CommunityLike)
			.where(CommunityLike.post_id == post_id)
			.order_by(CommunityLike.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def delete(self, like_id: str) -> bool:
		"""Supprime un like (suppression dure)."""
		like = await self.get_by_id(like_id)
		if like is None:
			return False
		await self.session.delete(like)
		await self.session.flush()
		return True


# ─── Groupes — Categorie (b) : soft_delete -> bool ───────────────────────────


class GroupRepository(BaseRepository[CommunityGroup]):
	"""Depot pour les groupes.

	Herite de BaseRepository[CommunityGroup].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityGroup, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, group_id: str) -> bool:
		"""Suppression logique d'un groupe."""
		result = await super().soft_delete(group_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_groups(
		self,
		group_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityGroup]:
		"""Liste les groupes."""
		conditions = []
		if group_type:
			conditions.append(CommunityGroup.group_type == group_type)

		stmt = (
			select(CommunityGroup)
			.where(and_(*conditions) if conditions else True)
			.order_by(CommunityGroup.member_count.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Evenements — Categorie (d) : suppression dure ────────────────────────────


class EventRepository(BaseRepository[CommunityEvent]):
	"""Depot pour les evenements.

	Herite de BaseRepository[CommunityEvent] pour create/get/update.
	Utilise une suppression dure — ne pas utiliser soft_delete/restore.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityEvent, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_events(
		self,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityEvent]:
		"""Liste les evenements."""
		conditions = []
		if group_id:
			conditions.append(CommunityEvent.group_id == group_id)

		stmt = (
			select(CommunityEvent)
			.where(and_(*conditions) if conditions else True)
			.order_by(CommunityEvent.starts_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def list_by_organizer(
		self,
		organizer_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityEvent]:
		"""Liste les evenements organises par un utilisateur."""
		stmt = (
			select(CommunityEvent)
			.where(CommunityEvent.organizer_id == organizer_id)
			.order_by(CommunityEvent.starts_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def delete(self, event_id: str) -> bool:
		"""Supprime un evenement (suppression dure)."""
		event = await self.get_by_id(event_id)
		if event is None:
			return False
		await self.session.delete(event)
		await self.session.flush()
		return True


# ─── Signalements (Reports) — Categorie (e) : pas de soft_delete ──────────────


class ReportRepository(BaseRepository[CommunityReport]):
	"""Depot pour les signalements.

	Herite de BaseRepository[CommunityReport] pour create/get/update.
	Pas de soft_delete — les signalements ne sont jamais supprimes logiquement.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityReport, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_reports(
		self,
		status: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[CommunityReport]:
		"""Liste les signalements."""
		conditions = []
		if status:
			conditions.append(CommunityReport.status == status)

		stmt = (
			select(CommunityReport)
			.where(and_(*conditions) if conditions else True)
			.order_by(CommunityReport.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Badges utilisateur — Categorie (d) : suppression dure ────────────────────


class BadgeUserRepository(BaseRepository[CommunityBadgeUser]):
	"""Depot pour les badges utilisateur.

	Herite de BaseRepository[CommunityBadgeUser] pour create/get.
	Utilise une suppression dure — ne pas utiliser soft_delete/restore.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(CommunityBadgeUser, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_user(
		self,
		user_id: str,
	) -> Sequence[CommunityBadgeUser]:
		"""Liste les badges d'un utilisateur."""
		stmt = (
			select(CommunityBadgeUser)
			.where(CommunityBadgeUser.user_id == user_id)
			.order_by(CommunityBadgeUser.awarded_at.desc())
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def delete(self, badge_id: str) -> bool:
		"""Supprime un badge utilisateur (suppression dure)."""
		badge = await self.get_by_id(badge_id)
		if badge is None:
			return False
		await self.session.delete(badge)
		await self.session.flush()
		return True
