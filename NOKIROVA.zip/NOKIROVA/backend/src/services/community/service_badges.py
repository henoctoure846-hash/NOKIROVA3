"""NOKIROVA — Service Communauté : Badges

Logique métier pour les badges communautaires :
- Attribution de badges
- Consultation des badges utilisateur
- Cache
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.events.bus import Event, event_bus
from src.services.community.dto import BadgeResponseDTO, UserBadgeResponseDTO
from src.services.community.repository import (
	BadgeRepository,
	UserBadgeRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_BADGES = "community:badges"
EVENT_DOMAIN = "community"


# ─── Service Badges ───────────────────────────────────────────────────────────


class BadgeService:
	"""Service métier pour les badges communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.badge_repo = BadgeRepository(session)
		self.user_badge_repo = UserBadgeRepository(session)

	# ─── Attribution ─────────────────────────────────────────────────────

	async def award_badge(
		self,
		user_id: str,
		badge_id: str,
	) -> UserBadgeResponseDTO:
		"""Attribue un badge à un utilisateur."""
		badge = await self.badge_repo.get_by_id(badge_id)
		if badge is None:
			raise ValueError("Badge introuvable")

		existing = await self.user_badge_repo.find_by_user_and_badge(user_id, badge_id)
		if existing:
			return self._user_badge_to_response(existing)

		user_badge = await self.user_badge_repo.create(
			{
				"user_id": user_id,
				"badge_id": badge_id,
			}
		)

		await cache_manager.invalidate_namespace(CACHE_NS_BADGES)

		await event_bus.publish(
			Event(
				event_type="badge_awarded",
				domain=EVENT_DOMAIN,
				payload={"user_id": user_id, "badge_id": badge_id},
			)
		)

		return self._user_badge_to_response(user_badge)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def list_user_badges(
		self,
		user_id: str,
	) -> list[UserBadgeResponseDTO]:
		"""Liste les badges d'un utilisateur."""
		cached = await cache_manager.get(CACHE_NS_BADGES, f"user:{user_id}")
		if cached:
			return [UserBadgeResponseDTO(**b) for b in cached]

		badges = await self.user_badge_repo.list_by_user(user_id)
		result = [self._user_badge_to_response(b) for b in badges]

		await cache_manager.set(
			CACHE_NS_BADGES,
			f"user:{user_id}",
			[b.model_dump(mode="json") for b in result],
			ttl=600,
		)
		return result

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _badge_to_response(badge) -> BadgeResponseDTO:
		"""Convertit un modèle CommunityBadge en DTO de réponse."""
		return BadgeResponseDTO(
			id=badge.id,
			name=badge.name,
			description=badge.description,
			icon_url=badge.icon_url,
			category=badge.category,
			rarity=badge.rarity,
			created_at=badge.created_at,
		)

	@staticmethod
	def _user_badge_to_response(user_badge) -> UserBadgeResponseDTO:
		"""Convertit un modèle UserBadge en DTO de réponse."""
		return UserBadgeResponseDTO(
			id=user_badge.id,
			user_id=user_badge.user_id,
			badge_id=user_badge.badge_id,
			awarded_at=user_badge.awarded_at,
		)
