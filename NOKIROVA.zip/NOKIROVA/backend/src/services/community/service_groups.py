"""NOKIROVA — Service Communauté : Groupes

Logique métier pour les groupes communautaires :
- CRUD groupes
- Adhésion (join/leave)
- Rôles au sein du groupe
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import (
	ConflictException,
	ForbiddenException,
	NotFoundException,
)
from src.events.bus import Event, event_bus
from src.services.community.dto import (
	GroupCreateDTO,
	GroupMemberResponseDTO,
	GroupResponseDTO,
	GroupUpdateDTO,
)
from src.services.community.repository import (
	GroupMemberRepository,
	GroupRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_GROUPS = "community:groups"
EVENT_DOMAIN = "community"

ROLE_OWNER = "owner"
ROLE_ADMIN = "admin"
ROLE_MODERATOR = "moderator"
ROLE_MEMBER = "member"


# ─── Service Groupes ──────────────────────────────────────────────────────────


class GroupService:
	"""Service métier pour les groupes communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.group_repo = GroupRepository(session)
		self.member_repo = GroupMemberRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_group(self, dto: GroupCreateDTO) -> GroupResponseDTO:
		"""Crée un groupe."""
		data = dto.model_dump(exclude_none=True)
		group = await self.group_repo.create(data)

		# Le créateur devient propriétaire
		await self.member_repo.create(
			{
				"group_id": group.id,
				"user_id": dto.creator_id,
				"role": ROLE_OWNER,
			}
		)

		await cache_manager.invalidate_namespace(CACHE_NS_GROUPS)

		await event_bus.publish(
			Event(
				event_type="group_created",
				domain=EVENT_DOMAIN,
				payload={"group_id": group.id},
			)
		)

		return self._group_to_response(group)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_group(self, group_id: str) -> GroupResponseDTO:
		"""Récupère un groupe."""
		cached = await cache_manager.get(CACHE_NS_GROUPS, group_id)
		if cached:
			return GroupResponseDTO(**cached)

		group = await self.group_repo.get_by_id(group_id)
		if group is None:
			raise NotFoundException("Groupe introuvable")

		response = self._group_to_response(group)
		await cache_manager.set(CACHE_NS_GROUPS, group_id, response.model_dump(mode="json"), ttl=600)
		return response

	async def list_groups(
		self,
		visibility: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[GroupResponseDTO]:
		"""Liste les groupes."""
		groups = await self.group_repo.list_groups(visibility, limit, offset)
		return [self._group_to_response(g) for g in groups]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_group(
		self,
		group_id: str,
		user_id: str,
		dto: GroupUpdateDTO,
	) -> GroupResponseDTO:
		"""Met à jour un groupe."""
		group = await self.group_repo.get_by_id(group_id)
		if group is None:
			raise NotFoundException("Groupe introuvable")

		membership = await self.member_repo.find_by_user_and_group(user_id, group_id)
		if membership is None or membership.role not in (ROLE_OWNER, ROLE_ADMIN):
			raise ForbiddenException("Droits insuffisants pour modifier ce groupe")

		data = dto.model_dump(exclude_none=True)
		updated = await self.group_repo.update(group_id, data)

		await cache_manager.delete(CACHE_NS_GROUPS, group_id)

		return self._group_to_response(updated)

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_group(self, group_id: str, user_id: str) -> bool:
		"""Supprime un groupe."""
		group = await self.group_repo.get_by_id(group_id)
		if group is None:
			raise NotFoundException("Groupe introuvable")

		membership = await self.member_repo.find_by_user_and_group(user_id, group_id)
		if membership is None or membership.role != ROLE_OWNER:
			raise ForbiddenException("Seul le propriétaire peut supprimer ce groupe")

		success = await self.group_repo.soft_delete(group_id)
		if success:
			await cache_manager.delete(CACHE_NS_GROUPS, group_id)

		return success

	# ─── Adhésion ─────────────────────────────────────────────────────────

	async def join_group(self, group_id: str, user_id: str) -> GroupMemberResponseDTO:
		"""Rejoint un groupe."""
		group = await self.group_repo.get_by_id(group_id)
		if group is None:
			raise NotFoundException("Groupe introuvable")

		existing = await self.member_repo.find_by_user_and_group(user_id, group_id)
		if existing:
			raise ConflictException("Déjà membre de ce groupe")

		member = await self.member_repo.create(
			{
				"group_id": group_id,
				"user_id": user_id,
				"role": ROLE_MEMBER,
			}
		)

		await cache_manager.invalidate_namespace(CACHE_NS_GROUPS)

		await event_bus.publish(
			Event(
				event_type="group_joined",
				domain=EVENT_DOMAIN,
				payload={"group_id": group_id, "user_id": user_id},
			)
		)

		return self._member_to_response(member)

	async def leave_group(self, group_id: str, user_id: str) -> bool:
		"""Quitte un groupe."""
		membership = await self.member_repo.find_by_user_and_group(user_id, group_id)
		if membership is None:
			raise NotFoundException("Non membre de ce groupe")
		if membership.role == ROLE_OWNER:
			raise ForbiddenException("Le propriétaire ne peut pas quitter le groupe")

		success = await self.member_repo.delete(membership.id)
		if success:
			await cache_manager.invalidate_namespace(CACHE_NS_GROUPS)

		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _group_to_response(group) -> GroupResponseDTO:
		"""Convertit un modèle CommunityGroup en DTO de réponse."""
		return GroupResponseDTO(
			id=group.id,
			name=group.name,
			description=group.description,
			visibility=group.visibility,
			rules=group.rules,
			icon_url=group.icon_url,
			creator_id=group.creator_id,
			created_at=group.created_at,
			updated_at=group.updated_at,
		)

	@staticmethod
	def _member_to_response(member) -> GroupMemberResponseDTO:
		"""Convertit un modèle GroupMember en DTO de réponse."""
		return GroupMemberResponseDTO(
			id=member.id,
			group_id=member.group_id,
			user_id=member.user_id,
			role=member.role,
			joined_at=member.joined_at,
		)
