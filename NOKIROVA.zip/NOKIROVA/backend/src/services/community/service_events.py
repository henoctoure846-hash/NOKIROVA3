"""NOKIROVA — Service Communauté : Événements

Logique métier pour les événements de groupe :
- CRUD événements
- Inscriptions (RSVP)
- Cache et événements bus
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import (
	ForbiddenException,
	NotFoundException,
)
from src.events.bus import Event, event_bus
from src.services.community.dto import (
	EventCreateDTO,
	EventResponseDTO,
	EventUpdateDTO,
	RSVPResponseDTO,
)
from src.services.community.repository import (
	EventRepository,
	RSVPRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_EVENTS = "community:events"
EVENT_DOMAIN = "community"


# ─── Service Événements ───────────────────────────────────────────────────────


class EventService:
	"""Service métier pour les événements communautaires."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.event_repo = EventRepository(session)
		self.rsvp_repo = RSVPRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_event(self, dto: EventCreateDTO) -> EventResponseDTO:
		"""Crée un événement."""
		data = dto.model_dump(exclude_none=True)
		event = await self.event_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_EVENTS)

		await event_bus.publish(
			Event(
				event_type="event_created",
				domain=EVENT_DOMAIN,
				payload={"event_id": event.id},
			)
		)

		return self._event_to_response(event)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_event(self, event_id: str) -> EventResponseDTO:
		"""Récupère un événement."""
		cached = await cache_manager.get(CACHE_NS_EVENTS, event_id)
		if cached:
			return EventResponseDTO(**cached)

		event = await self.event_repo.get_by_id(event_id)
		if event is None:
			raise NotFoundException("Événement introuvable")

		response = self._event_to_response(event)
		await cache_manager.set(CACHE_NS_EVENTS, event_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_events(
		self,
		group_id: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[EventResponseDTO]:
		"""Liste les événements."""
		events = await self.event_repo.list_events(group_id, limit, offset)
		return [self._event_to_response(e) for e in events]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_event(
		self,
		event_id: str,
		user_id: str,
		dto: EventUpdateDTO,
	) -> EventResponseDTO:
		"""Met à jour un événement."""
		event = await self.event_repo.get_by_id(event_id)
		if event is None:
			raise NotFoundException("Événement introuvable")
		if event.organizer_id != user_id:
			raise ForbiddenException("Seul l'organisateur peut modifier cet événement")

		data = dto.model_dump(exclude_none=True)
		updated = await self.event_repo.update(event_id, data)

		await cache_manager.delete(CACHE_NS_EVENTS, event_id)

		return self._event_to_response(updated)

	# ─── Suppression ─────────────────────────────────────────────────────

	async def delete_event(self, event_id: str, user_id: str) -> bool:
		"""Supprime un événement."""
		event = await self.event_repo.get_by_id(event_id)
		if event is None:
			raise NotFoundException("Événement introuvable")
		if event.organizer_id != user_id:
			raise ForbiddenException("Seul l'organisateur peut supprimer cet événement")

		success = await self.event_repo.delete(event_id)
		if success:
			await cache_manager.delete(CACHE_NS_EVENTS, event_id)

		return success

	# ─── Inscriptions (RSVP) ────────────────────────────────────────────

	async def rsvp(self, event_id: str, user_id: str, status: str) -> RSVPResponseDTO:
		"""Inscrit ou met à jour l'inscription d'un utilisateur."""
		event = await self.event_repo.get_by_id(event_id)
		if event is None:
			raise NotFoundException("Événement introuvable")

		existing = await self.rsvp_repo.find_by_user_and_event(user_id, event_id)
		if existing:
			updated = await self.rsvp_repo.update(existing.id, {"status": status})
			return self._rsvp_to_response(updated)

		rsvp = await self.rsvp_repo.create(
			{
				"event_id": event_id,
				"user_id": user_id,
				"status": status,
			}
		)

		await event_bus.publish(
			Event(
				event_type="event_rsvp",
				domain=EVENT_DOMAIN,
				payload={"event_id": event_id, "user_id": user_id, "status": status},
			)
		)

		return self._rsvp_to_response(rsvp)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _event_to_response(event) -> EventResponseDTO:
		"""Convertit un modèle CommunityEvent en DTO de réponse."""
		return EventResponseDTO(
			id=event.id,
			group_id=event.group_id,
			organizer_id=event.organizer_id,
			title=event.title,
			description=event.description,
			event_type=event.event_type,
			location=event.location,
			start_time=event.start_time,
			end_time=event.end_time,
			max_attendees=event.max_attendees,
			metadata_json=event.metadata_json,
			created_at=event.created_at,
			updated_at=event.updated_at,
		)

	@staticmethod
	def _rsvp_to_response(rsvp) -> RSVPResponseDTO:
		"""Convertit un modèle EventRSVP en DTO de réponse."""
		return RSVPResponseDTO(
			id=rsvp.id,
			event_id=rsvp.event_id,
			user_id=rsvp.user_id,
			status=rsvp.status,
			created_at=rsvp.created_at,
		)
