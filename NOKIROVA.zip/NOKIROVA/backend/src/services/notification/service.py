"""NOKIROVA — Service Notification

Logique métier pour les notifications, préférences et canaux.

Corrections clés :
- event_bus.publish(Event(event_type=, domain=, payload=))
- cache_manager.get(ns, key) / .set(ns, key, value, ttl) / .delete(ns, key) / .invalidate_namespace(ns)
- Exceptions : NotFoundException, ForbiddenException, ValidationException
- Notification : notification_type (pas type), priority, is_read, is_dismissed,
  delivery_channels/delivery_status (JSONB), metadata_json
- NotificationPreference : user_id (unique), tous les *_enabled, quiet_hours, digest_frequency
- NotificationChannel : channel_type, channel_address, is_verified, is_active,
  verification_code, config (JSONB)
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.notification.dto import (
	ChannelCreateDTO,
	ChannelResponseDTO,
	ChannelVerifyDTO,
	NotificationCreateDTO,
	NotificationResponseDTO,
	PreferenceResponseDTO,
	PreferenceUpdateDTO,
	UnreadCountDTO,
)
from src.services.notification.repository import (
	ChannelRepository,
	NotificationRepository,
	PreferenceRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_NOTIFICATIONS = "notification:notifications"
CACHE_NS_PREFERENCES = "notification:preferences"
CACHE_NS_CHANNELS = "notification:channels"
EVENT_DOMAIN = "notification"


# ─── Service principal ────────────────────────────────────────────────────────


class NotificationService:
	"""Service métier pour les notifications."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.notification_repo = NotificationRepository(session)
		self.preference_repo = PreferenceRepository(session)
		self.channel_repo = ChannelRepository(session)

	# ─── Notifications ───────────────────────────────────────────────────────

	async def create_notification(
		self,
		dto: NotificationCreateDTO,
	) -> NotificationResponseDTO:
		"""Crée une nouvelle notification."""
		data = dto.model_dump(exclude_none=True)

		# Convertir les delivery_channels en liste JSONB si fournie
		if dto.delivery_channels:
			data["delivery_channels"] = dto.delivery_channels

		notification = await self.notification_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_NOTIFICATIONS)

		await event_bus.publish(
			Event(
				event_type="notification_created",
				domain=EVENT_DOMAIN,
				payload={
					"notification_id": notification.id,
					"user_id": notification.user_id,
					"notification_type": notification.notification_type,
				},
			)
		)

		return self._notification_to_response(notification)

	async def get_notification(
		self,
		notification_id: str,
		user_id: str,
	) -> NotificationResponseDTO:
		"""Récupère une notification par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_NOTIFICATIONS, notification_id)
		if cached:
			return NotificationResponseDTO(**cached)

		notification = await self.notification_repo.get_by_id(notification_id)
		if notification is None:
			raise NotFoundException("Notification introuvable")
		if notification.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à cette notification")

		response = self._notification_to_response(notification)
		await cache_manager.set(
			CACHE_NS_NOTIFICATIONS, notification_id, response.model_dump(mode="json"), ttl=300
		)
		return response

	async def list_notifications(
		self,
		user_id: str,
		is_read: bool | None = None,
		is_dismissed: bool | None = None,
		notification_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[NotificationResponseDTO]:
		"""Liste les notifications d'un utilisateur avec filtres."""
		notifications = await self.notification_repo.get_by_user(
			user_id=user_id,
			is_read=is_read,
			is_dismissed=is_dismissed,
			notification_type=notification_type,
			limit=limit,
			offset=offset,
		)
		return [self._notification_to_response(n) for n in notifications]

	async def get_unread_count(self, user_id: str) -> UnreadCountDTO:
		"""Compte les notifications non lues."""
		count = await self.notification_repo.count_unread(user_id)
		return UnreadCountDTO(count=count)

	async def mark_as_read(
		self,
		notification_id: str,
		user_id: str,
	) -> NotificationResponseDTO:
		"""Marque une notification comme lue."""
		notification = await self.notification_repo.get_by_id(notification_id)
		if notification is None:
			raise NotFoundException("Notification introuvable")
		if notification.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à cette notification")

		updated = await self.notification_repo.mark_as_read(notification_id)
		await cache_manager.delete(CACHE_NS_NOTIFICATIONS, notification_id)

		return self._notification_to_response(updated)

	async def mark_all_as_read(self, user_id: str) -> int:
		"""Marque toutes les notifications d'un utilisateur comme lues."""
		count = await self.notification_repo.mark_all_as_read(user_id)
		await cache_manager.invalidate_namespace(CACHE_NS_NOTIFICATIONS)

		await event_bus.publish(
			Event(
				event_type="notifications_all_read",
				domain=EVENT_DOMAIN,
				payload={"user_id": user_id, "count": count},
			)
		)

		return count

	async def dismiss_notification(
		self,
		notification_id: str,
		user_id: str,
	) -> NotificationResponseDTO:
		"""Rejette une notification."""
		notification = await self.notification_repo.get_by_id(notification_id)
		if notification is None:
			raise NotFoundException("Notification introuvable")
		if notification.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à cette notification")

		updated = await self.notification_repo.dismiss(notification_id)
		await cache_manager.delete(CACHE_NS_NOTIFICATIONS, notification_id)

		return self._notification_to_response(updated)

	async def delete_notification(
		self,
		notification_id: str,
		user_id: str,
	) -> bool:
		"""Supprime une notification."""
		notification = await self.notification_repo.get_by_id(notification_id)
		if notification is None:
			raise NotFoundException("Notification introuvable")
		if notification.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à cette notification")

		success = await self.notification_repo.delete(notification_id)
		if success:
			await cache_manager.delete(CACHE_NS_NOTIFICATIONS, notification_id)
			await event_bus.publish(
				Event(
					event_type="notification_deleted",
					domain=EVENT_DOMAIN,
					payload={"notification_id": notification_id},
				)
			)
		return success

	# ─── Préférences ─────────────────────────────────────────────────────────

	async def get_preferences(self, user_id: str) -> PreferenceResponseDTO:
		"""Récupère les préférences de notification d'un utilisateur."""
		cached = await cache_manager.get(CACHE_NS_PREFERENCES, user_id)
		if cached:
			return PreferenceResponseDTO(**cached)

		pref = await self.preference_repo.get_or_create(user_id)

		response = self._preference_to_response(pref)
		await cache_manager.set(CACHE_NS_PREFERENCES, user_id, response.model_dump(mode="json"), ttl=600)
		return response

	async def update_preferences(
		self,
		user_id: str,
		dto: PreferenceUpdateDTO,
	) -> PreferenceResponseDTO:
		"""Met à jour les préférences de notification d'un utilisateur."""
		data = dto.model_dump(exclude_none=True)
		updated = await self.preference_repo.update(user_id, data)
		if updated is None:
			raise NotFoundException("Préférences introuvables")

		await cache_manager.delete(CACHE_NS_PREFERENCES, user_id)

		await event_bus.publish(
			Event(
				event_type="preferences_updated",
				domain=EVENT_DOMAIN,
				payload={"user_id": user_id},
			)
		)

		return self._preference_to_response(updated)

	# ─── Canaux ───────────────────────────────────────────────────────────────

	async def create_channel(
		self,
		dto: ChannelCreateDTO,
	) -> ChannelResponseDTO:
		"""Crée un nouveau canal de notification."""
		# Vérifier qu'un canal du même type n'existe pas déjà
		existing = await self.channel_repo.get_by_user(dto.user_id, dto.channel_type.value)
		if existing:
			raise ValidationException(
				"channel_type",
				f"Un canal de type {dto.channel_type.value} existe déjà pour cet utilisateur",
			)

		data = dto.model_dump(exclude_none=True)
		channel = await self.channel_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_CHANNELS)

		await event_bus.publish(
			Event(
				event_type="channel_created",
				domain=EVENT_DOMAIN,
				payload={"channel_id": channel.id, "user_id": channel.user_id},
			)
		)

		return self._channel_to_response(channel)

	async def list_channels(
		self,
		user_id: str,
		channel_type: str | None = None,
	) -> list[ChannelResponseDTO]:
		"""Liste les canaux de notification d'un utilisateur."""
		channels = await self.channel_repo.get_by_user(user_id, channel_type)
		return [self._channel_to_response(c) for c in channels]

	async def verify_channel(
		self,
		channel_id: str,
		user_id: str,
		dto: ChannelVerifyDTO,
	) -> ChannelResponseDTO:
		"""Vérifie un canal de notification."""
		channel = await self.channel_repo.get_by_id(channel_id)
		if channel is None:
			raise NotFoundException("Canal introuvable")
		if channel.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à ce canal")

		verified = await self.channel_repo.verify(channel_id, dto.verification_code)
		if verified is None:
			raise ValidationException("verification_code", "Code de vérification invalide")

		await cache_manager.delete(CACHE_NS_CHANNELS, channel_id)

		await event_bus.publish(
			Event(
				event_type="channel_verified",
				domain=EVENT_DOMAIN,
				payload={"channel_id": channel_id},
			)
		)

		return self._channel_to_response(verified)

	# Alias conformes à la BIBLE
	async def add_channel(
		self,
		dto: ChannelCreateDTO,
	) -> ChannelResponseDTO:
		"""Alias pour create_channel — ajoute un canal de notification."""
		return await self.create_channel(dto)

	async def remove_channel(
		self,
		channel_id: str,
		user_id: str,
	) -> bool:
		"""Alias pour delete_channel — supprime un canal de notification."""
		return await self.delete_channel(channel_id, user_id)

	async def delete_channel(
		self,
		channel_id: str,
		user_id: str,
	) -> bool:
		"""Supprime logiquement un canal de notification."""
		channel = await self.channel_repo.get_by_id(channel_id)
		if channel is None:
			raise NotFoundException("Canal introuvable")
		if channel.user_id != user_id:
			raise ForbiddenException("Accès non autorisé à ce canal")

		success = await self.channel_repo.soft_delete(channel_id)
		if success:
			await cache_manager.delete(CACHE_NS_CHANNELS, channel_id)
			await event_bus.publish(
				Event(
					event_type="channel_deleted",
					domain=EVENT_DOMAIN,
					payload={"channel_id": channel_id},
				)
			)
		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────────

	@staticmethod
	def _notification_to_response(notification) -> NotificationResponseDTO:
		"""Convertit un modèle Notification en DTO de réponse."""
		return NotificationResponseDTO(
			id=notification.id,
			user_id=notification.user_id,
			notification_type=notification.notification_type,
			title=notification.title,
			message=notification.message,
			icon=notification.icon,
			action_url=notification.action_url,
			action_text=notification.action_text,
			resource_type=notification.resource_type,
			resource_id=notification.resource_id,
			sender_id=notification.sender_id,
			priority=notification.priority,
			is_read=notification.is_read,
			is_dismissed=notification.is_dismissed,
			read_at=notification.read_at,
			delivery_channels=notification.delivery_channels,
			delivery_status=notification.delivery_status,
			scheduled_at=notification.scheduled_at,
			expires_at=notification.expires_at,
			metadata_json=notification.metadata_json,
			created_at=notification.created_at,
			updated_at=notification.updated_at,
		)

	@staticmethod
	def _preference_to_response(pref) -> PreferenceResponseDTO:
		"""Convertit un modèle NotificationPreference en DTO de réponse."""
		return PreferenceResponseDTO(
			id=pref.id,
			user_id=pref.user_id,
			achievement_enabled=pref.achievement_enabled,
			reminder_enabled=pref.reminder_enabled,
			social_enabled=pref.social_enabled,
			system_enabled=pref.system_enabled,
			ai_enabled=pref.ai_enabled,
			revision_enabled=pref.revision_enabled,
			course_enabled=pref.course_enabled,
			marketing_enabled=pref.marketing_enabled,
			push_enabled=pref.push_enabled,
			email_enabled=pref.email_enabled,
			sms_enabled=pref.sms_enabled,
			quiet_hours_start=pref.quiet_hours_start,
			quiet_hours_end=pref.quiet_hours_end,
			digest_frequency=pref.digest_frequency,
			preferred_language=pref.preferred_language,
			created_at=pref.created_at,
			updated_at=pref.updated_at,
		)

	@staticmethod
	def _channel_to_response(channel) -> ChannelResponseDTO:
		"""Convertit un modèle NotificationChannel en DTO de réponse."""
		return ChannelResponseDTO(
			id=channel.id,
			user_id=channel.user_id,
			channel_type=channel.channel_type,
			channel_address=channel.channel_address,
			is_verified=channel.is_verified,
			is_active=channel.is_active,
			verification_code=channel.verification_code,
			config=channel.config,
			created_at=channel.created_at,
			updated_at=channel.updated_at,
		)
