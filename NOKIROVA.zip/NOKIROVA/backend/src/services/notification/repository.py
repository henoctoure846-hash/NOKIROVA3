"""NOKIROVA — Depot Notification

Acces aux donnees pour les notifications, preferences et canaux.
Utilise les modeles SQLAlchemy reels de notifications.py.

Refactorisation :
    Channel — Categorie (b) : heritage + soft_delete -> bool
    Notification — Categorie (d) : suppression dure
    Preference — Categorie (c) : cle user_id, pas de soft_delete
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.notifications import (
	Notification,
	NotificationChannel,
	NotificationPreference,
)

# ─── Notifications — Categorie (d) : suppression dure ────────────────────────


class NotificationRepository(BaseRepository[Notification]):
	"""Depot pour les notifications.

	Herite de BaseRepository[Notification] pour create/get/update.
	Utilise une suppression dure (session.delete) — ne pas utiliser
	soft_delete/restore herites.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(Notification, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(
		self,
		user_id: str,
		is_read: bool | None = None,
		is_dismissed: bool | None = None,
		notification_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Notification]:
		"""Recupere les notifications d'un utilisateur avec filtres."""
		conditions = [Notification.user_id == user_id]
		if is_read is not None:
			conditions.append(Notification.is_read == is_read)
		if is_dismissed is not None:
			conditions.append(Notification.is_dismissed == is_dismissed)
		if notification_type:
			conditions.append(Notification.notification_type == notification_type)

		stmt = (
			select(Notification)
			.where(and_(*conditions))
			.order_by(Notification.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count_unread(self, user_id: str) -> int:
		"""Compte les notifications non lues d'un utilisateur."""
		stmt = select(func.count(Notification.id)).where(
			and_(
				Notification.user_id == user_id,
				Notification.is_read == False,  # noqa: E712
				Notification.is_dismissed == False,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one()

	async def mark_as_read(self, notification_id: str) -> Notification | None:
		"""Marque une notification comme lue."""
		notification = await self.get_by_id(notification_id)
		if notification is None:
			return None
		notification.is_read = True
		notification.read_at = datetime.now(UTC).isoformat()
		await self.session.flush()
		return notification

	async def mark_all_as_read(self, user_id: str) -> int:
		"""Marque toutes les notifications d'un utilisateur comme lues."""
		now_iso = datetime.now(UTC).isoformat()
		stmt = (
			update(Notification)
			.where(
				and_(
					Notification.user_id == user_id,
					Notification.is_read == False,  # noqa: E712
				)
			)
			.values(is_read=True, read_at=now_iso)
		)
		result = await self.session.execute(stmt)
		await self.session.flush()
		return result.rowcount

	async def dismiss(self, notification_id: str) -> Notification | None:
		"""Rejette une notification."""
		notification = await self.get_by_id(notification_id)
		if notification is None:
			return None
		notification.is_dismissed = True
		await self.session.flush()
		return notification

	async def delete(self, notification_id: str) -> bool:
		"""Supprime une notification (suppression dure)."""
		notification = await self.get_by_id(notification_id)
		if notification is None:
			return False
		await self.session.delete(notification)
		await self.session.flush()
		return True


# ─── Preferences — Categorie (c) : cle user_id ──────────────────────────────


class PreferenceRepository(BaseRepository[NotificationPreference]):
	"""Depot pour les preferences de notification.

	Herite de BaseRepository[NotificationPreference] pour create.
	Cle primaire d'acces : user_id (pas entity_id).
	Pas de soft_delete — les preferences sont permanentes.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(NotificationPreference, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(self, user_id: str) -> NotificationPreference | None:
		"""Recupere les preferences d'un utilisateur."""
		stmt = select(NotificationPreference).where(NotificationPreference.user_id == user_id)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def get_or_create(self, user_id: str) -> NotificationPreference:
		"""Recupere ou cree les preferences d'un utilisateur."""
		pref = await self.get_by_user(user_id)
		if pref is not None:
			return pref
		return await self.create({"user_id": user_id})

	async def update(self, user_id: str, data: dict) -> NotificationPreference | None:
		"""Met a jour les preferences d'un utilisateur (par user_id)."""
		pref = await self.get_by_user(user_id)
		if pref is None:
			return None
		for key, value in data.items():
			if value is not None and hasattr(pref, key):
				setattr(pref, key, value)
		await self.session.flush()
		return pref


# ─── Canaux — Categorie (b) ──────────────────────────────────────────────────


class ChannelRepository(BaseRepository[NotificationChannel]):
	"""Depot pour les canaux de notification.

	Herite de BaseRepository[NotificationChannel].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(NotificationChannel, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, channel_id: str) -> bool:
		"""Suppression logique d'un canal."""
		result = await super().soft_delete(channel_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user(
		self,
		user_id: str,
		channel_type: str | None = None,
	) -> Sequence[NotificationChannel]:
		"""Recupere les canaux d'un utilisateur."""
		conditions = [NotificationChannel.user_id == user_id]
		if channel_type:
			conditions.append(NotificationChannel.channel_type == channel_type)

		stmt = (
			select(NotificationChannel)
			.where(and_(*conditions))
			.order_by(NotificationChannel.created_at.desc())
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def verify(self, channel_id: str, code: str) -> NotificationChannel | None:
		"""Verifie un canal avec un code."""
		channel = await self.get_by_id(channel_id)
		if channel is None:
			return None
		if channel.verification_code != code:
			return None
		channel.is_verified = True
		channel.verification_code = None
		await self.session.flush()
		return channel
