"""NOKIROVA — DTOs du service Notification

Modèles Pydantic pour la validation des requêtes et réponses
du module Notification : notifications, préférences et canaux.
Alignés sur les modèles SQLAlchemy réels (notification.py).

Corrections clés :
- Notification : notification_type (pas type), priority, is_read, is_dismissed,
  delivery_channels/delivery_status (JSONB), metadata_json
- NotificationPreference : achievement_enabled, reminder_enabled, social_enabled,
  system_enabled, ai_enabled, revision_enabled, course_enabled, marketing_enabled,
  push_enabled, email_enabled, sms_enabled, quiet_hours_start/end, digest_frequency,
  preferred_language
- NotificationChannel : channel_type, channel_address, is_verified, is_active,
  verification_code, config (JSONB)
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class NotificationTypeEnum(StrEnum):
	"""Types de notification."""

	achievement = "achievement"
	reminder = "reminder"
	social = "social"
	system = "system"
	ai = "ai"
	revision = "revision"
	course = "course"
	marketing = "marketing"


class PriorityEnum(StrEnum):
	"""Priorités de notification."""

	low = "low"
	normal = "normal"
	high = "high"
	urgent = "urgent"


class ChannelTypeEnum(StrEnum):
	"""Types de canal de notification."""

	push = "push"
	email = "email"
	sms = "sms"
	in_app = "in_app"
	webhook = "webhook"


class DigestFrequencyEnum(StrEnum):
	"""Fréquences de synthèse."""

	never = "never"
	immediate = "immediate"
	hourly = "hourly"
	daily = "daily"
	weekly = "weekly"


class ResourceTypeEnum(StrEnum):
	"""Types de ressource liée."""

	course = "course"
	module = "module"
	quiz = "quiz"
	flashcard = "flashcard"
	community = "community"
	achievement = "achievement"
	user = "user"


# ─── Notifications ────────────────────────────────────────────────────────────


class NotificationCreateDTO(BaseModel):
	"""Création d'une notification."""

	user_id: str
	notification_type: NotificationTypeEnum
	title: str = Field(..., min_length=1, max_length=255)
	message: str = Field(..., min_length=1)
	icon: str | None = None
	action_url: str | None = None
	action_text: str | None = None
	resource_type: ResourceTypeEnum | None = None
	resource_id: str | None = None
	sender_id: str | None = None
	priority: PriorityEnum = PriorityEnum.normal
	delivery_channels: list[str] | None = None
	scheduled_at: str | None = None
	expires_at: str | None = None
	metadata_json: dict | None = None


class NotificationUpdateDTO(BaseModel):
	"""Mise à jour d'une notification (lecture, rejet)."""

	is_read: bool | None = None
	is_dismissed: bool | None = None


class NotificationResponseDTO(BaseModel):
	"""Réponse notification."""

	id: str
	user_id: str
	notification_type: str
	title: str
	message: str
	icon: str | None = None
	action_url: str | None = None
	action_text: str | None = None
	resource_type: str | None = None
	resource_id: str | None = None
	sender_id: str | None = None
	priority: str = "normal"
	is_read: bool = False
	is_dismissed: bool = False
	read_at: str | None = None
	delivery_channels: list[str] | None = None
	delivery_status: dict | None = None
	scheduled_at: str | None = None
	expires_at: str | None = None
	metadata_json: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Préférences ───────────────────────────────────────────────────────────────


class PreferenceUpdateDTO(BaseModel):
	"""Mise à jour des préférences de notification."""

	achievement_enabled: bool | None = None
	reminder_enabled: bool | None = None
	social_enabled: bool | None = None
	system_enabled: bool | None = None
	ai_enabled: bool | None = None
	revision_enabled: bool | None = None
	course_enabled: bool | None = None
	marketing_enabled: bool | None = None
	push_enabled: bool | None = None
	email_enabled: bool | None = None
	sms_enabled: bool | None = None
	quiet_hours_start: str | None = None
	quiet_hours_end: str | None = None
	digest_frequency: DigestFrequencyEnum | None = None
	preferred_language: str | None = None


class PreferenceResponseDTO(BaseModel):
	"""Réponse préférences."""

	id: str
	user_id: str
	achievement_enabled: bool = True
	reminder_enabled: bool = True
	social_enabled: bool = True
	system_enabled: bool = True
	ai_enabled: bool = True
	revision_enabled: bool = True
	course_enabled: bool = True
	marketing_enabled: bool = False
	push_enabled: bool = True
	email_enabled: bool = True
	sms_enabled: bool = False
	quiet_hours_start: str | None = None
	quiet_hours_end: str | None = None
	digest_frequency: str | None = None
	preferred_language: str | None = None
	created_at: datetime
	updated_at: datetime


# ─── Canaux ────────────────────────────────────────────────────────────────────


class ChannelCreateDTO(BaseModel):
	"""Création d'un canal de notification."""

	user_id: str
	channel_type: ChannelTypeEnum
	channel_address: str = Field(..., min_length=1, max_length=500)
	config: dict | None = None


class ChannelVerifyDTO(BaseModel):
	"""Vérification d'un canal de notification."""

	verification_code: str = Field(..., min_length=1, max_length=50)


class ChannelResponseDTO(BaseModel):
	"""Réponse canal."""

	id: str
	user_id: str
	channel_type: str
	channel_address: str
	is_verified: bool = False
	is_active: bool = True
	verification_code: str | None = None
	config: dict | None = None
	created_at: datetime
	updated_at: datetime


class UnreadCountDTO(BaseModel):
	"""Nombre de notifications non lues."""

	count: int = 0
