"""NOKIROVA — Service Utilisateur"""

from .repository import UserRepository as UserRepository
from .service import UserService as UserService
