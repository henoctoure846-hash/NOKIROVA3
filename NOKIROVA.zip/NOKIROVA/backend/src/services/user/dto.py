"""NOKIROVA — DTOs Utilisateur

Schémas de validation Pydantic pour les requêtes/réponses utilisateur.
Aucune logique métier — validation uniquement.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

# --- Requêtes ---


class UserCreateRequest(BaseModel):
	"""DTO de création d'utilisateur"""

	email: EmailStr
	username: str = Field(min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
	password: str = Field(min_length=8, max_length=128)
	first_name: str = Field(max_length=100)
	last_name: str = Field(max_length=100)
	role: str = Field(default="student", pattern=r"^(student|teacher|admin|parent)$")

	@field_validator("password")
	@classmethod
	def validate_password(cls, v):
		"""Valider la robustesse du mot de passe"""
		if not any(c.isupper() for c in v):
			raise ValueError("Le mot de passe doit contenir au moins une majuscule")
		if not any(c.isdigit() for c in v):
			raise ValueError("Le mot de passe doit contenir au moins un chiffre")
		return v


class UserUpdateRequest(BaseModel):
	"""DTO de mise à jour d'utilisateur"""

	first_name: str | None = Field(None, max_length=100)
	last_name: str | None = Field(None, max_length=100)
	avatar_url: str | None = None
	bio: str | None = Field(None, max_length=500)


class UserLoginRequest(BaseModel):
	"""DTO de connexion"""

	email: EmailStr
	password: str


class PasswordChangeRequest(BaseModel):
	"""DTO de changement de mot de passe"""

	current_password: str
	new_password: str = Field(min_length=8, max_length=128)

	@field_validator("new_password")
	@classmethod
	def validate_new_password(cls, v):
		if not any(c.isupper() for c in v):
			raise ValueError("Le mot de passe doit contenir au moins une majuscule")
		if not any(c.isdigit() for c in v):
			raise ValueError("Le mot de passe doit contenir au moins un chiffre")
		return v


class PasswordResetRequest(BaseModel):
	"""DTO de réinitialisation de mot de passe"""

	email: EmailStr


class EmailVerificationRequest(BaseModel):
	"""DTO de vérification d'email"""

	token: str


class ProfileUpdateRequest(BaseModel):
	"""DTO de mise à jour du profil"""

	bio: str | None = Field(None, max_length=500)
	avatar_url: str | None = None
	phone: str | None = None
	date_of_birth: datetime | None = None
	language: str | None = Field(None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
	timezone: str | None = None


class PreferencesUpdateRequest(BaseModel):
	"""DTO de mise à jour des préférences"""

	theme: str | None = Field(None, pattern=r"^(light|dark|auto)$")
	language: str | None = Field(None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
	notifications_email: bool | None = None
	notifications_push: bool | None = None
	notifications_sms: bool | None = None
	revision_reminder: bool | None = None
	revision_reminder_time: str | None = Field(None, pattern=r"^[0-9]{2}:[0-9]{2}$")
	accessibility_font_size: int | None = Field(None, ge=12, le=24)
	accessibility_high_contrast: bool | None = None
	accessibility_dyslexia_font: bool | None = None


# --- Réponses ---


class UserResponse(BaseModel):
	"""DTO de réponse utilisateur"""

	id: str
	email: str
	username: str
	first_name: str
	last_name: str
	role: str
	is_active: bool
	is_verified: bool
	avatar_url: str | None = None
	created_at: datetime
	updated_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class UserProfileResponse(BaseModel):
	"""DTO de réponse profil"""

	user_id: str
	bio: str | None = None
	avatar_url: str | None = None
	phone: str | None = None
	date_of_birth: datetime | None = None
	language: str = "fr"
	timezone: str = "Europe/Paris"
	total_xp: int = 0
	level: int = 1
	streak_days: int = 0
	longest_streak: int = 0
	created_at: datetime

	model_config = ConfigDict(from_attributes=True)


class UserPreferenceResponse(BaseModel):
	"""DTO de réponse préférences"""

	user_id: str
	theme: str = "auto"
	language: str = "fr"
	notifications_email: bool = True
	notifications_push: bool = True
	notifications_sms: bool = False
	revision_reminder: bool = True
	revision_reminder_time: str = "09:00"
	accessibility_font_size: int = 16
	accessibility_high_contrast: bool = False
	accessibility_dyslexia_font: bool = False

	model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
	"""DTO de réponse token JWT"""

	access_token: str
	refresh_token: str
	token_type: str = "bearer"
	expires_in: int  # secondes


class UserListResponse(BaseModel):
	"""DTO de réponse liste d'utilisateurs"""

	users: list[UserResponse]
	total: int
	offset: int
	limit: int
