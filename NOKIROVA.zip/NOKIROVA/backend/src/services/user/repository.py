"""NOKIROVA — Depot Utilisateur

Acces aux donnees pour les utilisateurs, profils et preferences.
Patron Style B : session (db) passee en argument a chaque methode.

Ce depot ne peut PAS heriter de BaseRepository car chaque methode
accepte sa propre session AsyncSession — in Compatible avec le
stockage de session dans BaseRepository.__init__.

Operations disponibles :
    - CRUD utilisateur (get_by_id, get_by_email, get_by_username,
      list_users, count, create, update, soft_delete)
    - Gestion du profil (get_profile, create_profile, update_profile)
    - Gestion des preferences (get_preferences, upsert_preferences)

Suppression douce : User.soft_delete() met is_active=False.
Pas de deleted_at sur le modele User (convention NOKIROVA).
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.users import User, UserPreference, UserProfile

# ─── Depot Utilisateur ────────────────────────────────────────────────


class UserRepository:
	"""Depot pour l'entite User — requetes DB uniquement.

	Patron Style B : chaque methode recoit sa session AsyncSession.
	Aucune logique metier, aucun SQL direct — SQLAlchemy ORM uniquement.
	"""

	# ── Recherche ──────────────────────────────────────────────────

	async def get_by_id(self, db: AsyncSession, user_id: str) -> User | None:
		"""Recupere un utilisateur par son identifiant."""
		result = await db.execute(select(User).where(User.id == user_id))
		return result.scalars().first()

	async def get_by_email(self, db: AsyncSession, email: str) -> User | None:
		"""Recupere un utilisateur par son adresse courriel."""
		result = await db.execute(select(User).where(User.email == email))
		return result.scalars().first()

	async def get_by_username(self, db: AsyncSession, username: str) -> User | None:
		"""Recupere un utilisateur par son nom d'utilisateur."""
		result = await db.execute(select(User).where(User.username == username))
		return result.scalars().first()

	# ── Listing ────────────────────────────────────────────────────

	async def list_users(
		self,
		db: AsyncSession,
		offset: int = 0,
		limit: int = 20,
		role: str | None = None,
		is_active: bool | None = None,
	) -> Sequence[User]:
		"""Liste les utilisateurs avec filtres optionnels."""
		query = select(User)
		conditions: list = []
		if role:
			conditions.append(User.role == role)
		if is_active is not None:
			conditions.append(User.is_active == is_active)
		if conditions:
			query = query.where(and_(*conditions))
		query = query.offset(offset).limit(limit).order_by(User.created_at.desc())
		result = await db.execute(query)
		return result.scalars().all()

	async def count(
		self,
		db: AsyncSession,
		role: str | None = None,
		is_active: bool | None = None,
	) -> int:
		"""Compte les utilisateurs selon les filtres."""
		query = select(func.count(User.id))
		conditions: list = []
		if role:
			conditions.append(User.role == role)
		if is_active is not None:
			conditions.append(User.is_active == is_active)
		if conditions:
			query = query.where(and_(*conditions))
		result = await db.execute(query)
		return result.scalar() or 0

	# ── Ecriture ───────────────────────────────────────────────────

	async def create(self, db: AsyncSession, user: User) -> User:
		"""Cree un nouvel utilisateur."""
		db.add(user)
		await db.flush()
		await db.refresh(user)
		return user

	async def update(self, db: AsyncSession, user_id: str, data: dict) -> User | None:
		"""Met a jour les champs d'un utilisateur."""
		await db.execute(update(User).where(User.id == user_id).values(**data))
		return await self.get_by_id(db, user_id)

	async def soft_delete(self, db: AsyncSession, user_id: str) -> bool:
		"""Suppression douce — desactivation (pas de suppression permanente).
		Utilise is_active=False via NOKIROVAModelMixin.soft_delete().
		Le champ deleted_at n'existe pas sur User (convention NOKIROVA).
		"""
		user = await self.get_by_id(db, user_id)
		if not user:
			return False
		user.soft_delete()
		await db.flush()
		return True

	# ── Profil ─────────────────────────────────────────────────────

	async def get_profile(self, db: AsyncSession, user_id: str) -> UserProfile | None:
		"""Recupere le profil d'un utilisateur."""
		result = await db.execute(select(UserProfile).where(UserProfile.user_id == user_id))
		return result.scalars().first()

	async def create_profile(self, db: AsyncSession, profile: UserProfile) -> UserProfile:
		"""Cree le profil d'un utilisateur."""
		db.add(profile)
		await db.flush()
		await db.refresh(profile)
		return profile

	async def update_profile(self, db: AsyncSession, user_id: str, data: dict) -> UserProfile | None:
		"""Met a jour le profil d'un utilisateur."""
		await db.execute(update(UserProfile).where(UserProfile.user_id == user_id).values(**data))
		return await self.get_profile(db, user_id)

	# ── Preferences ───────────────────────────────────────────────

	async def get_preferences(self, db: AsyncSession, user_id: str) -> UserPreference | None:
		"""Recupere les preferences d'un utilisateur."""
		result = await db.execute(select(UserPreference).where(UserPreference.user_id == user_id))
		return result.scalars().first()

	async def upsert_preferences(self, db: AsyncSession, prefs: UserPreference) -> UserPreference:
		"""Cree ou met a jour les preferences d'un utilisateur."""
		existing = await self.get_preferences(db, prefs.user_id)
		if existing:
			for key, value in prefs.__dict__.items():
				if not key.startswith("_") and key not in ("id", "user_id", "created_at"):
					setattr(existing, key, value)
			await db.flush()
			await db.refresh(existing)
			return existing
		else:
			db.add(prefs)
			await db.flush()
			await db.refresh(prefs)
			return prefs
