"""NOKIROVA — Service Utilisateur

Logique métier pour la gestion des utilisateurs.
- Pas de SQL direct (délégué au repository)
- Communication via Event Bus
- Self-healing : si échec, on journalise et on continue

Aligné sur les modèles réels :
  User : email, username, password_hash, role, is_verified,
  is_2fa_enabled, totp_secret, avatar_url, last_login_at,
  login_count, failed_login_count, locked_until, language,
  timezone. PAS de first_name, last_name, deleted_at,
  verification_token, verified_at, reset_token,
  reset_token_expires
  UserProfile : user_id, first_name, last_name, display_name,
  bio, birth_date, institution, degree, study_year, skills,
  interests, social_links
  UserPreference : user_id, theme, font_size,
  notifications_email, notifications_push,
  notifications_in_app, ai_model_preference, adaptive_ui,
  study_reminder_enabled, study_reminder_time,
  focus_mode_enabled, reduced_motion, high_contrast

Sécurité : hash_password/verify_password
  (PAS get_password_hash)
  create_access_token(data=dict) /
  create_refresh_token(data=dict)
Cache : cache_manager.get/set/delete(namespace, key)
  invalidate_namespace(namespace) PAS delete_namespace
Événements : event_bus.publish(Event(event_type=,
  domain=, payload=)) PAS event_bus.emit()
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.config import get_settings
from src.core.exceptions import ConflictError, ForbiddenError, NotFoundError, UnauthorizedError
from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.core.security import create_access_token, create_refresh_token, hash_password, verify_password
from src.database.models.users import User, UserPreference, UserProfile
from src.events.bus import Event, event_bus
from src.services.user.dto import (
	EmailVerificationRequest,
	PasswordChangeRequest,
	PasswordResetRequest,
	PreferencesUpdateRequest,
	ProfileUpdateRequest,
	TokenResponse,
	UserCreateRequest,
	UserListResponse,
	UserLoginRequest,
	UserPreferenceResponse,
	UserProfileResponse,
	UserResponse,
	UserUpdateRequest,
)
from src.services.user.repository import UserRepository

# ─── Constantes de cache ────────────────────────────────────────────────────

CACHE_NS_USER = "user_session"
CACHE_TTL_SESSION = 900  # 15 minutes


# ─── Service Utilisateur ────────────────────────────────────────────────────


class UserService:
	"""Service métier Utilisateur — toute la logique ici."""

	def __init__(self, session: AsyncSession):
		self.session = session
		self.repo = UserRepository()

	# ── Inscription ─────────────────────────────────────────────────

	async def register(self, data: UserCreateRequest) -> tuple[UserResponse, TokenResponse]:
		"""Inscrire un nouvel utilisateur.

		first_name/last_name vont sur UserProfile, PAS sur User.
		"""
		# Vérifier unicité email
		existing = await self.repo.get_by_email(self.session, data.email)
		if existing:
			raise ConflictError("Un compte avec cet email existe déjà")

		# Vérifier unicité nom d'utilisateur
		existing_username = await self.repo.get_by_username(self.session, data.username)
		if existing_username:
			raise ConflictError("Ce nom d'utilisateur est déjà pris")

		# Créer l'utilisateur — champs réels uniquement
		user = User(
			email=data.email,
			username=data.username,
			password_hash=hash_password(data.password),
			role=data.role,
			is_active=True,
			is_verified=False,
			language="fr",
			timezone="Europe/Paris",
		)
		user = await self.repo.create(self.session, user)

		# Créer le profil par défaut — first_name/last_name vont ICI
		profile = UserProfile(
			user_id=user.id,
			first_name=data.first_name,
			last_name=data.last_name,
			display_name=f"{data.first_name} {data.last_name}",
		)
		await self.repo.create_profile(self.session, profile)

		# Créer les préférences par défaut
		prefs = UserPreference(user_id=user.id)
		await self.repo.upsert_preferences(self.session, prefs)

		# Générer les tokens — API dict, PAS subject=str
		access_token = create_access_token(data={"sub": str(user.id)})
		refresh_token = create_refresh_token(data={"sub": str(user.id)})
		settings = get_settings()
		expires_in = settings.jwt.access_token_expire_minutes * 60

		# Publier l'événement via Event(dataclass)
		evenement = Event(
			event_type="user.registered",
			domain="user",
			payload={
				"user_id": str(user.id),
				"email": user.email,
				"username": user.username,
				"role": user.role,
			},
		)
		await event_bus.publish(evenement)

		# Invalider le cache — invalidate_namespace, PAS delete_namespace
		await cache_manager.invalidate_namespace(CACHE_NS_USER)

		return (
			UserResponse.model_validate(user),
			TokenResponse(
				access_token=access_token,
				refresh_token=refresh_token,
				expires_in=expires_in,
			),
		)

	# ── Connexion ────────────────────────────────────────────────────

	async def login(self, data: UserLoginRequest) -> tuple[UserResponse, TokenResponse]:
		"""Connecter un utilisateur."""
		user = await self.repo.get_by_email(self.session, data.email)
		if not user:
			raise UnauthorizedError("Email ou mot de passe incorrect")

		if not verify_password(data.password, user.password_hash):
			raise UnauthorizedError("Email ou mot de passe incorrect")

		if not user.is_active:
			raise ForbiddenError("Votre compte a été désactivé")

		# Mettre à jour la dernière connexion — datetime.now(timezone.utc)
		maintenant = datetime.now(UTC)
		await self.repo.update(
			self.session,
			user.id,
			{
				"last_login_at": maintenant,
				"login_count": (user.login_count or 0) + 1,
				"failed_login_count": 0,
			},
		)

		# Générer les tokens — API dict
		access_token = create_access_token(data={"sub": str(user.id)})
		refresh_token = create_refresh_token(data={"sub": str(user.id)})
		settings = get_settings()
		expires_in = settings.jwt.access_token_expire_minutes * 60

		# Mettre en cache la session
		await cache_manager.set(
			CACHE_NS_USER,
			f"session:{user.id}",
			{
				"user_id": str(user.id),
				"role": user.role,
				"login_at": maintenant.isoformat(),
			},
		)

		# Publier l'événement
		evenement = Event(
			event_type="user.logged_in",
			domain="user",
			payload={
				"user_id": str(user.id),
			},
		)
		await event_bus.publish(evenement)

		return (
			UserResponse.model_validate(user),
			TokenResponse(
				access_token=access_token,
				refresh_token=refresh_token,
				expires_in=expires_in,
			),
		)

	# ── Récupération ─────────────────────────────────────────────────

	async def get_user(self, user_id: str) -> UserResponse:
		"""Récupérer un utilisateur — avec cache."""
		# Essayer le cache d'abord
		cached = await cache_manager.get(CACHE_NS_USER, f"profile:{user_id}")
		if cached:
			return UserResponse(**cached)

		user = await self.repo.get_by_id(self.session, user_id)
		if not user:
			raise NotFoundError("Utilisateur non trouvé")

		response = UserResponse.model_validate(user)

		# Mettre en cache pour 15 minutes
		await cache_manager.set(
			CACHE_NS_USER,
			f"profile:{user_id}",
			response.model_dump(),
			ttl=CACHE_TTL_SESSION,
		)

		return response

	async def get_profile(self, user_id: str) -> UserProfileResponse:
		"""Récupérer le profil utilisateur."""
		profile = await self.repo.get_profile(self.session, user_id)
		if not profile:
			raise NotFoundError("Profil non trouvé")
		return UserProfileResponse.model_validate(profile)

	async def get_preferences(self, user_id: str) -> UserPreferenceResponse:
		"""Récupérer les préférences utilisateur."""
		prefs = await self.repo.get_preferences(self.session, user_id)
		if not prefs:
			raise NotFoundError("Préférences non trouvées")
		return UserPreferenceResponse.model_validate(prefs)

	async def list_users(
		self,
		offset: int = 0,
		limit: int = 20,
		role: str | None = None,
		is_active: bool | None = None,
	) -> UserListResponse:
		"""Lister les utilisateurs avec pagination."""
		users = await self.repo.list_users(
			self.session,
			offset=offset,
			limit=limit,
			role=role,
			is_active=is_active,
		)
		total = await self.repo.count(
			self.session,
			role=role,
			is_active=is_active,
		)
		return UserListResponse(
			users=[UserResponse.model_validate(u) for u in users],
			total=total,
			offset=offset,
			limit=limit,
		)

	# ── Mise à jour ─────────────────────────────────────────────────

	async def update_user(self, user_id: str, data: UserUpdateRequest) -> UserResponse:
		"""Mettre à jour un utilisateur.

		Les champs first_name/last_name/bio/avatar_url vont sur
		UserProfile (UserUpdateRequest contient ces champs mais
		ils ne sont PAS sur le modèle User).
		"""
		user = await self.repo.get_by_id(self.session, user_id)
		if not user:
			raise NotFoundError("Utilisateur non trouvé")

		update_data = data.model_dump(exclude_unset=True)

		# Séparer les champs User des champs UserProfile
		user_fields = {}
		profile_fields = {}

		profile_keys = {"first_name", "last_name", "bio"}

		for key, value in update_data.items():
			if key in profile_keys:
				profile_fields[key] = value
			elif hasattr(User, key):
				user_fields[key] = value

		# Mettre à jour l'utilisateur si des champs le concernent
		if user_fields:
			await self.repo.update(self.session, user_id, user_fields)

		# Mettre à jour le profil si des champs le concernent
		if profile_fields:
			await self.repo.update_profile(self.session, user_id, profile_fields)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_USER, f"profile:{user_id}")

		# Publier l'événement
		evenement = Event(
			event_type="user.updated",
			domain="user",
			payload={
				"user_id": user_id,
				"fields": list(update_data.keys()),
			},
		)
		await event_bus.publish(evenement)

		# Recharger l'utilisateur mis à jour
		user = await self.repo.get_by_id(self.session, user_id)
		return UserResponse.model_validate(user)

	async def update_profile(self, user_id: str, data: ProfileUpdateRequest) -> UserProfileResponse:
		"""Mettre à jour le profil."""
		update_data = data.model_dump(exclude_unset=True)
		profile = await self.repo.update_profile(self.session, user_id, update_data)
		if not profile:
			raise NotFoundError("Profil non trouvé")

		evenement = Event(
			event_type="user.profile_updated",
			domain="user",
			payload={"user_id": user_id},
		)
		await event_bus.publish(evenement)

		return UserProfileResponse.model_validate(profile)

	async def update_preferences(self, user_id: str, data: PreferencesUpdateRequest) -> UserPreferenceResponse:
		"""Mettre à jour les préférences."""
		update_data = data.model_dump(exclude_unset=True)
		prefs = await self.repo.get_preferences(self.session, user_id)
		if not prefs:
			raise NotFoundError("Préférences non trouvées")

		for key, value in update_data.items():
			if hasattr(prefs, key):
				setattr(prefs, key, value)

		prefs = await self.repo.upsert_preferences(self.session, prefs)

		evenement = Event(
			event_type="user.preferences_updated",
			domain="user",
			payload={"user_id": user_id},
		)
		await event_bus.publish(evenement)

		return UserPreferenceResponse.model_validate(prefs)

	# ── Mot de passe ─────────────────────────────────────────────────

	async def change_password(self, user_id: str, data: PasswordChangeRequest) -> bool:
		"""Changer le mot de passe."""
		user = await self.repo.get_by_id(self.session, user_id)
		if not user:
			raise NotFoundError("Utilisateur non trouvé")

		if not verify_password(data.current_password, user.password_hash):
			raise UnauthorizedError("Mot de passe actuel incorrect")

		await self.repo.update(
			self.session,
			user_id,
			{
				"password_hash": hash_password(data.new_password),
			},
		)

		# Invalider toutes les sessions
		await cache_manager.invalidate_namespace(CACHE_NS_USER)

		evenement = Event(
			event_type="user.password_changed",
			domain="user",
			payload={"user_id": user_id},
		)
		await event_bus.publish(evenement)

		return True

	async def request_password_reset(self, data: PasswordResetRequest) -> bool:
		"""Demander une réinitialisation de mot de passe.

		Note : Les champs reset_token / reset_token_expires
		n'existent pas sur le modèle User. On journalise la
		demande via événement — le token sera géré par un
		mécanisme externe (email, store temporaire, etc.).
		"""
		user = await self.repo.get_by_email(self.session, data.email)
		if not user:
			# Ne pas révéler si l'email existe (sécurité)
			return True

		# Générer un token de réinitialisation
		reset_token = secrets.token_urlsafe(32)

		# Publier l'événement — le handler se charge de l'envoi email
		evenement = Event(
			event_type="user.password_reset_requested",
			domain="user",
			payload={
				"user_id": str(user.id),
				"email": user.email,
				"reset_token": reset_token,
			},
		)
		await event_bus.publish(evenement)

		return True

	# ── Vérification email ───────────────────────────────────────────

	async def verify_email(self, data: EmailVerificationRequest) -> bool:
		"""Vérifier l'email d'un utilisateur.

		Note : Le champ verification_token n'existe pas sur le
		modèle User. On accepte le token et on marque is_verified=True
		si l'utilisateur correspondant est trouvé via un mécanisme externe.
		Pour l'instant, recherche par ID extrait du token.
		"""
		# Le token contient un identifiant utilisateur
		# Mécanisme simplifié : on marque directement is_verified
		# Le vrai mécanisme dépendra d'un store externe de tokens
		try:
			# Tentative de décodage du token comme UUID utilisateur
			# (mécanisme temporaire — à remplacer par un vrai store)
			user_id = data.token  # Temporaire
			user = await self.repo.get_by_id(self.session, user_id)
			if not user:
				raise NotFoundError("Token de vérification invalide")

			await self.repo.update(
				self.session,
				user.id,
				{
					"is_verified": True,
				},
			)

			evenement = Event(
				event_type="user.email_verified",
				domain="user",
				payload={"user_id": str(user.id)},
			)
			await event_bus.publish(evenement)

			return True
		except (ValueError, Exception) as exc:
			raise NotFoundError("Token de vérification invalide") from exc

	# ── Suppression douce ────────────────────────────────────────────

	async def archive_user(self, user_id: str) -> bool:
		"""Archiver un utilisateur (suppression douce — principe NOKIROVA)."""
		user = await self.repo.get_by_id(self.session, user_id)
		if not user:
			raise NotFoundError("Utilisateur non trouvé")

		await self.repo.soft_delete(self.session, user_id)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_USER, f"profile:{user_id}")

		evenement = Event(
			event_type="user.archived",
			domain="user",
			payload={"user_id": user_id},
		)
		await event_bus.publish(evenement)

		return True

	# ── Auto-guérison ────────────────────────────────────────────────

	async def heal_user_cache(self, user_id: str) -> bool:
		"""Auto-guérison : reconstruire le cache utilisateur si corrompu."""
		try:
			await cache_manager.delete(CACHE_NS_USER, f"profile:{user_id}")
			return True
		except DB_OPERATION_EXCEPTIONS:
			return False
