"""NOKIROVA — DTOs du service Document

Modèles Pydantic pour la validation des requêtes et réponses
du module Document : documents, versions, dossiers, partages, collaborateurs.
Alignés sur les modèles SQLAlchemy réels (documents.py).

Corrections clés :
- Champs alignés sur les vrais modèles (title, owner_id, folder_id, doc_type, status…)
- Plus de champs fantômes (taille_octets, mime_type, url_stockage, texte_ocr…)
- DocumentStatusEnum : draft, review, published, archived
- DocumentTypeEnum : note, paper, report, summary, presentation
- FolderVisibilityEnum supprimé (pas de champ visibilite sur DocumentFolder)
- OCR/Export restent en stub mais ne référencent aucun champ inexistant
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────


class DocumentStatusEnum(StrEnum):
	"""Statuts d'un document."""

	draft = "draft"
	review = "review"
	published = "published"
	archived = "archived"


class DocumentTypeEnum(StrEnum):
	"""Types de document."""

	note = "note"
	paper = "paper"
	report = "report"
	summary = "summary"
	presentation = "presentation"


class SharePermissionEnum(StrEnum):
	"""Permissions de partage."""

	view = "view"
	comment = "comment"
	edit = "edit"


class CollaboratorRoleEnum(StrEnum):
	"""Rôles de collaborateur."""

	owner = "owner"
	editor = "editor"
	commenter = "commenter"
	viewer = "viewer"


class ExportFormatEnum(StrEnum):
	"""Formats d'export supportés."""

	pdf = "pdf"
	docx = "docx"
	md = "md"
	html = "html"
	txt = "txt"


# ─── Documents ────────────────────────────────────────────


class DocumentCreateDTO(BaseModel):
	"""Création d'un document."""

	title: str = Field(..., min_length=1, max_length=500)
	folder_id: str | None = None
	doc_type: DocumentTypeEnum = DocumentTypeEnum.note
	content: str | None = None
	language: str = Field("fr", max_length=10)
	is_template: bool = False
	is_public: bool = False
	status: DocumentStatusEnum = DocumentStatusEnum.draft
	metadata_json: dict | None = None


class DocumentUpdateDTO(BaseModel):
	"""Mise à jour d'un document."""

	title: str | None = Field(None, min_length=1, max_length=500)
	folder_id: str | None = None
	doc_type: DocumentTypeEnum | None = None
	content: str | None = None
	language: str | None = Field(None, max_length=10)
	is_template: bool | None = None
	is_public: bool | None = None
	status: DocumentStatusEnum | None = None
	metadata_json: dict | None = None
	word_count: int | None = None
	current_version: int | None = None


class DocumentResponseDTO(BaseModel):
	"""Réponse document."""

	id: str
	title: str
	owner_id: str
	folder_id: str | None = None
	doc_type: DocumentTypeEnum = DocumentTypeEnum.note
	content: str | None = None
	word_count: int = 0
	language: str = "fr"
	is_template: bool = False
	is_public: bool = False
	status: DocumentStatusEnum = DocumentStatusEnum.draft
	metadata_json: dict | None = None
	current_version: int = 1
	created_at: datetime | None = None
	updated_at: datetime | None = None


# ─── Versions ──────────────────────────────────────────────


class DocumentVersionCreateDTO(BaseModel):
	"""Création d'une version de document."""

	content: str | None = None
	change_summary: str | None = None


class DocumentVersionResponseDTO(BaseModel):
	"""Réponse version de document."""

	id: str
	document_id: str
	version_number: int
	content: str | None = None
	change_summary: str | None = None
	edited_by: str
	word_count: int = 0
	created_at: datetime | None = None
	updated_at: datetime | None = None


# ─── Dossiers ─────────────────────────────────────────────


class DocumentFolderCreateDTO(BaseModel):
	"""Création d'un dossier."""

	name: str = Field(..., min_length=1, max_length=200)
	parent_id: str | None = None
	icon: str | None = Field(None, max_length=50)
	color: str | None = Field(None, max_length=20)
	sort_order: int = 0


class DocumentFolderUpdateDTO(BaseModel):
	"""Mise à jour d'un dossier."""

	name: str | None = Field(None, min_length=1, max_length=200)
	parent_id: str | None = None
	icon: str | None = None
	color: str | None = None
	sort_order: int | None = None


class DocumentFolderResponseDTO(BaseModel):
	"""Réponse dossier."""

	id: str
	name: str
	owner_id: str
	parent_id: str | None = None
	icon: str | None = None
	color: str | None = None
	sort_order: int = 0
	created_at: datetime | None = None
	updated_at: datetime | None = None


# ─── Partages ───────────────────────────────────────────


class DocumentShareCreateDTO(BaseModel):
	"""Création d'un lien de partage."""

	permission: SharePermissionEnum = SharePermissionEnum.view
	expires_at: str | None = None
	password: str | None = None


class DocumentShareResponseDTO(BaseModel):
	"""Réponse lien de partage."""

	id: str
	document_id: str
	shared_by: str
	share_token: str
	permission: SharePermissionEnum = SharePermissionEnum.view
	expires_at: str | None = None
	password_hash: str | None = None
	access_count: int = 0
	created_at: datetime | None = None
	updated_at: datetime | None = None


# ─── Collaborateurs ─────────────────────────────────────────


class DocumentCollaboratorCreateDTO(BaseModel):
	"""Ajout d'un collaborateur."""

	user_id: str
	role: CollaboratorRoleEnum = CollaboratorRoleEnum.viewer
	can_share: bool = False


class DocumentCollaboratorResponseDTO(BaseModel):
	"""Réponse collaborateur."""

	id: str
	document_id: str
	user_id: str
	role: CollaboratorRoleEnum = CollaboratorRoleEnum.viewer
	can_share: bool = False
	created_at: datetime | None = None
	updated_at: datetime | None = None


# ─── Export (stub) ───────────────────────────────────────


class ExportRequestDTO(BaseModel):
	"""Demande d'export — stub."""

	format_sortie: ExportFormatEnum = ExportFormatEnum.pdf
	options: dict | None = None
	inclure_metadonnees: bool = False
	inclure_ocr: bool = False


class ExportResponseDTO(BaseModel):
	"""Réponse export — stub."""

	document_id: str
	format_sortie: ExportFormatEnum = ExportFormatEnum.pdf
	url_telechargement: str = ""
	taille_octets: int = 0
	cree_le: datetime | None = None


# ─── OCR (stub — le vrai OCR est un module séparé) ───────────


class OcrRequestDTO(BaseModel):
	"""Demande d'OCR — stub."""

	langue: str = "fra"
	langues_supplementaires: list[str] = Field(default_factory=list)
	forcer: bool = False


class OcrResultDTO(BaseModel):
	"""Résultat OCR — stub."""

	document_id: str = ""
	texte: str = ""
	confiance: float = 0.0
	langues_detectees: list[str] = Field(default_factory=list)
	nombre_pages: int = 0
	temps_traitement_ms: int = 0
	statut: str = "en_attente"
