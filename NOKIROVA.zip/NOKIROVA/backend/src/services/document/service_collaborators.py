"""NOKIROVA — Sous-service Collaborateurs de Documents

Gestion des collaborateurs : ajout, mise à jour du rôle,
retrait, listage avec vérification des permissions.

Principe BIBLE #6 Modularité : collaborateurs isolés.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ConflictError, ForbiddenError, NotFoundError
from src.events.bus import Event, event_bus
from src.services.document.dto import (
	CollaboratorRoleEnum,
	DocumentCollaboratorCreateDTO,
	DocumentCollaboratorResponseDTO,
)
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentRepository,
	DocumentShareRepository,
)
from src.services.document.service_access import check_read_access
from src.services.document.service_converters import (
	CACHE_NS_COLLABS,
	collaborator_to_response,
)


class DocumentCollaboratorService:
	"""Sous-service pour la gestion des collaborateurs de documents."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.doc_repo = DocumentRepository(session)
		self.collaborator_repo = DocumentCollaboratorRepository(session)
		self.share_repo = DocumentShareRepository(session)

	async def add_collaborator(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentCollaboratorCreateDTO,
	) -> DocumentCollaboratorResponseDTO:
		"""Ajoute un collaborateur à un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		# Seul le propriétaire ou un collaborateur avec can_share peut ajouter
		if doc.owner_id != user_id:
			caller = await self.collaborator_repo.get_by_user_and_document(
				user_id,
				document_id,
			)
			if not caller or not caller.can_share:
				raise ForbiddenError("Vous n'avez pas la permission d'ajouter des collaborateurs")

		# Vérifier qu'il n'y a pas déjà un collaborateur pour cet utilisateur
		existing = await self.collaborator_repo.get_by_user_and_document(
			dto.user_id,
			document_id,
		)
		if existing:
			raise ConflictError("Cet utilisateur est déjà collaborateur de ce document")

		collab = await self.collaborator_repo.create(
			{
				"document_id": document_id,
				"user_id": dto.user_id,
				"role": dto.role.value,
				"can_share": dto.can_share,
			}
		)

		# Invalider le cache
		await cache_manager.invalidate_namespace(CACHE_NS_COLLABS)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.collaborator_added",
				domain="document",
				payload={
					"document_id": document_id,
					"collaborator_id": collab.id,
					"user_id": dto.user_id,
					"role": dto.role.value,
				},
			)
		)

		return collaborator_to_response(collab)

	async def update_collaborator(
		self,
		collaborator_id: str,
		user_id: str,
		role: CollaboratorRoleEnum | None = None,
		can_share: bool | None = None,
	) -> DocumentCollaboratorResponseDTO:
		"""Met à jour le rôle d'un collaborateur."""
		collab = await self.collaborator_repo.get_by_id(collaborator_id)
		if not collab:
			raise NotFoundError(f"Collaborateur introuvable : {collaborator_id}")

		doc = await self.doc_repo.get_by_id(collab.document_id)
		if not doc:
			raise NotFoundError("Document introuvable")

		# Seul le propriétaire peut modifier les collaborateurs
		if doc.owner_id != user_id:
			raise ForbiddenError("Seul le propriétaire peut modifier les collaborateurs")

		update_data = {}
		if role is not None:
			update_data["role"] = role.value
		if can_share is not None:
			update_data["can_share"] = can_share

		updated_collab = await self.collaborator_repo.update(collaborator_id, update_data)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_COLLABS, collaborator_id)

		return collaborator_to_response(updated_collab)

	async def remove_collaborator(
		self,
		collaborator_id: str,
		user_id: str,
	) -> bool:
		"""Retire un collaborateur d'un document."""
		collab = await self.collaborator_repo.get_by_id(collaborator_id)
		if not collab:
			raise NotFoundError(f"Collaborateur introuvable : {collaborator_id}")

		doc = await self.doc_repo.get_by_id(collab.document_id)
		if not doc:
			raise NotFoundError("Document introuvable")

		# Le propriétaire peut retirer n'importe qui ; un utilisateur peut se retirer lui-même
		if doc.owner_id != user_id and collab.user_id != user_id:
			raise ForbiddenError("Vous ne pouvez pas retirer ce collaborateur")

		await self.collaborator_repo.soft_delete(collaborator_id)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_COLLABS, collaborator_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.collaborator_removed",
				domain="document",
				payload={
					"collaborator_id": collaborator_id,
					"document_id": collab.document_id,
					"user_id": user_id,
				},
			)
		)

		return True

	async def list_collaborators(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentCollaboratorResponseDTO]:
		"""Liste les collaborateurs d'un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_read_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Accès refusé aux collaborateurs de ce document")

		collabs = await self.collaborator_repo.get_by_document(document_id, limit, offset)
		return [collaborator_to_response(c) for c in collabs]
