"""NOKIROVA — Contrôle d'accès du service Document

Fonctions partagées de vérification d'accès :
- Lecture (propriétaire, public, partage, collaborateur)
- Écriture (propriétaire, éditeur, partage edit)

Utilisées par plusieurs sous-services (CRUD, versions, collaborateurs…).

Principe BIBLE #6 Modularité : logique d'autorisation centralisée.
"""

from __future__ import annotations

from datetime import UTC, datetime

from src.database.models.documents import Document
from src.services.document.dto import CollaboratorRoleEnum, SharePermissionEnum
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentRepository,
	DocumentShareRepository,
)


async def check_read_access(
	doc: Document,
	user_id: str,
	collaborator_repo: DocumentCollaboratorRepository,
	share_repo: DocumentShareRepository,
) -> bool:
	"""Vérifie si un utilisateur peut lire un document."""
	# Le propriétaire a toujours accès
	if doc.owner_id == user_id:
		return True

	# Les documents publics sont accessibles à tous
	if doc.is_public:
		return True

	# Vérifier s'il y a un partage valide
	shares = await share_repo.get_by_document(doc.id)
	for share in shares:
		if share.expires_at and datetime.now(UTC) > share.expires_at.replace(
			tzinfo=UTC,
		):
			continue
		return True

	# Vérifier s'il est collaborateur
	collab = await collaborator_repo.get_by_user_and_document(
		user_id,
		doc.id,
	)
	return bool(collab)


async def check_write_access(
	doc: Document,
	user_id: str,
	collaborator_repo: DocumentCollaboratorRepository,
	share_repo: DocumentShareRepository,
) -> bool:
	"""Vérifie si un utilisateur peut modifier un document."""
	# Le propriétaire a toujours accès
	if doc.owner_id == user_id:
		return True

	# Vérifier le rôle collaborateur
	collab = await collaborator_repo.get_by_user_and_document(
		user_id,
		doc.id,
	)
	if collab and collab.role in (
		CollaboratorRoleEnum.owner.value,
		CollaboratorRoleEnum.editor.value,
	):
		return True

	# Vérifier les partages avec permission edit
	shares = await share_repo.get_by_document(doc.id)
	return any(share.permission == SharePermissionEnum.edit.value for share in shares)


async def get_document_count(
	doc_repo: DocumentRepository,
	owner_id: str,
) -> int:
	"""Compte les documents actifs d'un propriétaire."""
	return await doc_repo.count_by_owner(owner_id)
