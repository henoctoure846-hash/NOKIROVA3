"""NOKIROVA — Sous-service Export et OCR de Documents

Stubs pour l'export de documents et la demande d'OCR.
Le vrai OCR sera délégué à un module séparé.

Principe BIBLE #6 Modularité : export/OCR isolé.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.core.exceptions import ForbiddenError, NotFoundError
from src.services.document.dto import (
	ExportRequestDTO,
	ExportResponseDTO,
	OcrRequestDTO,
	OcrResultDTO,
)
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentRepository,
	DocumentShareRepository,
)
from src.services.document.service_access import check_read_access


class DocumentExportService:
	"""Sous-service pour l'export et l'OCR des documents (stubs)."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.doc_repo = DocumentRepository(session)
		self.collaborator_repo = DocumentCollaboratorRepository(session)
		self.share_repo = DocumentShareRepository(session)

	async def export_document(
		self,
		document_id: str,
		user_id: str,
		dto: ExportRequestDTO,
	) -> ExportResponseDTO:
		"""Exporte un document — stub, pas encore implémenté."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_read_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Accès refusé à ce document")

		# Stub — retourner une réponse vide
		return ExportResponseDTO(
			document_id=document_id,
			format_sortie=dto.format_sortie,
			url_telechargement="",
			taille_octets=0,
			cree_le=datetime.now(UTC),
		)

	async def request_ocr(
		self,
		document_id: str,
		user_id: str,
		dto: OcrRequestDTO,
	) -> OcrResultDTO:
		"""Demande d'OCR — stub, délégué au module OCR séparé."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_read_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Accès refusé à ce document")

		# Stub — retourner un résultat vide
		return OcrResultDTO(
			document_id=document_id,
			texte="",
			confiance=0.0,
			langues_detectees=[],
			nombre_pages=0,
			temps_traitement_ms=0,
			statut="en_attente",
		)
