"""NOKIROVA — Sous-service Versions de Documents

Gestion des versions : création, consultation, listage,
restauration d'une version antérieure.

Principe BIBLE #6 Modularité : versions isolées du CRUD.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenError, NotFoundError
from src.events.bus import Event, event_bus
from src.services.document.dto import (
	DocumentVersionCreateDTO,
	DocumentVersionResponseDTO,
)
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentRepository,
	DocumentShareRepository,
	DocumentVersionRepository,
)
from src.services.document.service_access import check_write_access
from src.services.document.service_converters import (
	CACHE_NS,
	compute_word_count,
	version_to_response,
)


class DocumentVersionService:
	"""Sous-service pour la gestion des versions de documents."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.doc_repo = DocumentRepository(session)
		self.version_repo = DocumentVersionRepository(session)
		self.collaborator_repo = DocumentCollaboratorRepository(session)
		self.share_repo = DocumentShareRepository(session)

	async def create_version(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentVersionCreateDTO,
	) -> DocumentVersionResponseDTO:
		"""Crée une nouvelle version d'un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_write_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Vous n'avez pas la permission de modifier ce document")

		# Calculer le numéro de version
		current_version = doc.current_version or 0
		new_version_number = current_version + 1

		# Calculer le nombre de mots
		content = dto.content or doc.content or ""
		word_count = compute_word_count(content)

		# Créer la version
		version = await self.version_repo.create(
			{
				"document_id": document_id,
				"version_number": new_version_number,
				"content": content,
				"change_summary": dto.change_summary,
				"edited_by": user_id,
				"word_count": word_count,
			}
		)

		# Mettre à jour le document principal
		await self.doc_repo.update(
			document_id,
			{
				"current_version": new_version_number,
				"content": content,
				"word_count": word_count,
				"updated_at": datetime.now(UTC),
			},
		)

		# Invalider le cache
		await cache_manager.invalidate_namespace(CACHE_NS)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.version_created",
				domain="document",
				payload={
					"document_id": document_id,
					"version_number": new_version_number,
					"edited_by": user_id,
				},
			)
		)

		return version_to_response(version)

	async def get_version(
		self,
		version_id: str,
		user_id: str,
	) -> DocumentVersionResponseDTO:
		"""Récupère une version spécifique d'un document."""
		version = await self.version_repo.get_by_id(version_id)
		if not version:
			raise NotFoundError(f"Version introuvable : {version_id}")

		doc = await self.doc_repo.get_by_id(version.document_id)
		if doc and not await check_write_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			# Lecture seule si accès en lecture
			from src.services.document.service_access import check_read_access

			if not await check_read_access(
				doc,
				user_id,
				self.collaborator_repo,
				self.share_repo,
			):
				raise ForbiddenError("Accès refusé à cette version")

		return version_to_response(version)

	async def list_versions(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentVersionResponseDTO]:
		"""Liste les versions d'un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		from src.services.document.service_access import check_read_access

		if not await check_read_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Accès refusé aux versions de ce document")

		versions = await self.version_repo.get_by_document(document_id, limit, offset)
		return [version_to_response(v) for v in versions]

	async def restore_version(
		self,
		document_id: str,
		version_id: str,
		user_id: str,
	) -> DocumentVersionResponseDTO:
		"""Restaure un document à une version antérieure."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_write_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Vous n'avez pas la permission de restaurer ce document")

		version = await self.version_repo.get_by_id(version_id)
		if not version or version.document_id != document_id:
			raise NotFoundError(f"Version introuvable : {version_id}")

		# Créer une nouvelle version avec le contenu de l'ancienne
		return await self.create_version(
			document_id=document_id,
			user_id=user_id,
			dto=DocumentVersionCreateDTO(
				content=version.content,
				change_summary=f"Restauration de la version {version.version_number}",
			),
		)
