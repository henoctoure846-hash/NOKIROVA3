"""NOKIROVA — Service Document (Facade)

Facade qui délègue aux sous-services spécialisés :
- DocumentCRUDService : opérations CRUD
- DocumentVersionService : gestion des versions
- DocumentFolderService : gestion des dossiers
- DocumentShareService : gestion des partages
- DocumentCollaboratorService : gestion des collaborateurs
- DocumentExportService : export et OCR

Principe BIBLE #6 Modularité : facade pattern.
Principe BIBLE #8 Élégance : une classe facade, plusieurs sous-services.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.document.dto import (
	CollaboratorRoleEnum,
	DocumentCollaboratorCreateDTO,
	DocumentCollaboratorResponseDTO,
	DocumentCreateDTO,
	DocumentFolderCreateDTO,
	DocumentFolderResponseDTO,
	DocumentFolderUpdateDTO,
	DocumentResponseDTO,
	DocumentShareCreateDTO,
	DocumentShareResponseDTO,
	DocumentUpdateDTO,
	DocumentVersionCreateDTO,
	DocumentVersionResponseDTO,
	ExportRequestDTO,
	ExportResponseDTO,
	OcrRequestDTO,
	OcrResultDTO,
)
from src.services.document.service_access import get_document_count
from src.services.document.service_collaborators import DocumentCollaboratorService
from src.services.document.service_crud import DocumentCRUDService
from src.services.document.service_export import DocumentExportService
from src.services.document.service_folders import DocumentFolderService
from src.services.document.service_shares import DocumentShareService
from src.services.document.service_versions import DocumentVersionService


class DocumentService:
	"""Service métier pour les documents (facade).

	Délègue chaque domaine à un sous-service spécialisé.
	L'API publique reste identique — transparent pour les appelants.
	"""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.crud = DocumentCRUDService(session)
		self.versions = DocumentVersionService(session)
		self.folders = DocumentFolderService(session)
		self.shares = DocumentShareService(session)
		self.collaborators = DocumentCollaboratorService(session)
		self.export = DocumentExportService(session)

	# ─── Documents : CRUD ──────────────────────────────────────

	async def create_document(
		self,
		owner_id: str,
		dto: DocumentCreateDTO,
	) -> DocumentResponseDTO:
		"""Crée un nouveau document."""
		return await self.crud.create_document(owner_id, dto)

	async def get_document(
		self,
		document_id: str,
		user_id: str,
	) -> DocumentResponseDTO:
		"""Récupère un document par son identifiant."""
		return await self.crud.get_document(document_id, user_id)

	async def update_document(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentUpdateDTO,
	) -> DocumentResponseDTO:
		"""Met à jour un document existant."""
		return await self.crud.update_document(document_id, user_id, dto)

	async def delete_document(
		self,
		document_id: str,
		user_id: str,
	) -> bool:
		"""Supprime (soft delete) un document."""
		return await self.crud.delete_document(document_id, user_id)

	async def list_documents_by_owner(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Liste les documents d'un propriétaire."""
		return await self.crud.list_documents_by_owner(owner_id, limit, offset)

	async def list_public_documents(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Liste les documents publics."""
		return await self.crud.list_public_documents(limit, offset)

	async def search_documents(
		self,
		user_id: str,
		query: str,
		limit: int = 20,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Recherche full-text dans les documents accessibles."""
		return await self.crud.search_documents(user_id, query, limit, offset)

	# ─── Versions ─────────────────────────────────────────────

	async def create_version(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentVersionCreateDTO,
	) -> DocumentVersionResponseDTO:
		"""Crée une nouvelle version d'un document."""
		return await self.versions.create_version(document_id, user_id, dto)

	async def get_version(
		self,
		version_id: str,
		user_id: str,
	) -> DocumentVersionResponseDTO:
		"""Récupère une version spécifique."""
		return await self.versions.get_version(version_id, user_id)

	async def list_versions(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentVersionResponseDTO]:
		"""Liste les versions d'un document."""
		return await self.versions.list_versions(document_id, user_id, limit, offset)

	async def restore_version(
		self,
		document_id: str,
		version_id: str,
		user_id: str,
	) -> DocumentVersionResponseDTO:
		"""Restaure un document à une version antérieure."""
		return await self.versions.restore_version(document_id, version_id, user_id)

	# ─── Dossiers ─────────────────────────────────────────────

	async def create_folder(
		self,
		owner_id: str,
		dto: DocumentFolderCreateDTO,
	) -> DocumentFolderResponseDTO:
		"""Crée un nouveau dossier."""
		return await self.folders.create_folder(owner_id, dto)

	async def get_folder(
		self,
		folder_id: str,
		user_id: str,
	) -> DocumentFolderResponseDTO:
		"""Récupère un dossier par son identifiant."""
		return await self.folders.get_folder(folder_id, user_id)

	async def update_folder(
		self,
		folder_id: str,
		user_id: str,
		dto: DocumentFolderUpdateDTO,
	) -> DocumentFolderResponseDTO:
		"""Met à jour un dossier existant."""
		return await self.folders.update_folder(folder_id, user_id, dto)

	async def delete_folder(
		self,
		folder_id: str,
		user_id: str,
	) -> bool:
		"""Supprime (soft delete) un dossier."""
		return await self.folders.delete_folder(folder_id, user_id)

	async def list_folders(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentFolderResponseDTO]:
		"""Liste les dossiers d'un propriétaire."""
		return await self.folders.list_folders(owner_id, limit, offset)

	async def list_subfolders(
		self,
		parent_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentFolderResponseDTO]:
		"""Liste les sous-dossiers d'un dossier."""
		return await self.folders.list_subfolders(parent_id, user_id, limit, offset)

	# ─── Partage ───────────────────────────────────────────────

	async def create_share(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentShareCreateDTO,
	) -> DocumentShareResponseDTO:
		"""Crée un lien de partage pour un document."""
		return await self.shares.create_share(document_id, user_id, dto)

	async def get_share_by_token(
		self,
		share_token: str,
		password: str | None = None,
	) -> DocumentShareResponseDTO:
		"""Récupère un partage par son token."""
		return await self.shares.get_share_by_token(share_token, password)

	async def list_shares(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentShareResponseDTO]:
		"""Liste les partages d'un document."""
		return await self.shares.list_shares(document_id, user_id, limit, offset)

	async def revoke_share(
		self,
		share_id: str,
		user_id: str,
	) -> bool:
		"""Révoque un lien de partage."""
		return await self.shares.revoke_share(share_id, user_id)

	# ─── Collaborateurs ────────────────────────────────────────

	async def add_collaborator(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentCollaboratorCreateDTO,
	) -> DocumentCollaboratorResponseDTO:
		"""Ajoute un collaborateur à un document."""
		return await self.collaborators.add_collaborator(document_id, user_id, dto)

	async def update_collaborator(
		self,
		collaborator_id: str,
		user_id: str,
		role: CollaboratorRoleEnum | None = None,
		can_share: bool | None = None,
	) -> DocumentCollaboratorResponseDTO:
		"""Met à jour le rôle d'un collaborateur."""
		return await self.collaborators.update_collaborator(
			collaborator_id,
			user_id,
			role,
			can_share,
		)

	async def remove_collaborator(
		self,
		collaborator_id: str,
		user_id: str,
	) -> bool:
		"""Retire un collaborateur d'un document."""
		return await self.collaborators.remove_collaborator(collaborator_id, user_id)

	async def list_collaborators(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentCollaboratorResponseDTO]:
		"""Liste les collaborateurs d'un document."""
		return await self.collaborators.list_collaborators(
			document_id,
			user_id,
			limit,
			offset,
		)

	# ─── Export (stub) ───────────────────────────────────────

	async def export_document(
		self,
		document_id: str,
		user_id: str,
		dto: ExportRequestDTO,
	) -> ExportResponseDTO:
		"""Exporte un document — stub, pas encore implémenté."""
		return await self.export.export_document(document_id, user_id, dto)

	# ─── OCR (stub — le vrai OCR est un module séparé) ─────

	async def request_ocr(
		self,
		document_id: str,
		user_id: str,
		dto: OcrRequestDTO,
	) -> OcrResultDTO:
		"""Demande d'OCR — stub, délégué au module OCR séparé."""
		return await self.export.request_ocr(document_id, user_id, dto)

	# ─── Statistiques ────────────────────────────────────────

	async def get_document_count(self, owner_id: str) -> int:
		"""Compte les documents actifs d'un propriétaire."""
		from src.services.document.repository import DocumentRepository

		doc_repo = DocumentRepository(self.session)
		return await get_document_count(doc_repo, owner_id)
