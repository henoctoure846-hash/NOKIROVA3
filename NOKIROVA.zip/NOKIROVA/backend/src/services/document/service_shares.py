"""NOKIROVA — Sous-service Partages de Documents

Gestion des liens de partage : création avec mot de passe,
consultation par token, listage, révocation.

Principe BIBLE #6 Modularité : partages isolés du CRUD.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenError, NotFoundError
from src.events.bus import Event, event_bus
from src.services.document.dto import (
	DocumentShareCreateDTO,
	DocumentShareResponseDTO,
)
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentRepository,
	DocumentShareRepository,
)
from src.services.document.service_converters import (
	CACHE_NS_SHARES,
	share_to_response,
)


class DocumentShareService:
	"""Sous-service pour la gestion des partages de documents."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.doc_repo = DocumentRepository(session)
		self.share_repo = DocumentShareRepository(session)
		self.collaborator_repo = DocumentCollaboratorRepository(session)

	async def create_share(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentShareCreateDTO,
	) -> DocumentShareResponseDTO:
		"""Crée un lien de partage pour un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		# Vérifier que l'utilisateur peut partager
		if doc.owner_id != user_id:
			collab = await self.collaborator_repo.get_by_user_and_document(
				user_id,
				document_id,
			)
			if not collab or not collab.can_share:
				raise ForbiddenError("Vous n'avez pas la permission de partager ce document")

		# Hasher le mot de passe si fourni
		password_hash = None
		if dto.password:
			password_hash = hashlib.sha256(
				dto.password.encode(),
			).hexdigest()

		# Parser la date d'expiration
		expires_at = None
		if dto.expires_at:
			try:
				expires_at = datetime.fromisoformat(dto.expires_at).replace(
					tzinfo=UTC,
				)
			except (ValueError, TypeError):
				expires_at = None

		share = await self.share_repo.create(
			{
				"document_id": document_id,
				"shared_by": user_id,
				"permission": dto.permission.value,
				"expires_at": expires_at,
				"password_hash": password_hash,
			}
		)

		# Invalider le cache
		await cache_manager.invalidate_namespace(CACHE_NS_SHARES)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.shared",
				domain="document",
				payload={
					"document_id": document_id,
					"share_id": share.id,
					"shared_by": user_id,
					"permission": dto.permission.value,
				},
			)
		)

		return share_to_response(share)

	async def get_share_by_token(
		self,
		share_token: str,
		password: str | None = None,
	) -> DocumentShareResponseDTO:
		"""Récupère un partage par son token (avec vérification de mot de passe)."""
		share = await self.share_repo.get_by_token(share_token)
		if not share:
			raise NotFoundError("Lien de partage introuvable")

		# Vérifier l'expiration
		if share.expires_at and datetime.now(UTC) > share.expires_at.replace(
			tzinfo=UTC,
		):
			raise ForbiddenError("Ce lien de partage a expiré")

		# Vérifier le mot de passe si nécessaire
		if share.password_hash:
			if not password:
				raise ForbiddenError("Un mot de passe est requis pour ce lien")
			provided_hash = hashlib.sha256(password.encode()).hexdigest()
			if provided_hash != share.password_hash:
				raise ForbiddenError("Mot de passe incorrect")

		# Incrémenter le compteur d'accès
		await self.share_repo.increment_access(share.id)

		return share_to_response(share)

	async def list_shares(
		self,
		document_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentShareResponseDTO]:
		"""Liste les partages d'un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if doc.owner_id != user_id:
			raise ForbiddenError("Seul le propriétaire peut lister les partages")

		shares = await self.share_repo.get_by_document(document_id, limit, offset)
		return [share_to_response(s) for s in shares]

	async def revoke_share(
		self,
		share_id: str,
		user_id: str,
	) -> bool:
		"""Révoque un lien de partage."""
		share = await self.share_repo.get_by_id(share_id)
		if not share:
			raise NotFoundError(f"Partage introuvable : {share_id}")

		# Vérifier que l'utilisateur est celui qui a partagé ou le propriétaire
		doc = await self.doc_repo.get_by_id(share.document_id)
		if not doc:
			raise NotFoundError("Document introuvable")

		if share.shared_by != user_id and doc.owner_id != user_id:
			raise ForbiddenError("Vous ne pouvez pas révoquer ce partage")

		await self.share_repo.soft_delete(share_id)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_SHARES, share_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.share_revoked",
				domain="document",
				payload={
					"share_id": share_id,
					"document_id": share.document_id,
					"user_id": user_id,
				},
			)
		)

		return True
