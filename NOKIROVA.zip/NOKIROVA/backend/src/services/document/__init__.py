"""NOKIROVA — Service Document

Exports : DocumentService (facade) et tous les sous-services.
Pas d'instances module-level.

Principe BIBLE #6 Modularité : sous-services importables individuellement.
"""

from src.services.document.service import DocumentService
from src.services.document.service_collaborators import DocumentCollaboratorService
from src.services.document.service_crud import DocumentCRUDService
from src.services.document.service_export import DocumentExportService
from src.services.document.service_folders import DocumentFolderService
from src.services.document.service_shares import DocumentShareService
from src.services.document.service_versions import DocumentVersionService

__all__ = [
	"DocumentService",
	"DocumentCRUDService",
	"DocumentVersionService",
	"DocumentFolderService",
	"DocumentShareService",
	"DocumentCollaboratorService",
	"DocumentExportService",
]
