"""NOKIROVA — Sous-service Dossiers de Documents

Gestion des dossiers : création, lecture, mise à jour,
suppression, listage et sous-dossiers.

Principe BIBLE #6 Modularité : dossiers isolés du CRUD documents.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenError, NotFoundError
from src.events.bus import Event, event_bus
from src.services.document.dto import (
	DocumentFolderCreateDTO,
	DocumentFolderResponseDTO,
	DocumentFolderUpdateDTO,
)
from src.services.document.repository import (
	DocumentFolderRepository,
)
from src.services.document.service_converters import (
	CACHE_NS_FOLDERS,
	folder_to_response,
)


class DocumentFolderService:
	"""Sous-service pour la gestion des dossiers de documents."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.folder_repo = DocumentFolderRepository(session)

	async def create_folder(
		self,
		owner_id: str,
		dto: DocumentFolderCreateDTO,
	) -> DocumentFolderResponseDTO:
		"""Crée un nouveau dossier."""
		# Vérifier le dossier parent si précisé
		if dto.parent_id:
			parent = await self.folder_repo.get_by_id(dto.parent_id)
			if not parent:
				raise NotFoundError(f"Dossier parent introuvable : {dto.parent_id}")

		folder = await self.folder_repo.create(
			{
				"name": dto.name,
				"owner_id": owner_id,
				"parent_id": dto.parent_id,
				"icon": dto.icon,
				"color": dto.color,
			}
		)

		# Invalider le cache
		await cache_manager.invalidate_namespace(CACHE_NS_FOLDERS)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.folder_created",
				domain="document",
				payload={
					"folder_id": folder.id,
					"owner_id": owner_id,
				},
			)
		)

		return folder_to_response(folder)

	async def get_folder(
		self,
		folder_id: str,
		user_id: str,
	) -> DocumentFolderResponseDTO:
		"""Récupère un dossier par son identifiant."""
		folder = await self.folder_repo.get_by_id(folder_id)
		if not folder:
			raise NotFoundError(f"Dossier introuvable : {folder_id}")

		if folder.owner_id != user_id:
			raise ForbiddenError("Accès refusé à ce dossier")

		return folder_to_response(folder)

	async def update_folder(
		self,
		folder_id: str,
		user_id: str,
		dto: DocumentFolderUpdateDTO,
	) -> DocumentFolderResponseDTO:
		"""Met à jour un dossier existant."""
		folder = await self.folder_repo.get_by_id(folder_id)
		if not folder:
			raise NotFoundError(f"Dossier introuvable : {folder_id}")

		if folder.owner_id != user_id:
			raise ForbiddenError("Vous n'avez pas la permission de modifier ce dossier")

		update_data = {}
		if dto.name is not None:
			update_data["name"] = dto.name
		if dto.icon is not None:
			update_data["icon"] = dto.icon
		if dto.color is not None:
			update_data["color"] = dto.color
		if dto.sort_order is not None:
			update_data["sort_order"] = dto.sort_order

		updated_folder = await self.folder_repo.update(folder_id, update_data)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_FOLDERS, folder_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.folder_updated",
				domain="document",
				payload={
					"folder_id": folder_id,
					"updated_by": user_id,
				},
			)
		)

		return folder_to_response(updated_folder)

	async def delete_folder(
		self,
		folder_id: str,
		user_id: str,
	) -> bool:
		"""Supprime (soft delete) un dossier."""
		folder = await self.folder_repo.get_by_id(folder_id)
		if not folder:
			raise NotFoundError(f"Dossier introuvable : {folder_id}")

		if folder.owner_id != user_id:
			raise ForbiddenError("Seul le propriétaire peut supprimer ce dossier")

		await self.folder_repo.soft_delete(folder_id)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS_FOLDERS, folder_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.folder_deleted",
				domain="document",
				payload={
					"folder_id": folder_id,
					"deleted_by": user_id,
				},
			)
		)

		return True

	async def list_folders(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentFolderResponseDTO]:
		"""Liste les dossiers d'un propriétaire."""
		folders = await self.folder_repo.get_by_owner(owner_id, limit, offset)
		return [folder_to_response(f) for f in folders]

	async def list_subfolders(
		self,
		parent_id: str,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentFolderResponseDTO]:
		"""Liste les sous-dossiers d'un dossier."""
		parent = await self.folder_repo.get_by_id(parent_id)
		if not parent:
			raise NotFoundError(f"Dossier parent introuvable : {parent_id}")

		if parent.owner_id != user_id:
			raise ForbiddenError("Accès refusé à ce dossier")

		folders = await self.folder_repo.get_children(parent_id, limit, offset)
		return [folder_to_response(f) for f in folders]
