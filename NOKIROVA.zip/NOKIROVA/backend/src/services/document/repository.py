"""NOKIROVA — Depot Document

Acces aux donnees pour les documents, versions, dossiers,
partages et collaborateurs.
Utilise les modeles SQLAlchemy reels de documents.py.
Filtre systematiquement par is_active=True.

Refactorisation : heritage de BaseRepository[ModelType]
	Document, DocumentVersion, DocumentFolder, DocumentShare,
	DocumentCollaborator — Categorie (a) : heritage propre
"""

from __future__ import annotations

import secrets
from collections.abc import Sequence

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.documents import (
	Document,
	DocumentCollaborator,
	DocumentFolder,
	DocumentShare,
	DocumentVersion,
)

# ─── Document ────────────────────────────────────────────────────────


class DocumentRepository(BaseRepository[Document]):
	"""Depot pour les documents.

	Herite de BaseRepository[Document] pour les operations CRUD communes.
	get_by_id est surcharge pour filtrer par is_active=True.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(Document, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, document_id: str) -> Document | None:
		"""Recupere un document actif par son identifiant."""
		return await self.get_by_id_active(document_id)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_owner(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Document]:
		"""Recupere les documents actifs d'un proprietaire."""
		stmt = (
			select(Document)
			.where(
				and_(
					Document.owner_id == owner_id,
					Document.is_active == True,  # noqa: E712
				)
			)
			.order_by(Document.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_by_folder(
		self,
		folder_id: str,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Document]:
		"""Recupere les documents actifs d'un dossier."""
		stmt = (
			select(Document)
			.where(
				and_(
					Document.folder_id == folder_id,
					Document.owner_id == owner_id,
					Document.is_active == True,  # noqa: E712
				)
			)
			.order_by(Document.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_public(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Document]:
		"""Recupere les documents publics et actifs."""
		stmt = (
			select(Document)
			.where(
				and_(
					Document.is_public == True,  # noqa: E712
					Document.is_active == True,  # noqa: E712
				)
			)
			.order_by(Document.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_by_status(
		self,
		status: str,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[Document]:
		"""Recupere les documents actifs par statut."""
		stmt = (
			select(Document)
			.where(
				and_(
					Document.status == status,
					Document.owner_id == owner_id,
					Document.is_active == True,  # noqa: E712
				)
			)
			.order_by(Document.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def archive(self, document_id: str) -> Document | None:
		"""Archive un document (status=archived + soft delete)."""
		doc = await self.get_by_id_active(document_id)
		if not doc:
			return None
		doc.status = "archived"
		doc.soft_delete()
		await self.session.flush()
		return doc

	async def count_by_owner(self, owner_id: str) -> int:
		"""Compte les documents actifs d'un proprietaire."""
		stmt = (
			select(func.count())
			.select_from(Document)
			.where(
				and_(
					Document.owner_id == owner_id,
					Document.is_active == True,  # noqa: E712
				)
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar() or 0

	async def search(
		self,
		owner_id: str,
		query_text: str,
		limit: int = 20,
		offset: int = 0,
	) -> Sequence[Document]:
		"""Recherche textuelle dans les titres."""
		pattern = f"%{query_text}%"
		stmt = (
			select(Document)
			.where(
				and_(
					Document.owner_id == owner_id,
					Document.is_active == True,  # noqa: E712
					Document.title.ilike(pattern),
				)
			)
			.order_by(Document.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Version ────────────────────────────────────────────────────────


class DocumentVersionRepository(BaseRepository[DocumentVersion]):
	"""Depot pour les versions de document.

	Herite de BaseRepository[DocumentVersion] — Categorie (a).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(DocumentVersion, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, version_id: str) -> DocumentVersion | None:
		"""Recupere une version active par son identifiant."""
		return await self.get_by_id_active(version_id)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_document(
		self,
		document_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[DocumentVersion]:
		"""Recupere les versions actives d'un document."""
		stmt = (
			select(DocumentVersion)
			.where(
				and_(
					DocumentVersion.document_id == document_id,
					DocumentVersion.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentVersion.version_number.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_latest(self, document_id: str) -> DocumentVersion | None:
		"""Recupere la derniere version d'un document."""
		stmt = (
			select(DocumentVersion)
			.where(
				and_(
					DocumentVersion.document_id == document_id,
					DocumentVersion.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentVersion.version_number.desc())
			.limit(1)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()


# ─── Dossier ────────────────────────────────────────────────────────


class DocumentFolderRepository(BaseRepository[DocumentFolder]):
	"""Depot pour les dossiers de documents.

	Herite de BaseRepository[DocumentFolder] — Categorie (a).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(DocumentFolder, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, folder_id: str) -> DocumentFolder | None:
		"""Recupere un dossier actif par son identifiant."""
		return await self.get_by_id_active(folder_id)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_owner(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[DocumentFolder]:
		"""Recupere les dossiers actifs d'un proprietaire."""
		stmt = (
			select(DocumentFolder)
			.where(
				and_(
					DocumentFolder.owner_id == owner_id,
					DocumentFolder.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentFolder.sort_order.asc(), DocumentFolder.name.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_children(
		self,
		parent_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[DocumentFolder]:
		"""Recupere les sous-dossiers actifs d'un dossier."""
		stmt = (
			select(DocumentFolder)
			.where(
				and_(
					DocumentFolder.parent_id == parent_id,
					DocumentFolder.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentFolder.sort_order.asc(), DocumentFolder.name.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Partage ────────────────────────────────────────────────────────


class DocumentShareRepository(BaseRepository[DocumentShare]):
	"""Depot pour les liens de partage de document.

	Herite de BaseRepository[DocumentShare] — Categorie (a).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(DocumentShare, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def create(self, data: dict) -> DocumentShare:
		"""Cree un nouveau lien de partage. Genere un token si absent."""
		if "share_token" not in data:
			data["share_token"] = secrets.token_urlsafe(32)
		return await super().create(data)

	async def get_by_id(self, share_id: str) -> DocumentShare | None:
		"""Recupere un partage actif par son identifiant."""
		return await self.get_by_id_active(share_id)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_token(self, share_token: str) -> DocumentShare | None:
		"""Recupere un partage par son token."""
		stmt = select(DocumentShare).where(
			and_(
				DocumentShare.share_token == share_token,
				DocumentShare.is_active == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def get_by_document(
		self,
		document_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[DocumentShare]:
		"""Recupere les partages actifs d'un document."""
		stmt = (
			select(DocumentShare)
			.where(
				and_(
					DocumentShare.document_id == document_id,
					DocumentShare.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentShare.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def increment_access(self, share_id: str) -> DocumentShare | None:
		"""Incremente le compteur d'acces d'un partage."""
		share = await self.get_by_id_active(share_id)
		if not share:
			return None
		share.access_count += 1
		await self.session.flush()
		return share


# ─── Collaborateur ──────────────────────────────────────────────────


class DocumentCollaboratorRepository(BaseRepository[DocumentCollaborator]):
	"""Depot pour les collaborateurs de document.

	Herite de BaseRepository[DocumentCollaborator] — Categorie (a).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(DocumentCollaborator, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, collaborator_id: str) -> DocumentCollaborator | None:
		"""Recupere un collaborateur actif par son identifiant."""
		return await self.get_by_id_active(collaborator_id)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_document(
		self,
		document_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[DocumentCollaborator]:
		"""Recupere les collaborateurs actifs d'un document."""
		stmt = (
			select(DocumentCollaborator)
			.where(
				and_(
					DocumentCollaborator.document_id == document_id,
					DocumentCollaborator.is_active == True,  # noqa: E712
				)
			)
			.order_by(DocumentCollaborator.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_by_user_and_document(
		self,
		user_id: str,
		document_id: str,
	) -> DocumentCollaborator | None:
		"""Recupere le collaborateur pour un utilisateur et un document."""
		stmt = select(DocumentCollaborator).where(
			and_(
				DocumentCollaborator.user_id == user_id,
				DocumentCollaborator.document_id == document_id,
				DocumentCollaborator.is_active == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()
