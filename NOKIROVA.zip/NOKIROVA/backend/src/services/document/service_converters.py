"""NOKIROVA — Convertisseurs et constantes du service Document

Utilitaires partagés par tous les sous-services :
- Fonctions de conversion modèle → DTO
- Constantes de namespace cache
- Compteur de mots

Principe BIBLE #6 Modularité : chaque sous-service importe
uniquement ce dont il a besoin depuis ce module partagé.
"""

from __future__ import annotations

from src.database.models.documents import (
	Document,
	DocumentCollaborator,
	DocumentFolder,
	DocumentShare,
	DocumentVersion,
)
from src.services.document.dto import (
	CollaboratorRoleEnum,
	DocumentCollaboratorResponseDTO,
	DocumentFolderResponseDTO,
	DocumentResponseDTO,
	DocumentShareResponseDTO,
	DocumentStatusEnum,
	DocumentTypeEnum,
	DocumentVersionResponseDTO,
	SharePermissionEnum,
)

# ─── Constantes de cache ──────────────────────────────────────────
CACHE_NS = "documents"
CACHE_NS_FOLDERS = "document_folders"
CACHE_NS_SHARES = "document_shares"
CACHE_NS_COLLABS = "document_collaborators"
CACHE_TTL = 300  # secondes


# ─── Utilitaires ──────────────────────────────────────────────────


def compute_word_count(text: str) -> int:
	"""Compte les mots dans un texte."""
	if not text:
		return 0
	return len(text.split())


def model_to_response(doc: Document) -> DocumentResponseDTO:
	"""Convertit un modèle Document en DTO de réponse."""
	return DocumentResponseDTO(
		id=doc.id,
		title=doc.title,
		owner_id=doc.owner_id,
		folder_id=doc.folder_id,
		doc_type=doc.doc_type if doc.doc_type else DocumentTypeEnum.note,
		content=doc.content,
		word_count=doc.word_count if doc.word_count is not None else 0,
		language=doc.language if doc.language else "fr",
		is_template=doc.is_template if doc.is_template is not None else False,
		is_public=doc.is_public if doc.is_public is not None else False,
		status=doc.status if doc.status else DocumentStatusEnum.draft,
		metadata_json=doc.metadata_json,
		current_version=doc.current_version if doc.current_version is not None else 1,
		created_at=doc.created_at,
		updated_at=doc.updated_at,
	)


def version_to_response(ver: DocumentVersion) -> DocumentVersionResponseDTO:
	"""Convertit un modèle DocumentVersion en DTO de réponse."""
	return DocumentVersionResponseDTO(
		id=ver.id,
		document_id=ver.document_id,
		version_number=ver.version_number,
		content=ver.content,
		change_summary=ver.change_summary,
		edited_by=ver.edited_by,
		word_count=ver.word_count if ver.word_count is not None else 0,
		created_at=ver.created_at,
		updated_at=ver.updated_at,
	)


def folder_to_response(folder: DocumentFolder) -> DocumentFolderResponseDTO:
	"""Convertit un modèle DocumentFolder en DTO de réponse."""
	return DocumentFolderResponseDTO(
		id=folder.id,
		name=folder.name,
		owner_id=folder.owner_id,
		parent_id=folder.parent_id,
		icon=folder.icon,
		color=folder.color,
		sort_order=folder.sort_order if folder.sort_order is not None else 0,
		created_at=folder.created_at,
		updated_at=folder.updated_at,
	)


def share_to_response(share: DocumentShare) -> DocumentShareResponseDTO:
	"""Convertit un modèle DocumentShare en DTO de réponse."""
	return DocumentShareResponseDTO(
		id=share.id,
		document_id=share.document_id,
		shared_by=share.shared_by,
		share_token=share.share_token,
		permission=share.permission if share.permission else SharePermissionEnum.view,
		expires_at=share.expires_at,
		password_hash=share.password_hash,
		access_count=share.access_count if share.access_count is not None else 0,
		created_at=share.created_at,
		updated_at=share.updated_at,
	)


def collaborator_to_response(
	collab: DocumentCollaborator,
) -> DocumentCollaboratorResponseDTO:
	"""Convertit un modèle DocumentCollaborator en DTO de réponse."""
	return DocumentCollaboratorResponseDTO(
		id=collab.id,
		document_id=collab.document_id,
		user_id=collab.user_id,
		role=collab.role if collab.role else CollaboratorRoleEnum.viewer,
		can_share=collab.can_share if collab.can_share is not None else False,
		created_at=collab.created_at,
		updated_at=collab.updated_at,
	)
