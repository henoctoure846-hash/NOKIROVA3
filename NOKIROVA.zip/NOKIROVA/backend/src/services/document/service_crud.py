"""NOKIROVA — Sous-service CRUD Documents

Opérations de création, lecture, mise à jour, suppression,
listage et recherche de documents.

Principe BIBLE #6 Modularité : CRUD isolé du reste.
Principe BIBLE #8 Élégance : un fichier = un domaine.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenError, NotFoundError
from src.events.bus import Event, event_bus
from src.services.document.dto import (
	DocumentCreateDTO,
	DocumentResponseDTO,
	DocumentStatusEnum,
	DocumentUpdateDTO,
)
from src.services.document.repository import (
	DocumentCollaboratorRepository,
	DocumentFolderRepository,
	DocumentRepository,
	DocumentShareRepository,
)
from src.services.document.service_access import check_read_access, check_write_access
from src.services.document.service_converters import (
	CACHE_NS,
	compute_word_count,
	model_to_response,
)


class DocumentCRUDService:
	"""Sous-service CRUD pour les documents."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.doc_repo = DocumentRepository(session)
		self.folder_repo = DocumentFolderRepository(session)
		self.collaborator_repo = DocumentCollaboratorRepository(session)
		self.share_repo = DocumentShareRepository(session)

	async def create_document(
		self,
		owner_id: str,
		dto: DocumentCreateDTO,
	) -> DocumentResponseDTO:
		"""Crée un nouveau document."""
		# Vérifier que le dossier parent existe si précisé
		if dto.folder_id:
			folder = await self.folder_repo.get_by_id(dto.folder_id)
			if not folder:
				raise NotFoundError(f"Dossier introuvable : {dto.folder_id}")

		word_count = compute_word_count(dto.content or "")

		doc = await self.doc_repo.create(
			{
				"title": dto.title,
				"owner_id": owner_id,
				"folder_id": dto.folder_id,
				"doc_type": dto.doc_type.value,
				"content": dto.content,
				"word_count": word_count,
				"language": dto.language or "fr",
				"is_template": dto.is_template,
				"is_public": dto.is_public,
				"status": DocumentStatusEnum.draft.value,
			}
		)

		# Créer la première version automatiquement
		if dto.content:
			from src.services.document.repository import DocumentVersionRepository

			version_repo = DocumentVersionRepository(self.session)
			await version_repo.create(
				{
					"document_id": doc.id,
					"version_number": 1,
					"content": dto.content,
					"change_summary": "Version initiale",
					"edited_by": owner_id,
					"word_count": word_count,
				}
			)

		# Invalider le cache
		await cache_manager.invalidate_namespace(CACHE_NS)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.created",
				domain="document",
				payload={
					"document_id": doc.id,
					"owner_id": owner_id,
					"title": doc.title,
				},
			)
		)

		return model_to_response(doc)

	async def get_document(
		self,
		document_id: str,
		user_id: str,
	) -> DocumentResponseDTO:
		"""Récupère un document par son identifiant."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_read_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Accès refusé à ce document")

		return model_to_response(doc)

	async def update_document(
		self,
		document_id: str,
		user_id: str,
		dto: DocumentUpdateDTO,
	) -> DocumentResponseDTO:
		"""Met à jour un document existant."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if not await check_write_access(
			doc,
			user_id,
			self.collaborator_repo,
			self.share_repo,
		):
			raise ForbiddenError("Vous n'avez pas la permission de modifier ce document")

		update_data = {}
		if dto.title is not None:
			update_data["title"] = dto.title
		if dto.content is not None:
			update_data["content"] = dto.content
			update_data["word_count"] = compute_word_count(dto.content)
		if dto.doc_type is not None:
			update_data["doc_type"] = dto.doc_type.value
		if dto.language is not None:
			update_data["language"] = dto.language
		if dto.is_template is not None:
			update_data["is_template"] = dto.is_template
		if dto.is_public is not None:
			update_data["is_public"] = dto.is_public
		if dto.status is not None:
			update_data["status"] = dto.status.value
		if dto.folder_id is not None:
			update_data["folder_id"] = dto.folder_id

		updated_doc = await self.doc_repo.update(document_id, update_data)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS, document_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.updated",
				domain="document",
				payload={
					"document_id": document_id,
					"updated_by": user_id,
				},
			)
		)

		return model_to_response(updated_doc)

	async def delete_document(
		self,
		document_id: str,
		user_id: str,
	) -> bool:
		"""Supprime (soft delete) un document."""
		doc = await self.doc_repo.get_by_id(document_id)
		if not doc:
			raise NotFoundError(f"Document introuvable : {document_id}")

		if doc.owner_id != user_id:
			raise ForbiddenError("Seul le propriétaire peut supprimer ce document")

		await self.doc_repo.soft_delete(document_id)

		# Invalider le cache
		await cache_manager.delete(CACHE_NS, document_id)

		# Publier l'événement
		await event_bus.publish(
			Event(
				event_type="document.deleted",
				domain="document",
				payload={
					"document_id": document_id,
					"deleted_by": user_id,
				},
			)
		)

		return True

	async def list_documents_by_owner(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Liste les documents d'un propriétaire."""
		docs = await self.doc_repo.get_by_owner(owner_id, limit, offset)
		return [model_to_response(d) for d in docs]

	async def list_public_documents(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Liste les documents publics."""
		docs = await self.doc_repo.get_public(limit, offset)
		return [model_to_response(d) for d in docs]

	async def search_documents(
		self,
		user_id: str,
		query: str,
		limit: int = 20,
		offset: int = 0,
	) -> list[DocumentResponseDTO]:
		"""Recherche full-text dans les documents accessibles."""
		results = await self.doc_repo.search(query, user_id, limit, offset)
		return [model_to_response(d) for d in results]
