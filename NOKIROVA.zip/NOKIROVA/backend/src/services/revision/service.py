"""NOKIROVA — Service Révision

Logique métier pour les plans de révision, sujets et sessions.
Aucun SQL direct — tout passe par le dépôt.
"""

import uuid
from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.revision import RevisionPlan, RevisionSession, RevisionTopic
from src.services.revision.dto import (
	RevisionPlanCreateRequest,
	RevisionPlanListResponse,
	RevisionPlanResponse,
	RevisionPlanUpdateRequest,
	RevisionSessionEndRequest,
	RevisionSessionResponse,
	RevisionSessionStartRequest,
	RevisionStatsResponse,
	RevisionTopicCreateRequest,
	RevisionTopicResponse,
	RevisionTopicUpdateRequest,
)
from src.services.revision.repository import RevisionRepository

repo = RevisionRepository()


class RevisionService:
	"""Service métier pour la révision intelligente"""

	# --- Plans de révision ---

	async def create_plan(
		self, db: AsyncSession, user_id: str, data: RevisionPlanCreateRequest
	) -> RevisionPlanResponse:
		"""Crée un nouveau plan de révision"""
		plan = RevisionPlan(
			id=str(uuid.uuid4()),
			owner_id=user_id,
			title=data.title,
			description=data.description,
			course_id=data.course_id,
			plan_type=data.plan_type,
			start_date=data.start_date,
			end_date=data.end_date,
			exam_date=data.exam_date,
			daily_hours=data.daily_hours,
			priority=data.priority,
			algorithm=data.algorithm,
			settings=data.settings or {},
			status="active",
			ai_generated=False,
			progress=0.0,
			metadata_json={},
		)
		plan = await repo.create_plan(db, plan)
		return RevisionPlanResponse.model_validate(plan)

	async def get_plan(self, db: AsyncSession, plan_id: str, user_id: str) -> RevisionPlanResponse | None:
		"""Récupère un plan par identifiant"""
		plan = await repo.get_plan(db, plan_id)
		if not plan or plan.owner_id != user_id:
			return None
		# Charger les sujets associés
		topics = await repo.list_topics(db, plan_id)
		resp = RevisionPlanResponse.model_validate(plan)
		resp.topics = [RevisionTopicResponse.model_validate(t) for t in topics]
		return resp

	async def list_plans(
		self, db: AsyncSession, user_id: str, offset: int = 0, limit: int = 20
	) -> RevisionPlanListResponse:
		"""Liste les plans de l'utilisateur"""
		plans = await repo.list_plans(db, user_id, offset, limit)
		return RevisionPlanListResponse(
			plans=[RevisionPlanResponse.model_validate(p) for p in plans],
			total=len(plans),
			offset=offset,
			limit=limit,
		)

	async def update_plan(
		self, db: AsyncSession, plan_id: str, user_id: str, data: RevisionPlanUpdateRequest
	) -> RevisionPlanResponse | None:
		"""Met à jour un plan existant"""
		plan = await repo.get_plan(db, plan_id)
		if not plan or plan.owner_id != user_id:
			return None
		update_data = data.model_dump(exclude_unset=True)
		plan = await repo.update_plan(db, plan_id, update_data)
		return RevisionPlanResponse.model_validate(plan) if plan else None

	async def delete_plan(self, db: AsyncSession, plan_id: str, user_id: str) -> bool:
		"""Supprime (logiquement) un plan"""
		plan = await repo.get_plan(db, plan_id)
		if not plan or plan.owner_id != user_id:
			return False
		return await repo.soft_delete_plan(db, plan_id)

	# --- Sujets de révision ---

	async def add_topic(
		self, db: AsyncSession, user_id: str, data: RevisionTopicCreateRequest
	) -> RevisionTopicResponse | None:
		"""Ajoute un sujet à un plan de révision"""
		plan = await repo.get_plan(db, data.plan_id)
		if not plan or plan.owner_id != user_id:
			return None
		topic = RevisionTopic(
			id=str(uuid.uuid4()),
			plan_id=data.plan_id,
			name=data.name,
			description=data.description,
			subject=data.subject,
			priority=data.priority,
			difficulty=data.difficulty,
			confidence_level=data.confidence_level,
			estimated_hours=data.estimated_hours,
			actual_hours=0.0,
			mastery_level="new",
			sort_order=data.sort_order,
			resource_refs=data.resource_refs or [],
		)
		topic = await repo.create_topic(db, topic)
		return RevisionTopicResponse.model_validate(topic)

	async def update_topic(
		self, db: AsyncSession, topic_id: str, user_id: str, data: RevisionTopicUpdateRequest
	) -> RevisionTopicResponse | None:
		"""Met à jour un sujet de révision"""
		topic = await repo.get_topic(db, topic_id)
		if not topic:
			return None
		# Vérifier que l'utilisateur est propriétaire du plan
		plan = await repo.get_plan(db, topic.plan_id)
		if not plan or plan.owner_id != user_id:
			return None
		update_data = data.model_dump(exclude_unset=True)
		topic = await repo.update_topic(db, topic_id, update_data)
		return RevisionTopicResponse.model_validate(topic) if topic else None

	async def remove_topic(self, db: AsyncSession, topic_id: str, user_id: str) -> bool:
		"""Supprime un sujet de révision"""
		topic = await repo.get_topic(db, topic_id)
		if not topic:
			return False
		plan = await repo.get_plan(db, topic.plan_id)
		if not plan or plan.owner_id != user_id:
			return False
		return await repo.delete_topic(db, topic_id)

	# --- Sessions de révision ---

	async def start_session(
		self, db: AsyncSession, user_id: str, data: RevisionSessionStartRequest
	) -> RevisionSessionResponse | None:
		"""Démarre une session de révision"""
		plan = await repo.get_plan(db, data.plan_id)
		if not plan or plan.owner_id != user_id:
			return None
		# Vérifier le sujet si spécifié
		if data.topic_id:
			topic = await repo.get_topic(db, data.topic_id)
			if not topic or topic.plan_id != data.plan_id:
				return None

		now = datetime.now(UTC)
		session = RevisionSession(
			id=str(uuid.uuid4()),
			user_id=user_id,
			plan_id=data.plan_id,
			topic_id=data.topic_id,
			session_type=data.session_type,
			duration_minutes=data.duration_minutes,
			actual_duration_minutes=None,
			focus_score=None,
			started_at=now,
			ended_at=None,
			status="in_progress",
			notes=None,
		)
		session = await repo.create_session(db, session)
		return RevisionSessionResponse.model_validate(session)

	async def end_session(
		self, db: AsyncSession, session_id: str, user_id: str, data: RevisionSessionEndRequest
	) -> RevisionSessionResponse | None:
		"""Termine une session de révision"""
		session = await repo.get_session(db, session_id)
		if not session or session.user_id != user_id:
			return None

		now = datetime.now(UTC)
		update_data = data.model_dump(exclude_unset=True)
		update_data["ended_at"] = now
		if "status" not in update_data:
			update_data["status"] = "completed"

		# Calculer la durée réelle si non fournie
		if "actual_duration_minutes" not in update_data and session.started_at:
			elapsed = (now - session.started_at).total_seconds() / 60
			update_data["actual_duration_minutes"] = int(elapsed)

		session = await repo.update_session(db, session_id, update_data)
		return RevisionSessionResponse.model_validate(session) if session else None

	async def list_sessions(
		self, db: AsyncSession, user_id: str, offset: int = 0, limit: int = 20
	) -> list[RevisionSessionResponse]:
		"""Liste les sessions de l'utilisateur"""
		sessions = await repo.list_sessions(db, user_id, offset, limit)
		return [RevisionSessionResponse.model_validate(s) for s in sessions]

	# --- Statistiques ---

	async def get_stats(self, db: AsyncSession, user_id: str, plan_id: str | None = None) -> RevisionStatsResponse:
		"""Récupère les statistiques de révision"""
		stats = await repo.get_stats(db, user_id, plan_id)
		if stats:
			return RevisionStatsResponse.model_validate(stats)
		# Retourner des statistiques vides si aucune n'existe
		return RevisionStatsResponse(
			user_id=user_id,
			plan_id=plan_id,
			date=datetime.now(UTC).strftime("%Y-%m-%d"),
			total_study_minutes=0,
			total_break_minutes=0,
			sessions_completed=0,
			topics_covered=0,
			avg_focus_score=None,
			streak_days=0,
		)

	async def get_summary(self, db: AsyncSession, user_id: str) -> dict:
		"""Résumé global de révision"""
		total_sessions = await repo.count_completed_sessions(db, user_id)
		total_minutes = await repo.get_total_revision_time(db, user_id)
		return {
			"total_sessions": total_sessions,
			"total_study_minutes": total_minutes,
		}
