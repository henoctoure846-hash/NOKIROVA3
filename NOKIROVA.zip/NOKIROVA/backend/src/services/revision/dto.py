"""NOKIROVA — DTOs Révision

Schémas de validation pour les plans de révision, sujets et sessions.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

# --- Plans de révision ---


class RevisionPlanCreateRequest(BaseModel):
	"""DTO de création de plan de révision"""

	title: str = Field(min_length=3, max_length=200)
	description: str | None = Field(None, max_length=1000)
	course_id: str | None = None
	plan_type: str = Field(pattern=r"^(spaced|cram|pomodoro|custom)$", default="spaced")
	start_date: str | None = None
	end_date: str | None = None
	exam_date: str | None = None
	daily_hours: float = Field(ge=0.5, le=12.0, default=2.0)
	priority: str = Field(pattern=r"^(low|medium|high|critical)$", default="medium")
	algorithm: str = Field(pattern=r"^(sm2|leitner|custom)$", default="sm2")
	settings: dict | None = None


class RevisionPlanUpdateRequest(BaseModel):
	"""DTO de mise à jour de plan de révision"""

	title: str | None = Field(None, min_length=3, max_length=200)
	description: str | None = Field(None, max_length=1000)
	plan_type: str | None = Field(None, pattern=r"^(spaced|cram|pomodoro|custom)$")
	start_date: str | None = None
	end_date: str | None = None
	exam_date: str | None = None
	daily_hours: float | None = Field(None, ge=0.5, le=12.0)
	priority: str | None = Field(None, pattern=r"^(low|medium|high|critical)$")
	status: str | None = Field(None, pattern=r"^(draft|active|paused|completed|archived)$")
	algorithm: str | None = Field(None, pattern=r"^(sm2|leitner|custom)$")
	settings: dict | None = None
	progress: float | None = Field(None, ge=0.0, le=100.0)


# --- Sujets de révision ---


class RevisionTopicCreateRequest(BaseModel):
	"""DTO de création de sujet de révision"""

	plan_id: str
	name: str = Field(min_length=1, max_length=200)
	description: str | None = Field(None, max_length=1000)
	subject: str | None = Field(None, max_length=100)
	priority: str = Field(pattern=r"^(low|medium|high|critical)$", default="medium")
	difficulty: str = Field(pattern=r"^(easy|medium|hard)$", default="medium")
	confidence_level: float = Field(ge=0.0, le=1.0, default=0.5)
	estimated_hours: float = Field(ge=0.1, le=100.0, default=1.0)
	sort_order: int = Field(ge=0, default=0)
	resource_refs: list | None = None


class RevisionTopicUpdateRequest(BaseModel):
	"""DTO de mise à jour de sujet de révision"""

	name: str | None = Field(None, min_length=1, max_length=200)
	description: str | None = Field(None, max_length=1000)
	subject: str | None = Field(None, max_length=100)
	priority: str | None = Field(None, pattern=r"^(low|medium|high|critical)$")
	difficulty: str | None = Field(None, pattern=r"^(easy|medium|hard)$")
	confidence_level: float | None = Field(None, ge=0.0, le=1.0)
	estimated_hours: float | None = Field(None, ge=0.1, le=100.0)
	actual_hours: float | None = Field(None, ge=0.0)
	mastery_level: str | None = Field(None, pattern=r"^(new|learning|familiar|proficient|mastered)$")
	sort_order: int | None = Field(None, ge=0)
	resource_refs: list | None = None


# --- Sessions de révision ---


class RevisionSessionStartRequest(BaseModel):
	"""DTO de démarrage de session"""

	plan_id: str
	topic_id: str | None = None
	session_type: str = Field(pattern=r"^(study|review|practice|break)$", default="study")
	duration_minutes: int = Field(ge=5, le=480, default=25)


class RevisionSessionEndRequest(BaseModel):
	"""DTO de fin de session"""

	actual_duration_minutes: int | None = Field(None, ge=1, le=480)
	focus_score: float | None = Field(None, ge=0.0, le=100.0)
	status: str | None = Field(None, pattern=r"^(completed|skipped)$")
	notes: str | None = Field(None, max_length=2000)


# --- Réponses ---


class RevisionTopicResponse(BaseModel):
	"""DTO de réponse sujet de révision"""

	id: str
	plan_id: str
	name: str
	description: str | None = None
	subject: str | None = None
	priority: str = "medium"
	difficulty: str = "medium"
	confidence_level: float = 0.5
	estimated_hours: float = 1.0
	actual_hours: float = 0.0
	mastery_level: str = "new"
	sort_order: int = 0
	resource_refs: list | None = None

	model_config = ConfigDict(from_attributes=True)


class RevisionPlanResponse(BaseModel):
	"""DTO de réponse plan de révision"""

	id: str
	owner_id: str
	title: str
	description: str | None = None
	course_id: str | None = None
	plan_type: str = "spaced"
	start_date: str | None = None
	end_date: str | None = None
	exam_date: str | None = None
	daily_hours: float = 2.0
	priority: str = "medium"
	status: str = "active"
	ai_generated: bool = False
	algorithm: str = "sm2"
	progress: float = 0.0
	topics: list[RevisionTopicResponse] | None = None
	created_at: datetime | None = None

	model_config = ConfigDict(from_attributes=True)


class RevisionSessionResponse(BaseModel):
	"""DTO de réponse session"""

	id: str
	user_id: str
	plan_id: str
	topic_id: str | None = None
	session_type: str = "study"
	duration_minutes: int = 25
	actual_duration_minutes: int | None = None
	focus_score: float | None = None
	started_at: str | None = None
	ended_at: str | None = None
	status: str = "scheduled"
	notes: str | None = None

	model_config = ConfigDict(from_attributes=True)


class RevisionStatsResponse(BaseModel):
	"""DTO de statistiques de révision"""

	user_id: str
	plan_id: str | None = None
	date: str = ""
	total_study_minutes: int = 0
	total_break_minutes: int = 0
	sessions_completed: int = 0
	topics_covered: int = 0
	avg_focus_score: float | None = None
	streak_days: int = 0

	model_config = ConfigDict(from_attributes=True)


class RevisionPlanListResponse(BaseModel):
	"""DTO de liste de plans"""

	plans: list[RevisionPlanResponse]
	total: int
	offset: int
	limit: int
