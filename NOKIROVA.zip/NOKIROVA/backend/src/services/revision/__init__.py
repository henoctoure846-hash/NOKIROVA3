"""NOKIROVA — Service Révision"""

from .repository import RevisionRepository as RevisionRepository
from .service import RevisionService as RevisionService
