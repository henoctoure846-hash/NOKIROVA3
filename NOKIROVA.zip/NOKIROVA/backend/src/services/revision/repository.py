"""NOKIROVA — Depot Revision

Acces aux donnees pour les plans, sujets, sessions et statistiques
de revision.
Patron Style B : session (db) passee en argument a chaque methode.

Ce depot ne peut PAS heriter de BaseRepository car chaque methode
accepte sa propre session AsyncSession — in Compatible avec le
stockage de session dans BaseRepository.__init__.

Operations disponibles :
    - Plans de revision (get_plan, list_plans, create_plan,
      update_plan, soft_delete_plan)
    - Sujets de revision (get_topic, list_topics, create_topic,
      update_topic, delete_topic)
    - Sessions de revision (get_session, list_sessions,
      create_session, update_session)
    - Statistiques (get_stats, count_completed_sessions,
      get_total_revision_time)

Suppression douce : is_active=False sur RevisionPlan et
RevisionTopic. Pas de deleted_at (convention NOKIROVA).
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.revision import RevisionPlan, RevisionSession, RevisionStats, RevisionTopic

# ─── Depot Revision ──────────────────────────────────────────────────


class RevisionRepository:
	"""Depot pour les entites Revision — requetes DB uniquement.

	Patron Style B : chaque methode recoit sa session AsyncSession.
	Aucune logique metier, aucun SQL direct — SQLAlchemy ORM uniquement.
	"""

	# ── Plans de revision ──────────────────────────────────────────

	async def get_plan(self, db: AsyncSession, plan_id: str) -> RevisionPlan | None:
		"""Recupere un plan de revision par son identifiant."""
		result = await db.execute(select(RevisionPlan).where(RevisionPlan.id == plan_id))
		return result.scalars().first()

	async def list_plans(
		self, db: AsyncSession, owner_id: str, offset: int = 0, limit: int = 20
	) -> Sequence[RevisionPlan]:
		"""Liste les plans de revision d'un proprietaire."""
		result = await db.execute(
			select(RevisionPlan)
			.where(RevisionPlan.owner_id == owner_id)
			.offset(offset)
			.limit(limit)
			.order_by(RevisionPlan.created_at.desc())
		)
		return result.scalars().all()

	async def create_plan(self, db: AsyncSession, plan: RevisionPlan) -> RevisionPlan:
		"""Cree un nouveau plan de revision."""
		db.add(plan)
		await db.flush()
		await db.refresh(plan)
		return plan

	async def update_plan(self, db: AsyncSession, plan_id: str, data: dict) -> RevisionPlan | None:
		"""Met a jour les champs d'un plan de revision."""
		await db.execute(update(RevisionPlan).where(RevisionPlan.id == plan_id).values(**data))
		return await self.get_plan(db, plan_id)

	async def soft_delete_plan(self, db: AsyncSession, plan_id: str) -> bool:
		"""Suppression douce d'un plan — is_active=False."""
		await db.execute(update(RevisionPlan).where(RevisionPlan.id == plan_id).values(is_active=False))
		return True

	# ── Sujets de revision ────────────────────────────────────────

	async def get_topic(self, db: AsyncSession, topic_id: str) -> RevisionTopic | None:
		"""Recupere un sujet de revision par son identifiant."""
		result = await db.execute(select(RevisionTopic).where(RevisionTopic.id == topic_id))
		return result.scalars().first()

	async def list_topics(self, db: AsyncSession, plan_id: str) -> Sequence[RevisionTopic]:
		"""Liste les sujets d'un plan de revision."""
		result = await db.execute(
			select(RevisionTopic)
			.where(RevisionTopic.plan_id == plan_id)
			.order_by(RevisionTopic.sort_order, RevisionTopic.name)
		)
		return result.scalars().all()

	async def create_topic(self, db: AsyncSession, topic: RevisionTopic) -> RevisionTopic:
		"""Cree un nouveau sujet de revision."""
		db.add(topic)
		await db.flush()
		await db.refresh(topic)
		return topic

	async def update_topic(self, db: AsyncSession, topic_id: str, data: dict) -> RevisionTopic | None:
		"""Met a jour les champs d'un sujet de revision."""
		await db.execute(update(RevisionTopic).where(RevisionTopic.id == topic_id).values(**data))
		return await self.get_topic(db, topic_id)

	async def delete_topic(self, db: AsyncSession, topic_id: str) -> bool:
		"""Suppression douce d'un sujet — is_active=False."""
		await db.execute(update(RevisionTopic).where(RevisionTopic.id == topic_id).values(is_active=False))
		return True

	# ── Sessions de revision ───────────────────────────────────────

	async def get_session(self, db: AsyncSession, session_id: str) -> RevisionSession | None:
		"""Recupere une session de revision par son identifiant."""
		result = await db.execute(select(RevisionSession).where(RevisionSession.id == session_id))
		return result.scalars().first()

	async def list_sessions(
		self, db: AsyncSession, user_id: str, offset: int = 0, limit: int = 20
	) -> Sequence[RevisionSession]:
		"""Liste les sessions de revision d'un utilisateur."""
		result = await db.execute(
			select(RevisionSession)
			.where(RevisionSession.user_id == user_id)
			.offset(offset)
			.limit(limit)
			.order_by(RevisionSession.created_at.desc())
		)
		return result.scalars().all()

	async def create_session(self, db: AsyncSession, session: RevisionSession) -> RevisionSession:
		"""Cree une nouvelle session de revision."""
		db.add(session)
		await db.flush()
		await db.refresh(session)
		return session

	async def update_session(self, db: AsyncSession, session_id: str, data: dict) -> RevisionSession | None:
		"""Met a jour les champs d'une session de revision."""
		await db.execute(update(RevisionSession).where(RevisionSession.id == session_id).values(**data))
		return await self.get_session(db, session_id)

	# ── Statistiques ───────────────────────────────────────────────

	async def get_stats(self, db: AsyncSession, user_id: str, plan_id: str | None = None) -> RevisionStats | None:
		"""Recupere les statistiques de revision d'un utilisateur,
		eventuellement filtree par plan.
		"""
		query = select(RevisionStats).where(RevisionStats.user_id == user_id)
		if plan_id:
			query = query.where(RevisionStats.plan_id == plan_id)
		query = query.order_by(RevisionStats.date.desc()).limit(1)
		result = await db.execute(query)
		return result.scalars().first()

	async def count_completed_sessions(self, db: AsyncSession, user_id: str) -> int:
		"""Compte les sessions de revision terminee d'un utilisateur."""
		result = await db.execute(
			select(func.count(RevisionSession.id)).where(
				and_(
					RevisionSession.user_id == user_id,
					RevisionSession.status == "completed",
				)
			)
		)
		return result.scalar() or 0

	async def get_total_revision_time(self, db: AsyncSession, user_id: str) -> int:
		"""Calcule le temps total de revision en minutes."""
		result = await db.execute(
			select(func.coalesce(func.sum(RevisionSession.actual_duration_minutes), 0)).where(
				and_(
					RevisionSession.user_id == user_id,
					RevisionSession.status == "completed",
				)
			)
		)
		return result.scalar() or 0
