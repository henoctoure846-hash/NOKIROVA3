"""NOKIROVA — Service Recherche"""

from .service import SearchService as SearchService
