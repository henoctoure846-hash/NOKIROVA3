"""NOKIROVA — DTOs Recherche

Structures de validation Pydantic pour la recherche
textuelle et l'indexation des ressources.
Aligné sur les modèles réels : SearchIndex, VectorEmbedding, IndexJob
du module src.database.models.indexing.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Énumérations ────────────────────────────────────────────────────────────


class TypeRessourceEnum(StrEnum):
	"""Types de ressources recherchables."""

	cours = "cours"
	lecon = "lecon"
	flashcard = "flashcard"
	quiz = "quiz"
	document = "document"
	publication = "publication"
	commentaire = "commentaire"
	utilisateur = "utilisateur"
	badge = "badge"
	fil_discussion = "fil_discussion"


class TriRechercheEnum(StrEnum):
	"""Options de tri pour les résultats de recherche."""

	pertinence = "pertinence"
	date_creation = "date_creation"
	date_modification = "date_modification"


# ─── DTOs de requête ──────────────────────────────────────────────────────────


class FiltreRechercheDTO(BaseModel):
	"""Filtres avancés pour la recherche."""

	types: list[TypeRessourceEnum] | None = None
	owner_id: str | None = None
	langue: str | None = None
	est_public: bool | None = None


class RechercheDTO(BaseModel):
	"""Requête de recherche complète."""

	requete: str = Field(..., min_length=1, max_length=500, description="Texte de recherche")
	filtres: FiltreRechercheDTO | None = None
	tri: TriRechercheEnum = TriRechercheEnum.pertinence
	page: int = Field(default=1, ge=1)
	taille_page: int = Field(default=20, ge=1, le=100)
	inclure_contenu: bool = Field(default=False, description="Inclure le contenu complet")
	surligner: bool = Field(default=True, description="Surligner les correspondances")


class AutocompletionDTO(BaseModel):
	"""Requête d'autocomplétion."""

	requete: str = Field(..., min_length=1, max_length=100)
	limite: int = Field(default=10, ge=1, le=50)
	types: list[TypeRessourceEnum] | None = None


# ─── DTOs de réponse ─────────────────────────────────────────────────────────


class ResultatRechercheDTO(BaseModel):
	"""Un résultat individuel de recherche."""

	id: str
	resource_type: str
	title: str
	summary: str | None = None
	content: str | None = None
	keywords: list[str] | None = None
	language: str | None = None
	owner_id: str | None = None
	is_public: bool | None = None
	relevance_score: float = Field(default=1.0, ge=0, le=1, description="Score de pertinence")
	surlignage: dict | None = None


class RechercheResponseDTO(BaseModel):
	"""Réponse complète de recherche."""

	requete: str
	resultats: list[ResultatRechercheDTO]
	total: int
	page: int
	taille_page: int
	total_pages: int
	temps_ms: int
	facettes: dict | None = None
	suggestions_correction: list[str] | None = None


class SuggestionAutocompletionDTO(BaseModel):
	"""Une suggestion d'autocomplétion."""

	texte: str
	resource_type: str
	resource_id: str | None = None
	score: float


class AutocompletionResponseDTO(BaseModel):
	"""Réponse d'autocomplétion."""

	requete: str
	suggestions: list[SuggestionAutocompletionDTO]
	temps_ms: int


class IndexationDTO(BaseModel):
	"""Requête d'indexation d'une ressource — alignée sur SearchIndex."""

	resource_type: str = Field(..., description="Type de ressource (document, course, lesson…)")
	resource_id: str = Field(..., description="UUID de la ressource")
	title: str = Field(..., max_length=500, description="Titre de la ressource")
	content: str | None = None
	summary: str | None = None
	keywords: list[str] | None = None
	language: str = "fr"
	owner_id: str = Field(..., description="UUID du propriétaire")
	is_public: bool = True
	relevance_score: float = Field(default=1.0, ge=0)


class IndexationResponseDTO(BaseModel):
	"""Réponse d'indexation."""

	resource_type: str
	resource_id: str
	indexe: bool
	message: str | None = None


class DesindexationResponseDTO(BaseModel):
	"""Réponse de désindexation."""

	resource_type: str
	resource_id: str
	supprime: bool
	message: str | None = None


class VectorEmbeddingDTO(BaseModel):
	"""DTO pour les embeddings vectoriels — aligné sur VectorEmbedding."""

	resource_type: str
	resource_id: str
	chunk_index: int = 0
	chunk_text: str | None = None
	embedding_model: str
	embedding_dim: int = 1536
	index_metadata: dict | None = None


class IndexJobDTO(BaseModel):
	"""DTO pour les tâches d'indexation — aligné sur IndexJob."""

	resource_type: str
	resource_id: str
	job_type: str = Field(..., description="full_index, update_index, reindex, delete_index")
	status: str = "pending"
	chunks_created: int = 0
	embeddings_created: int = 0
	error_message: str | None = None
	started_at: str | None = None
	completed_at: str | None = None
