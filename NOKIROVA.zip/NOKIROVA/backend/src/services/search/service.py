"""NOKIROVA — Service Recherche

Logique métier pour la recherche full-text,
l'autocomplétion et l'indexation des ressources.
Utilise l'injection de session — pas d'instances module-level.
"""

from __future__ import annotations

import time
from collections.abc import Sequence

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.database.models.indexing import IndexJob, VectorEmbedding
from src.events.bus import Event, event_bus
from src.services.search.dto import (
	AutocompletionDTO,
	AutocompletionResponseDTO,
	DesindexationResponseDTO,
	IndexationDTO,
	IndexationResponseDTO,
	RechercheDTO,
	RechercheResponseDTO,
	ResultatRechercheDTO,
	SuggestionAutocompletionDTO,
	VectorEmbeddingDTO,
)
from src.services.search.repository import (
	IndexJobRepository,
	IndexRepository,
	VectorEmbeddingRepository,
)

# ─── Constantes de cache ────────────────────────────────────────────────────

CACHE_NS_SEARCH = "search_index"
CACHE_NS_AUTOCOMPLETE = "autocomplete"
CACHE_TTL_COURT = 300  # 5 minutes
CACHE_TTL_MOYEN = 900  # 15 minutes
CACHE_TTL_LONG = 3600  # 1 heure


# ─── Service Recherche ──────────────────────────────────────────────────────


class SearchService:
	"""Service principal de recherche et d'indexation.

	Injecte la session AsyncSession — chaque requête HTTP
	crée un service avec sa propre session.
	"""

	def __init__(self, session: AsyncSession):
		self.session = session
		self.index_repo = IndexRepository(session)
		self.job_repo = IndexJobRepository(session)
		self.vector_repo = VectorEmbeddingRepository(session)

	# ── Recherche ────────────────────────────────────────────────────

	async def search(self, dto: RechercheDTO) -> RechercheResponseDTO:
		"""Effectue une recherche full-text avec filtres."""
		debut = time.time()

		# Vérification du cache
		cle_cache = f"rech:{dto.requete}:{dto.page}:{dto.taille_page}"
		resultat_cache = await cache_manager.get(CACHE_NS_SEARCH, cle_cache)
		if resultat_cache is not None:
			return resultat_cache

		# Construction des filtres
		types = None
		if dto.filtres and dto.filtres.types:
			types = [t.value for t in dto.filtres.types]

		owner_id = dto.filtres.owner_id if dto.filtres else None
		langue = dto.filtres.langue if dto.filtres else None
		est_public = dto.filtres.est_public if dto.filtres else None

		# Exécution de la recherche
		resultats_bruts, total = await self.index_repo.full_text_search(
			requete=dto.requete,
			types=types,
			owner_id=owner_id,
			langue=langue,
			est_public=est_public,
			page=dto.page,
			taille_page=dto.taille_page,
		)

		# Conversion en DTOs
		resultats_dto = []
		for index_entry, score in resultats_bruts:
			resultat = ResultatRechercheDTO(
				id=str(index_entry.id),
				resource_type=index_entry.resource_type,
				title=index_entry.title,
				summary=index_entry.summary,
				content=index_entry.content if dto.inclure_contenu else None,
				keywords=index_entry.keywords,
				language=index_entry.language,
				owner_id=str(index_entry.owner_id),
				is_public=index_entry.is_public,
				relevance_score=score if score else float(index_entry.relevance_score),
			)
			resultats_dto.append(resultat)

		# Calcul du nombre de pages
		total_pages = (total + dto.taille_page - 1) // dto.taille_page if total > 0 else 0

		# Construction de la facette par type
		facettes = {}
		for res in resultats_dto:
			rt = res.resource_type
			facettes[rt] = facettes.get(rt, 0) + 1

		temps_ms = int((time.time() - debut) * 1000)

		reponse = RechercheResponseDTO(
			requete=dto.requete,
			resultats=resultats_dto,
			total=total,
			page=dto.page,
			taille_page=dto.taille_page,
			total_pages=total_pages,
			temps_ms=temps_ms,
			facettes=facettes if facettes else None,
		)

		# Mise en cache du résultat
		await cache_manager.set(CACHE_NS_SEARCH, cle_cache, reponse, ttl=CACHE_TTL_COURT)

		# Publication de l'événement de recherche
		evenement = Event(
			event_type="search.recherche.effectuee",
			domain="search",
			payload={
				"requete": dto.requete,
				"nombre_resultats": total,
				"temps_ms": temps_ms,
				"filtres": {
					"types": types,
					"owner_id": owner_id,
					"langue": langue,
					"est_public": est_public,
				},
			},
		)
		await event_bus.publish(evenement)

		return reponse

	# ── Autocomplétion ───────────────────────────────────────────────

	async def autocomplete(self, dto: AutocompletionDTO) -> AutocompletionResponseDTO:
		"""Fournit des suggestions d'autocomplétion.

		Pas de table SearchSuggestion — on utilise
		directement SearchIndex.title et SearchIndex.keywords.
		"""
		debut = time.time()

		# Vérification du cache
		cle_cache = f"auto:{dto.requete}:{dto.limite}"
		resultat_cache = await cache_manager.get(CACHE_NS_AUTOCOMPLETE, cle_cache)
		if resultat_cache is not None:
			return resultat_cache

		# Recherche dans l'index
		types = [t.value for t in dto.types] if dto.types else None
		resultats = await self.index_repo.autocomplete(
			requete=dto.requete,
			limite=dto.limite,
			types=types,
		)

		# Conversion en suggestions
		suggestions = []
		for idx in resultats:
			suggestion = SuggestionAutocompletionDTO(
				texte=idx.title,
				resource_type=idx.resource_type,
				resource_id=str(idx.resource_id),
				score=float(idx.relevance_score),
			)
			suggestions.append(suggestion)

		temps_ms = int((time.time() - debut) * 1000)

		reponse = AutocompletionResponseDTO(
			requete=dto.requete,
			suggestions=suggestions,
			temps_ms=temps_ms,
		)

		# Mise en cache
		await cache_manager.set(CACHE_NS_AUTOCOMPLETE, cle_cache, reponse, ttl=CACHE_TTL_COURT)

		return reponse

	# ── Indexation ───────────────────────────────────────────────────

	async def index(self, dto: IndexationDTO) -> IndexationResponseDTO:
		"""Indexe ou met à jour une ressource dans l'index de recherche."""
		# Création / mise à jour de l'index
		index = await self.index_repo.upsert(
			resource_type=dto.resource_type,
			resource_id=dto.resource_id,
			title=dto.title,
			content=dto.content,
			summary=dto.summary,
			keywords=dto.keywords,
			language=dto.language,
			owner_id=dto.owner_id,
			is_public=dto.is_public,
			relevance_score=dto.relevance_score,
		)

		# Création d'une tâche d'indexation
		job = await self.job_repo.create(
			resource_type=dto.resource_type,
			resource_id=dto.resource_id,
			job_type="full_index",
			status="pending",
		)

		# Invalidation du cache
		await cache_manager.invalidate_namespace(CACHE_NS_SEARCH)
		await cache_manager.invalidate_namespace(CACHE_NS_AUTOCOMPLETE)

		# Publication de l'événement
		evenement = Event(
			event_type="search.ressource.indexee",
			domain="search",
			payload={
				"resource_type": dto.resource_type,
				"resource_id": dto.resource_id,
				"index_id": str(index.id),
				"job_id": str(job.id),
			},
		)
		await event_bus.publish(evenement)

		return IndexationResponseDTO(
			resource_type=dto.resource_type,
			resource_id=dto.resource_id,
			indexe=True,
			message="Ressource indexée avec succès",
		)

	async def deindex(self, resource_type: str, resource_id: str) -> DesindexationResponseDTO:
		"""Désindexe une ressource (suppression douce)."""
		supprime = await self.index_repo.delete_by_type_and_id(resource_type, resource_id)

		# Suppression douce des embeddings
		await self.vector_repo.delete_by_resource(resource_type, resource_id)

		# Invalidation du cache
		await cache_manager.invalidate_namespace(CACHE_NS_SEARCH)
		await cache_manager.invalidate_namespace(CACHE_NS_AUTOCOMPLETE)

		# Publication de l'événement
		evenement = Event(
			event_type="search.ressource.desindexee",
			domain="search",
			payload={
				"resource_type": resource_type,
				"resource_id": resource_id,
				"supprime": supprime,
			},
		)
		await event_bus.publish(evenement)

		return DesindexationResponseDTO(
			resource_type=resource_type,
			resource_id=resource_id,
			supprime=supprime,
			message="Ressource désindexée" if supprime else "Ressource non trouvée",
		)

	# ── Embeddings vectoriels ─────────────────────────────────────────

	async def create_embedding(self, dto: VectorEmbeddingDTO) -> VectorEmbedding:
		"""Crée un embedding vectoriel pour une ressource."""
		embedding = await self.vector_repo.create(
			resource_type=dto.resource_type,
			resource_id=dto.resource_id,
			chunk_index=dto.chunk_index,
			chunk_text=dto.chunk_text,
			embedding_model=dto.embedding_model,
			embedding_dim=dto.embedding_dim,
			index_metadata=dto.index_metadata,
		)
		return embedding

	async def get_embeddings(self, resource_type: str, resource_id: str) -> Sequence[VectorEmbedding]:
		"""Récupère les embeddings d'une ressource."""
		return await self.vector_repo.get_by_resource(resource_type, resource_id)

	# ── Tâches d'indexation ──────────────────────────────────────────

	async def get_index_job(self, job_id: str) -> IndexJob | None:
		"""Récupère une tâche d'indexation par ID."""
		return await self.job_repo.get_by_id(job_id)

	async def get_resource_jobs(self, resource_type: str, resource_id: str) -> Sequence[IndexJob]:
		"""Récupère les tâches d'indexation d'une ressource."""
		return await self.job_repo.get_by_resource(resource_type, resource_id)

	async def update_job(self, job_id: str, statut: str, **donnees) -> IndexJob | None:
		"""Met à jour le statut d'une tâche d'indexation."""
		return await self.job_repo.update_status(job_id, statut, **donnees)
