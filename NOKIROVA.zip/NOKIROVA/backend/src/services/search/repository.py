"""NOKIROVA — Référentiel Recherche

Couche d'accès aux données uniquement —
requêtes SQL pour la recherche full-text,
l'indexation et l'autocomplétion.
Aligné sur les modèles réels : SearchIndex, VectorEmbedding, IndexJob
issus du module src.database.models.indexing.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, desc, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.models.indexing import (
	IndexJob,
	SearchIndex,
	VectorEmbedding,
)

# ─── Index Repository ────────────────────────────────────────────────────────


class IndexRepository:
	"""Accès aux données de l'index de recherche.

	Utilise l'injection de session (pas d'instances module-level).
	Champs alignés sur SearchIndex : resource_type, resource_id, title,
	content, summary, keywords, language, owner_id, is_public, relevance_score.
	"""

	def __init__(self, session: AsyncSession):
		self.session = session

	# ── CRUD SearchIndex ──────────────────────────────────────────────

	async def upsert(self, **donnees) -> SearchIndex:
		"""Crée ou met à jour un enregistrement d'index de recherche."""
		resource_type = donnees.get("resource_type", "")
		resource_id = donnees.get("resource_id", "")

		existant = await self.get_by_type_and_id(resource_type, resource_id)
		if existant:
			for cle, valeur in donnees.items():
				if hasattr(existant, cle):
					setattr(existant, cle, valeur)
			await self.session.flush()
			return existant

		index = SearchIndex(**donnees)
		self.session.add(index)
		await self.session.flush()
		return index

	async def get_by_type_and_id(self, resource_type: str, resource_id: str) -> SearchIndex | None:
		"""Récupère un index par type et ID de ressource."""
		result = await self.session.execute(
			select(SearchIndex).where(
				and_(
					SearchIndex.resource_type == resource_type,
					SearchIndex.resource_id == resource_id,
				)
			)
		)
		return result.scalar_one_or_none()

	async def get_by_id(self, index_id: str) -> SearchIndex | None:
		"""Récupère un index par son identifiant primaire."""
		result = await self.session.execute(select(SearchIndex).where(SearchIndex.id == index_id))
		return result.scalar_one_or_none()

	async def delete_by_type_and_id(self, resource_type: str, resource_id: str) -> bool:
		"""Suppression douce — désactive l'index au lieu de le supprimer."""
		index = await self.get_by_type_and_id(resource_type, resource_id)
		if index:
			index.soft_delete()
			await self.session.flush()
			return True
		return False

	# ── Recherche full-text ──────────────────────────────────────────

	async def full_text_search(
		self,
		requete: str,
		types: list[str] | None = None,
		owner_id: str | None = None,
		langue: str | None = None,
		est_public: bool | None = None,
		page: int = 1,
		taille_page: int = 20,
	) -> tuple[Sequence[tuple[SearchIndex, float]], int]:
		"""Recherche full-text avec filtres.

		Utilise ts_vector PostgreSQL pour la recherche plein texte.
		Les filtres sont alignés sur les champs réels de SearchIndex.
		"""
		conditions = [SearchIndex.is_active == True]  # noqa: E712

		if types:
			conditions.append(SearchIndex.resource_type.in_(types))
		if owner_id:
			conditions.append(SearchIndex.owner_id == owner_id)
		if est_public is not None:
			conditions.append(SearchIndex.is_public == est_public)
		if langue:
			conditions.append(SearchIndex.language == langue)

		# Recherche full-text PostgreSQL (ts_vector)
		# Construction de la requête tsquery
		requete_ts = " & ".join(f"{mot}:*" for mot in requete.split() if len(mot) >= 2)

		if requete_ts:
			# Score de pertinence via ts_rank
			clause_rank = func.ts_rank(
				text("indexing_search.search_vector"),
				func.to_tsquery("french", requete_ts),
			).label("rank")

			requete_select = (
				select(SearchIndex, clause_rank)
				.where(
					and_(
						*conditions,
						text(
							"indexing_search.search_vector @@ to_tsquery('french', :q)"
						).bindparams(q=requete_ts),
					)
				)
				.order_by(desc("rank"))
			)
		else:
			# Pas de recherche full-text, juste les filtres
			requete_select = (
				select(SearchIndex).where(and_(*conditions)).order_by(desc(SearchIndex.created_at))
			)

		# Compter le total
		count_req = select(func.count()).select_from(requete_select.subquery())
		total = (await self.session.execute(count_req)).scalar() or 0

		# Paginer
		result = await self.session.execute(requete_select.offset((page - 1) * taille_page).limit(taille_page))

		if requete_ts:
			lignes = result.all()
			return [(ligne[0], ligne[1] if len(ligne) > 1 else 0.0) for ligne in lignes], total
		else:
			indices = result.scalars().all()
			return [(idx, 0.0) for idx in indices], total

	# ── Autocomplétion ───────────────────────────────────────────────

	async def autocomplete(
		self,
		requete: str,
		limite: int = 10,
		types: list[str] | None = None,
	) -> list[SearchIndex]:
		"""Autocomplétion basée sur les titres et mots-clés existants.

		Pas de table SearchSuggestion — on utilise directement
		SearchIndex.keywords et SearchIndex.title pour les suggestions.
		"""
		conditions = [SearchIndex.is_active == True]  # noqa: E712

		if types:
			conditions.append(SearchIndex.resource_type.in_(types))

		# Recherche préfixe sur le titre
		requete_autocomplete = (
			select(SearchIndex)
			.where(
				and_(
					*conditions,
					SearchIndex.title.ilike(f"{requete}%"),
				)
			)
			.order_by(desc(SearchIndex.relevance_score))
			.limit(limite)
		)

		result = await self.session.execute(requete_autocomplete)
		return list(result.scalars().all())


# ─── IndexJob Repository ─────────────────────────────────────────────────────


class IndexJobRepository:
	"""Accès aux données des tâches d'indexation."""

	def __init__(self, session: AsyncSession):
		self.session = session

	async def create(self, **donnees) -> IndexJob:
		"""Crée une tâche d'indexation."""
		job = IndexJob(**donnees)
		self.session.add(job)
		await self.session.flush()
		return job

	async def get_by_id(self, job_id: str) -> IndexJob | None:
		"""Récupère une tâche d'indexation par ID."""
		result = await self.session.execute(select(IndexJob).where(IndexJob.id == job_id))
		return result.scalar_one_or_none()

	async def get_by_resource(self, resource_type: str, resource_id: str) -> Sequence[IndexJob]:
		"""Récupère les tâches d'indexation d'une ressource."""
		result = await self.session.execute(
			select(IndexJob)
			.where(
				and_(
					IndexJob.resource_type == resource_type,
					IndexJob.resource_id == resource_id,
				)
			)
			.order_by(desc(IndexJob.created_at))
		)
		return result.scalars().all()

	async def update_status(self, job_id: str, statut: str, **donnees_supplementaires) -> IndexJob | None:
		"""Met à jour le statut d'une tâche d'indexation."""
		job = await self.get_by_id(job_id)
		if job:
			job.status = statut
			for cle, valeur in donnees_supplementaires.items():
				if hasattr(job, cle):
					setattr(job, cle, valeur)
			await self.session.flush()
		return job


# ─── VectorEmbedding Repository ──────────────────────────────────────────────


class VectorEmbeddingRepository:
	"""Accès aux données des embeddings vectoriels."""

	def __init__(self, session: AsyncSession):
		self.session = session

	async def create(self, **donnees) -> VectorEmbedding:
		"""Crée un embedding vectoriel."""
		embedding = VectorEmbedding(**donnees)
		self.session.add(embedding)
		await self.session.flush()
		return embedding

	async def get_by_resource(self, resource_type: str, resource_id: str) -> Sequence[VectorEmbedding]:
		"""Récupère les embeddings d'une ressource."""
		result = await self.session.execute(
			select(VectorEmbedding)
			.where(
				and_(
					VectorEmbedding.resource_type == resource_type,
					VectorEmbedding.resource_id == resource_id,
				)
			)
			.order_by(VectorEmbedding.chunk_index)
		)
		return result.scalars().all()

	async def delete_by_resource(self, resource_type: str, resource_id: str) -> int:
		"""Supprime les embeddings d'une ressource (soft delete)."""
		result = await self.session.execute(
			select(VectorEmbedding).where(
				and_(
					VectorEmbedding.resource_type == resource_type,
					VectorEmbedding.resource_id == resource_id,
				)
			)
		)
		embeddings = result.scalars().all()
		for emb in embeddings:
			emb.soft_delete()
		await self.session.flush()
		return len(embeddings)
