"""NOKIROVA — Service IA : Agents

Logique métier pour les agents IA :
- CRUD agents
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	AgentCreateDTO,
	AgentResponseDTO,
	AgentUpdateDTO,
)
from src.services.ai.repository import AgentRepository, ModelConfigRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_AGENTS = "ai:agents"
EVENT_DOMAIN = "ai"


# ─── Service Agents ──────────────────────────────────────────────────────────


class AIAgentService:
	"""Service métier pour les agents IA."""

	def __init__(
		self,
		session: AsyncSession,
		model_config_repo: ModelConfigRepository | None = None,
	) -> None:
		self.session = session
		self.agent_repo = AgentRepository(session)
		# Dépendance cross-domain : injectée par la façade ou autocréée
		self.model_config_repo = model_config_repo or ModelConfigRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_agent(
		self,
		dto: AgentCreateDTO,
	) -> AgentResponseDTO:
		"""Crée un agent IA."""
		# Vérifier le modèle si spécifié
		if dto.model_id:
			model = await self.model_config_repo.get_by_id(dto.model_id)
			if model is None:
				raise NotFoundException("Configuration de modèle introuvable")

		data = dto.model_dump(exclude_none=True)
		agent = await self.agent_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_AGENTS)

		await event_bus.publish(
			Event(
				event_type="agent_created",
				domain=EVENT_DOMAIN,
				payload={"agent_id": agent.id, "agent_type": agent.agent_type},
			)
		)

		return self._agent_to_response(agent)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_agent(self, agent_id: str) -> AgentResponseDTO:
		"""Récupère un agent IA."""
		cached = await cache_manager.get(CACHE_NS_AGENTS, agent_id)
		if cached:
			return AgentResponseDTO(**cached)

		agent = await self.agent_repo.get_by_id(agent_id)
		if agent is None:
			raise NotFoundException("Agent introuvable")

		response = self._agent_to_response(agent)
		await cache_manager.set(CACHE_NS_AGENTS, agent_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_agents(
		self,
		agent_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[AgentResponseDTO]:
		"""Liste les agents actifs."""
		agents = await self.agent_repo.list_active(agent_type, limit, offset)
		return [self._agent_to_response(a) for a in agents]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_agent(
		self,
		agent_id: str,
		dto: AgentUpdateDTO,
	) -> AgentResponseDTO:
		"""Met à jour un agent IA."""
		agent = await self.agent_repo.get_by_id(agent_id)
		if agent is None:
			raise NotFoundException("Agent introuvable")

		data = dto.model_dump(exclude_none=True)
		updated = await self.agent_repo.update(agent_id, data)

		await cache_manager.delete(CACHE_NS_AGENTS, agent_id)

		await event_bus.publish(
			Event(
				event_type="agent_updated",
				domain=EVENT_DOMAIN,
				payload={"agent_id": agent_id},
			)
		)

		return self._agent_to_response(updated)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _agent_to_response(agent) -> AgentResponseDTO:
		"""Convertit un modèle AIAgent en DTO de réponse."""
		return AgentResponseDTO(
			id=agent.id,
			name=agent.name,
			agent_type=agent.agent_type,
			description=agent.description,
			model_id=agent.model_id,
			system_prompt=agent.system_prompt,
			temperature=agent.temperature,
			max_tokens=agent.max_tokens,
			is_active=agent.is_active,
			config=agent.config,
			created_at=agent.created_at,
			updated_at=agent.updated_at,
		)
