"""NOKIROVA — Service IA : Messages

Logique métier pour les messages de conversation :
- Envoi de messages (cross-domain : journalise aussi l'utilisation)
- Consultation des messages d'une conversation
- Cache et événements

Dépendances cross-domain :
- ConversationRepository : validation d'existence / archive
- UsageLogRepository : journalisation automatique de l'utilisation
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	MessageCreateDTO,
	MessageResponseDTO,
)
from src.services.ai.repository import (
	ConversationRepository,
	MessageRepository,
	UsageLogRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_CONVERSATIONS = "ai:conversations"
EVENT_DOMAIN = "ai"


# ─── Service Messages ───────────────────────────────────────────────────────


class AIMessageService:
	"""Service métier pour les messages de conversation IA.

	send_message est une opération cross-domain : elle crée un message
	ET journalise automatiquement l'utilisation si des tokens/coûts
	sont disponibles. Les repos de conversation et d'utilisation
	sont injectés via le constructeur.
	"""

	def __init__(
		self,
		session: AsyncSession,
		conversation_repo: ConversationRepository,
		usage_repo: UsageLogRepository,
	) -> None:
		self.session = session
		self.message_repo = MessageRepository(session)
		self.conversation_repo = conversation_repo
		self.usage_repo = usage_repo

	# ─── Envoi de message ─────────────────────────────────────────────────

	async def send_message(
		self,
		dto: MessageCreateDTO,
	) -> MessageResponseDTO:
		"""Envoie un message dans une conversation.

		Cross-domain : crée le message ET journalise l'utilisation
		si des tokens/coûts sont disponibles (BIBLE #12 : Auditabilité).
		"""
		conversation = await self.conversation_repo.get_by_id(dto.conversation_id)
		if conversation is None:
			raise NotFoundException("Conversation introuvable")
		if conversation.is_archived:
			raise ValidationException("conversation_id", "Cette conversation est archivée")

		# Créer le message
		data = dto.model_dump(exclude_none=True)
		message = await self.message_repo.create(data)

		# Invalider le cache de la conversation
		await cache_manager.delete(CACHE_NS_CONVERSATIONS, dto.conversation_id)

		# Journaliser l'utilisation si pertinent (BIBLE #12 : Auditabilité)
		if message.token_count and message.cost:
			await self.usage_repo.create(
				{
					"user_id": conversation.user_id,
					"model_id": conversation.agent_id,
					"conversation_id": dto.conversation_id,
					"request_type": "chat",
					"prompt_tokens": message.token_count,
					"completion_tokens": 0,
					"total_tokens": message.token_count,
					"cost": message.cost,
					"latency_ms": message.latency_ms or 0,
					"is_cached": False,
					"engine": message.model_used,
				}
			)

		await event_bus.publish(
			Event(
				event_type="message_sent",
				domain=EVENT_DOMAIN,
				payload={
					"message_id": message.id,
					"conversation_id": dto.conversation_id,
					"role": message.role,
				},
			)
		)

		return self._message_to_response(message)

	# ─── Consultation ─────────────────────────────────────────────────────

	async def get_conversation_messages(
		self,
		conversation_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[MessageResponseDTO]:
		"""Récupère les messages d'une conversation."""
		conversation = await self.conversation_repo.get_by_id(conversation_id)
		if conversation is None:
			raise NotFoundException("Conversation introuvable")

		messages = await self.message_repo.list_by_conversation(conversation_id, limit, offset)
		return [self._message_to_response(m) for m in messages]

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _message_to_response(message) -> MessageResponseDTO:
		"""Convertit un modèle AIMessage en DTO de réponse."""
		return MessageResponseDTO(
			id=message.id,
			conversation_id=message.conversation_id,
			role=message.role,
			content=message.content,
			token_count=message.token_count,
			model_used=message.model_used,
			latency_ms=message.latency_ms,
			cost=message.cost,
			tool_calls=message.tool_calls,
			reasoning_chain=message.reasoning_chain,
			created_at=message.created_at,
			updated_at=message.updated_at,
		)
