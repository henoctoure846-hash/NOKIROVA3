"""NOKIROVA — Service IA : Façade de délégation

Façade principale qui délègue aux 6 sous-services métier :
- AIAGentService          → Agents IA
- AIConversationService   → Conversations
- AIMessageService         → Messages
- AIReasoningService       → Chaînes de raisonnement
- AIModelConfigService     → Configurations de modèle
- AIUsageService           → Journaux d'utilisation

BIBLE #7 (Modularité) : séparation claire des responsabilités.
BIBLE #5 (Interface Uniforme) : API publique identique au monolithe.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.ai.dto import (
	AgentCreateDTO,
	AgentResponseDTO,
	AgentUpdateDTO,
	ConversationCreateDTO,
	ConversationResponseDTO,
	MessageCreateDTO,
	MessageResponseDTO,
	ModelConfigCreateDTO,
	ModelConfigResponseDTO,
	ModelConfigUpdateDTO,
	ReasoningChainCreateDTO,
	ReasoningChainResponseDTO,
	UsageLogCreateDTO,
	UsageLogResponseDTO,
	UsageSummaryDTO,
)
from src.services.ai.repository import (
	AgentRepository,
	ConversationRepository,
	MessageRepository,
	ModelConfigRepository,
	ReasoningChainRepository,
	UsageLogRepository,
)
from src.services.ai.service_agents import AIAgentService
from src.services.ai.service_conversations import AIConversationService
from src.services.ai.service_messages import AIMessageService
from src.services.ai.service_models import AIModelConfigService
from src.services.ai.service_reasoning import AIReasoningService
from src.services.ai.service_usage import AIUsageService

# ─── Façade principale ──────────────────────────────────────────────────────


class AIService:
	"""Façade de délégation pour l'intelligence artificielle.

	API publique IDENTIQUE au monolithe original — BIBLE #5.
	Toutes les méthodes délèguent au sous-service compétent.
	"""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session

		# Repositories partagés (injectés dans les sous-services selon leurs besoins)
		self.agent_repo = AgentRepository(session)
		self.conversation_repo = ConversationRepository(session)
		self.message_repo = MessageRepository(session)
		self.chain_repo = ReasoningChainRepository(session)
		self.model_config_repo = ModelConfigRepository(session)
		self.usage_repo = UsageLogRepository(session)

		# Instanciation des 6 sous-services
		self.agent_svc = AIAgentService(
			session,
			model_config_repo=self.model_config_repo,
		)
		self.conversation_svc = AIConversationService(
			session,
			agent_repo=self.agent_repo,
		)
		self.message_svc = AIMessageService(
			session,
			conversation_repo=self.conversation_repo,
			usage_repo=self.usage_repo,
		)
		self.reasoning_svc = AIReasoningService(session)
		self.model_svc = AIModelConfigService(session)
		self.usage_svc = AIUsageService(session)

	# ─── Agents ────────────────────────────────────────────────────────

	async def create_agent(self, dto: AgentCreateDTO) -> AgentResponseDTO:
		"""Crée un agent IA."""
		return await self.agent_svc.create_agent(dto)

	async def get_agent(self, agent_id: str) -> AgentResponseDTO:
		"""Récupère un agent IA."""
		return await self.agent_svc.get_agent(agent_id)

	async def list_agents(
		self,
		agent_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[AgentResponseDTO]:
		"""Liste les agents actifs."""
		return await self.agent_svc.list_agents(agent_type, limit, offset)

	async def update_agent(
		self,
		agent_id: str,
		dto: AgentUpdateDTO,
	) -> AgentResponseDTO:
		"""Met à jour un agent IA."""
		return await self.agent_svc.update_agent(agent_id, dto)

	# ─── Conversations ──────────────────────────────────────────────────

	async def create_conversation(
		self,
		dto: ConversationCreateDTO,
	) -> ConversationResponseDTO:
		"""Crée une conversation."""
		return await self.conversation_svc.create_conversation(dto)

	async def get_conversation(
		self,
		conversation_id: str,
	) -> ConversationResponseDTO:
		"""Récupère une conversation."""
		return await self.conversation_svc.get_conversation(conversation_id)

	async def list_conversations(
		self,
		user_id: str,
		is_archived: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ConversationResponseDTO]:
		"""Liste les conversations d'un utilisateur."""
		return await self.conversation_svc.list_conversations(user_id, is_archived, limit, offset)

	async def archive_conversation(
		self,
		conversation_id: str,
	) -> ConversationResponseDTO:
		"""Archive une conversation."""
		return await self.conversation_svc.archive_conversation(conversation_id)

	# ─── Messages ──────────────────────────────────────────────────────

	async def send_message(
		self,
		dto: MessageCreateDTO,
	) -> MessageResponseDTO:
		"""Envoie un message dans une conversation."""
		return await self.message_svc.send_message(dto)

	async def get_conversation_messages(
		self,
		conversation_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[MessageResponseDTO]:
		"""Récupère les messages d'une conversation."""
		return await self.message_svc.get_conversation_messages(conversation_id, limit, offset)

	# ─── Chaînes de raisonnement ────────────────────────────────────────

	async def create_reasoning_chain(
		self,
		dto: ReasoningChainCreateDTO,
	) -> ReasoningChainResponseDTO:
		"""Crée une chaîne de raisonnement pour un message."""
		return await self.reasoning_svc.create_reasoning_chain(dto)

	async def get_reasoning_chain(
		self,
		message_id: str,
	) -> ReasoningChainResponseDTO | None:
		"""Récupère la chaîne de raisonnement d'un message."""
		return await self.reasoning_svc.get_reasoning_chain(message_id)

	# ─── Configuration de modèle ────────────────────────────────────────

	async def create_model_config(
		self,
		dto: ModelConfigCreateDTO,
	) -> ModelConfigResponseDTO:
		"""Crée une configuration de modèle."""
		return await self.model_svc.create_model_config(dto)

	async def get_model_config(
		self,
		config_id: str,
	) -> ModelConfigResponseDTO:
		"""Récupère une configuration de modèle."""
		return await self.model_svc.get_model_config(config_id)

	async def list_model_configs(
		self,
		provider: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ModelConfigResponseDTO]:
		"""Liste les configurations de modèle actives."""
		return await self.model_svc.list_model_configs(provider, limit, offset)

	async def update_model_config(
		self,
		config_id: str,
		dto: ModelConfigUpdateDTO,
	) -> ModelConfigResponseDTO:
		"""Met à jour une configuration de modèle."""
		return await self.model_svc.update_model_config(config_id, dto)

	@staticmethod
	def resoudre_cle_api(config) -> str | None:
		"""Déchiffre la clé API — délègue à AIModelConfigService (BIBLE #8)."""
		return AIModelConfigService.resoudre_cle_api(config)

	# ─── Journaux d'utilisation ──────────────────────────────────────────

	async def log_usage(
		self,
		dto: UsageLogCreateDTO,
	) -> UsageLogResponseDTO:
		"""Enregistre une entrée de journal d'utilisation."""
		return await self.usage_svc.log_usage(dto)

	async def get_usage_summary(
		self,
		user_id: str,
	) -> UsageSummaryDTO:
		"""Récupère le résumé d'utilisation d'un utilisateur."""
		return await self.usage_svc.get_usage_summary(user_id)

	async def list_user_usage(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[UsageLogResponseDTO]:
		"""Liste les journaux d'utilisation d'un utilisateur."""
		return await self.usage_svc.list_user_usage(user_id, limit, offset)
