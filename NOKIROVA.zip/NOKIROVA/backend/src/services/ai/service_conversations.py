"""NOKIROVA — Service IA : Conversations

Logique métier pour les conversations :
- CRUD conversations
- Archivage
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	ConversationCreateDTO,
	ConversationResponseDTO,
)
from src.services.ai.repository import (
	AgentRepository,
	ConversationRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_CONVERSATIONS = "ai:conversations"
EVENT_DOMAIN = "ai"


# ─── Service Conversations ───────────────────────────────────────────────────


class AIConversationService:
	"""Service métier pour les conversations IA."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.conversation_repo = ConversationRepository(session)
		self.agent_repo = AgentRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_conversation(
		self,
		dto: ConversationCreateDTO,
	) -> ConversationResponseDTO:
		"""Crée une conversation."""
		# Vérifier que l'agent existe et est actif
		agent = await self.agent_repo.get_by_id(dto.agent_id)
		if agent is None:
			raise NotFoundException("Agent introuvable")
		if not agent.is_active:
			raise ValidationException("agent_id", "Cet agent n'est plus actif")

		data = dto.model_dump(exclude_none=True)
		conversation = await self.conversation_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_CONVERSATIONS)

		await event_bus.publish(
			Event(
				event_type="conversation_created",
				domain=EVENT_DOMAIN,
				payload={
					"conversation_id": conversation.id,
					"user_id": dto.user_id,
					"agent_id": dto.agent_id,
				},
			)
		)

		return await self._conversation_to_response(conversation)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_conversation(
		self,
		conversation_id: str,
	) -> ConversationResponseDTO:
		"""Récupère une conversation."""
		cached = await cache_manager.get(CACHE_NS_CONVERSATIONS, conversation_id)
		if cached:
			return ConversationResponseDTO(**cached)

		conversation = await self.conversation_repo.get_by_id(conversation_id)
		if conversation is None:
			raise NotFoundException("Conversation introuvable")

		response = await self._conversation_to_response(conversation)
		await cache_manager.set(
			CACHE_NS_CONVERSATIONS,
			conversation_id,
			response.model_dump(mode="json"),
			ttl=300,
		)
		return response

	async def list_conversations(
		self,
		user_id: str,
		is_archived: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ConversationResponseDTO]:
		"""Liste les conversations d'un utilisateur."""
		conversations = await self.conversation_repo.list_by_user(user_id, is_archived, limit, offset)
		return [await self._conversation_to_response(c) for c in conversations]

	# ─── Archivage ────────────────────────────────────────────────────────

	async def archive_conversation(
		self,
		conversation_id: str,
	) -> ConversationResponseDTO:
		"""Archive une conversation."""
		conversation = await self.conversation_repo.get_by_id(conversation_id)
		if conversation is None:
			raise NotFoundException("Conversation introuvable")

		updated = await self.conversation_repo.update(conversation_id, {"is_archived": True})

		await cache_manager.delete(CACHE_NS_CONVERSATIONS, conversation_id)

		await event_bus.publish(
			Event(
				event_type="conversation_archived",
				domain=EVENT_DOMAIN,
				payload={"conversation_id": conversation_id},
			)
		)

		return await self._conversation_to_response(updated)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	async def _conversation_to_response(self, conversation) -> ConversationResponseDTO:
		"""Convertit un modèle AIConversation en DTO de réponse."""
		message_count = await self.conversation_repo.count_messages(conversation.id)
		return ConversationResponseDTO(
			id=conversation.id,
			user_id=conversation.user_id,
			agent_id=conversation.agent_id,
			title=conversation.title,
			context=conversation.context,
			is_archived=conversation.is_archived,
			summary=conversation.summary,
			metadata_json=conversation.metadata_json,
			message_count=message_count,
			created_at=conversation.created_at,
			updated_at=conversation.updated_at,
		)
