"""NOKIROVA — Depot AI

Acces aux donnees pour les agents, conversations, messages,
chaines de raisonnement, configurations de modele et journaux
d'utilisation. Utilise les modeles SQLAlchemy reels de ai.py.

Refactorisation :
    Agent, ModelConfig — Categorie (b) : heritage + soft_delete -> bool
    Conversation — Categorie (c) : soft_delete personnalise (is_archived=True)
    Message, ReasoningChain, UsageLog — Categorie (e) : pas de soft_delete
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.ai import (
	AIAgent,
	AIConversation,
	AIMessage,
	AIModelConfig,
	AIReasoningChain,
	AIUsageLog,
)

# ─── Agents — Categorie (b) ──────────────────────────────────────────────────


class AgentRepository(BaseRepository[AIAgent]):
	"""Depot pour les agents IA.

	Herite de BaseRepository[AIAgent].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIAgent, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, agent_id: str) -> bool:
		"""Suppression logique d'un agent."""
		result = await super().soft_delete(agent_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_active(
		self,
		agent_type: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[AIAgent]:
		"""Liste les agents actifs."""
		conditions = [AIAgent.is_active == True]  # noqa: E712
		if agent_type:
			conditions.append(AIAgent.agent_type == agent_type)

		stmt = (
			select(AIAgent)
			.where(and_(*conditions))
			.order_by(AIAgent.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Conversations — Categorie (c) : soft_delete personnalise ────────────────


class ConversationRepository(BaseRepository[AIConversation]):
	"""Depot pour les conversations.

	Herite de BaseRepository[AIConversation] para create/get/update.
	soft_delete surcharge : utilise is_archived=True (pas is_active).
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIConversation, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, conversation_id: str) -> bool:
		"""Suppression logique d'une conversation (archivage).

		Note : Contrairement a BaseRepository.soft_delete qui met
		is_active=False, ici on archive la conversation (is_archived=True).
		"""
		conversation = await self.get_by_id(conversation_id)
		if conversation is None:
			return False
		conversation.is_archived = True
		await self.session.flush()
		return True

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_user(
		self,
		user_id: str,
		is_archived: bool | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[AIConversation]:
		"""Liste les conversations d'un utilisateur."""
		conditions = [AIConversation.user_id == user_id]
		if is_archived is not None:
			conditions.append(AIConversation.is_archived == is_archived)

		stmt = (
			select(AIConversation)
			.where(and_(*conditions))
			.order_by(AIConversation.updated_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count_messages(self, conversation_id: str) -> int:
		"""Compte les messages d'une conversation."""
		stmt = select(func.count(AIMessage.id)).where(AIMessage.conversation_id == conversation_id)
		result = await self.session.execute(stmt)
		return result.scalar_one()


# ─── Messages — Categorie (e) ─────────────────────────────────────────────────


class MessageRepository(BaseRepository[AIMessage]):
	"""Depot pour les messages.

	Herite de BaseRepository[AIMessage] para create/get/update.
	Pas de soft_delete — les messages sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIMessage, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_conversation(
		self,
		conversation_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[AIMessage]:
		"""Liste les messages d'une conversation."""
		stmt = (
			select(AIMessage)
			.where(AIMessage.conversation_id == conversation_id)
			.order_by(AIMessage.created_at.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Chaines de raisonnement — Categorie (e) ─────────────────────────────────


class ReasoningChainRepository(BaseRepository[AIReasoningChain]):
	"""Depot pour les chaines de raisonnement.

	Herite de BaseRepository[AIReasoningChain] para create/get/update.
	Pas de soft_delete — les chaines sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIReasoningChain, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_message(self, message_id: str) -> AIReasoningChain | None:
		"""Recupere la chaine associee a un message (unique par message_id)."""
		stmt = select(AIReasoningChain).where(AIReasoningChain.message_id == message_id)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()


# ─── Configuration de modele — Categorie (b) ────────────────────────────────


class ModelConfigRepository(BaseRepository[AIModelConfig]):
	"""Depot pour les configurations de modele.

	Herite de BaseRepository[AIModelConfig].
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIModelConfig, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def soft_delete(self, config_id: str) -> bool:
		"""Suppression logique d'une configuration."""
		result = await super().soft_delete(config_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_model_name(self, model_name: str) -> AIModelConfig | None:
		"""Recupere une configuration par le nom du modele."""
		stmt = select(AIModelConfig).where(
			and_(
				AIModelConfig.model_name == model_name,
				AIModelConfig.is_active == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def list_active(
		self,
		provider: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[AIModelConfig]:
		"""Liste les configurations actives."""
		conditions = [AIModelConfig.is_active == True]  # noqa: E712
		if provider:
			conditions.append(AIModelConfig.provider == provider)

		stmt = (
			select(AIModelConfig)
			.where(and_(*conditions))
			.order_by(AIModelConfig.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()


# ─── Journaux d'utilisation — Categorie (e) ──────────────────────────────────


class UsageLogRepository(BaseRepository[AIUsageLog]):
	"""Depot pour les journaux d'utilisation.

	Herite de BaseRepository[AIUsageLog] para create/get.
	Pas de soft_delete — les journaux sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(AIUsageLog, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def list_by_user(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[AIUsageLog]:
		"""Liste les journaux d'un utilisateur."""
		stmt = (
			select(AIUsageLog)
			.where(AIUsageLog.user_id == user_id)
			.order_by(AIUsageLog.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_usage_summary(self, user_id: str) -> dict:
		"""Recupere le resume d'utilisation d'un utilisateur."""
		stmt = select(
			func.count(AIUsageLog.id).label("total_requests"),
			func.coalesce(func.sum(AIUsageLog.total_tokens), 0).label("total_tokens"),
			func.coalesce(func.sum(AIUsageLog.cost), 0.0).label("total_cost"),
			func.coalesce(func.avg(AIUsageLog.latency_ms), 0.0).label("avg_latency_ms"),
		).where(AIUsageLog.user_id == user_id)

		result = await self.session.execute(stmt)
		row = result.one()

		# Calculer le taux de succes du cache
		cached_stmt = select(func.count(AIUsageLog.id)).where(
			and_(
				AIUsageLog.user_id == user_id,
				AIUsageLog.is_cached == True,  # noqa: E712
			)
		)
		cached_result = await self.session.execute(cached_stmt)
		cached_count = cached_result.scalar_one()

		total = row.total_requests or 1
		cache_hit_rate = cached_count / total

		return {
			"total_requests": row.total_requests,
			"total_tokens": row.total_tokens,
			"total_cost": float(row.total_cost),
			"avg_latency_ms": float(row.avg_latency_ms),
			"cache_hit_rate": round(cache_hit_rate, 4),
		}
