"""NOKIROVA — DTOs du service AI

Modèles Pydantic pour la validation des requêtes et réponses
du module IA : agents, conversations, messages, chaînes de
raisonnement, configurations de modèle et journaux d'utilisation.
Alignés sur les modèles SQLAlchemy réels (ai.py).

Corrections clés :
- AIAgent : agent_type, model_id, system_prompt, temperature (Float),
  max_tokens, is_active, config (JSONB)
- AIConversation : user_id, agent_id, title, context (JSONB),
  is_archived, summary, metadata_json
- AIMessage : conversation_id, role, content, token_count, model_used,
  latency_ms, cost (Float), tool_calls (JSONB), reasoning_chain
- AIReasoningChain : message_id (unique), chain_type, steps (JSONB),
  final_answer, confidence_score (Float)
- AIModelConfig : provider, model_name, display_name, api_endpoint,
  api_key (entrée claire) → api_key_encrypted (stockage chiffré, réponse masquée),
  context_window, input_cost_per_1k/output_cost_per_1k (Float),
  is_active, capabilities (JSONB), config (JSONB)
- AIUsageLog : user_id, model_id, conversation_id, request_type,
  prompt_tokens, completion_tokens, total_tokens, cost (Float),
  latency_ms, is_cached, engine
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class AgentTypeEnum(StrEnum):
	"""Types d'agent IA."""

	tutor = "tutor"
	assistant = "assistant"
	evaluator = "evaluator"
	mentor = "mentor"
	creative = "creative"
	analyst = "analyst"


class MessageRoleEnum(StrEnum):
	"""Rôles de message."""

	system = "system"
	user = "user"
	assistant = "assistant"
	tool = "tool"


class ChainTypeEnum(StrEnum):
	"""Types de chaîne de raisonnement."""

	cot = "cot"
	tot = "tot"
	react = "react"
	reflection = "reflection"


class RequestTypeEnum(StrEnum):
	"""Types de requête IA."""

	chat = "chat"
	completion = "completion"
	embedding = "embedding"
	image = "image"
	transcription = "transcription"


class EngineEnum(StrEnum):
	"""Moteurs IA."""

	openai = "openai"
	anthropic = "anthropic"
	google = "google"
	local = "local"


# ─── Agents ────────────────────────────────────────────────────────────────────


class AgentCreateDTO(BaseModel):
	"""Création d'un agent IA."""

	name: str = Field(..., min_length=1, max_length=100)
	agent_type: AgentTypeEnum = AgentTypeEnum.assistant
	description: str | None = None
	model_id: str | None = None
	system_prompt: str | None = None
	temperature: float | None = Field(None, ge=0.0, le=2.0)
	max_tokens: int | None = Field(None, ge=1)
	is_active: bool = True
	config: dict | None = None


class AgentUpdateDTO(BaseModel):
	"""Mise à jour d'un agent IA."""

	name: str | None = Field(None, min_length=1, max_length=100)
	agent_type: AgentTypeEnum | None = None
	description: str | None = None
	model_id: str | None = None
	system_prompt: str | None = None
	temperature: float | None = Field(None, ge=0.0, le=2.0)
	max_tokens: int | None = Field(None, ge=1)
	is_active: bool | None = None
	config: dict | None = None


class AgentResponseDTO(BaseModel):
	"""Réponse agent IA."""

	id: str
	name: str
	agent_type: str
	description: str | None = None
	model_id: str | None = None
	system_prompt: str | None = None
	temperature: float | None = None
	max_tokens: int | None = None
	is_active: bool = True
	config: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Conversations ─────────────────────────────────────────────────────────────


class ConversationCreateDTO(BaseModel):
	"""Création d'une conversation."""

	user_id: str
	agent_id: str
	title: str | None = None
	context: dict | None = None
	metadata_json: dict | None = None


class ConversationUpdateDTO(BaseModel):
	"""Mise à jour d'une conversation."""

	title: str | None = None
	context: dict | None = None
	is_archived: bool | None = None
	summary: str | None = None
	metadata_json: dict | None = None


class ConversationResponseDTO(BaseModel):
	"""Réponse conversation."""

	id: str
	user_id: str
	agent_id: str
	title: str | None = None
	context: dict | None = None
	is_archived: bool = False
	summary: str | None = None
	metadata_json: dict | None = None
	message_count: int | None = 0
	created_at: datetime
	updated_at: datetime


# ─── Messages ───────────────────────────────────────────────────────────────────


class MessageCreateDTO(BaseModel):
	"""Création d'un message."""

	conversation_id: str
	role: MessageRoleEnum
	content: str = Field(..., min_length=1)
	token_count: int | None = None
	model_used: str | None = None
	latency_ms: int | None = None
	cost: float | None = None
	tool_calls: dict | None = None


class MessageResponseDTO(BaseModel):
	"""Réponse message."""

	id: str
	conversation_id: str
	role: str
	content: str
	token_count: int | None = None
	model_used: str | None = None
	latency_ms: int | None = None
	cost: float | None = None
	tool_calls: dict | None = None
	reasoning_chain: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Chaînes de raisonnement ───────────────────────────────────────────────────


class ReasoningChainCreateDTO(BaseModel):
	"""Création d'une chaîne de raisonnement."""

	message_id: str
	chain_type: ChainTypeEnum = ChainTypeEnum.cot
	steps: list[dict] | None = None
	final_answer: str | None = None
	confidence_score: float | None = Field(None, ge=0.0, le=1.0)


class ReasoningChainResponseDTO(BaseModel):
	"""Réponse chaîne de raisonnement."""

	id: str
	message_id: str
	chain_type: str
	steps: list[dict] | None = None
	final_answer: str | None = None
	confidence_score: float | None = None
	created_at: datetime
	updated_at: datetime


# ─── Configuration de modèle ───────────────────────────────────────────────────


class ModelConfigCreateDTO(BaseModel):
	"""Création d'une configuration de modèle."""

	provider: str = Field(..., min_length=1)
	model_name: str = Field(..., min_length=1)
	display_name: str | None = None
	api_endpoint: str | None = None
	api_key: str | None = Field(
		default=None,
		description=(
			"Clé API en clair fournie par l'admin — "
			"sera chiffrée au repos (Principe BIBLE #8 : Confidentialité)"
		),
	)
	context_window: int | None = None
	input_cost_per_1k: float | None = None
	output_cost_per_1k: float | None = None
	is_active: bool = True
	capabilities: dict | None = None
	config: dict | None = None


class ModelConfigUpdateDTO(BaseModel):
	"""Mise à jour d'une configuration de modèle."""

	provider: str | None = None
	model_name: str | None = None
	display_name: str | None = None
	api_endpoint: str | None = None
	api_key: str | None = Field(
		default=None,
		description=(
			"Nouvelle clé API en clair — sera chiffrée au repos (Principe BIBLE #8 : Confidentialité)"
		),
	)
	context_window: int | None = None
	input_cost_per_1k: float | None = None
	output_cost_per_1k: float | None = None
	is_active: bool | None = None
	capabilities: dict | None = None
	config: dict | None = None


class ModelConfigResponseDTO(BaseModel):
	"""Réponse configuration de modèle — clé API toujours masquée."""

	id: str
	provider: str
	model_name: str
	display_name: str | None = None
	api_endpoint: str | None = None
	api_key_encrypted: str | None = Field(
		default=None,
		description=("Toujours masqué (••••••••) — jamais la valeur réelle (BIBLE #8 : Confidentialité)"),
	)
	context_window: int | None = None
	input_cost_per_1k: float | None = None
	output_cost_per_1k: float | None = None
	is_active: bool = True
	capabilities: dict | None = None
	config: dict | None = None
	created_at: datetime
	updated_at: datetime


# ─── Journaux d'utilisation ─────────────────────────────────────────────────────


class UsageLogCreateDTO(BaseModel):
	"""Création d'un journal d'utilisation."""

	user_id: str
	model_id: str
	conversation_id: str | None = None
	request_type: RequestTypeEnum = RequestTypeEnum.chat
	prompt_tokens: int = 0
	completion_tokens: int = 0
	total_tokens: int = 0
	cost: float = 0.0
	latency_ms: int = 0
	is_cached: bool = False
	engine: str | None = None


class UsageLogResponseDTO(BaseModel):
	"""Réponse journal d'utilisation."""

	id: str
	user_id: str
	model_id: str
	conversation_id: str | None = None
	request_type: str
	prompt_tokens: int = 0
	completion_tokens: int = 0
	total_tokens: int = 0
	cost: float = 0.0
	latency_ms: int = 0
	is_cached: bool = False
	engine: str | None = None
	created_at: datetime
	updated_at: datetime


class UsageSummaryDTO(BaseModel):
	"""Résumé d'utilisation."""

	total_requests: int = 0
	total_tokens: int = 0
	total_cost: float = 0.0
	avg_latency_ms: float = 0.0
	cache_hit_rate: float = 0.0
