"""NOKIROVA — Service IA : Chaînes de raisonnement

Logique métier pour les chaînes de raisonnement :
- Création et consultation
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	ReasoningChainCreateDTO,
	ReasoningChainResponseDTO,
)
from src.services.ai.repository import (
	MessageRepository,
	ReasoningChainRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_CHAINS = "ai:chains"
EVENT_DOMAIN = "ai"


# ─── Service Chaînes de raisonnement ────────────────────────────────────────


class AIReasoningService:
	"""Service métier pour les chaînes de raisonnement IA."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.chain_repo = ReasoningChainRepository(session)
		self.message_repo = MessageRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_reasoning_chain(
		self,
		dto: ReasoningChainCreateDTO,
	) -> ReasoningChainResponseDTO:
		"""Crée une chaîne de raisonnement pour un message."""
		# Vérifier que le message existe
		message = await self.message_repo.get_by_id(dto.message_id)
		if message is None:
			raise NotFoundException("Message introuvable")

		# Vérifier qu'il n'existe pas déjà une chaîne pour ce message
		existing = await self.chain_repo.get_by_message(dto.message_id)
		if existing is not None:
			raise ValidationException(
				"message_id", "Une chaîne de raisonnement existe déjà pour ce message"
			)

		data = dto.model_dump(exclude_none=True)
		chain = await self.chain_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_CHAINS)

		await event_bus.publish(
			Event(
				event_type="reasoning_chain_created",
				domain=EVENT_DOMAIN,
				payload={"chain_id": chain.id, "message_id": dto.message_id},
			)
		)

		return self._chain_to_response(chain)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_reasoning_chain(
		self,
		message_id: str,
	) -> ReasoningChainResponseDTO | None:
		"""Récupère la chaîne de raisonnement d'un message."""
		cached = await cache_manager.get(CACHE_NS_CHAINS, message_id)
		if cached:
			return ReasoningChainResponseDTO(**cached)

		chain = await self.chain_repo.get_by_message(message_id)
		if chain is None:
			return None

		response = self._chain_to_response(chain)
		await cache_manager.set(CACHE_NS_CHAINS, message_id, response.model_dump(mode="json"), ttl=300)
		return response

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _chain_to_response(chain) -> ReasoningChainResponseDTO:
		"""Convertit un modèle AIReasoningChain en DTO de réponse."""
		return ReasoningChainResponseDTO(
			id=chain.id,
			message_id=chain.message_id,
			chain_type=chain.chain_type,
			steps=chain.steps,
			final_answer=chain.final_answer,
			confidence_score=chain.confidence_score,
			created_at=chain.created_at,
			updated_at=chain.updated_at,
		)
