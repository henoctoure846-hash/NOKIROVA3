"""NOKIROVA — Service IA : Journaux d'utilisation

Logique métier pour les journaux d'utilisation :
- Enregistrement et consultation
- Résumé d'utilisation
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	UsageLogCreateDTO,
	UsageLogResponseDTO,
	UsageSummaryDTO,
)
from src.services.ai.repository import UsageLogRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_USAGE = "ai:usage"
EVENT_DOMAIN = "ai"


# ─── Service Journaux d'utilisation ─────────────────────────────────────────


class AIUsageService:
	"""Service métier pour les journaux d'utilisation IA."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.usage_repo = UsageLogRepository(session)

	# ─── Enregistrement ─────────────────────────────────────────────────

	async def log_usage(
		self,
		dto: UsageLogCreateDTO,
	) -> UsageLogResponseDTO:
		"""Enregistre une entrée de journal d'utilisation."""
		data = dto.model_dump(exclude_none=True)
		log = await self.usage_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_USAGE)

		await event_bus.publish(
			Event(
				event_type="usage_logged",
				domain=EVENT_DOMAIN,
				payload={
					"user_id": dto.user_id,
					"model_id": dto.model_id,
					"total_tokens": dto.total_tokens,
					"cost": dto.cost,
				},
			)
		)

		return self._usage_log_to_response(log)

	# ─── Consultation ─────────────────────────────────────────────────────

	async def get_usage_summary(
		self,
		user_id: str,
	) -> UsageSummaryDTO:
		"""Récupère le résumé d'utilisation d'un utilisateur."""
		cached = await cache_manager.get(CACHE_NS_USAGE, f"summary:{user_id}")
		if cached:
			return UsageSummaryDTO(**cached)

		summary_data = await self.usage_repo.get_usage_summary(user_id)
		summary = UsageSummaryDTO(**summary_data)

		await cache_manager.set(
			CACHE_NS_USAGE,
			f"summary:{user_id}",
			summary.model_dump(mode="json"),
			ttl=120,
		)
		return summary

	async def list_user_usage(
		self,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[UsageLogResponseDTO]:
		"""Liste les journaux d'utilisation d'un utilisateur."""
		logs = await self.usage_repo.list_by_user(user_id, limit, offset)
		return [self._usage_log_to_response(log_entry) for log_entry in logs]

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _usage_log_to_response(log) -> UsageLogResponseDTO:
		"""Convertit un modèle AIUsageLog en DTO de réponse."""
		return UsageLogResponseDTO(
			id=log.id,
			user_id=log.user_id,
			model_id=log.model_id,
			conversation_id=log.conversation_id,
			request_type=log.request_type,
			prompt_tokens=log.prompt_tokens,
			completion_tokens=log.completion_tokens,
			total_tokens=log.total_tokens,
			cost=log.cost,
			latency_ms=log.latency_ms,
			is_cached=log.is_cached,
			engine=log.engine,
			created_at=log.created_at,
			updated_at=log.updated_at,
		)
