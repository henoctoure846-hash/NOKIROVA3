"""NOKIROVA — Service IA : Configurations de modèle

Logique métier pour les configurations de modèle :
- CRUD configurations
- Chiffrement clé API au repos (BIBLE #8 : Confidentialité)
- Résolution interne de clé API (jamais exposée)
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.encryption import get_encryption_service
from src.core.exceptions import NotFoundException
from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.events.bus import Event, event_bus
from src.services.ai.dto import (
	ModelConfigCreateDTO,
	ModelConfigResponseDTO,
	ModelConfigUpdateDTO,
)
from src.services.ai.repository import ModelConfigRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_MODELS = "ai:models"
EVENT_DOMAIN = "ai"


# ─── Service Configurations de modèle ────────────────────────────────────────


class AIModelConfigService:
	"""Service métier pour les configurations de modèle IA."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.model_config_repo = ModelConfigRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_model_config(
		self,
		dto: ModelConfigCreateDTO,
	) -> ModelConfigResponseDTO:
		"""Crée une configuration de modèle — clé API chiffrée au repos (BIBLE #8)."""
		data = dto.model_dump(exclude_none=True)
		# Chiffrement de la clé API avant stockage (Principe BIBLE #8 : Confidentialité)
		cle_api = data.pop("api_key", None)
		if cle_api:
			encryption_svc = get_encryption_service()
			data["api_key_encrypted"] = encryption_svc.encrypt(cle_api)
		config = await self.model_config_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_MODELS)

		await event_bus.publish(
			Event(
				event_type="model_config_created",
				domain=EVENT_DOMAIN,
				payload={"config_id": config.id, "model_name": config.model_name},
			)
		)

		return self._model_config_to_response(config)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_model_config(
		self,
		config_id: str,
	) -> ModelConfigResponseDTO:
		"""Récupère une configuration de modèle."""
		cached = await cache_manager.get(CACHE_NS_MODELS, config_id)
		if cached:
			return ModelConfigResponseDTO(**cached)

		config = await self.model_config_repo.get_by_id(config_id)
		if config is None:
			raise NotFoundException("Configuration de modèle introuvable")

		response = self._model_config_to_response(config)
		await cache_manager.set(CACHE_NS_MODELS, config_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_model_configs(
		self,
		provider: str | None = None,
		limit: int = 50,
		offset: int = 0,
	) -> list[ModelConfigResponseDTO]:
		"""Liste les configurations de modèle actives."""
		configs = await self.model_config_repo.list_active(provider, limit, offset)
		return [self._model_config_to_response(c) for c in configs]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_model_config(
		self,
		config_id: str,
		dto: ModelConfigUpdateDTO,
	) -> ModelConfigResponseDTO:
		"""Met à jour une configuration de modèle — clé API chiffrée au repos (BIBLE #8)."""
		config = await self.model_config_repo.get_by_id(config_id)
		if config is None:
			raise NotFoundException("Configuration de modèle introuvable")

		data = dto.model_dump(exclude_none=True)
		# Chiffrement de la clé API avant stockage (Principe BIBLE #8 : Confidentialité)
		cle_api = data.pop("api_key", None)
		if cle_api:
			encryption_svc = get_encryption_service()
			data["api_key_encrypted"] = encryption_svc.encrypt(cle_api)
		updated = await self.model_config_repo.update(config_id, data)

		await cache_manager.delete(CACHE_NS_MODELS, config_id)

		return self._model_config_to_response(updated)

	# ─── Résolution interne de clé API ─────────────────────────────────────

	@staticmethod
	def resoudre_cle_api(config) -> str | None:
		"""Déchiffre la clé API d'une configuration de modèle.

		Utilisé uniquement en interne par l'orchestrateur et les
		moteurs IA pour les appels SDK réels — JAMAIS exposé dans
		les réponses API (BIBLE #8 : Confidentialité).

		Args:
			config: Objet AIModelConfig avec champ api_key_encrypted.

		Returns:
			Clé API en clair pour l'appel provider, ou None.
		"""
		if not config or not config.api_key_encrypted:
			return None
		encryption_svc = get_encryption_service()
		try:
			return encryption_svc.decrypt(config.api_key_encrypted)
		except DB_OPERATION_EXCEPTIONS:
			# Échec de déchiffrement = clé corrompue ou rotation ratée
			# On loggue sans propager — le moteur IA gérera l'absence de clé
			return None

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _model_config_to_response(config) -> ModelConfigResponseDTO:
		"""Convertit un modèle AIModelConfig en DTO de réponse.

		La clé API est TOUJOURS masquée (••••••••) dans la réponse —
		jamais la valeur réelle, même chiffrée (BIBLE #8 : Confidentialité).
		"""
		encryption_svc = get_encryption_service()
		cle_masquee = encryption_svc.mask_token(config.api_key_encrypted)
		return ModelConfigResponseDTO(
			id=config.id,
			provider=config.provider,
			model_name=config.model_name,
			display_name=config.display_name,
			api_endpoint=config.api_endpoint,
			api_key_encrypted=cle_masquee,
			context_window=config.context_window,
			input_cost_per_1k=config.input_cost_per_1k,
			output_cost_per_1k=config.output_cost_per_1k,
			is_active=config.is_active,
			capabilities=config.capabilities,
			config=config.config,
			created_at=config.created_at,
			updated_at=config.updated_at,
		)
