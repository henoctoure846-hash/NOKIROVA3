"""NOKIROVA — Depot Flashcard

Acces aux donnees pour les paquets, cartes, revisions et sessions d'etude.
Utilise les modeles SQLAlchemy reels de flashcards.py.

Refactorisation :
    FlashcardDeck, Flashcard — Categorie (b) : heritage + soft_delete -> bool
    FlashcardReview — Categorie (e) : heritage create/get, pas de soft_delete
    FlashcardStudySession — Categorie (e) : heritage create/get/update
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base_repository import BaseRepository
from src.database.models.flashcards import (
	Flashcard,
	FlashcardDeck,
	FlashcardReview,
	FlashcardStudySession,
)

# ─── Paquets (Decks) — Categorie (b) ────────────────────────────────────────


class FlashcardDeckRepository(BaseRepository[FlashcardDeck]):
	"""Depot pour les paquets de cartes.

	Herite de BaseRepository[FlashcardDeck].
	get_by_id surcharge pour filtrer par is_active=True.
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(FlashcardDeck, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, deck_id: str) -> FlashcardDeck | None:
		"""Recupere un paquet actif par son identifiant."""
		return await self.get_by_id_active(deck_id)

	async def soft_delete(self, deck_id: str) -> bool:
		"""Suppression logique d'un paquet."""
		result = await super().soft_delete(deck_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_owner(
		self,
		owner_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[FlashcardDeck]:
		"""Recupere les paquets actifs d'un proprietaire."""
		stmt = (
			select(FlashcardDeck)
			.where(
				and_(
					FlashcardDeck.owner_id == owner_id,
					FlashcardDeck.is_active == True,  # noqa: E712
				)
			)
			.order_by(FlashcardDeck.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_public(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[FlashcardDeck]:
		"""Recupere les paquets publics et actifs."""
		stmt = (
			select(FlashcardDeck)
			.where(
				and_(
					FlashcardDeck.is_public == True,  # noqa: E712
					FlashcardDeck.is_active == True,  # noqa: E712
				)
			)
			.order_by(FlashcardDeck.created_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count_cards(self, deck_id: str) -> int:
		"""Compte les cartes actives d'un paquet."""
		stmt = (
			select(func.count())
			.select_from(Flashcard)
			.where(
				and_(
					Flashcard.deck_id == deck_id,
					Flashcard.is_active == True,  # noqa: E712
				)
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar() or 0


# ─── Cartes (Flashcard) — Categorie (b) ─────────────────────────────────────


class FlashcardRepository(BaseRepository[Flashcard]):
	"""Depot pour les cartes memoire.

	Herite de BaseRepository[Flashcard].
	get_by_id surcharge pour filtrer par is_active=True.
	soft_delete surcharge pour retourner bool.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(Flashcard, session)

	# ── Surcharges ──────────────────────────────────────────────────

	async def get_by_id(self, card_id: str) -> Flashcard | None:
		"""Recupere une carte active par son identifiant."""
		return await self.get_by_id_active(card_id)

	async def soft_delete(self, card_id: str) -> bool:
		"""Suppression logique d'une carte."""
		result = await super().soft_delete(card_id)
		return result is not None

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_deck(
		self,
		deck_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> Sequence[Flashcard]:
		"""Recupere les cartes actives d'un paquet."""
		stmt = (
			select(Flashcard)
			.where(
				and_(
					Flashcard.deck_id == deck_id,
					Flashcard.is_active == True,  # noqa: E712
				)
			)
			.order_by(Flashcard.sort_order.asc(), Flashcard.created_at.asc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_due_cards(
		self,
		deck_id: str,
		user_id: str,
		limit: int = 20,
	) -> Sequence[Flashcard]:
		"""Recupere les cartes dues pour revision."""
		now_str = datetime.now(UTC).isoformat()
		stmt = (
			select(Flashcard)
			.where(
				and_(
					Flashcard.deck_id == deck_id,
					Flashcard.is_active == True,  # noqa: E712
					Flashcard.next_review_at <= now_str,
				)
			)
			.order_by(Flashcard.next_review_at.asc())
			.limit(limit)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def update_sm2_data(
		self,
		card_id: str,
		interval_days: int,
		ease_factor: float,
		repetitions: int,
		next_review_at: str,
	) -> Flashcard | None:
		"""Met a jour les donnees SM-2 directement sur la carte."""
		card = await self.get_by_id_active(card_id)
		if card is None:
			return None
		card.interval_days = interval_days
		card.ease_factor = ease_factor
		card.repetitions = repetitions
		card.next_review_at = next_review_at
		card.last_reviewed_at = datetime.now(UTC).isoformat()
		await self.session.flush()
		return card

	async def count_by_deck(self, deck_id: str) -> int:
		"""Compte les cartes actives d'un paquet."""
		stmt = (
			select(func.count())
			.select_from(Flashcard)
			.where(
				and_(
					Flashcard.deck_id == deck_id,
					Flashcard.is_active == True,  # noqa: E712
				)
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar() or 0


# ─── Revisions (Reviews) — Categorie (e) ─────────────────────────────────────


class FlashcardReviewRepository(BaseRepository[FlashcardReview]):
	"""Depot pour les revisions de cartes.

	Herite de BaseRepository[FlashcardReview] pour create/get_by_id/count.
	Pas de soft_delete — les revisions sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(FlashcardReview, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_card(
		self,
		card_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> Sequence[FlashcardReview]:
		"""Recupere les revisions d'une carte."""
		stmt = (
			select(FlashcardReview)
			.where(FlashcardReview.card_id == card_id)
			.order_by(FlashcardReview.reviewed_at.desc())
			.limit(limit)
			.offset(offset)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def get_by_user_and_deck(
		self,
		user_id: str,
		deck_id: str,
		limit: int = 100,
	) -> Sequence[FlashcardReview]:
		"""Recupere les revisions d'un utilisateur pour un paquet."""
		stmt = (
			select(FlashcardReview)
			.where(
				and_(
					FlashcardReview.user_id == user_id,
					FlashcardReview.deck_id == deck_id,
				)
			)
			.order_by(FlashcardReview.reviewed_at.desc())
			.limit(limit)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count_by_card(self, card_id: str) -> int:
		"""Compte les revisions d'une carte."""
		stmt = select(func.count()).select_from(FlashcardReview).where(FlashcardReview.card_id == card_id)
		result = await self.session.execute(stmt)
		return result.scalar() or 0


# ─── Sessions d'etude — Categorie (e) ────────────────────────────────────────


class FlashcardStudySessionRepository(BaseRepository[FlashcardStudySession]):
	"""Depot pour les sessions d'etude.

	Herite de BaseRepository[FlashcardStudySession] pour create/get/update.
	Pas de soft_delete — les sessions sont des enregistrements permanents.
	"""

	def __init__(self, session: AsyncSession) -> None:
		super().__init__(FlashcardStudySession, session)

	# ── Requetes specifiques au domaine ─────────────────────────────

	async def get_by_user_and_deck(
		self,
		user_id: str,
		deck_id: str,
		limit: int = 20,
	) -> Sequence[FlashcardStudySession]:
		"""Recupere les sessions d'etude d'un utilisateur pour un paquet."""
		stmt = (
			select(FlashcardStudySession)
			.where(
				and_(
					FlashcardStudySession.user_id == user_id,
					FlashcardStudySession.deck_id == deck_id,
				)
			)
			.order_by(FlashcardStudySession.created_at.desc())
			.limit(limit)
		)
		result = await self.session.execute(stmt)
		return result.scalars().all()
