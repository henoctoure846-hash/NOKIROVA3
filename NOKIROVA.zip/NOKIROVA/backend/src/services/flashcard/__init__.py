"""NOKIROVA — Domaine Flashcard

Sous-services :
- FlashcardDeckService    → CRUD paquets
- FlashcardCardService    → Cartes + Révisions SM-2
- FlashcardSessionService → Sessions d'étude

Façade :
- FlashcardService        → Délègue aux 3 sous-services

Repositories :
- FlashcardDeckRepository
- FlashcardRepository
- FlashcardReviewRepository
- FlashcardStudySessionRepository
"""

from src.services.flashcard.repository import (
	FlashcardDeckRepository,
	FlashcardRepository,
	FlashcardReviewRepository,
	FlashcardStudySessionRepository,
)
from src.services.flashcard.service import FlashcardService
from src.services.flashcard.service_cards import FlashcardCardService
from src.services.flashcard.service_decks import FlashcardDeckService
from src.services.flashcard.service_sessions import FlashcardSessionService

__all__ = [
	# Façade
	"FlashcardService",
	# Sous-services
	"FlashcardDeckService",
	"FlashcardCardService",
	"FlashcardSessionService",
	# Repositories
	"FlashcardDeckRepository",
	"FlashcardRepository",
	"FlashcardReviewRepository",
	"FlashcardStudySessionRepository",
]
