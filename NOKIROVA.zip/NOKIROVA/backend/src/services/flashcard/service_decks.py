"""NOKIROVA — Service Flashcard : Paquets (Decks)

Logique métier pour les paquets de cartes :
- CRUD paquets
- Cache et événements
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException
from src.events.bus import Event, event_bus
from src.services.flashcard.dto import (
	FlashcardDeckCreateDTO,
	FlashcardDeckResponseDTO,
	FlashcardDeckUpdateDTO,
)
from src.services.flashcard.repository import FlashcardDeckRepository

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_DECKS = "flashcard:decks"
CACHE_NS_CARDS = "flashcard:cards"
EVENT_DOMAIN = "flashcard"


# ─── Service Paquets ────────────────────────────────────────────────────────


class FlashcardDeckService:
	"""Service métier pour les paquets de cartes."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.deck_repo = FlashcardDeckRepository(session)

	# ─── Création ────────────────────────────────────────────────────────

	async def create_deck(
		self,
		user_id: str,
		dto: FlashcardDeckCreateDTO,
	) -> FlashcardDeckResponseDTO:
		"""Crée un nouveau paquet de cartes."""
		data = dto.model_dump(exclude_none=True)
		data["owner_id"] = user_id
		deck = await self.deck_repo.create(data)

		await cache_manager.invalidate_namespace(CACHE_NS_DECKS)

		await event_bus.publish(
			Event(
				event_type="deck_created",
				domain=EVENT_DOMAIN,
				payload={"deck_id": deck.id, "owner_id": user_id},
			)
		)

		return self._deck_to_response(deck)

	# ─── Lecture ─────────────────────────────────────────────────────────

	async def get_deck(self, deck_id: str, user_id: str) -> FlashcardDeckResponseDTO:
		"""Récupère un paquet par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_DECKS, deck_id)
		if cached:
			return FlashcardDeckResponseDTO(**cached)

		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id and not deck.is_public:
			raise ForbiddenException("Accès non autorisé à ce paquet")

		response = self._deck_to_response(deck)
		await cache_manager.set(CACHE_NS_DECKS, deck_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_user_decks(
		self,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[FlashcardDeckResponseDTO]:
		"""Liste les paquets d'un utilisateur."""
		decks = await self.deck_repo.get_by_owner(user_id, limit, offset)
		return [self._deck_to_response(d) for d in decks]

	async def list_public_decks(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[FlashcardDeckResponseDTO]:
		"""Liste les paquets publics."""
		decks = await self.deck_repo.get_public(limit, offset)
		return [self._deck_to_response(d) for d in decks]

	# ─── Mise à jour ─────────────────────────────────────────────────────

	async def update_deck(
		self,
		deck_id: str,
		user_id: str,
		dto: FlashcardDeckUpdateDTO,
	) -> FlashcardDeckResponseDTO:
		"""Met à jour un paquet de cartes."""
		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id:
			raise ForbiddenException("Seul le propriétaire peut modifier ce paquet")

		data = dto.model_dump(exclude_none=True)
		updated = await self.deck_repo.update(deck_id, data)

		await cache_manager.delete(CACHE_NS_DECKS, deck_id)

		await event_bus.publish(
			Event(
				event_type="deck_updated",
				domain=EVENT_DOMAIN,
				payload={"deck_id": deck_id, "owner_id": user_id},
			)
		)

		return self._deck_to_response(updated)

	# ─── Suppression ──────────────────────────────────────────────────────

	async def delete_deck(self, deck_id: str, user_id: str) -> bool:
		"""Supprime logiquement un paquet de cartes."""
		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id:
			raise ForbiddenException("Seul le propriétaire peut supprimer ce paquet")

		success = await self.deck_repo.soft_delete(deck_id)
		if success:
			await cache_manager.delete(CACHE_NS_DECKS, deck_id)
			await cache_manager.invalidate_namespace(CACHE_NS_CARDS)

			await event_bus.publish(
				Event(
					event_type="deck_deleted",
					domain=EVENT_DOMAIN,
					payload={"deck_id": deck_id, "owner_id": user_id},
				)
			)

		return success

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _deck_to_response(deck) -> FlashcardDeckResponseDTO:
		"""Convertit un modèle FlashcardDeck en DTO de réponse."""
		return FlashcardDeckResponseDTO(
			id=deck.id,
			owner_id=deck.owner_id,
			title=deck.title,
			description=deck.description,
			course_id=deck.course_id,
			is_public=deck.is_public,
			language=deck.language,
			card_count=deck.card_count,
			difficulty=deck.difficulty,
			algorithm=deck.algorithm,
			tags=deck.tags,
			cover_image=deck.cover_image,
			is_active=deck.is_active,
			created_at=deck.created_at,
			updated_at=deck.updated_at,
		)
