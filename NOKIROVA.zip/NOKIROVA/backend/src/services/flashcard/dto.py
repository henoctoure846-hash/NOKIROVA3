"""NOKIROVA — DTOs du service Flashcard

Modèles Pydantic pour la validation des requêtes et réponses
du module Flashcard : paquets, cartes, révisions, sessions d'étude.
Alignés sur les modèles SQLAlchemy réels (flashcards.py).
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── Enums ────────────────────────────────────────────────────────────────────


class CardTypeEnum(StrEnum):
	"""Types de cartes mémoire."""

	basic = "basic"
	cloze = "cloze"
	image = "image"
	audio = "audio"


class DifficultyEnum(StrEnum):
	"""Niveaux de difficulté."""

	easy = "easy"
	medium = "medium"
	hard = "hard"


class AlgorithmEnum(StrEnum):
	"""Algorithmes de révision."""

	spaced_repetition = "spaced_repetition"
	leitner = "leitner"
	custom = "custom"


class SessionTypeEnum(StrEnum):
	"""Types de session d'étude."""

	review = "review"
	learn = "learn"
	cram = "cram"


# ─── Paquets (Decks) ─────────────────────────────────────────────────────────


class FlashcardDeckCreateDTO(BaseModel):
	"""Création d'un paquet de cartes."""

	title: str = Field(..., min_length=1, max_length=200)
	description: str | None = Field(None, max_length=2000)
	course_id: str | None = None
	is_public: bool = False
	language: str = Field("fr", max_length=10)
	difficulty: DifficultyEnum = DifficultyEnum.medium
	algorithm: AlgorithmEnum = AlgorithmEnum.spaced_repetition
	tags: list[str] | None = None
	cover_image: str | None = None


class FlashcardDeckUpdateDTO(BaseModel):
	"""Mise à jour d'un paquet de cartes."""

	title: str | None = Field(None, min_length=1, max_length=200)
	description: str | None = None
	course_id: str | None = None
	is_public: bool | None = None
	language: str | None = Field(None, max_length=10)
	difficulty: DifficultyEnum | None = None
	algorithm: AlgorithmEnum | None = None
	tags: list[str] | None = None
	cover_image: str | None = None


class FlashcardDeckResponseDTO(BaseModel):
	"""Réponse paquet de cartes."""

	id: str
	owner_id: str
	title: str
	description: str | None = None
	course_id: str | None = None
	is_public: bool = False
	language: str = "fr"
	card_count: int = 0
	difficulty: str = "medium"
	algorithm: str = "spaced_repetition"
	tags: list[str] | None = None
	cover_image: str | None = None
	is_active: bool = True
	created_at: datetime
	updated_at: datetime


# ─── Cartes (Flashcards) ───────────────────────────────────────────────────────


class FlashcardCreateDTO(BaseModel):
	"""Création d'une carte mémoire."""

	front_content: str = Field(..., min_length=1, max_length=10000)
	back_content: str = Field(..., min_length=1, max_length=10000)
	card_type: CardTypeEnum = CardTypeEnum.basic
	hint: str | None = Field(None, max_length=2000)
	sort_order: int = Field(0, ge=0)
	difficulty: DifficultyEnum = DifficultyEnum.medium
	media_urls: list[str] | None = None
	tags: list[str] | None = None


class FlashcardUpdateDTO(BaseModel):
	"""Mise à jour d'une carte mémoire."""

	front_content: str | None = Field(None, min_length=1, max_length=10000)
	back_content: str | None = Field(None, min_length=1, max_length=10000)
	card_type: CardTypeEnum | None = None
	hint: str | None = None
	sort_order: int | None = Field(None, ge=0)
	difficulty: DifficultyEnum | None = None
	media_urls: list[str] | None = None
	tags: list[str] | None = None


class FlashcardResponseDTO(BaseModel):
	"""Réponse carte mémoire — inclut les données SM-2."""

	id: str
	deck_id: str
	front_content: str
	back_content: str
	card_type: str = "basic"
	hint: str | None = None
	sort_order: int = 0
	difficulty: str = "medium"
	media_urls: list[str] | None = None
	tags: list[str] | None = None
	# Données SM-2 stockées directement sur la carte
	interval_days: int = 1
	ease_factor: float = 2.5
	repetitions: int = 0
	next_review_at: str | None = None
	last_reviewed_at: str | None = None
	is_active: bool = True
	created_at: datetime
	updated_at: datetime


# ─── Révisions (Reviews) ─────────────────────────────────────────────────────


class FlashcardReviewCreateDTO(BaseModel):
	"""Création d'une révision de carte."""

	card_id: str
	quality: int = Field(..., ge=0, le=5, description="Échelle SM-2 : 0=oubli, 5=parfait")
	response_time_ms: int | None = Field(None, ge=0)


class FlashcardReviewResponseDTO(BaseModel):
	"""Réponse révision de carte."""

	id: str
	deck_id: str
	card_id: str
	user_id: str
	quality: int
	response_time_ms: int | None = None
	reviewed_at: str
	created_at: datetime


# ─── Sessions d'étude ─────────────────────────────────────────────────────────


class FlashcardStudySessionCreateDTO(BaseModel):
	"""Création d'une session d'étude."""

	deck_id: str
	session_type: SessionTypeEnum = SessionTypeEnum.review


class FlashcardStudySessionResponseDTO(BaseModel):
	"""Réponse session d'étude."""

	id: str
	deck_id: str
	user_id: str
	cards_reviewed: int = 0
	cards_correct: int = 0
	duration_seconds: int = 0
	started_at: str
	ended_at: str | None = None
	session_type: str = "review"
	is_active: bool = True
	created_at: datetime
	updated_at: datetime


# ─── Résultats de session ────────────────────────────────────────────────────


class StudySessionResultDTO(BaseModel):
	"""Résultat agrégé d'une session d'étude."""

	session_id: str
	deck_id: str
	cards_reviewed: int = 0
	cards_correct: int = 0
	accuracy_percent: float = 0.0
	duration_seconds: int = 0
	average_response_time_ms: float = 0.0
	cards_due_next: int = 0


# ─── SM-2 Résultat ────────────────────────────────────────────────────────────


class SM2ResultDTO(BaseModel):
	"""Résultat du calcul SM-2 pour une carte."""

	card_id: str
	interval_days: int
	ease_factor: float
	repetitions: int
	next_review_at: str
