"""NOKIROVA — Service Flashcard : Sessions d'étude

Logique métier pour les sessions d'étude :
- Démarrer une session
- Terminer une session (résultats agrégés)
- Cache et événements

Dépendances cross-domain :
- FlashcardDeckRepository : validation d'existence / autorisation
- FlashcardRepository : cartes dues restantes
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException
from src.events.bus import Event, event_bus
from src.services.flashcard.dto import (
	FlashcardStudySessionCreateDTO,
	FlashcardStudySessionResponseDTO,
	StudySessionResultDTO,
)
from src.services.flashcard.repository import (
	FlashcardDeckRepository,
	FlashcardRepository,
	FlashcardStudySessionRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_SESSIONS = "flashcard:sessions"
EVENT_DOMAIN = "flashcard"


# ─── Service Sessions d'étude ───────────────────────────────────────────────


class FlashcardSessionService:
	"""Service métier pour les sessions d'étude."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.session_repo = FlashcardStudySessionRepository(session)
		# Dépendances cross-domain : même session
		self.deck_repo = FlashcardDeckRepository(session)
		self.card_repo = FlashcardRepository(session)

	# ─── Démarrer une session ───────────────────────────────────────────

	async def start_study_session(
		self,
		user_id: str,
		dto: FlashcardStudySessionCreateDTO,
	) -> FlashcardStudySessionResponseDTO:
		"""Démarre une nouvelle session d'étude."""
		deck = await self.deck_repo.get_by_id(dto.deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id and not deck.is_public:
			raise ForbiddenException("Accès non autorisé")

		session_data = {
			"deck_id": dto.deck_id,
			"user_id": user_id,
			"started_at": datetime.now(UTC).isoformat(),
			"session_type": dto.session_type,
		}
		study_session = await self.session_repo.create(session_data)

		await event_bus.publish(
			Event(
				event_type="study_session_started",
				domain=EVENT_DOMAIN,
				payload={
					"session_id": study_session.id,
					"deck_id": dto.deck_id,
					"user_id": user_id,
				},
			)
		)

		return self._session_to_response(study_session)

	# ─── Terminer une session ───────────────────────────────────────────

	async def finish_study_session(
		self,
		session_id: str,
		user_id: str,
		cards_reviewed: int = 0,
		cards_correct: int = 0,
		duration_seconds: int = 0,
	) -> StudySessionResultDTO:
		"""Termine une session d'étude et calcule les résultats."""
		study_session = await self.session_repo.get_by_id(session_id)
		if study_session is None:
			raise NotFoundException("Session d'étude introuvable")
		if study_session.user_id != user_id:
			raise ForbiddenException("Session non autorisée")

		update_data = {
			"cards_reviewed": cards_reviewed,
			"cards_correct": cards_correct,
			"duration_seconds": duration_seconds,
			"ended_at": datetime.now(UTC).isoformat(),
		}
		await self.session_repo.update(session_id, update_data)

		# Calculer les résultats agrégés
		accuracy = (cards_correct / cards_reviewed * 100) if cards_reviewed > 0 else 0.0

		# Compter les cartes dues restantes
		due_cards = await self.card_repo.get_due_cards(study_session.deck_id, user_id, limit=1000)

		await cache_manager.invalidate_namespace(CACHE_NS_SESSIONS)

		await event_bus.publish(
			Event(
				event_type="study_session_finished",
				domain=EVENT_DOMAIN,
				payload={
					"session_id": session_id,
					"deck_id": study_session.deck_id,
					"cards_reviewed": cards_reviewed,
					"cards_correct": cards_correct,
					"user_id": user_id,
				},
			)
		)

		return StudySessionResultDTO(
			session_id=session_id,
			deck_id=study_session.deck_id,
			cards_reviewed=cards_reviewed,
			cards_correct=cards_correct,
			accuracy_percent=round(accuracy, 1),
			duration_seconds=duration_seconds,
			cards_due_next=len(due_cards),
		)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _session_to_response(
		session,
	) -> FlashcardStudySessionResponseDTO:
		"""Convertit un modèle FlashcardStudySession en DTO de réponse."""
		return FlashcardStudySessionResponseDTO(
			id=session.id,
			deck_id=session.deck_id,
			user_id=session.user_id,
			cards_reviewed=session.cards_reviewed,
			cards_correct=session.cards_correct,
			duration_seconds=session.duration_seconds,
			started_at=session.started_at,
			ended_at=session.ended_at,
			session_type=session.session_type,
			is_active=session.is_active,
			created_at=session.created_at,
			updated_at=session.updated_at,
		)
