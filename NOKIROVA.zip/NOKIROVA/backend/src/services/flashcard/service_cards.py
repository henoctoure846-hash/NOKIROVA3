"""NOKIROVA — Service Flashcard : Cartes et Révisions

Logique métier pour les cartes et révisions SM-2 :
- CRUD cartes
- Révision de carte (SM-2)
- Cartes dues

Dépendances cross-domain :
- FlashcardDeckRepository : validation d'existence / autorisation + mise à jour compteurs
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from src.cache.manager import cache_manager
from src.core.exceptions import ForbiddenException, NotFoundException, ValidationException
from src.events.bus import Event, event_bus
from src.services.flashcard.dto import (
	FlashcardCreateDTO,
	FlashcardResponseDTO,
	FlashcardReviewCreateDTO,
	FlashcardReviewResponseDTO,
	FlashcardUpdateDTO,
	SM2ResultDTO,
)
from src.services.flashcard.repository import (
	FlashcardDeckRepository,
	FlashcardRepository,
	FlashcardReviewRepository,
)

# ─── Constantes ──────────────────────────────────────────────────────────────

CACHE_NS_CARDS = "flashcard:cards"
EVENT_DOMAIN = "flashcard"


# ─── Service Cartes et Révisions ─────────────────────────────────────────────


class FlashcardCardService:
	"""Service métier pour les cartes et révisions SM-2."""

	def __init__(self, session: AsyncSession) -> None:
		self.session = session
		self.card_repo = FlashcardRepository(session)
		self.review_repo = FlashcardReviewRepository(session)
		# Dépendance cross-domain : même session
		self.deck_repo = FlashcardDeckRepository(session)

	# ─── Cartes : Création ───────────────────────────────────────────────

	async def create_card(
		self,
		deck_id: str,
		user_id: str,
		dto: FlashcardCreateDTO,
	) -> FlashcardResponseDTO:
		"""Crée une nouvelle carte dans un paquet."""
		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id:
			raise ForbiddenException("Seul le propriétaire peut ajouter des cartes")

		data = dto.model_dump(exclude_none=True)
		data["deck_id"] = deck_id
		# Initialiser les données SM-2 par défaut
		data.setdefault("interval_days", 1)
		data.setdefault("ease_factor", 2.5)
		data.setdefault("repetitions", 0)
		# Prochaine révision : maintenant (carte nouvelle)
		data.setdefault("next_review_at", datetime.now(UTC).isoformat())

		card = await self.card_repo.create(data)

		# Mettre à jour le nombre de cartes du paquet
		card_count = await self.card_repo.count_by_deck(deck_id)
		await self.deck_repo.update(deck_id, {"card_count": card_count})

		await cache_manager.invalidate_namespace(CACHE_NS_CARDS)

		await event_bus.publish(
			Event(
				event_type="card_created",
				domain=EVENT_DOMAIN,
				payload={"card_id": card.id, "deck_id": deck_id},
			)
		)

		return self._card_to_response(card)

	# ─── Cartes : Lecture ────────────────────────────────────────────────

	async def get_card(self, card_id: str) -> FlashcardResponseDTO:
		"""Récupère une carte par son identifiant."""
		cached = await cache_manager.get(CACHE_NS_CARDS, card_id)
		if cached:
			return FlashcardResponseDTO(**cached)

		card = await self.card_repo.get_by_id(card_id)
		if card is None:
			raise NotFoundException("Carte introuvable")

		response = self._card_to_response(card)
		await cache_manager.set(CACHE_NS_CARDS, card_id, response.model_dump(mode="json"), ttl=300)
		return response

	async def list_deck_cards(
		self,
		deck_id: str,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[FlashcardResponseDTO]:
		"""Liste les cartes d'un paquet."""
		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id and not deck.is_public:
			raise ForbiddenException("Accès non autorisé")

		cards = await self.card_repo.get_by_deck(deck_id, limit, offset)
		return [self._card_to_response(c) for c in cards]

	# ─── Cartes : Mise à jour ────────────────────────────────────────────

	async def update_card(
		self,
		card_id: str,
		user_id: str,
		dto: FlashcardUpdateDTO,
	) -> FlashcardResponseDTO:
		"""Met à jour une carte existante."""
		card = await self.card_repo.get_by_id(card_id)
		if card is None:
			raise NotFoundException("Carte introuvable")

		# Vérifier les droits via le paquet
		deck = await self.deck_repo.get_by_id(card.deck_id)
		if deck is None or deck.owner_id != user_id:
			raise ForbiddenException("Seul le propriétaire du paquet peut modifier les cartes")

		data = dto.model_dump(exclude_none=True)
		updated = await self.card_repo.update(card_id, data)

		await cache_manager.delete(CACHE_NS_CARDS, card_id)

		return self._card_to_response(updated)

	# ─── Cartes : Suppression ────────────────────────────────────────────

	async def delete_card(self, card_id: str, user_id: str) -> bool:
		"""Supprime logiquement une carte."""
		card = await self.card_repo.get_by_id(card_id)
		if card is None:
			raise NotFoundException("Carte introuvable")

		deck = await self.deck_repo.get_by_id(card.deck_id)
		if deck is None or deck.owner_id != user_id:
			raise ForbiddenException("Seul le propriétaire du paquet peut supprimer les cartes")

		success = await self.card_repo.soft_delete(card_id)
		if success:
			card_count = await self.card_repo.count_by_deck(card.deck_id)
			await self.deck_repo.update(card.deck_id, {"card_count": card_count})

			await cache_manager.delete(CACHE_NS_CARDS, card_id)

			await event_bus.publish(
				Event(
					event_type="card_deleted",
					domain=EVENT_DOMAIN,
					payload={"card_id": card_id, "deck_id": card.deck_id},
				)
			)

		return success

	# ─── Révisions SM-2 ──────────────────────────────────────────────────

	async def review_card(
		self,
		user_id: str,
		deck_id: str,
		dto: FlashcardReviewCreateDTO,
	) -> FlashcardReviewResponseDTO:
		"""Réviser une carte — enregistre la révision et met à jour le SM-2."""
		card = await self.card_repo.get_by_id(dto.card_id)
		if card is None:
			raise NotFoundException("Carte introuvable")
		if card.deck_id != deck_id:
			raise ValidationException("La carte n'appartient pas à ce paquet")

		# Créer l'enregistrement de révision
		review_data = {
			"deck_id": deck_id,
			"card_id": dto.card_id,
			"user_id": user_id,
			"quality": dto.quality,
			"response_time_ms": dto.response_time_ms,
			"reviewed_at": datetime.now(UTC).isoformat(),
		}
		review = await self.review_repo.create(review_data)

		# Calculer les nouvelles données SM-2 et les stocker SUR la carte
		sm2 = self._calculate_sm2(
			quality=dto.quality,
			interval_days=card.interval_days,
			ease_factor=card.ease_factor,
			repetitions=card.repetitions,
		)
		await self.card_repo.update_sm2_data(
			card_id=dto.card_id,
			interval_days=sm2.interval_days,
			ease_factor=sm2.ease_factor,
			repetitions=sm2.repetitions,
			next_review_at=sm2.next_review_at,
		)

		await cache_manager.delete(CACHE_NS_CARDS, dto.card_id)

		await event_bus.publish(
			Event(
				event_type="card_reviewed",
				domain=EVENT_DOMAIN,
				payload={
					"card_id": dto.card_id,
					"deck_id": deck_id,
					"quality": dto.quality,
					"user_id": user_id,
				},
			)
		)

		return FlashcardReviewResponseDTO(
			id=review.id,
			deck_id=deck_id,
			card_id=dto.card_id,
			user_id=user_id,
			quality=review.quality,
			response_time_ms=review.response_time_ms,
			reviewed_at=review.reviewed_at,
			created_at=review.created_at,
		)

	async def get_due_cards(
		self,
		deck_id: str,
		user_id: str,
		limit: int = 20,
	) -> list[FlashcardResponseDTO]:
		"""Récupère les cartes dues pour révision."""
		deck = await self.deck_repo.get_by_id(deck_id)
		if deck is None:
			raise NotFoundException("Paquet de cartes introuvable")
		if deck.owner_id != user_id and not deck.is_public:
			raise ForbiddenException("Accès non autorisé")

		cards = await self.card_repo.get_due_cards(deck_id, user_id, limit)
		return [self._card_to_response(c) for c in cards]

	# ─── Algorithme SM-2 ────────────────────────────────────────────────

	@staticmethod
	def _calculate_sm2(
		quality: int,
		interval_days: int,
		ease_factor: float,
		repetitions: int,
	) -> SM2ResultDTO:
		"""Implémentation de l'algorithme SM-2 (SuperMemo 2).

		quality : 0-5 (0 = oubli complet, 5 = réponse parfaite)
		Les données sont stockées SUR la carte, pas sur la révision.
		"""
		now = datetime.now(UTC)

		if quality < 3:
			# Échec — réinitialiser
			new_repetitions = 0
			new_interval = 1
		else:
			# Succès
			new_repetitions = repetitions + 1
			if new_repetitions == 1:
				new_interval = 1
			elif new_repetitions == 2:
				new_interval = 6
			else:
				new_interval = max(1, round(interval_days * ease_factor))

		# Ajuster le facteur de facilité
		new_ease = ease_factor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
		new_ease = max(1.3, min(2.5, new_ease))  # Bornes [1.3, 2.5]

		next_review = now + timedelta(days=new_interval)

		return SM2ResultDTO(
			card_id="",  # Sera rempli par l'appelant
			interval_days=new_interval,
			ease_factor=round(new_ease, 2),
			repetitions=new_repetitions,
			next_review_at=next_review.isoformat(),
		)

	# ─── Utilitaires de mapping ────────────────────────────────────────────

	@staticmethod
	def _card_to_response(card) -> FlashcardResponseDTO:
		"""Convertit un modèle Flashcard en DTO de réponse (inclut SM-2)."""
		return FlashcardResponseDTO(
			id=card.id,
			deck_id=card.deck_id,
			front_content=card.front_content,
			back_content=card.back_content,
			card_type=card.card_type,
			hint=card.hint,
			sort_order=card.sort_order,
			difficulty=card.difficulty,
			media_urls=card.media_urls,
			tags=card.tags,
			interval_days=card.interval_days,
			ease_factor=card.ease_factor,
			repetitions=card.repetitions,
			next_review_at=card.next_review_at,
			last_reviewed_at=card.last_reviewed_at,
			is_active=card.is_active,
			created_at=card.created_at,
			updated_at=card.updated_at,
		)
