"""NOKIROVA — Service Flashcard (Façade)

Façade qui délègue aux trois sous-services :
- FlashcardDeckService   → CRUD paquets
- FlashcardCardService   → Cartes + Révisions SM-2
- FlashcardSessionService → Sessions d'étude

Expose les 4 repositories pour les sous-services et
les contrôleurs qui en ont besoin.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from src.services.flashcard.dto import (
	FlashcardCreateDTO,
	FlashcardDeckCreateDTO,
	FlashcardDeckResponseDTO,
	FlashcardDeckUpdateDTO,
	FlashcardResponseDTO,
	FlashcardReviewCreateDTO,
	FlashcardReviewResponseDTO,
	FlashcardStudySessionCreateDTO,
	FlashcardStudySessionResponseDTO,
	FlashcardUpdateDTO,
	StudySessionResultDTO,
)
from src.services.flashcard.repository import (
	FlashcardDeckRepository,
	FlashcardRepository,
	FlashcardReviewRepository,
	FlashcardStudySessionRepository,
)
from src.services.flashcard.service_cards import FlashcardCardService
from src.services.flashcard.service_decks import FlashcardDeckService
from src.services.flashcard.service_sessions import FlashcardSessionService

# ─── Façade Flashcard ───────────────────────────────────────────────────────


class FlashcardService:
	"""Façade unifiée pour le domaine Flashcard."""

	def __init__(self, session: AsyncSession) -> None:
		self.deck_service = FlashcardDeckService(session)
		self.card_service = FlashcardCardService(session)
		self.session_service = FlashcardSessionService(session)

		# Exposer les repositories pour usage externe
		self.deck_repo = FlashcardDeckRepository(session)
		self.card_repo = FlashcardRepository(session)
		self.review_repo = FlashcardReviewRepository(session)
		self.session_repo = FlashcardStudySessionRepository(session)

	# ─── Paquets (délégation) ───────────────────────────────────────────

	async def create_deck(
		self,
		user_id: str,
		dto: FlashcardDeckCreateDTO,
	) -> FlashcardDeckResponseDTO:
		return await self.deck_service.create_deck(user_id, dto)

	async def get_deck(
		self,
		deck_id: str,
		user_id: str,
	) -> FlashcardDeckResponseDTO:
		return await self.deck_service.get_deck(deck_id, user_id)

	async def list_user_decks(
		self,
		user_id: str,
		limit: int = 50,
		offset: int = 0,
	) -> list[FlashcardDeckResponseDTO]:
		return await self.deck_service.list_user_decks(user_id, limit, offset)

	async def list_public_decks(
		self,
		limit: int = 50,
		offset: int = 0,
	) -> list[FlashcardDeckResponseDTO]:
		return await self.deck_service.list_public_decks(limit, offset)

	async def update_deck(
		self,
		deck_id: str,
		user_id: str,
		dto: FlashcardDeckUpdateDTO,
	) -> FlashcardDeckResponseDTO:
		return await self.deck_service.update_deck(deck_id, user_id, dto)

	async def delete_deck(
		self,
		deck_id: str,
		user_id: str,
	) -> bool:
		return await self.deck_service.delete_deck(deck_id, user_id)

	# ─── Cartes (délégation) ────────────────────────────────────────────

	async def create_card(
		self,
		deck_id: str,
		user_id: str,
		dto: FlashcardCreateDTO,
	) -> FlashcardResponseDTO:
		return await self.card_service.create_card(deck_id, user_id, dto)

	async def get_card(self, card_id: str) -> FlashcardResponseDTO:
		return await self.card_service.get_card(card_id)

	async def list_deck_cards(
		self,
		deck_id: str,
		user_id: str,
		limit: int = 100,
		offset: int = 0,
	) -> list[FlashcardResponseDTO]:
		return await self.card_service.list_deck_cards(deck_id, user_id, limit, offset)

	async def update_card(
		self,
		card_id: str,
		user_id: str,
		dto: FlashcardUpdateDTO,
	) -> FlashcardResponseDTO:
		return await self.card_service.update_card(card_id, user_id, dto)

	async def delete_card(
		self,
		card_id: str,
		user_id: str,
	) -> bool:
		return await self.card_service.delete_card(card_id, user_id)

	# ─── Révisions (délégation) ────────────────────────────────────────

	async def review_card(
		self,
		user_id: str,
		deck_id: str,
		dto: FlashcardReviewCreateDTO,
	) -> FlashcardReviewResponseDTO:
		return await self.card_service.review_card(user_id, deck_id, dto)

	async def get_due_cards(
		self,
		deck_id: str,
		user_id: str,
		limit: int = 20,
	) -> list[FlashcardResponseDTO]:
		return await self.card_service.get_due_cards(deck_id, user_id, limit)

	# ─── Sessions (délégation) ─────────────────────────────────────────

	async def start_study_session(
		self,
		user_id: str,
		dto: FlashcardStudySessionCreateDTO,
	) -> FlashcardStudySessionResponseDTO:
		return await self.session_service.start_study_session(user_id, dto)

	async def finish_study_session(
		self,
		session_id: str,
		user_id: str,
		cards_reviewed: int = 0,
		cards_correct: int = 0,
		duration_seconds: int = 0,
	) -> StudySessionResultDTO:
		return await self.session_service.finish_study_session(
			session_id,
			user_id,
			cards_reviewed,
			cards_correct,
			duration_seconds,
		)
