"""NOKIROVA — Modèles d'événements

Types fondamentaux du bus d'événements :
- EventPriority   : priorité des événements
- EventStatus      : statut de traitement
- Event            : unité fondamentale de communication
- EventHandler     : handler enregistré
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from enum import StrEnum

from src.core.health_exceptions import EVENT_BUS_EXCEPTIONS
from src.core.logging import get_logger

logger = get_logger(__name__)


# ═══════════════════════════════════════
# Priorités et statuts
# ═══════════════════════════════════════


class EventPriority(StrEnum):
	"""Priorité des événements."""

	CRITICAL = "critical"  # Self-healing, erreurs système
	HIGH = "high"  # IA, workflows critiques
	NORMAL = "normal"  # Opérations standard
	LOW = "low"  # Analytics, logging


class EventStatus(StrEnum):
	"""Statut du traitement d'un événement."""

	PENDING = "pending"
	PROCESSING = "processing"
	COMPLETED = "completed"
	FAILED = "failed"
	DEAD_LETTER = "dead_letter"


# ═══════════════════════════════════════
# Événement
# ═══════════════════════════════════════


@dataclass
class Event:
	"""Événement NOKIROVA — unité fondamentale de communication."""

	# Identité
	event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	event_type: str = ""
	domain: str = ""  # Domaine métier (auth, documents, ai, etc.)

	# Contenu
	payload: dict = field(default_factory=dict)
	metadata: dict = field(default_factory=dict)

	# Traçabilité
	source: str = ""  # Module émetteur
	correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	causation_id: str | None = None  # ID de l'événement qui a causé celui-ci

	# Priorité & livraison
	priority: EventPriority = EventPriority.NORMAL
	status: EventStatus = EventStatus.PENDING

	# Timing
	timestamp: float = field(default_factory=time.time)
	scheduled_at: float | None = None  # Événement différé
	expires_at: float | None = None  # TTL

	# Retry
	retry_count: int = 0
	max_retries: int = 3

	def to_dict(self) -> dict:
		"""Sérialiser l'événement."""
		d = asdict(self)
		d["priority"] = self.priority.value
		d["status"] = self.status.value
		return d

	@classmethod
	def from_dict(cls, data: dict) -> Event:
		"""Désérialiser un événement."""
		data["priority"] = EventPriority(data.get("priority", "normal"))
		data["status"] = EventStatus(data.get("status", "pending"))
		# Conversion explicite des champs numériques venant de Redis (stockés en string)
		data["retry_count"] = int(data.get("retry_count", 0))
		return cls(**data)


# ═══════════════════════════════════════
# Handler d'événement
# ═══════════════════════════════════════


@dataclass
class EventHandler:
	"""Handler enregistré pour un type d'événement."""

	handler_id: str = field(default_factory=lambda: str(uuid.uuid4()))
	event_type: str = ""  # Pattern : "document.*" ou "document.created"
	domain: str = ""  # Domaine du handler
	callback: Callable | None = None
	is_async: bool = True
	max_retries: int = 3
	dead_letter_on_failure: bool = True

	async def execute(self, event: Event) -> bool:
		"""Exécuter le handler pour un événement."""
		if not self.callback:
			return False
		try:
			if self.is_async:
				await self.callback(event)
			else:
				self.callback(event)
			return True
		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(
				f"Handler {self.handler_id} échoué pour {event.event_type}: {e}",
				extra={"event_id": event.event_id, "handler_id": self.handler_id},
			)
			return False
