"""
NOKIROVA — Handlers d'événements Révision

Réactions aux événements du domaine révision :
- revision.session.started → analytics, focus mode
- revision.session.completed → mise à jour spaced repetition, XP
- revision.flashcard.reviewed → mise à jour algorithme SM-2
- revision.quiz.completed → analytics, badges
"""

from ...core.logging import get_logger
from ..bus import Event, event_bus

logger = get_logger(__name__)


async def on_revision_started(event: Event):
	"""Réagir au démarrage d'une session de révision."""
	logger.info(f"Session de révision démarrée : {event.payload.get('session_id')}")
	# Étape 1 : Activer le mode focus
	# Étape 2 : Désactiver les notifications non-critiques
	# Étape 3 : Logger pour analytics


async def on_revision_completed(event: Event):
	"""Réagir à la fin d'une session de révision — spaced repetition + XP."""
	logger.info(f"Session de révision terminée : {event.payload.get('session_id')}")
	# Étape 1 : Mettre à jour l'algorithme SM-2 (next review date)
	# Étape 2 : Calculer et attribuer les XP
	# Étape 3 : Vérifier les badges débloqués
	# Étape 4 : Mettre à jour le graphe de progression


async def on_flashcard_reviewed(event: Event):
	"""Réagir à la révision d'une flashcard — mise à jour SM-2."""
	logger.info(f"Flashcard révisée : {event.payload.get('flashcard_id')}")
	# Étape 1 : Calculer le nouvel intervalle SM-2
	# Étape 2 : Mettre à jour ease_factor, interval, next_review
	# Étape 3 : Publier événement revision.schedule.updated


async def on_quiz_completed(event: Event):
	"""Réagir à la complétion d'un quiz — analytics + badges."""
	logger.info(f"Quiz complété : {event.payload.get('quiz_id')}")
	# Étape 1 : Calculer le score
	# Étape 2 : Attribuer les XP
	# Étape 3 : Vérifier les badges
	# Étape 4 : Mettre à jour la progression


def register_revision_handlers():
	"""Enregistrer tous les handlers du domaine révision."""
	event_bus.subscribe("revision.session.started", on_revision_started, domain="revision")
	event_bus.subscribe("revision.session.completed", on_revision_completed, domain="revision")
	event_bus.subscribe("revision.flashcard.reviewed", on_flashcard_reviewed, domain="revision")
	event_bus.subscribe("revision.quiz.completed", on_quiz_completed, domain="revision")
	logger.info("Handlers révision enregistrés")
