"""
NOKIROVA — Handlers d'événements Documents

Réactions aux événements du domaine documents :
- document.created → indexation, notification
- document.uploaded → OCR, extraction, chunking
- document.deleted → désindexation, archive
- document.shared → notification
"""

from ...core.logging import get_logger
from ..bus import Event, event_bus

logger = get_logger(__name__)


async def on_document_created(event: Event):
	"""Réagir à la création d'un document — indexation automatique."""
	logger.info(f"Document créé : {event.payload.get('document_id')}")
	# Étape 1 : Indexer dans le moteur de recherche
	# Étape 2 : Envoyer une notification
	# Étape 3 : Mettre à jour le Knowledge Graph


async def on_document_uploaded(event: Event):
	"""Réagir à l'upload d'un document — pipeline OCR + extraction."""
	logger.info(f"Document uploadé : {event.payload.get('document_id')}")
	# Étape 1 : Lancer l'OCR (si image/PDF)
	# Étape 2 : Extraire le texte
	# Étape 3 : Chunking pour les embeddings
	# Étape 4 : Publier événement document.text_extracted


async def on_document_deleted(event: Event):
	"""Réagir à la suppression d'un document — archive + désindexation."""
	logger.info(f"Document archivé : {event.payload.get('document_id')}")
	# Étape 1 : Archiver (pas de suppression permanente)
	# Étape 2 : Désindexer du moteur de recherche
	# Étape 3 : Retirer du Knowledge Lake


async def on_document_shared(event: Event):
	"""Réagir au partage d'un document — notifications."""
	logger.info(f"Document partagé : {event.payload.get('document_id')}")
	# Étape 1 : Notifier les destinataires
	# Étape 2 : Créer l'entrée dans le stockage partagé


def register_document_handlers():
	"""Enregistrer tous les handlers du domaine documents."""
	event_bus.subscribe("document.created", on_document_created, domain="documents")
	event_bus.subscribe("document.uploaded", on_document_uploaded, domain="documents")
	event_bus.subscribe("document.deleted", on_document_deleted, domain="documents")
	event_bus.subscribe("document.shared", on_document_shared, domain="documents")
	logger.info("Handlers documents enregistrés")
