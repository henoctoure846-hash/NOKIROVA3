"""
NOKIROVA — Handlers d'événements Communauté

Réactions aux événements du domaine communauté :
- community.post.created → notification abonnés, indexation
- community.comment.added → notification auteur
- community.resource.shared → analytics, indexation marketplace
- community.report.submitted → modération
"""

from ...core.logging import get_logger
from ..bus import Event, event_bus

logger = get_logger(__name__)


async def on_post_created(event: Event):
	"""Réagir à la création d'un post — notification + indexation."""
	logger.info(f"Post créé : {event.payload.get('post_id')}")
	# Étape 1 : Notifier les abonnés du sujet
	# Étape 2 : Indexer dans le moteur de recherche communautaire
	# Étape 3 : Attribuer les XP de contribution


async def on_comment_added(event: Event):
	"""Réagir à un commentaire — notification auteur."""
	logger.info(f"Commentaire ajouté : {event.payload.get('comment_id')}")
	# Étape 1 : Notifier l'auteur du post
	# Étape 2 : Mettre à jour le compteur de commentaires
	# Étape 3 : Attribuer XP


async def on_resource_shared(event: Event):
	"""Réagir au partage d'une ressource — marketplace + analytics."""
	logger.info(f"Ressource partagée : {event.payload.get('resource_id')}")
	# Étape 1 : Indexer dans la marketplace
	# Étape 2 : Créer l'entrée de téléchargement
	# Étape 3 : Attribuer XP de partage


async def on_report_submitted(event: Event):
	"""Réagir à un signalement — modération."""
	logger.warning(f"Signalement : {event.payload.get('report_id')}")
	# Étape 1 : Créer le ticket de modération
	# Étape 2 : Notifier les modérateurs
	# Étape 3 : Si critique, masquer automatiquement


def register_community_handlers():
	"""Enregistrer tous les handlers du domaine communauté."""
	event_bus.subscribe("community.post.created", on_post_created, domain="community")
	event_bus.subscribe("community.comment.added", on_comment_added, domain="community")
	event_bus.subscribe("community.resource.shared", on_resource_shared, domain="community")
	event_bus.subscribe("community.report.submitted", on_report_submitted, domain="community")
	logger.info("Handlers communauté enregistrés")
