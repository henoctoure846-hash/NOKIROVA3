"""
NOKIROVA — Handlers d'événements Auth

Réactions aux événements du domaine authentification :
- auth.user.registered → email de bienvenue, profil initial
- auth.user.login → log de connexion, analytics
- auth.user.password_reset → notification
- auth.user.deleted → archive, anonymisation RGPD
"""

from ...core.logging import get_logger
from ..bus import Event, event_bus

logger = get_logger(__name__)


async def on_user_registered(event: Event):
	"""Réagir à l'inscription — email de bienvenue + profil initial."""
	logger.info(f"Utilisateur inscrit : {event.payload.get('user_id')}")
	# Étape 1 : Envoyer email de bienvenue
	# Étape 2 : Créer le profil initial (Progression à 0)
	# Étape 3 : Initialiser les paramètres par défaut
	# Étape 4 : Créer le dossier de stockage personnel


async def on_user_login(event: Event):
	"""Réagir à une connexion — log + analytics."""
	logger.info(f"Connexion : {event.payload.get('user_id')}")
	# Étape 1 : Logger la connexion (date, IP, device)
	# Étape 2 : Mettre à jour last_login
	# Étape 3 : Incrémenter les analytics


async def on_password_reset(event: Event):
	"""Réagir à une réinitialisation de mot de passe."""
	logger.info(f"Reset mot de passe demandé : {event.payload.get('user_id')}")
	# Étape 1 : Envoyer email avec token
	# Étape 2 : Logger l'événement de sécurité


async def on_user_deleted(event: Event):
	"""Réagir à une suppression de compte — archive + anonymisation RGPD."""
	logger.info(f"Compte archivé : {event.payload.get('user_id')}")
	# Étape 1 : Archiver (jamais supprimer)
	# Étape 2 : Anonymiser les données personnelles (RGPD)
	# Étape 3 : Désactiver les tokens
	# Étape 4 : Notifier l'admin


def register_auth_handlers():
	"""Enregistrer tous les handlers du domaine auth."""
	event_bus.subscribe("auth.user.registered", on_user_registered, domain="auth")
	event_bus.subscribe("auth.user.login", on_user_login, domain="auth")
	event_bus.subscribe("auth.user.password_reset", on_password_reset, domain="auth")
	event_bus.subscribe("auth.user.deleted", on_user_deleted, domain="auth")
	logger.info("Handlers auth enregistrés")
