"""
NOKIROVA — Handlers d'événements IA

Réactions aux événements du domaine IA :
- ai.request.received → dispatch vers l'orchestrateur
- ai.generation.completed → notification, mémoire
- ai.generation.failed → retry ou fallback
- ai.memory.updated → sync Knowledge Graph
"""

from ...core.logging import get_logger
from ..bus import Event, event_bus

logger = get_logger(__name__)


async def on_ai_request_received(event: Event):
	"""Réagir à une requête IA — dispatch vers l'orchestrateur SIO."""
	logger.info(f"Requête IA reçue : {event.payload.get('request_id')}")
	# L'orchestrateur SIO prend le relais
	# Étape 8 étapes : understand→search→compare→reason→produce→verify→cite→memorize


async def on_ai_generation_completed(event: Event):
	"""Réagir à une génération IA terminée — mémoriser + notifier."""
	logger.info(f"Génération IA terminée : {event.payload.get('generation_id')}")
	# Étape 1 : Mémoriser dans le système de mémoire
	# Étape 2 : Notifier l'utilisateur
	# Étape 3 : Mettre à jour les analytics


async def on_ai_generation_failed(event: Event):
	"""Réagir à un échec de génération IA — retry ou fallback."""
	logger.warning(f"Génération IA échouée : {event.payload.get('generation_id')}")
	# Self-healing : retry avec provider alternatif
	# Si retry_count < max : republier l'événement
	# Sinon : fallback vers réponse générique + notification


async def on_ai_memory_updated(event: Event):
	"""Réagir à une mise à jour mémoire IA — sync Knowledge Graph."""
	logger.info(f"Mémoire IA mise à jour : {event.payload.get('memory_id')}")
	# Synchroniser avec le Knowledge Graph
	# Mettre à jour les embeddings


def register_ai_handlers():
	"""Enregistrer tous les handlers du domaine IA."""
	event_bus.subscribe("ai.request.received", on_ai_request_received, domain="ai")
	event_bus.subscribe("ai.generation.completed", on_ai_generation_completed, domain="ai")
	event_bus.subscribe("ai.generation.failed", on_ai_generation_failed, domain="ai")
	event_bus.subscribe("ai.memory.updated", on_ai_memory_updated, domain="ai")
	logger.info("Handlers IA enregistrés")
