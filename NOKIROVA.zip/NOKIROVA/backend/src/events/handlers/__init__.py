"""
NOKIROVA — Handlers d'événements par domaine

Chaque module enregistre ses handlers ici.
Les handlers sont découplés : ils réagissent aux événements via le bus.
"""

from .ai_handlers import register_ai_handlers
from .auth_handlers import register_auth_handlers
from .community_handlers import register_community_handlers
from .document_handlers import register_document_handlers
from .revision_handlers import register_revision_handlers

__all__ = [
	"register_document_handlers",
	"register_ai_handlers",
	"register_auth_handlers",
	"register_revision_handlers",
	"register_community_handlers",
]


def register_all_handlers():
	"""Enregistrer tous les handlers d'événements."""
	register_document_handlers()
	register_ai_handlers()
	register_auth_handlers()
	register_revision_handlers()
	register_community_handlers()
