"""NOKIROVA — Bus d'événements (façade)

Façade composant :
- EventDispatcher : abonnements et publication
- EventConsumer    : consommation et replay
- DeadLetterHandler : dead-letter queue

Pattern singleton : event_bus = EventBus()
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import redis.asyncio as aioredis

from src.core.config import settings
from src.core.health_exceptions import EVENT_BUS_EXCEPTIONS
from src.core.logging import get_logger
from src.events.consumer import EventConsumer
from src.events.dead_letter import DeadLetterHandler
from src.events.dispatcher import EventDispatcher
from src.events.models import Event, EventHandler, EventPriority

logger = get_logger(__name__)


# ─── Bus d'événements (façade) ──────────────────────────────────────────────


class EventBus:
	"""Bus d'événements NOKIROVA — façade composant Dispatcher, Consumer, DeadLetter."""

	def __init__(self, redis_url: str | None = None) -> None:
		self._redis_url = redis_url or getattr(settings, "REDIS_URL", "redis://localhost:6379")
		self._redis: aioredis.Redis | None = None

		# Composants internes
		self._dispatcher = EventDispatcher()
		self._consumer: EventConsumer | None = None
		self._dead_letter: DeadLetterHandler | None = None

		# Statistiques
		self._stats: dict[str, Any] = {
			"published": 0,
			"processed": 0,
			"failed": 0,
			"dead_lettered": 0,
		}

	# ─── Connexion Redis ───────────────────────────────────────────────

	async def connect(self) -> None:
		"""Établir la connexion Redis et initialiser les composants."""
		try:
			self._redis = aioredis.from_url(
				self._redis_url,
				decode_responses=True,
				max_connections=20,
			)
			await self._redis.ping()

			self._dead_letter = DeadLetterHandler(self._redis)
			self._consumer = EventConsumer(self._redis, self._dispatcher, self._dead_letter)

			logger.info("Event Bus : connecté à Redis")
		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(f"Event Bus : erreur connexion Redis : {e}")
			raise

	async def disconnect(self) -> None:
		"""Fermer la connexion Redis et arrêter la consommation."""
		if self._consumer:
			await self._consumer.stop()
		if self._redis:
			await self._redis.close()
			self._redis = None
			logger.info("Event Bus : déconnecté de Redis")

	# ─── Abonnement ────────────────────────────────────────────────────

	def subscribe(
		self,
		event_type: str,
		callback: Callable,
		domain: str = "",
		is_async: bool = True,
		max_retries: int = 3,
	) -> str:
		"""S'abonner à un type d'événement (délègue au Dispatcher)."""
		return self._dispatcher.subscribe(
			event_type, callback, domain=domain, is_async=is_async, max_retries=max_retries
		)

	def unsubscribe(self, handler_id: str) -> bool:
		"""Retirer un handler (délègue au Dispatcher)."""
		return self._dispatcher.unsubscribe(handler_id)

	# ─── Publication ──────────────────────────────────────────────────

	async def publish(
		self,
		event_type: str | Event,
		payload: dict | None = None,
		domain: str = "",
		source: str = "",
		priority: str = "normal",
		correlation_id: str | None = None,
		metadata: dict | None = None,
	) -> str:
		"""
		Publier un événement.

		Accepte soit un objet Event complet, soit les arguments individuels.

		Args:
			event_type: Objet Event ou type de l'événement (chaîne)
			payload: Données de l'événement
			domain: Domaine métier
			source: Module émetteur
			priority: critical / high / normal / low
			correlation_id: ID de corrélation
			metadata: Métadonnées additionnelles

		Returns:
			ID du message Redis
		"""
		# ── Si un objet Event est passé directement, l'utiliser tel quel ──
		if isinstance(event_type, Event):
			event = event_type
		else:
			try:
				prio = EventPriority(priority)
			except ValueError:
				prio = EventPriority.NORMAL

			event = Event(
				event_type=event_type,
				payload=payload or {},
				domain=domain,
				source=source,
				correlation_id=correlation_id or str(time.time()),
				priority=prio,
				metadata=metadata or {},
			)

		if not self._redis:
			await self.connect()

		msg_id = await EventDispatcher.publish_to_redis(self._redis, event)
		self._stats["published"] += 1

		logger.info(
			f"Événement publié : {event_type} [{domain}]",
			extra={"event_id": event.event_id, "msg_id": msg_id},
		)

		return event.event_id

	# ─── Consommation ──────────────────────────────────────────────────

	async def start_consuming(
		self,
		domains: list[str] | None = None,
	) -> None:
		"""Démarrer la consommation (délègue au Consumer)."""
		if not self._consumer:
			await self.connect()
		if self._consumer:
			await self._consumer.start(domains)

	async def stop_consuming(self) -> None:
		"""Arrêter la consommation (délègue au Consumer)."""
		if self._consumer:
			await self._consumer.stop()

	# ─── Dead Letter ────────────────────────────────────────────────────

	async def get_dead_letter_count(self) -> int:
		"""Nombre de messages en dead-letter (délègue au DeadLetterHandler)."""
		if not self._dead_letter:
			return 0
		return await self._dead_letter.get_dead_letter_count()

	async def process_dead_letters(self, limit: int = 100) -> int:
		"""Retraiter les dead-letters (délègue au DeadLetterHandler)."""
		if not self._dead_letter:
			return 0
		return await self._dead_letter.process_dead_letters(limit)

	# ─── Replay ────────────────────────────────────────────────────────

	async def replay_events(
		self,
		domain: str,
		from_timestamp: float,
		to_timestamp: float | None = None,
		event_types: list[str] | None = None,
	) -> int:
		"""Rejouer les événements d'un domaine (délègue au Consumer)."""
		if not self._consumer:
			await self.connect()
		if self._consumer:
			return await self._consumer.replay_events(
				domain, from_timestamp, to_timestamp, event_types, self._stats
			)
		return 0

	# ─── Statistiques ──────────────────────────────────────────────────

	def get_stats(self) -> dict[str, Any]:
		"""Statistiques du bus d'événements."""
		return {
			**self._stats,
			"handler_count": self._dispatcher.handler_count,
			"running": self._consumer.running if self._consumer else False,
			"active_streams": self._consumer.active_stream_count if self._consumer else 0,
			"dead_letter_count": 0,  # Async — appelé séparément
		}

	@property
	def handlers(self) -> dict[str, list[EventHandler]]:
		"""Accès en lecture aux handlers enregistrés."""
		return self._dispatcher.handlers


# ─── Singleton ──────────────────────────────────────────────────────────────

event_bus = EventBus()
