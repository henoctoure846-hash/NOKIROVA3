"""
NOKIROVA — Décorateurs Event Bus

Décorateurs pour simplifier l'abonnement aux événements.
Usage :
	@subscribe("document.created")
	async def on_document_created(event: Event):
		...

	@on_event("ai.*")
	async def on_any_ai_event(event: Event):
		...
"""

import functools
from collections.abc import Callable

from .bus import Event, event_bus


def subscribe(event_type: str, domain: str = "", max_retries: int = 3):
	"""
	Décorateur pour abonner une fonction à un type d'événement.

	Args:
		event_type: Type d'événement ("document.created", "ai.*")
		domain: Domaine du handler
		max_retries: Tentatives max en cas d'erreur

	Usage:
		@subscribe("document.created")
		async def on_document_created(event: Event):
			# Traitement asynchrone
			pass
	"""

	def decorator(func: Callable) -> Callable:
		handler_id = event_bus.subscribe(
			event_type=event_type,
			callback=func,
			domain=domain or func.__module__,
			is_async=functools.iscoroutinefunction(func),
			max_retries=max_retries,
		)

		# Stocker le handler_id sur la fonction pour pouvoir se désabonner
		func._event_handler_id = handler_id
		func._event_type = event_type

		@functools.wraps(func)
		async def wrapper(*args, **kwargs):
			return await func(*args, **kwargs)

		return wrapper

	return decorator


# Alias
on_event = subscribe


def publish_event(event_type: str, domain: str = "", **payload_kwargs):
	"""
	Décorateur qui publie un événement APRÈS l'exécution de la fonction.

	Usage:
		@publish_event("document.created", domain="documents")
		async def create_document(...):
			# La fonction s'exécute d'abord
			# Puis un événement est publié automatiquement
			return document
	"""

	def decorator(func: Callable) -> Callable:
		@functools.wraps(func)
		async def wrapper(*args, **kwargs):
			result = await func(*args, **kwargs)

			event = Event(
				event_type=event_type,
				domain=domain,
				source=func.__module__,
				payload=payload_kwargs,
				metadata={"function": func.__name__, "result_type": type(result).__name__},
			)

			await event_bus.publish(event)
			return result

		return wrapper

	return decorator
