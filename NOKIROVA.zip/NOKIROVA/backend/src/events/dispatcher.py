"""NOKIROVA — Dispatcher d'événements

Gestion des abonnements et dispatch :
- subscribe / unsubscribe de handlers
- Recherche de handlers (match exact + wildcard)
- Publication d'événements sur Redis Streams
- Notification temps réel via Pub/Sub
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import redis.asyncio as aioredis

from src.core.health_exceptions import EVENT_BUS_EXCEPTIONS
from src.core.logging import get_logger
from src.events.models import Event, EventHandler

logger = get_logger(__name__)


# ─── Constantes ──────────────────────────────────────────────────────────────

STREAM_PREFIX = "nokirova:events:"


# ─── Dispatcher ─────────────────────────────────────────────────────────────


class EventDispatcher:
	"""Dispatcher d'événements — abonnements et publication."""

	def __init__(self) -> None:
		self._handlers: dict[str, list[EventHandler]] = {}

	# ─── Abonnement ────────────────────────────────────────────────────

	def subscribe(
		self,
		event_type: str,
		callback: Callable,
		domain: str = "",
		is_async: bool = True,
		max_retries: int = 3,
	) -> str:
		"""
		S'abonner à un type d'événement.

		Args:
			event_type: Type ou pattern ("document.*", "ai.generation.completed")
			callback: Fonction de traitement
			domain: Domaine du handler
			is_async: Le callback est-il async ?
			max_retries: Nombre max de tentatives

		Returns:
			Handler ID
		"""
		handler = EventHandler(
			event_type=event_type,
			domain=domain,
			callback=callback,
			is_async=is_async,
			max_retries=max_retries,
		)

		if event_type not in self._handlers:
			self._handlers[event_type] = []
		self._handlers[event_type].append(handler)

		logger.info(
			f"Handler enregistré : {event_type} → {handler.handler_id}",
			extra={"handler_id": handler.handler_id},
		)

		return handler.handler_id

	def unsubscribe(self, handler_id: str) -> bool:
		"""Retirer un handler."""
		for _event_type, handlers in self._handlers.items():
			for i, h in enumerate(handlers):
				if h.handler_id == handler_id:
					handlers.pop(i)
					logger.info(f"Handler retiré : {handler_id}")
					return True
		return False

	# ─── Recherche de handlers ──────────────────────────────────────────

	def find_handlers(self, event_type: str) -> list[EventHandler]:
		"""Trouver les handlers correspondant à un type d'événement."""
		handlers: list[EventHandler] = []

		# Match exact
		if event_type in self._handlers:
			handlers.extend(self._handlers[event_type])

		# Match wildcard ("document.*" matche "document.created")
		for pattern, pattern_handlers in self._handlers.items():
			if pattern.endswith(".*"):
				prefix = pattern[:-2]
				if event_type.startswith(prefix + "."):
					handlers.extend(pattern_handlers)
			elif pattern == "*":
				handlers.extend(pattern_handlers)

		return handlers

	# ─── Propriétés ────────────────────────────────────────────────────

	@property
	def handlers(self) -> dict[str, list[EventHandler]]:
		"""Dictionnaire interne des handlers (lecture seule)."""
		return self._handlers

	@property
	def handler_count(self) -> int:
		"""Nombre total de handlers enregistrés."""
		return sum(len(h) for h in self._handlers.values())

	# ─── Publication ──────────────────────────────────────────────────

	@staticmethod
	async def publish_to_redis(
		redis: aioredis.Redis,
		event: Event,
		max_stream_length: int = 10000,
	) -> str:
		"""
		Publier un événement sur Redis Streams + notification Pub/Sub.

		Args:
			redis: Connexion Redis
			event: Événement à publier
			max_stream_length: Longueur max du stream

		Returns:
			ID du message dans Redis
		"""
		stream_key = f"{STREAM_PREFIX}{event.domain}:{event.event_type}"
		event_data = event.to_dict()

		# Sérialiser le payload en JSON pour Redis
		serialized: dict[str, Any] = {}
		for k, v in event_data.items():
			if isinstance(v, (dict, list)):
				serialized[k] = json.dumps(v, ensure_ascii=False)
			elif isinstance(v, (int, float, bool, str)):
				serialized[k] = str(v) if not isinstance(v, (int, float, bool)) else v
			elif v is None:
				serialized[k] = ""
			else:
				serialized[k] = str(v)

		try:
			msg_id = await redis.xadd(
				stream_key,
				serialized,
				maxlen=max_stream_length,
			)

			# Notification temps réel via Redis Pub/Sub
			await redis.publish(
				f"nokirova:notify:{event.domain}",
				json.dumps(
					{"event_type": event.event_type, "event_id": event.event_id},
					ensure_ascii=False,
				),
			)

			return msg_id

		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(f"Erreur publication événement {event.event_type}: {e}")
			raise
