"""NOKIROVA — Consommateur d'événements

Consommation asynchrone depuis Redis Streams :
- Démarrage / arrêt des consumers
- Boucle de consommation avec back-off exponentiel
- Traitement et dispatch des messages aux handlers
- Création des consumer groups Redis
"""

from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import suppress

import redis.asyncio as aioredis

from src.core.health_exceptions import EVENT_BUS_EXCEPTIONS
from src.core.logging import get_logger
from src.events.models import Event

logger = get_logger(__name__)


# ─── Constantes ──────────────────────────────────────────────────────────────

STREAM_PREFIX = "nokirova:events:"
CONSUMER_GROUP = "nokirova_workers"


# ─── Consommateur ──────────────────────────────────────────────────────────


class EventConsumer:
	"""Consommateur d'événements depuis Redis Streams."""

	def __init__(
		self,
		redis: aioredis.Redis,
		dispatcher,  # EventDispatcher
		dead_letter_handler,  # DeadLetterHandler
	) -> None:
		self._redis = redis
		self._dispatcher = dispatcher
		self._dead_letter = dead_letter_handler
		self._running = False
		self._consumer_tasks: list[asyncio.Task] = []

	# ─── Démarrage / arrêt ──────────────────────────────────────────────

	async def start(
		self,
		domains: list[str] | None = None,
	) -> None:
		"""
		Démarrer la consommation des événements.

		Args:
			domains: Domaines à consommer (None = tous les handlers enregistrés)
		"""
		self._running = True

		if domains:
			for domain in domains:
				stream_key = f"{STREAM_PREFIX}{domain}"
				await self._ensure_consumer_group(stream_key)
				task = asyncio.create_task(self._consume_stream(stream_key))
				self._consumer_tasks.append(task)
		else:
			# Consommer depuis tous les handlers enregistrés
			for event_type in self._dispatcher.handlers:
				domain = event_type.split(".")[0] if "." in event_type else "general"
				stream_key = f"{STREAM_PREFIX}{domain}"
				await self._ensure_consumer_group(stream_key)
				task = asyncio.create_task(self._consume_stream(stream_key))
				self._consumer_tasks.append(task)

		logger.info(f"Event Bus : consommation démarrée ({len(self._consumer_tasks)} streams)")

	async def stop(self) -> None:
		"""Arrêter la consommation."""
		self._running = False
		for task in self._consumer_tasks:
			task.cancel()
		self._consumer_tasks.clear()

	# ─── Consumer group Redis ────────────────────────────────────────────

	async def _ensure_consumer_group(self, stream_key: str) -> None:
		"""Créer le consumer group Redis s'il n'existe pas."""
		with suppress(EVENT_BUS_EXCEPTIONS):
			await self._redis.xgroup_create(stream_key, CONSUMER_GROUP, id="0", mkstream=True)

	# ─── Boucle de consommation ─────────────────────────────────────────

	async def _consume_stream(self, stream_key: str) -> None:
		"""Boucle de consommation d'un stream Redis."""
		consumer_name = f"worker-{uuid.uuid4().hex[:8]}"
		backoff = 1  # secondes
		max_backoff = 60

		while self._running:
			try:
				messages = await self._redis.xreadgroup(
					CONSUMER_GROUP,
					consumer_name,
					{stream_key: ">"},
					count=10,
					block=5000,  # 5 secondes
				)

				if messages:
					for _stream, msgs in messages:
						for msg_id, data in msgs:
							await self._process_message(msg_id, data, stream_key)

				backoff = 1  # Réinitialiser après succès

			except asyncio.CancelledError:
				break
			except EVENT_BUS_EXCEPTIONS as e:
				logger.error(
					f"Erreur consommation stream {stream_key}: {e}",
					extra={"backoff": backoff, "stream": stream_key},
				)
				await asyncio.sleep(backoff)
				backoff = min(backoff * 2, max_backoff)

	# ─── Traitement des messages ────────────────────────────────────────

	async def _process_message(
		self,
		msg_id: str,
		data: dict,
		stream_key: str,
		stats: dict | None = None,
	) -> None:
		"""Traiter un message Redis et dispatcher aux handlers."""
		event_type = data.get("event_type", "unknown")

		# Reconstruire l'événement
		try:
			payload_str = data.get("payload", "{}")
			if isinstance(payload_str, str):
				data["payload"] = json.loads(payload_str)
			metadata_str = data.get("metadata", "{}")
			if isinstance(metadata_str, str):
				data["metadata"] = json.loads(metadata_str)

			event = Event.from_dict(data)
		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(f"Erreur désérialisation événement {msg_id}: {e}")
			await self._dead_letter.move_to_dead_letter(msg_id, data, stream_key, "deserialization_error")
			return

		# Trouver les handlers correspondants
		matched_handlers = self._dispatcher.find_handlers(event_type)

		if not matched_handlers:
			logger.debug(f"Aucun handler pour {event_type}")
			await self._redis.xack(stream_key, CONSUMER_GROUP, msg_id)
			return

		# Exécuter chaque handler
		all_success = True
		for handler in matched_handlers:
			success = await handler.execute(event)
			if not success:
				event.retry_count += 1
				if event.retry_count >= handler.max_retries:
					if handler.dead_letter_on_failure:
						await self._dead_letter.move_to_dead_letter(
							msg_id, data, stream_key, "max_retries_exceeded"
						)
						if stats is not None:
							stats["dead_lettered"] = stats.get("dead_lettered", 0) + 1
					all_success = False
				else:
					logger.warning(
						f"Handler échoué, retry {event.retry_count}/{handler.max_retries}"
						f" pour {event_type}"
					)
					all_success = False

		if all_success:
			if stats is not None:
				stats["processed"] = stats.get("processed", 0) + 1
		else:
			if stats is not None:
				stats["failed"] = stats.get("failed", 0) + 1

		# Acquitter le message
		await self._redis.xack(stream_key, CONSUMER_GROUP, msg_id)

	# ─── Replay ────────────────────────────────────────────────────────

	async def replay_events(
		self,
		domain: str,
		from_timestamp: float,
		to_timestamp: float | None = None,
		event_types: list[str] | None = None,
		stats: dict | None = None,
	) -> int:
		"""
		Rejouer les événements d'un domaine.

		Args:
			domain: Domaine à rejouer
			from_timestamp: Timestamp de début
			to_timestamp: Timestamp de fin (None = maintenant)
			event_types: Types spécifiques à rejouer
			stats: Compteurs à mettre à jour

		Returns:
			Nombre d'événements rejoués
		"""
		stream_key = f"{STREAM_PREFIX}{domain}"
		replayed = 0

		try:
			messages = await self._redis.xrange(stream_key, min=from_timestamp, max=to_timestamp or "+")

			for msg_id, data in messages:
				event_type = data.get("event_type", "")

				if event_types and event_type not in event_types:
					continue

				await self._process_message(msg_id, data, stream_key, stats)
				replayed += 1

		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(f"Erreur replay événements domaine {domain}: {e}")

		logger.info(f"Replay terminé : {replayed} événements rejoués pour {domain}")
		return replayed

	# ─── Propriétés ────────────────────────────────────────────────────

	@property
	def running(self) -> bool:
		"""Le consommateur est-il actif ?"""
		return self._running

	@property
	def active_stream_count(self) -> int:
		"""Nombre de streams actifs."""
		return len(self._consumer_tasks)
