"""NOKIROVA — Dead Letter Queue

Gestion des événements échoués :
- Déplacement vers la dead-letter stream
- Comptage des messages en dead-letter
- Retraitement des dead-letters
"""

from __future__ import annotations

import json
import time
from typing import Any

import redis.asyncio as aioredis

from src.core.health_exceptions import EVENT_BUS_EXCEPTIONS
from src.core.logging import get_logger

logger = get_logger(__name__)


# ─── Constantes ──────────────────────────────────────────────────────────────

DEAD_LETTER_STREAM = "nokirova:events:dead_letter"


# ─── Dead Letter Handler ───────────────────────────────────────────────────


class DeadLetterHandler:
	"""Gestionnaire de la dead-letter queue."""

	def __init__(self, redis: aioredis.Redis) -> None:
		self._redis = redis

	# ─── Déplacement ──────────────────────────────────────────────────

	async def move_to_dead_letter(
		self,
		msg_id: str,
		data: dict,
		stream_key: str,
		reason: str,
	) -> None:
		"""Déplacer un message vers la dead-letter queue."""
		data["dead_letter_reason"] = reason
		data["original_stream"] = stream_key
		data["dead_letter_at"] = time.time()

		serialized: dict[str, Any] = {}
		for k, v in data.items():
			if isinstance(v, (dict, list)):
				serialized[k] = json.dumps(v, ensure_ascii=False)
			else:
				serialized[k] = str(v) if v is not None else ""

		await self._redis.xadd(DEAD_LETTER_STREAM, serialized, maxlen=10000)
		logger.warning(f"Événement déplacé en dead-letter : {reason}")

	# ─── Comptage ──────────────────────────────────────────────────────

	async def get_dead_letter_count(self) -> int:
		"""Nombre de messages dans la dead-letter queue."""
		try:
			return await self._redis.xlen(DEAD_LETTER_STREAM)
		except EVENT_BUS_EXCEPTIONS:
			return 0

	# ─── Retraitement ──────────────────────────────────────────────────

	async def process_dead_letters(self, limit: int = 100) -> int:
		"""Retraiter les messages de la dead-letter queue."""
		processed = 0
		try:
			messages = await self._redis.xrange(DEAD_LETTER_STREAM, count=limit)
			for msg_id, data in messages:
				original_stream = data.get("original_stream", "")
				if original_stream:
					# Re-publier vers le stream original
					await self._redis.xadd(original_stream, data)
					processed += 1
					logger.info(f"Dead-letter retraité : {msg_id}")
		except EVENT_BUS_EXCEPTIONS as e:
			logger.error(f"Erreur traitement dead-letters : {e}")
		return processed
