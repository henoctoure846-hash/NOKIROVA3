"""NOKIROVA — Module événements

Exports publics :
- Event, EventHandler, EventPriority, EventStatus (modèles)
- EventDispatcher (dispatcher d'événements)
- EventConsumer (consommateur d'événements)
- DeadLetterHandler (dead-letter queue)
- EventBus (façade du bus d'événements)
- event_bus (singleton)
"""

from src.events.bus import EventBus, event_bus
from src.events.consumer import EventConsumer
from src.events.dead_letter import DeadLetterHandler
from src.events.dispatcher import EventDispatcher
from src.events.models import Event, EventHandler, EventPriority, EventStatus

__all__ = [
	"Event",
	"EventHandler",
	"EventPriority",
	"EventStatus",
	"EventDispatcher",
	"EventConsumer",
	"DeadLetterHandler",
	"EventBus",
	"event_bus",
]
