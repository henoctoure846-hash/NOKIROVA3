"""Configuration pytest pour les tests NOKIROVA.

Fournit les fixtures partagées pour l'ensemble de la suite de tests :
- Client de test FastAPI
- Session de base de données de test
- Utilisateur de test authentifié
"""

import asyncio
from collections.abc import Generator

import pytest
import pytest_asyncio
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from src.main import app

# ── Moteur de base de données de test ──────────────────────────

TEST_DATABASE_URL = "sqlite+aiosqlite:///./test_nokirova.db"

test_engine = create_async_engine(
	TEST_DATABASE_URL,
	echo=False,
)

TestSessionLocal = async_sessionmaker(
	test_engine,
	class_=AsyncSession,
	expire_on_commit=False,
)


# ── Fixtures ──────────────────────────────────────────────────


@pytest.fixture(scope="session")
def event_loop():
	"""Boucle d'événements pour les tests asynchrones."""
	loop = asyncio.new_event_loop()
	yield loop
	loop.close()


@pytest_asyncio.fixture
async def db_session() -> Generator:
	"""Session de base de données de test avec rollback automatique."""
	async with TestSessionLocal() as session:
		yield session


@pytest_asyncio.fixture
async def client() -> AsyncClient:
	"""Client HTTP asynchrone pour les tests d'API."""
	async with AsyncClient(app=app, base_url="http://test") as ac:
		yield ac


@pytest_asyncio.fixture
async def auth_client(client: AsyncClient) -> AsyncClient:
	"""Client HTTP authentifié avec un utilisateur de test."""
	# TODO : créer un utilisateur de test et obtenir un jeton JWT
	return client
