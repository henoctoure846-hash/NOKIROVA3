"""NOKIROVA — Tests unitaires : dead-letter queue.

Couverture :
- DeadLetterHandler.move_to_dead_letter() : déplacement avec raison
- DeadLetterHandler.get_dead_letter_count() : comptage
- DeadLetterHandler.process_dead_letters() : retraitement

Redis est mocké intégralement.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest

from src.events.dead_letter import DEAD_LETTER_STREAM, DeadLetterHandler

# ─── Helpers ────────────────────────────────────────────────────────────────


def _make_mock_redis() -> AsyncMock:
	"""Créer un mock Redis avec les méthodes utilisées par DeadLetterHandler."""
	mock = AsyncMock()
	mock.xadd = AsyncMock(return_value="dl-msg-001")
	mock.xlen = AsyncMock(return_value=5)
	mock.xrange = AsyncMock(return_value=[])
	return mock


# ═══════════════════════════════════════
# move_to_dead_letter
# ═══════════════════════════════════════


class TestDeadLetterMove:
	"""Tests du déplacement vers la dead-letter queue."""

	@pytest.mark.asyncio
	async def test_move_adds_metadata(self):
		"""move_to_dead_letter ajoute reason, original_stream, dead_letter_at."""
		mock_redis = _make_mock_redis()
		handler = DeadLetterHandler(mock_redis)

		data = {"event_type": "test.fail", "payload": json.dumps({})}
		await handler.move_to_dead_letter(
			msg_id="msg-001",
			data=data,
			stream_key="nokirova:events:test",
			reason="max_retries_exceeded",
		)

		mock_redis.xadd.assert_called_once()
		call_args = mock_redis.xadd.call_args

		# Le premier argument positionnel est le stream key
		assert call_args[0][0] == DEAD_LETTER_STREAM

		# Les données sérialisées contiennent les métadonnées ajoutées
		serialized = call_args[0][1]
		assert "dead_letter_reason" in serialized
		assert serialized["dead_letter_reason"] == "max_retries_exceeded"
		assert "original_stream" in serialized
		assert serialized["original_stream"] == "nokirova:events:test"
		assert "dead_letter_at" in serialized

	@pytest.mark.asyncio
	async def test_move_serializes_nested_data(self):
		"""Les dicts/listes imbriqués sont sérialisés en JSON string."""
		mock_redis = _make_mock_redis()
		handler = DeadLetterHandler(mock_redis)

		data = {
			"event_type": "test.nested",
			"payload": json.dumps({"deep": [1, 2, 3]}),
			"metadata": json.dumps({"trace": True}),
		}

		await handler.move_to_dead_letter(
			msg_id="msg-nested",
			data=data,
			stream_key="nokirova:events:test",
			reason="deserialization_error",
		)

		call_args = mock_redis.xadd.call_args
		serialized = call_args[0][1]

		# Les dicts imbriqués (payload, metadata) doivent être des strings JSON
		# car la méthode sérialise dict/list en json.dumps
		# Après ajout de dead_letter_at (float), celui-ci sera str(float)
		assert isinstance(serialized["payload"], str)
		assert isinstance(serialized["metadata"], str)

	@pytest.mark.asyncio
	async def test_move_respects_maxlen(self):
		"""xadd est appelé avec maxlen=10000."""
		mock_redis = _make_mock_redis()
		handler = DeadLetterHandler(mock_redis)

		data = {"event_type": "test.maxlen"}
		await handler.move_to_dead_letter(
			msg_id="msg-ml",
			data=data,
			stream_key="nokirova:events:test",
			reason="test",
		)

		call_args = mock_redis.xadd.call_args
		assert call_args[1].get("maxlen") == 10000


# ═══════════════════════════════════════
# get_dead_letter_count
# ═══════════════════════════════════════


class TestDeadLetterCount:
	"""Tests du comptage des dead-letters."""

	@pytest.mark.asyncio
	async def test_count_returns_xlen(self):
		"""get_dead_letter_count() retourne xlen du stream dead-letter."""
		mock_redis = _make_mock_redis()
		mock_redis.xlen = AsyncMock(return_value=7)
		handler = DeadLetterHandler(mock_redis)

		count = await handler.get_dead_letter_count()
		assert count == 7
		mock_redis.xlen.assert_called_once_with(DEAD_LETTER_STREAM)

	@pytest.mark.asyncio
	async def test_count_returns_zero_on_error(self):
		"""get_dead_letter_count() retourne 0 si Redis échoue."""
		mock_redis = _make_mock_redis()
		mock_redis.xlen = AsyncMock(side_effect=ConnectionError("Redis down"))
		handler = DeadLetterHandler(mock_redis)

		count = await handler.get_dead_letter_count()
		assert count == 0


# ═══════════════════════════════════════
# process_dead_letters
# ═══════════════════════════════════════


class TestDeadLetterProcess:
	"""Tests du retraitement des dead-letters."""

	@pytest.mark.asyncio
	async def test_process_republishes_to_original_stream(self):
		"""process_dead_letters() republie vers le stream original."""
		mock_redis = _make_mock_redis()

		# Données typiques d'un message en dead-letter
		dl_data = {
			"event_type": "test.retry",
			"original_stream": "nokirova:events:documents",
			"payload": json.dumps({"doc_id": "abc"}),
			"dead_letter_reason": "max_retries_exceeded",
			"dead_letter_at": "1700000000.0",
		}

		mock_redis.xrange = AsyncMock(
			return_value=[
				("dl-msg-1", dl_data),
			]
		)
		handler = DeadLetterHandler(mock_redis)

		processed = await handler.process_dead_letters(limit=100)
		assert processed == 1

		# xadd appelé pour republier vers le stream original
		mock_redis.xadd.assert_called_once_with(
			"nokirova:events:documents",
			dl_data,
		)

	@pytest.mark.asyncio
	async def test_process_skips_messages_without_original_stream(self):
		"""Les messages sans original_stream sont ignorés."""
		mock_redis = _make_mock_redis()
		mock_redis.xrange = AsyncMock(
			return_value=[
				(
					"dl-msg-orphan",
					{
						"event_type": "test.orphan",
						"payload": json.dumps({}),
					},
				),
			]
		)
		handler = DeadLetterHandler(mock_redis)

		processed = await handler.process_dead_letters()
		assert processed == 0
		mock_redis.xadd.assert_not_called()

	@pytest.mark.asyncio
	async def test_process_respects_limit(self):
		"""process_dead_letters() passe la limite à xrange."""
		mock_redis = _make_mock_redis()
		handler = DeadLetterHandler(mock_redis)

		await handler.process_dead_letters(limit=50)

		mock_redis.xrange.assert_called_once_with(DEAD_LETTER_STREAM, count=50)

	@pytest.mark.asyncio
	async def test_process_returns_zero_on_error(self):
		"""process_dead_letters() retourne 0 si Redis échoue."""
		mock_redis = _make_mock_redis()
		mock_redis.xrange = AsyncMock(side_effect=ConnectionError("Redis down"))
		handler = DeadLetterHandler(mock_redis)

		processed = await handler.process_dead_letters()
		assert processed == 0

	@pytest.mark.asyncio
	async def test_process_multiple_messages(self):
		"""process_dead_letters() retraite plusieurs messages."""
		mock_redis = _make_mock_redis()

		mock_redis.xrange = AsyncMock(
			return_value=[
				(
					"dl-1",
					{
						"event_type": "a.b",
						"original_stream": "nokirova:events:docs",
					},
				),
				(
					"dl-2",
					{
						"event_type": "c.d",
						"original_stream": "nokirova:events:auth",
					},
				),
			]
		)
		handler = DeadLetterHandler(mock_redis)

		processed = await handler.process_dead_letters()
		assert processed == 2
		assert mock_redis.xadd.call_count == 2
