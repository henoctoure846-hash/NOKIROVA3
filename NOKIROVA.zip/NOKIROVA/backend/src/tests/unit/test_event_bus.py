"""NOKIROVA — Tests unitaires : bus d'événements (façade).

Couverture :
- EventBus.__init__() : construction, composants internes
- EventBus.subscribe() / unsubscribe() : délégation au Dispatcher
- EventBus.publish() : construction d'Event + délégation au Dispatcher
- EventBus.start_consuming() / stop_consuming() : délégation au Consumer
- EventBus.get_dead_letter_count() / process_dead_letters() : délégation
- EventBus.get_stats() : statistiques agrégées
- Singleton event_bus

Redis est mocké intégralement — aucun serveur requis.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from src.events.bus import EventBus, event_bus
from src.events.models import Event

# ─── Helpers ────────────────────────────────────────────────────────────────


def _make_mock_redis() -> AsyncMock:
	"""Créer un mock Redis complet pour les tests du bus."""
	mock = AsyncMock()
	mock.ping = AsyncMock()
	mock.xadd = AsyncMock(return_value="msg-001")
	mock.publish = AsyncMock()
	mock.xgroup_create = AsyncMock()
	mock.xreadgroup = AsyncMock(return_value=[])
	mock.xack = AsyncMock()
	mock.xrange = AsyncMock(return_value=[])
	mock.xlen = AsyncMock(return_value=0)
	mock.close = AsyncMock()
	return mock


# ═══════════════════════════════════════
# Construction
# ═══════════════════════════════════════


class TestEventBusConstruction:
	"""Tests de la construction du bus d'événements."""

	def test_bus_init_default_redis_url(self):
		"""EventBus accepte une URL Redis par défaut."""
		bus = EventBus()
		# L'URL par défaut vient de settings.REDIS_URL ou "redis://localhost:6379"
		assert bus._redis_url is not None

	def test_bus_init_custom_redis_url(self):
		"""EventBus accepte une URL Redis personnalisée."""
		bus = EventBus(redis_url="redis://custom:6380")
		assert bus._redis_url == "redis://custom:6380"

	def test_bus_init_creates_dispatcher(self):
		"""Le Dispatcher est créé à la construction."""
		bus = EventBus()
		assert bus._dispatcher is not None
		assert bus._dispatcher.handler_count == 0

	def test_bus_init_stats_default(self):
		"""Les statistiques démarrent à zéro."""
		bus = EventBus()
		stats = bus.get_stats()
		assert stats["published"] == 0
		assert stats["processed"] == 0
		assert stats["failed"] == 0
		assert stats["dead_lettered"] == 0


# ═══════════════════════════════════════
# Connexion
# ═══════════════════════════════════════


class TestEventBusConnection:
	"""Tests de la connexion Redis."""

	@pytest.mark.asyncio
	async def test_connect_initializes_components(self):
		"""connect() initialise DeadLetter et Consumer."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			await bus.connect()

		assert bus._dead_letter is not None
		assert bus._consumer is not None
		assert bus._redis is not None

	@pytest.mark.asyncio
	async def test_disconnect_closes_redis(self):
		"""disconnect() ferme la connexion Redis."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			await bus.connect()
			await bus.disconnect()

		assert bus._redis is None


# ═══════════════════════════════════════
# Subscribe / Unsubscribe
# ═══════════════════════════════════════


class TestEventBusSubscribe:
	"""Tests de la délégation d'abonnement au Dispatcher."""

	def test_subscribe_delegates_to_dispatcher(self):
		"""subscribe() enregistre un handler via le Dispatcher."""
		bus = EventBus()

		async def cb(event: Event):
			pass

		handler_id = bus.subscribe("test.event", cb, domain="test")
		assert handler_id
		assert bus._dispatcher.handler_count == 1

	def test_unsubscribe_delegates_to_dispatcher(self):
		"""unsubscribe() retire un handler via le Dispatcher."""
		bus = EventBus()

		async def cb(event: Event):
			pass

		handler_id = bus.subscribe("test.event", cb)
		assert bus.unsubscribe(handler_id) is True
		assert bus._dispatcher.handler_count == 0

	def test_unsubscribe_unknown_returns_false(self):
		"""unsubscribe() retourne False pour un ID inconnu."""
		bus = EventBus()
		assert bus.unsubscribe("nonexistent-id") is False


# ═══════════════════════════════════════
# Publish
# ═══════════════════════════════════════


class TestEventBusPublish:
	"""Tests de la publication d'événements."""

	@pytest.mark.asyncio
	async def test_publish_creates_event_and_dispatches(self):
		"""publish() crée un Event et le publie via le Dispatcher."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			event_id = await bus.publish(
				event_type="document.created",
				payload={"doc_id": "abc"},
				domain="documents",
				source="doc_service",
				priority="high",
			)

		assert event_id  # L'ID de l'événement
		assert bus._stats["published"] == 1

	@pytest.mark.asyncio
	async def test_publish_invalid_priority_defaults_normal(self):
		"""publish() avec une priorité invalide utilise NORMAL."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			event_id = await bus.publish(
				event_type="test.event",
				domain="test",
				priority="invalid_value",
			)

		assert event_id


# ═══════════════════════════════════════
# Consommation
# ═══════════════════════════════════════


class TestEventBusConsuming:
	"""Tests de la consommation d'événements."""

	@pytest.mark.asyncio
	async def test_start_consuming(self):
		"""start_consuming() démarre le Consumer."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			await bus.connect()
			await bus.start_consuming(domains=["test"])

		assert bus._consumer.running is True

		await bus.stop_consuming()

	@pytest.mark.asyncio
	async def test_stop_consuming(self):
		"""stop_consuming() arrête le Consumer."""
		bus = EventBus(redis_url="redis://localhost:6379")

		mock_redis = _make_mock_redis()
		with patch("src.events.bus.aioredis.from_url", return_value=mock_redis):
			await bus.connect()
			await bus.start_consuming(domains=["test"])
			await bus.stop_consuming()

		assert bus._consumer.running is False


# ═══════════════════════════════════════
# Dead Letter
# ═══════════════════════════════════════


class TestEventBusDeadLetter:
	"""Tests de la dead-letter via le bus."""

	@pytest.mark.asyncio
	async def test_get_dead_letter_count_without_connection(self):
		"""get_dead_letter_count() retourne 0 sans connexion."""
		bus = EventBus()
		count = await bus.get_dead_letter_count()
		assert count == 0

	@pytest.mark.asyncio
	async def test_process_dead_letters_without_connection(self):
		"""process_dead_letters() retourne 0 sans connexion."""
		bus = EventBus()
		count = await bus.process_dead_letters()
		assert count == 0


# ═══════════════════════════════════════
# Statistiques
# ═══════════════════════════════════════


class TestEventBusStats:
	"""Tests des statistiques du bus."""

	def test_get_stats_includes_all_keys(self):
		"""get_stats() contient toutes les clés attendues."""
		bus = EventBus()
		stats = bus.get_stats()

		assert "published" in stats
		assert "processed" in stats
		assert "failed" in stats
		assert "dead_lettered" in stats
		assert "handler_count" in stats
		assert "running" in stats
		assert "active_streams" in stats

	def test_get_stats_handler_count_matches(self):
		"""handler_count dans stats correspond au Dispatcher."""
		bus = EventBus()

		async def cb(event: Event):
			pass

		bus.subscribe("a.b", cb)
		bus.subscribe("c.d", cb)

		stats = bus.get_stats()
		assert stats["handler_count"] == 2


# ═══════════════════════════════════════
# Singleton
# ═══════════════════════════════════════


class TestEventBusSingleton:
	"""Tests du singleton event_bus."""

	def test_singleton_exists(self):
		"""Le module exporte un singleton event_bus."""
		assert event_bus is not None
		assert isinstance(event_bus, EventBus)

	def test_singleton_is_unique(self):
		"""Le singleton est la même instance partout."""
		from src.events import event_bus as imported_bus

		assert imported_bus is event_bus
