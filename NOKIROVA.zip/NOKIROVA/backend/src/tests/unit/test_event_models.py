"""NOKIROVA — Tests unitaires : modèles d'événements.

Couverture :
- EventPriority (enum, valeurs)
- EventStatus (enum, valeurs)
- Event (construction, sérialisation, désérialisation, valeurs par défaut)
- EventHandler (construction, exécution sync/async, gestion erreurs)
"""

from __future__ import annotations

import pytest

from src.events.models import Event, EventHandler, EventPriority, EventStatus

# ═══════════════════════════════════════
# EventPriority
# ═══════════════════════════════════════


class TestEventPriority:
	"""Tests de l'enum EventPriority."""

	def test_priority_values(self):
		"""Vérifier les 4 niveaux de priorité."""
		assert EventPriority.CRITICAL.value == "critical"
		assert EventPriority.HIGH.value == "high"
		assert EventPriority.NORMAL.value == "normal"
		assert EventPriority.LOW.value == "low"

	def test_priority_is_str_enum(self):
		"""EventPriority hérite de str + Enum."""
		assert isinstance(EventPriority.CRITICAL, str)
		assert EventPriority.CRITICAL == "critical"

	def test_priority_from_value(self):
		"""Construire une priorité depuis sa valeur string."""
		assert EventPriority("high") == EventPriority.HIGH


# ═══════════════════════════════════════
# EventStatus
# ═══════════════════════════════════════


class TestEventStatus:
	"""Tests de l'enum EventStatus."""

	def test_status_values(self):
		"""Vérifier les 5 statuts possibles."""
		assert EventStatus.PENDING.value == "pending"
		assert EventStatus.PROCESSING.value == "processing"
		assert EventStatus.COMPLETED.value == "completed"
		assert EventStatus.FAILED.value == "failed"
		assert EventStatus.DEAD_LETTER.value == "dead_letter"

	def test_status_is_str_enum(self):
		"""EventStatus hérite de str + Enum."""
		assert isinstance(EventStatus.COMPLETED, str)


# ═══════════════════════════════════════
# Event
# ═══════════════════════════════════════


class TestEvent:
	"""Tests du dataclass Event."""

	def test_event_default_values(self):
		"""Un événement par défaut a des valeurs raisonnables."""
		event = Event()
		assert event.event_id  # UUID auto-généré
		assert event.event_type == ""
		assert event.domain == ""
		assert event.payload == {}
		assert event.metadata == {}
		assert event.source == ""
		assert event.correlation_id  # UUID auto-généré
		assert event.causation_id is None
		assert event.priority == EventPriority.NORMAL
		assert event.status == EventStatus.PENDING
		assert event.timestamp > 0
		assert event.scheduled_at is None
		assert event.expires_at is None
		assert event.retry_count == 0
		assert event.max_retries == 3

	def test_event_custom_values(self):
		"""Construire un événement avec des valeurs personnalisées."""
		event = Event(
			event_type="document.created",
			domain="documents",
			payload={"doc_id": "abc123"},
			source="document_service",
			priority=EventPriority.HIGH,
			correlation_id="corr-001",
			causation_id="cause-001",
			max_retries=5,
		)
		assert event.event_type == "document.created"
		assert event.domain == "documents"
		assert event.payload == {"doc_id": "abc123"}
		assert event.source == "document_service"
		assert event.priority == EventPriority.HIGH
		assert event.correlation_id == "corr-001"
		assert event.causation_id == "cause-001"
		assert event.max_retries == 5

	def test_event_to_dict(self):
		"""Sérialisation Event → dict."""
		event = Event(
			event_type="ai.generation.completed",
			domain="ai",
			payload={"result": "ok"},
			priority=EventPriority.CRITICAL,
			status=EventStatus.PROCESSING,
		)
		d = event.to_dict()

		assert d["event_type"] == "ai.generation.completed"
		assert d["domain"] == "ai"
		assert d["payload"] == {"result": "ok"}
		assert d["priority"] == "critical"  # valeur string, pas l'enum
		assert d["status"] == "processing"  # valeur string, pas l'enum

	def test_event_from_dict(self):
		"""Désérialisation dict → Event."""
		data = {
			"event_id": "test-id-001",
			"event_type": "auth.login.success",
			"domain": "auth",
			"payload": {"user_id": "u42"},
			"metadata": {"ip": "1.2.3.4"},
			"source": "auth_service",
			"correlation_id": "corr-002",
			"causation_id": None,
			"priority": "high",
			"status": "completed",
			"timestamp": 1700000000.0,
			"scheduled_at": None,
			"expires_at": None,
			"retry_count": 1,
			"max_retries": 3,
		}
		event = Event.from_dict(data)

		assert event.event_id == "test-id-001"
		assert event.event_type == "auth.login.success"
		assert event.domain == "auth"
		assert event.priority == EventPriority.HIGH
		assert event.status == EventStatus.COMPLETED
		assert event.retry_count == 1

	def test_event_roundtrip_serialization(self):
		"""Sérialisation puis désérialisation préserve les données."""
		original = Event(
			event_type="test.roundtrip",
			domain="test",
			payload={"key": "value"},
			priority=EventPriority.LOW,
		)
		d = original.to_dict()
		restored = Event.from_dict(d)

		assert restored.event_type == original.event_type
		assert restored.domain == original.domain
		assert restored.payload == original.payload
		assert restored.priority == original.priority
		assert restored.event_id == original.event_id

	def test_event_unique_ids(self):
		"""Deux événements ont des IDs différents."""
		e1 = Event()
		e2 = Event()
		assert e1.event_id != e2.event_id
		assert e1.correlation_id != e2.correlation_id


# ═══════════════════════════════════════
# EventHandler
# ═══════════════════════════════════════


class TestEventHandler:
	"""Tests du dataclass EventHandler."""

	def test_handler_default_values(self):
		"""Un handler par défaut a des valeurs raisonnables."""
		handler = EventHandler()
		assert handler.handler_id  # UUID auto-généré
		assert handler.event_type == ""
		assert handler.domain == ""
		assert handler.callback is None
		assert handler.is_async is True
		assert handler.max_retries == 3
		assert handler.dead_letter_on_failure is True

	@pytest.mark.asyncio
	async def test_handler_execute_async_success(self):
		"""Exécution async réussie d'un handler."""
		called = False

		async def my_callback(event: Event):
			nonlocal called
			called = True
			return True

		handler = EventHandler(
			event_type="test.event",
			callback=my_callback,
			is_async=True,
		)
		event = Event(event_type="test.event")

		result = await handler.execute(event)
		assert result is True
		assert called is True

	@pytest.mark.asyncio
	async def test_handler_execute_sync_success(self):
		"""Exécution sync réussie d'un handler."""
		called = False

		def my_callback(event: Event):
			nonlocal called
			called = True
			return True

		handler = EventHandler(
			event_type="test.event",
			callback=my_callback,
			is_async=False,
		)
		event = Event(event_type="test.event")

		result = await handler.execute(event)
		assert result is True
		assert called is True

	@pytest.mark.asyncio
	async def test_handler_execute_no_callback(self):
		"""Un handler sans callback retourne False."""
		handler = EventHandler(event_type="test.event", callback=None)
		event = Event(event_type="test.event")

		result = await handler.execute(event)
		assert result is False

	@pytest.mark.asyncio
	async def test_handler_execute_exception_returns_false(self):
		"""Un handler qui lève une exception retourne False."""

		async def failing_callback(event: Event):
			raise RuntimeError("Panne simulée")

		handler = EventHandler(
			event_type="test.event",
			callback=failing_callback,
			is_async=True,
		)
		event = Event(event_type="test.event")

		result = await handler.execute(event)
		assert result is False

	def test_handler_unique_ids(self):
		"""Deux handlers ont des IDs différents."""
		h1 = EventHandler()
		h2 = EventHandler()
		assert h1.handler_id != h2.handler_id
