"""NOKIROVA — Tests unitaires : dispatcher d'événements.

Couverture :
- EventDispatcher.subscribe() : enregistrement de handlers
- EventDispatcher.unsubscribe() : retrait de handlers
- EventDispatcher.find_handlers() : match exact, wildcard, global
- EventDispatcher.handler_count : comptage
- EventDispatcher.publish_to_redis() : publication (mock Redis)
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest

from src.events.dispatcher import STREAM_PREFIX, EventDispatcher
from src.events.models import Event

# ═══════════════════════════════════════
# Subscribe / Unsubscribe
# ═══════════════════════════════════════


class TestEventDispatcherSubscribe:
	"""Tests d'abonnement et de désabonnement."""

	def test_subscribe_returns_handler_id(self):
		"""subscribe() retourne un handler_id non vide."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		handler_id = dispatcher.subscribe("test.event", cb)
		assert handler_id  # UUID non vide

	def test_subscribe_multiple_same_type(self):
		"""Plusieurs handlers peuvent s'abonner au même type."""
		dispatcher = EventDispatcher()

		async def cb1(event: Event):
			pass

		async def cb2(event: Event):
			pass

		id1 = dispatcher.subscribe("test.event", cb1)
		id2 = dispatcher.subscribe("test.event", cb2)

		assert id1 != id2
		assert dispatcher.handler_count == 2

	def test_subscribe_different_types(self):
		"""Handlers sur des types différents."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("auth.login", cb, domain="auth")
		dispatcher.subscribe("doc.created", cb, domain="documents")

		assert dispatcher.handler_count == 2
		assert "auth.login" in dispatcher.handlers
		assert "doc.created" in dispatcher.handlers

	def test_subscribe_with_domain_and_options(self):
		"""subscribe() accepte domain, is_async, max_retries."""
		dispatcher = EventDispatcher()

		def sync_cb(event: Event):
			pass

		dispatcher.subscribe(
			"test.sync",
			sync_cb,
			domain="test",
			is_async=False,
			max_retries=5,
		)

		handler = dispatcher.handlers["test.sync"][0]
		assert handler.domain == "test"
		assert handler.is_async is False
		assert handler.max_retries == 5

	def test_unsubscribe_existing_handler(self):
		"""unsubscribe() retourne True pour un handler existant."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		handler_id = dispatcher.subscribe("test.event", cb)
		assert dispatcher.unsubscribe(handler_id) is True
		assert dispatcher.handler_count == 0

	def test_unsubscribe_nonexistent_handler(self):
		"""unsubscribe() retourne False pour un handler inexistant."""
		dispatcher = EventDispatcher()
		assert dispatcher.unsubscribe("fake-id-000") is False

	def test_unsubscribe_one_of_many(self):
		"""Retirer un handler parmi plusieurs du même type."""
		dispatcher = EventDispatcher()

		async def cb1(event: Event):
			pass

		async def cb2(event: Event):
			pass

		id1 = dispatcher.subscribe("test.event", cb1)
		id2 = dispatcher.subscribe("test.event", cb2)

		dispatcher.unsubscribe(id1)
		assert dispatcher.handler_count == 1
		assert dispatcher.handlers["test.event"][0].handler_id == id2


# ═══════════════════════════════════════
# find_handlers
# ═══════════════════════════════════════


class TestEventDispatcherFindHandlers:
	"""Tests de recherche de handlers."""

	def test_find_exact_match(self):
		"""find_handlers() retourne les handlers pour un match exact."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("document.created", cb, domain="documents")

		handlers = dispatcher.find_handlers("document.created")
		assert len(handlers) == 1
		assert handlers[0].domain == "documents"

	def test_find_no_match(self):
		"""find_handlers() retourne [] si aucun handler ne correspond."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("auth.login", cb)

		handlers = dispatcher.find_handlers("auth.logout")
		assert handlers == []

	def test_find_wildcard_match(self):
		"""Un pattern 'document.*' matche 'document.created'."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("document.*", cb, domain="documents")

		handlers = dispatcher.find_handlers("document.created")
		assert len(handlers) == 1

	def test_find_wildcard_no_match(self):
		"""Un pattern 'document.*' ne matche pas 'auth.login'."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("document.*", cb, domain="documents")

		handlers = dispatcher.find_handlers("auth.login")
		assert handlers == []

	def test_find_global_wildcard(self):
		"""Le pattern '*' matche tout type d'événement."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("*", cb, domain="monitoring")

		handlers = dispatcher.find_handlers("any.event.type")
		assert len(handlers) == 1

	def test_find_exact_plus_wildcard(self):
		"""Les handlers exacts et wildcard sont tous retournés."""
		dispatcher = EventDispatcher()

		async def exact_cb(event: Event):
			pass

		async def wildcard_cb(event: Event):
			pass

		dispatcher.subscribe("document.created", exact_cb, domain="documents")
		dispatcher.subscribe("document.*", wildcard_cb, domain="documents")

		handlers = dispatcher.find_handlers("document.created")
		assert len(handlers) == 2


# ═══════════════════════════════════════
# handler_count
# ═══════════════════════════════════════


class TestEventDispatcherCount:
	"""Tests du comptage de handlers."""

	def test_handler_count_empty(self):
		"""handler_count vaut 0 sans handlers."""
		dispatcher = EventDispatcher()
		assert dispatcher.handler_count == 0

	def test_handler_count_multiple(self):
		"""handler_count retourne le nombre total."""
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("a.b", cb)
		dispatcher.subscribe("a.b", cb)
		dispatcher.subscribe("c.d", cb)

		assert dispatcher.handler_count == 3


# ═══════════════════════════════════════
# publish_to_redis (mock)
# ═══════════════════════════════════════


class TestEventDispatcherPublishToRedis:
	"""Tests de la publication Redis (mockée)."""

	@pytest.mark.asyncio
	async def test_publish_calls_xadd(self):
		"""publish_to_redis appelle redis.xadd avec les bons arguments."""
		mock_redis = AsyncMock()
		mock_redis.xadd = AsyncMock(return_value="1234567890-0")
		mock_redis.publish = AsyncMock()

		event = Event(
			event_type="test.publish",
			domain="test",
			payload={"key": "value"},
		)

		msg_id = await EventDispatcher.publish_to_redis(mock_redis, event)

		assert msg_id == "1234567890-0"
		mock_redis.xadd.assert_called_once()
		mock_redis.publish.assert_called_once()

	@pytest.mark.asyncio
	async def test_publish_stream_key_format(self):
		"""Le stream_key suit le format nokirova:events:{domain}:{type}."""
		mock_redis = AsyncMock()
		mock_redis.xadd = AsyncMock(return_value="msg-001")
		mock_redis.publish = AsyncMock()

		event = Event(
			event_type="document.created",
			domain="documents",
		)

		await EventDispatcher.publish_to_redis(mock_redis, event)

		# Vérifier le premier argument (stream_key)
		call_args = mock_redis.xadd.call_args
		stream_key = call_args[0][0]
		assert stream_key == f"{STREAM_PREFIX}documents:document.created"

	@pytest.mark.asyncio
	async def test_publish_serializes_nested_dicts(self):
		"""Les dicts imbriqués sont sérialisés en JSON."""
		mock_redis = AsyncMock()
		mock_redis.xadd = AsyncMock(return_value="msg-002")
		mock_redis.publish = AsyncMock()

		event = Event(
			event_type="test.nested",
			domain="test",
			payload={"nested": {"deep": True}},
		)

		await EventDispatcher.publish_to_redis(mock_redis, event)

		call_args = mock_redis.xadd.call_args
		serialized = call_args[0][1]
		# Le payload doit être un string JSON
		assert isinstance(serialized["payload"], str)
		assert json.loads(serialized["payload"]) == {"nested": {"deep": True}}

	@pytest.mark.asyncio
	async def test_publish_redis_error_raises(self):
		"""Une erreur Redis propage l'exception."""
		mock_redis = AsyncMock()
		mock_redis.xadd = AsyncMock(side_effect=ConnectionError("Redis down"))

		event = Event(event_type="test.fail", domain="test")

		with pytest.raises(ConnectionError):
			await EventDispatcher.publish_to_redis(mock_redis, event)
