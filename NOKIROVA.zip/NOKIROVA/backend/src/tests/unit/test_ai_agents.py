"""Tests unitaires du moteur IA NOKIROVA.

Valide :
- BaseAgent : construction, statuts, retry, fallback
- AgentResult : valeurs par défaut, immutabilité
- AgentStatus : enum complet
- Registry : 16 agents décrits, prompts système présents
- AIAgent model : champs obligatoires, relations
- Event publication après exécution
"""

from unittest.mock import AsyncMock, patch

import pytest

from src.ai.agents.base import (
	AgentResult,
	AgentStatus,
	BaseAgent,
)
from src.ai.agents.registry import DESCRIPTIONS, SYSTEMS
from src.database.models.ai import (
	AIAgent,
	AIConversation,
	AIMessage,
	AIModelConfig,
	AIReasoningChain,
	AIUsageLog,
)

# ── AgentStatus ─────────────────────────────────


class TestAgentStatus:
	"""L'enum AgentStatus doit contenir tous les statuts prévus."""

	def test_all_statuses_defined(self):
		"""Les 5 statuts sont présents."""
		assert AgentStatus.IDLE == "idle"
		assert AgentStatus.RUNNING == "running"
		assert AgentStatus.COMPLETED == "completed"
		assert AgentStatus.FAILED == "failed"
		assert AgentStatus.FALLBACK == "fallback"

	def test_status_count(self):
		"""Exactement 5 statuts."""
		assert len(AgentStatus) == 5


# ── AgentResult ────────────────────────────────


class TestAgentResult:
	"""L'AgentResult doit avoir des valeurs par défaut correctes."""

	def test_default_values(self):
		"""Valeurs par défaut cohérentes."""
		result = AgentResult()
		assert result.agent_name == ""
		assert result.status == AgentStatus.IDLE
		assert result.output is None
		assert result.error is None
		assert result.duration_ms == 0.0
		assert result.tokens_used == 0
		assert result.cost_cents == 0.0
		assert result.metadata == {}

	def test_unique_agent_ids(self):
		"""Chaque AgentResult a un identifiant unique."""
		results = [AgentResult() for _ in range(100)]
		ids = {r.agent_id for r in results}
		assert len(ids) == 100

	def test_custom_values(self):
		"""Les champs personnalisés sont assignés correctement."""
		result = AgentResult(
			agent_name="tutor",
			status=AgentStatus.COMPLETED,
			output="Réponse simulée",
			tokens_used=150,
		)
		assert result.agent_name == "tutor"
		assert result.status == AgentStatus.COMPLETED
		assert result.output == "Réponse simulée"
		assert result.tokens_used == 150


# ── BaseAgent ─────────────────────────────────


class DummyAgent(BaseAgent):
	"""Agent concret pour les tests unitaires."""

	name = "dummy"
	domain = "test"
	description = "Agent de test"
	max_retries = 1

	async def execute(self, prompt, context=None, **kwargs):
		result = AgentResult(agent_name=self.name)
		result.output = f"Exécuté : {prompt}"
		result.tokens_used = 42
		return result


class FailingAgent(BaseAgent):
	"""Agent qui échoue systématiquement."""

	name = "failing"
	domain = "test"
	description = "Agent qui plante"
	max_retries = 1

	async def execute(self, prompt, context=None, **kwargs):
		raise ConnectionError("Provider IA indisponible")


class TestBaseAgent:
	"""BaseAgent doit gérer l'exécution, le retry et le fallback."""

	def test_agent_attributes(self):
		"""Un agent a nom, domaine, description."""
		agent = DummyAgent()
		assert agent.name == "dummy"
		assert agent.domain == "test"
		assert agent.description == "Agent de test"
		assert agent._status == AgentStatus.IDLE

	@pytest.mark.asyncio
	async def test_successful_execution(self):
		"""Un agent sain exécute et retourne COMPLETED."""
		agent = DummyAgent()
		with patch.object(agent, "_publish_event", new_callable=AsyncMock):
			result = await agent.run("Bonjour")
		assert result.status == AgentStatus.COMPLETED
		assert result.output == "Exécuté : Bonjour"
		assert result.agent_name == "dummy"
		assert result.tokens_used == 42
		assert result.duration_ms > 0

	@pytest.mark.asyncio
	async def test_failed_execution(self):
		"""Un agent défaillant retourne FAILED après retry."""
		agent = FailingAgent()
		with patch.object(agent, "_publish_event", new_callable=AsyncMock):
			result = await agent.run("Test")
		assert result.status == AgentStatus.FAILED
		assert "Provider IA indisponible" in result.error
		assert result.duration_ms > 0

	@pytest.mark.asyncio
	async def test_publish_event_on_success(self):
		"""Un agent appelle _publish_event après exécution réussie."""
		agent = DummyAgent()
		with patch.object(agent, "_publish_event", new_callable=AsyncMock) as mock_pub:
			await agent.run("Test événement")
		mock_pub.assert_called_once()
		# Vérifier que l'argument est un AgentResult
		call_args = mock_pub.call_args[0]
		assert isinstance(call_args[0], AgentResult)
		assert call_args[0].status == AgentStatus.COMPLETED

	@pytest.mark.asyncio
	async def test_publish_event_on_failure(self):
		"""Un agent appelle _publish_event même en cas d'échec."""
		agent = FailingAgent()
		with patch.object(agent, "_publish_event", new_callable=AsyncMock) as mock_pub:
			await agent.run("Test")
		mock_pub.assert_called_once()
		call_args = mock_pub.call_args[0]
		assert call_args[0].status == AgentStatus.FAILED

	@pytest.mark.asyncio
	async def test_call_provider_stub(self):
		"""Le stub _call_provider retourne un dict avec content et meta."""
		agent = DummyAgent()
		result = await agent._call_provider("système", "utilisateur")
		assert "content" in result
		assert "_meta" in result
		assert "tokens" in result["_meta"]

	@pytest.mark.asyncio
	async def test_status_transitions(self):
		"""Le statut passe IDLE→RUNNING→COMPLETED."""
		agent = DummyAgent()
		assert agent._status == AgentStatus.IDLE
		with patch.object(agent, "_publish_event", new_callable=AsyncMock):
			await agent.run("Test")
		assert agent._status == AgentStatus.COMPLETED

	@pytest.mark.asyncio
	async def test_failing_status_transitions(self):
		"""Le statut passe IDLE→RUNNING→FAILED."""
		agent = FailingAgent()
		with patch.object(agent, "_publish_event", new_callable=AsyncMock):
			await agent.run("Test")
		assert agent._status == AgentStatus.FAILED


# ── Registry ─────────────────────────────────


class TestAgentRegistry:
	"""Le registre doit contenir les 16 agents spécialistes."""

	def test_all_16_descriptions(self):
		"""Exactement 16 descriptions d'agents."""
		assert len(DESCRIPTIONS) == 16

	def test_all_16_systems(self):
		"""Exactement 16 prompts système."""
		assert len(SYSTEMS) == 16

	def test_descriptions_and_systems_match(self):
		"""Les clés DESCRIPTIONS et SYSTEMS sont identiques."""
		assert set(DESCRIPTIONS.keys()) == set(SYSTEMS.keys())

	def test_known_agents_present(self):
		"""Les agents clés sont présents dans le registre."""
		for name in [
			"flashcard",
			"quiz",
			"summary",
			"ocr",
			"search",
			"memory",
			"code",
			"writing",
			"math",
			"revision",
			"knowledge",
			"moderation",
			"analytics",
			"embedding",
		]:
			assert name in DESCRIPTIONS
			assert name in SYSTEMS

	def test_descriptions_non_empty(self):
		"""Aucune description vide."""
		for key, desc in DESCRIPTIONS.items():
			assert len(desc) > 0, f"Description vide pour {key}"

	def test_systems_non_empty(self):
		"""Aucun prompt système vide."""
		for key, prompt in SYSTEMS.items():
			assert len(prompt) > 0, f"Prompt vide pour {key}"


# ── Modèles IA ──────────────────────────────


class TestAIModels:
	"""Les modèles SQLAlchemy IA doivent avoir les bonnes tables."""

	def test_ai_agent_table_name(self):
		assert AIAgent.__tablename__ == "ai_agents"

	def test_ai_conversation_table_name(self):
		assert AIConversation.__tablename__ == "ai_conversations"

	def test_ai_message_table_name(self):
		assert AIMessage.__tablename__ == "ai_messages"

	def test_ai_reasoning_chain_table_name(self):
		assert AIReasoningChain.__tablename__ == "ai_reasoning_chains"

	def test_ai_model_config_table_name(self):
		assert AIModelConfig.__tablename__ == "ai_model_configs"

	def test_ai_usage_log_table_name(self):
		assert AIUsageLog.__tablename__ == "ai_usage_logs"

	def test_ai_agent_required_fields(self):
		"""AIAgent a les champs obligatoires."""
		columns = {c.name for c in AIAgent.__table__.columns}
		assert "name" in columns
		assert "agent_type" in columns
		assert "temperature" in columns
		assert "max_tokens" in columns

	def test_ai_usage_log_tracks_costs(self):
		"""AIUsageLog suit les coûts et tokens."""
		columns = {c.name for c in AIUsageLog.__table__.columns}
		assert "prompt_tokens" in columns
		assert "completion_tokens" in columns
		assert "total_tokens" in columns
		assert "cost" in columns
		assert "is_cached" in columns
