"""NOKIROVA — Tests unitaires : consommateur d'événements.

Couverture :
- EventConsumer.start() / stop() : cycle de vie
- EventConsumer._process_message() : traitement et dispatch
- EventConsumer._ensure_consumer_group() : création consumer group
- EventConsumer.replay_events() : replay avec filtres
- Propriétés : running, active_stream_count

Redis est mocké intégralement — aucun serveur requis.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest

from src.events.consumer import CONSUMER_GROUP, STREAM_PREFIX, EventConsumer
from src.events.dead_letter import DeadLetterHandler
from src.events.dispatcher import EventDispatcher
from src.events.models import Event

# ─── Helpers ────────────────────────────────────────────────────────────────


def _make_mock_redis() -> AsyncMock:
	"""Créer un mock Redis avec les méthodes utilisées par EventConsumer."""
	mock = AsyncMock()
	mock.xgroup_create = AsyncMock()
	mock.xreadgroup = AsyncMock(return_value=[])
	mock.xack = AsyncMock()
	mock.xadd = AsyncMock(return_value="dead-msg-001")
	mock.xrange = AsyncMock(return_value=[])
	mock.xlen = AsyncMock(return_value=0)
	mock.ping = AsyncMock()
	mock.close = AsyncMock()
	return mock


def _build_redis_event_data(**overrides) -> dict:
	"""Construire un dict d'événement au format Redis (valeurs string)."""
	base = {
		"event_id": "evt-test-001",
		"event_type": "test.success",
		"domain": "test",
		"payload": json.dumps({"key": "value"}),
		"metadata": json.dumps({}),
		"source": "test_service",
		"correlation_id": "corr-001",
		"causation_id": "",
		"priority": "normal",
		"status": "pending",
		"timestamp": "1700000000.0",
		"scheduled_at": "",
		"expires_at": "",
		"retry_count": "0",
		"max_retries": "3",
	}
	base.update(overrides)
	return base


# ═══════════════════════════════════════
# Cycle de vie
# ═══════════════════════════════════════


class TestEventConsumerLifecycle:
	"""Tests du démarrage et de l'arrêt du consommateur."""

	@pytest.mark.asyncio
	async def test_start_creates_consumer_tasks(self):
		"""start() crée des tâches de consommation pour les domaines spécifiés."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		await consumer.start(domains=["documents", "auth"])

		assert consumer.running is True
		assert consumer.active_stream_count == 2

		await consumer.stop()

	@pytest.mark.asyncio
	async def test_stop_cancels_tasks(self):
		"""stop() annule les tâches et réinitialise l'état."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		await consumer.start(domains=["test"])
		await consumer.stop()

		assert consumer.running is False
		assert consumer.active_stream_count == 0

	@pytest.mark.asyncio
	async def test_start_from_dispatcher_handlers(self):
		"""start() sans domaines utilise les handlers enregistrés."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("document.created", cb, domain="documents")
		dispatcher.subscribe("auth.login", cb, domain="auth")

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		await consumer.start()

		# Au moins 2 domaines extraits des handlers
		assert consumer.active_stream_count >= 2

		await consumer.stop()


# ═══════════════════════════════════════
# Consumer group
# ═══════════════════════════════════════


class TestEventConsumerGroup:
	"""Tests de la création des consumer groups Redis."""

	@pytest.mark.asyncio
	async def test_ensure_consumer_group_calls_xgroup_create(self):
		"""_ensure_consumer_group appelle xgroup_create avec les bons args."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		stream_key = f"{STREAM_PREFIX}test"
		await consumer._ensure_consumer_group(stream_key)

		mock_redis.xgroup_create.assert_called_once_with(stream_key, CONSUMER_GROUP, id="0", mkstream=True)


# ═══════════════════════════════════════
# Traitement des messages
# ═══════════════════════════════════════


class TestEventConsumerProcessMessage:
	"""Tests du traitement individuel des messages."""

	@pytest.mark.asyncio
	async def test_process_message_success(self):
		"""Un message valide est traité avec succès et acquitté."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		callback_called = False

		async def my_handler(event: Event):
			nonlocal callback_called
			callback_called = True

		dispatcher.subscribe("test.success", my_handler, domain="test")

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		data = _build_redis_event_data(event_type="test.success")
		stream_key = f"{STREAM_PREFIX}test"
		await consumer._process_message("msg-001", data, stream_key)

		assert callback_called is True
		mock_redis.xack.assert_called_once_with(stream_key, CONSUMER_GROUP, "msg-001")

	@pytest.mark.asyncio
	async def test_process_message_no_handlers(self):
		"""Un message sans handler est acquitté sans erreur."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		data = _build_redis_event_data(event_type="unknown.event", event_id="evt-002")
		stream_key = f"{STREAM_PREFIX}test"
		await consumer._process_message("msg-002", data, stream_key)

		# Acquitté même sans handler
		mock_redis.xack.assert_called_once()

	@pytest.mark.asyncio
	async def test_process_message_deserialization_error_moves_to_dead_letter(self):
		"""Un message avec payload invalide va en dead-letter."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		data = _build_redis_event_data(
			event_type="test.broken",
			payload="NOT VALID JSON{{{",
		)
		stream_key = f"{STREAM_PREFIX}test"
		await consumer._process_message("msg-bad", data, stream_key)

		# Le message doit être déplacé en dead-letter
		mock_redis.xadd.assert_called_once()

	@pytest.mark.asyncio
	async def test_process_message_handler_failure_tracks_stats(self):
		"""Un handler qui échoue est suivi dans les stats."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		async def failing_handler(event: Event):
			raise RuntimeError("Échec simulé")

		# max_retries=3 par défaut ; retry_count=2 signifie que le 3e échec
		# dépassera max_retries et déclenchera dead-letter
		dispatcher.subscribe("test.fail", failing_handler, domain="test")

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		# retry_count=2 → après échec, retry_count=3 >= max_retries=3
		data = _build_redis_event_data(
			event_type="test.fail",
			retry_count="2",
		)

		stats = {"processed": 0, "failed": 0, "dead_lettered": 0}
		stream_key = f"{STREAM_PREFIX}test"
		await consumer._process_message("msg-fail", data, stream_key, stats)

		# L'événement a retry_count=2, après échec retry_count=3 >= max_retries=3
		# → dead_letter_on_failure=True → moved to dead letter
		assert stats["dead_lettered"] >= 1

	@pytest.mark.asyncio
	async def test_process_message_updates_processed_on_success(self):
		"""Un message traité avec succès incrémente 'processed' dans les stats."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		async def ok_handler(event: Event):
			pass

		dispatcher.subscribe("test.ok", ok_handler, domain="test")

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		data = _build_redis_event_data(event_type="test.ok")
		stats = {"processed": 0, "failed": 0, "dead_lettered": 0}
		stream_key = f"{STREAM_PREFIX}test"
		await consumer._process_message("msg-ok", data, stream_key, stats)

		assert stats["processed"] == 1


# ═══════════════════════════════════════
# Replay
# ═══════════════════════════════════════


class TestEventConsumerReplay:
	"""Tests du replay d'événements."""

	@pytest.mark.asyncio
	async def test_replay_returns_count(self):
		"""replay_events() retourne le nombre d'événements rejoués."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("test.replay", cb, domain="test")

		# Simuler des messages dans le stream
		mock_redis.xrange = AsyncMock(
			return_value=[
				(
					"msg-r1",
					_build_redis_event_data(
						event_type="test.replay",
						event_id="evt-r1",
					),
				),
			]
		)

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		replayed = await consumer.replay_events("test", from_timestamp=0.0)
		assert replayed == 1

	@pytest.mark.asyncio
	async def test_replay_with_event_type_filter(self):
		"""replay_events() filtre par event_types."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()

		async def cb(event: Event):
			pass

		dispatcher.subscribe("test.target", cb, domain="test")

		# Deux messages, un seul correspond au filtre
		mock_redis.xrange = AsyncMock(
			return_value=[
				(
					"msg-r1",
					_build_redis_event_data(
						event_type="test.target",
						event_id="evt-r1",
						correlation_id="c1",
					),
				),
				(
					"msg-r2",
					_build_redis_event_data(
						event_type="test.other",
						event_id="evt-r2",
						correlation_id="c2",
					),
				),
			]
		)

		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		replayed = await consumer.replay_events("test", from_timestamp=0.0, event_types=["test.target"])
		assert replayed == 1

	@pytest.mark.asyncio
	async def test_replay_returns_zero_on_redis_error(self):
		"""replay_events() retourne 0 si Redis échoue."""
		mock_redis = _make_mock_redis()
		mock_redis.xrange = AsyncMock(side_effect=ConnectionError("Redis down"))
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		replayed = await consumer.replay_events("test", from_timestamp=0.0)
		assert replayed == 0


# ═══════════════════════════════════════
# Propriétés
# ═══════════════════════════════════════


class TestEventConsumerProperties:
	"""Tests des propriétés du consommateur."""

	def test_running_default_false(self):
		"""running vaut False avant start()."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		assert consumer.running is False

	def test_active_stream_count_default_zero(self):
		"""active_stream_count vaut 0 avant start()."""
		mock_redis = _make_mock_redis()
		dispatcher = EventDispatcher()
		dead_letter = DeadLetterHandler(mock_redis)
		consumer = EventConsumer(mock_redis, dispatcher, dead_letter)

		assert consumer.active_stream_count == 0
