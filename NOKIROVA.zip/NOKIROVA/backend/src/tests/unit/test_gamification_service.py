"""Tests unitaires du service Gamification NOKIROVA.

Valide :
- DTO : validation Pydantic, enums, contraintes de champs
- Modèles SQLAlchemy : tables, colonnes, contraintes
- Service XP : logique d'attribution, passage de niveau
- Streaks : mise à jour d'activité, gel de série
- Badges : catégories, raretés, critères
- Événements publiés sur chaque opération
"""

from datetime import UTC, datetime

import pytest

from src.database.models.gamification import (
	GamificationAchievement,
	GamificationBadge,
	GamificationChallenge,
	GamificationLeaderboard,
	GamificationReward,
	GamificationStreak,
	GamificationUserXP,
)
from src.services.gamification.dto import (
	AchievementTypeEnum,
	BadgeCategoryEnum,
	BadgeCreateDTO,
	BadgeRarityEnum,
	BadgeUpdateDTO,
	ChallengeTypeEnum,
	LeaderboardTypeEnum,
	RewardSourceEnum,
	RewardTypeEnum,
	StreakFreezeDTO,
	StreakTypeEnum,
	UserXPResponseDTO,
	XPAdjustDTO,
)

# ── Enums Gamification ───────────────────────────


class TestGamificationEnums:
	"""Les enums de gamification doivent être complètes."""

	def test_badge_categories(self):
		assert len(BadgeCategoryEnum) == 5
		assert BadgeCategoryEnum.learning == "learning"
		assert BadgeCategoryEnum.mastery == "mastery"

	def test_badge_rarities(self):
		assert len(BadgeRarityEnum) == 4
		assert BadgeRarityEnum.common == "common"
		assert BadgeRarityEnum.legendary == "legendary"

	def test_achievement_types(self):
		assert len(AchievementTypeEnum) == 8
		assert AchievementTypeEnum.first_quiz == "first_quiz"
		assert AchievementTypeEnum.perfect_score == "perfect_score"

	def test_leaderboard_types(self):
		assert len(LeaderboardTypeEnum) == 5
		assert LeaderboardTypeEnum.global_lb == "global"

	def test_streak_types(self):
		assert len(StreakTypeEnum) == 3
		assert StreakTypeEnum.daily == "daily"
		assert StreakTypeEnum.review == "review"

	def test_challenge_types(self):
		assert len(ChallengeTypeEnum) == 4
		assert ChallengeTypeEnum.daily == "daily"
		assert ChallengeTypeEnum.special == "special"

	def test_reward_types(self):
		assert len(RewardTypeEnum) == 5
		assert RewardTypeEnum.xp == "xp"
		assert RewardTypeEnum.feature_unlock == "feature_unlock"

	def test_reward_sources(self):
		assert len(RewardSourceEnum) == 4
		assert RewardSourceEnum.challenge == "challenge"


# ── DTOs Gamification ─────────────────────────────


class TestBadgeCreateDTO:
	"""BadgeCreateDTO valide les contraintes."""

	def test_valid_badge(self):
		dto = BadgeCreateDTO(
			name="Premier Quiz",
			description="Réalise ton premier quiz",
			icon="quiz-icon",
		)
		assert dto.name == "Premier Quiz"
		assert dto.category == BadgeCategoryEnum.learning
		assert dto.rarity == BadgeRarityEnum.common
		assert dto.xp_reward == 0
		assert dto.is_secret is False

	def test_empty_name_rejected(self):
		with pytest.raises(ValueError):
			BadgeCreateDTO(name="", description="desc", icon="icon")

	def test_negative_xp_rejected(self):
		with pytest.raises(ValueError):
			BadgeCreateDTO(
				name="Badge",
				description="desc",
				icon="icon",
				xp_reward=-10,
			)

	def test_custom_rarity(self):
		dto = BadgeCreateDTO(
			name="Légende",
			description="Succès légendaire",
			icon="legend",
			rarity=BadgeRarityEnum.legendary,
			xp_reward=500,
		)
		assert dto.rarity == BadgeRarityEnum.legendary
		assert dto.xp_reward == 500


class TestBadgeUpdateDTO:
	"""BadgeUpdateDTO accepte les champs optionnels."""

	def test_all_none_by_default(self):
		dto = BadgeUpdateDTO()
		assert dto.name is None
		assert dto.is_active is None

	def test_partial_update(self):
		dto = BadgeUpdateDTO(is_active=False)
		assert dto.is_active is False


class TestXPAdjustDTO:
	"""XPAdjustDTO valide le montant et la raison."""

	def test_valid_adjust(self):
		dto = XPAdjustDTO(amount=100, reason="Correction administrative")
		assert dto.amount == 100

	def test_empty_reason_rejected(self):
		with pytest.raises(ValueError):
			XPAdjustDTO(amount=50, reason="")


class TestStreakFreezeDTO:
	"""StreakFreezeDTO a un défaut à True."""

	def test_default(self):
		dto = StreakFreezeDTO()
		assert dto.freeze is True


class TestUserXPResponseDTO:
	"""UserXPResponseDTO sérialise correctement."""

	def test_response_fields(self):
		now = datetime.now(UTC)
		resp = UserXPResponseDTO(
			id="xp-1",
			user_id="user-1",
			total_xp=500,
			level=3,
			current_level_xp=50,
			next_level_xp=225,
			weekly_xp=100,
			monthly_xp=300,
			created_at=now,
			updated_at=now,
		)
		assert resp.total_xp == 500
		assert resp.level == 3


# ── Modèles SQLAlchemy Gamification ───────────


class TestGamificationModels:
	"""Les modèles SQLAlchemy doivent avoir les bonnes tables."""

	def test_badge_table_name(self):
		assert GamificationBadge.__tablename__ == "gamification_badges"

	def test_achievement_table_name(self):
		assert GamificationAchievement.__tablename__ == "gamification_achievements"

	def test_user_xp_table_name(self):
		assert GamificationUserXP.__tablename__ == "gamification_user_xp"

	def test_streak_table_name(self):
		assert GamificationStreak.__tablename__ == "gamification_streaks"

	def test_leaderboard_table_name(self):
		assert GamificationLeaderboard.__tablename__ == "gamification_leaderboards"

	def test_challenge_table_name(self):
		assert GamificationChallenge.__tablename__ == "gamification_challenges"

	def test_reward_table_name(self):
		assert GamificationReward.__tablename__ == "gamification_rewards"


class TestGamificationBadgeModel:
	"""GamificationBadge doit avoir les colonnes requises."""

	def test_badge_required_columns(self):
		columns = {c.name for c in GamificationBadge.__table__.columns}
		required = {"name", "description", "icon", "category", "rarity", "xp_reward", "criteria"}
		assert required.issubset(columns)

	def test_badge_has_active_and_secret(self):
		columns = {c.name for c in GamificationBadge.__table__.columns}
		assert "is_active" in columns
		assert "is_secret" in columns


class TestGamificationUserXPModel:
	"""GamificationUserXP doit avoir les colonnes de suivi XP."""

	def test_xp_columns(self):
		columns = {c.name for c in GamificationUserXP.__table__.columns}
		assert "total_xp" in columns
		assert "level" in columns
		assert "current_level_xp" in columns
		assert "next_level_xp" in columns
		assert "weekly_xp" in columns
		assert "monthly_xp" in columns
		assert "xp_history" in columns


class TestGamificationStreakModel:
	"""GamificationStreak doit avoir les colonnes de série."""

	def test_streak_columns(self):
		columns = {c.name for c in GamificationStreak.__table__.columns}
		assert "current_streak" in columns
		assert "longest_streak" in columns
		assert "last_activity_date" in columns
		assert "is_frozen" in columns
		assert "freezes_available" in columns


class TestGamificationChallengeModel:
	"""GamificationChallenge doit avoir les colonnes de défi."""

	def test_challenge_columns(self):
		columns = {c.name for c in GamificationChallenge.__table__.columns}
		assert "title" in columns
		assert "objective" in columns
		assert "target_value" in columns
		assert "xp_reward" in columns
		assert "participant_count" in columns
		assert "completion_count" in columns


# ── Logique métier XP (mockée) ──────────────


class TestXPLevelUpLogic:
	"""La logique de passage de niveau doit fonctionner correctement."""

	def test_level_up_threshold(self):
		"""next_level_xp croît de 1.5x à chaque niveau."""
		initial_next = 100
		current_xp = 0
		level = 1

		# Simuler l'accumulation de 150 XP
		current_xp += 150
		while current_xp >= initial_next:
			current_xp -= initial_next
			level += 1
			initial_next = int(initial_next * 1.5)

		assert level == 2
		assert current_xp == 50  # 150 - 100
		assert initial_next == 150  # 100 * 1.5

	def test_multiple_level_ups(self):
		"""On peut monter plusieurs niveaux d'un coup."""
		next_xp = 100
		level = 1
		current = 0
		current += 500

		while current >= next_xp:
			current -= next_xp
			level += 1
			next_xp = int(next_xp * 1.5)

		# Niveau 1→2 (100 XP), 2→3 (150 XP), 3→4 (225 XP) = 475 XP
		# Reste 25 XP, niveau 4
		assert level == 4
		assert current == 25

	def test_no_level_up_if_insufficient(self):
		"""Pas de passage de niveau si XP insuffisant."""
		next_xp = 100
		level = 1
		current = 50

		while current >= next_xp:
			current -= next_xp
			level += 1
			next_xp = int(next_xp * 1.5)

		assert level == 1
