"""Tests unitaires du service Document NOKIROVA.

Valide :
- DTO : validation Pydantic, enums, contraintes de champs
- Convertisseurs : model_to_response, compute_word_count
- CRUD (logique métier mockée) : création, lecture, suppression
- Contrôle d'accès : propriétaire vs. collaborateur vs. inconnu
- Événements publiés sur chaque opération
"""

from datetime import UTC, datetime

import pytest

from src.services.document.dto import (
	CollaboratorRoleEnum,
	DocumentCreateDTO,
	DocumentFolderCreateDTO,
	DocumentResponseDTO,
	DocumentStatusEnum,
	DocumentTypeEnum,
	DocumentUpdateDTO,
	DocumentVersionCreateDTO,
	ExportFormatEnum,
	SharePermissionEnum,
)
from src.services.document.service_converters import (
	CACHE_NS,
	compute_word_count,
)

# ── DTOs ──────────────────────────────────────────


class TestDocumentEnums:
	"""Les enums Document doivent être complètes."""

	def test_document_statuses(self):
		assert len(DocumentStatusEnum) == 4
		assert DocumentStatusEnum.draft == "draft"
		assert DocumentStatusEnum.published == "published"

	def test_document_types(self):
		assert len(DocumentTypeEnum) == 5
		assert DocumentTypeEnum.note == "note"
		assert DocumentTypeEnum.paper == "paper"

	def test_share_permissions(self):
		assert len(SharePermissionEnum) == 3
		assert SharePermissionEnum.view == "view"
		assert SharePermissionEnum.edit == "edit"

	def test_collaborator_roles(self):
		assert len(CollaboratorRoleEnum) == 4
		assert CollaboratorRoleEnum.owner == "owner"

	def test_export_formats(self):
		assert len(ExportFormatEnum) == 5
		assert ExportFormatEnum.pdf == "pdf"
		assert ExportFormatEnum.md == "md"


class TestDocumentCreateDTO:
	"""DocumentCreateDTO doit valider les contraintes."""

	def test_valid_creation(self):
		dto = DocumentCreateDTO(title="Mon document")
		assert dto.title == "Mon document"
		assert dto.doc_type == DocumentTypeEnum.note
		assert dto.language == "fr"
		assert dto.is_template is False
		assert dto.is_public is False
		assert dto.status == DocumentStatusEnum.draft

	def test_empty_title_rejected(self):
		"""Un titre vide est rejeté."""
		with pytest.raises(ValueError):
			DocumentCreateDTO(title="")

	def test_title_too_long_rejected(self):
		"""Un titre > 500 caractères est rejeté."""
		with pytest.raises(ValueError):
			DocumentCreateDTO(title="x" * 501)

	def test_custom_doc_type(self):
		dto = DocumentCreateDTO(
			title="Rapport",
			doc_type=DocumentTypeEnum.report,
		)
		assert dto.doc_type == DocumentTypeEnum.report

	def test_custom_language(self):
		dto = DocumentCreateDTO(title="Doc", language="en")
		assert dto.language == "en"


class TestDocumentUpdateDTO:
	"""DocumentUpdateDTO doit accepter les champs optionnels."""

	def test_all_none_by_default(self):
		dto = DocumentUpdateDTO()
		assert dto.title is None
		assert dto.content is None
		assert dto.status is None

	def test_partial_update(self):
		dto = DocumentUpdateDTO(title="Nouveau titre")
		assert dto.title == "Nouveau titre"
		assert dto.content is None


class TestDocumentResponseDTO:
	"""DocumentResponseDTO doit sérialiser correctement."""

	def test_response_fields(self):
		now = datetime.now(UTC)
		resp = DocumentResponseDTO(
			id="abc-123",
			title="Test",
			owner_id="user-1",
			word_count=100,
			created_at=now,
			updated_at=now,
		)
		assert resp.id == "abc-123"
		assert resp.word_count == 100


# ── Convertisseurs ────────────────────────────────


class TestComputeWordCount:
	"""compute_word_count doit compter correctement."""

	def test_empty_text(self):
		assert compute_word_count("") == 0

	def test_none_text(self):
		assert compute_word_count(None) == 0  # type: ignore

	def test_single_word(self):
		assert compute_word_count("Bonjour") == 1

	def test_multiple_words(self):
		assert compute_word_count("Bonjour le monde") == 3

	def test_extra_spaces(self):
		assert compute_word_count("  Bonjour   le   monde  ") == 3

	def test_french_text(self):
		assert compute_word_count("L'éducation est la clé du succès") == 6

	def test_long_text(self):
		text = " ".join(["mot"] * 500)
		assert compute_word_count(text) == 500


class TestCacheNamespace:
	"""Le namespace de cache Document est correct."""

	def test_cache_ns(self):
		assert CACHE_NS == "documents"


# ── Folder DTO ────────────────────────────────────


class TestDocumentFolderCreateDTO:
	"""DocumentFolderCreateDTO valide le nom."""

	def test_valid_folder(self):
		dto = DocumentFolderCreateDTO(name="Mes cours")
		assert dto.name == "Mes cours"
		assert dto.sort_order == 0

	def test_empty_name_rejected(self):
		with pytest.raises(ValueError):
			DocumentFolderCreateDTO(name="")

	def test_name_too_long_rejected(self):
		with pytest.raises(ValueError):
			DocumentFolderCreateDTO(name="x" * 201)


# ── Version DTO ─────────────────────────────────


class TestDocumentVersionCreateDTO:
	"""DocumentVersionCreateDTO accepte le contenu optionnel."""

	def test_default_values(self):
		dto = DocumentVersionCreateDTO()
		assert dto.content is None
		assert dto.change_summary is None

	def test_with_content(self):
		dto = DocumentVersionCreateDTO(
			content="Nouvelle version",
			change_summary="Mise à jour majeure",
		)
		assert dto.content == "Nouvelle version"
		assert dto.change_summary == "Mise à jour majeure"
