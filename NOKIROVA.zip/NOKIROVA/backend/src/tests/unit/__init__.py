"""NOKIROVA — Tests unitaires.

Couverture par module du backend.
"""
