"""
NOKIROVA — Point d'entrée principal FastAPI

Configuration complète :
- Lifespan (startup/shutdown)
- Middleware (CORS, logging, rate-limiting, tenant)
- Routers (22 domaines + SIO + workflows + health)
- WebSocket manager
- Event Bus initialisation
- Workers Celery
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from src.api.router import api_router
from src.core.config import get_settings
from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.core.logging import logger

settings = get_settings()

# ─── Lifespan ──────────────────────────────────────────────────────────────────


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
	"""Cycle de vie de l'application NOKIROVA."""
	# ── Startup ──────────────────────────────────────────────────────────
	logger.info("🚀 NOKIROVA — Démarrage...")

	try:
		from src.events.bus import event_bus
		from src.events.handlers import register_all_handlers

		await event_bus.connect()
		logger.info("✅ Event Bus connecté")
		register_all_handlers()
		logger.info("✅ Handlers d'événements enregistrés")
		asyncio.create_task(event_bus.start_consuming())
		logger.info("✅ Event Bus consumers actifs")
	except WORKER_EXCEPTIONS as e:
		logger.warning(f"⚠️ Event Bus non disponible : {e}")

	try:
		from src.workflows.definitions import register_builtin_workflows

		register_builtin_workflows()
		logger.info("✅ Workflows prédéfinis enregistrés")
	except WORKER_EXCEPTIONS as e:
		logger.warning(f"⚠️ Workflows non disponibles : {e}")

	try:
		logger.info("✅ Orchestrateur SIO initialisé")
	except WORKER_EXCEPTIONS as e:
		logger.warning(f"⚠️ Orchestrateur SIO non disponible : {e}")

	try:
		from src.self_healing.engine import self_healing_engine

		await self_healing_engine.start()
		logger.info("✅ Moteur de Self-Healing démarré")
	except WORKER_EXCEPTIONS as e:
		logger.warning(f"⚠️ Self-Healing non disponible : {e}")

	try:
		from src.self_healing.handlers import register_self_healing_handlers

		await register_self_healing_handlers()
		logger.info("✅ Handlers Self-Healing Event Bus enregistrés")
	except WORKER_EXCEPTIONS as e:
		logger.warning(f"⚠️ Handlers Self-Healing non enregistrés : {e}")

	logger.info("🎉 NOKIROVA est prêt !")

	yield

	# ── Shutdown ─────────────────────────────────────────────────────────
	logger.info("🛑 NOKIROVA — Arrêt...")
	try:
		from src.self_healing.engine import self_healing_engine

		await self_healing_engine.stop()
		logger.info("✅ Moteur de Self-Healing arrêté")
	except WORKER_EXCEPTIONS:
		pass
	try:
		from src.events.bus import event_bus

		await event_bus.disconnect()
		logger.info("✅ Event Bus déconnecté")
	except WORKER_EXCEPTIONS:
		pass
	logger.info("👋 NOKIROVA est arrêté")


# ─── Application FastAPI ──────────────────────────────────────────────────────

app = FastAPI(
	title="NOKIROVA API",
	description="Écosystème éducatif IA — API v1",
	version="1.0.0",
	docs_url="/api/docs",
	redoc_url="/api/redoc",
	openapi_url="/api/openapi.json",
	lifespan=lifespan,
)


# ─── Middleware ────────────────────────────────────────────────────────────────

# CORS — utilise settings.cors.origins_list (propriété calculée depuis CORSSettings)
app.add_middleware(
	CORSMiddleware,
	allow_origins=settings.cors.origins_list,
	allow_credentials=settings.cors.allow_credentials,
	allow_methods=["*"],
	allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)

# ── Confidentialité (BIBLE #8) — en-têtes de sécurité + cookie consent ──
try:
	from src.middleware.privacy import PrivacyMiddleware

	app.add_middleware(PrivacyMiddleware)
	logger.info("✅ PrivacyMiddleware activé (BIBLE #8 : Confidentialité)")
except ImportError:
	logger.warning("⚠️ PrivacyMiddleware non disponible")


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
	"""Log chaque requête avec durée."""
	import time

	start = time.monotonic()
	response: Response = await call_next(request)
	duration_ms = (time.monotonic() - start) * 1000
	logger.info(f"{request.method} {request.url.path} → {response.status_code} ({duration_ms:.0f}ms)")
	response.headers["X-Process-Time-Ms"] = str(int(duration_ms))
	return response


# ─── Routers ──────────────────────────────────────────────────────────────────

app.include_router(api_router)

try:
	from src.ai.orchestrator.router import router as sio_router

	app.include_router(sio_router, prefix="/api/v1/sio", tags=["SIO — Orchestrateur IA"])
except ImportError:
	pass

try:
	from src.workflows.engine.router import workflow_router

	app.include_router(workflow_router, prefix="/api/v1/workflows", tags=["Workflows"])
except ImportError:
	pass


# ─── Routes racine et santé ───────────────────────────────────────────────────


@app.get("/", tags=["Racine"])
async def root():
	return {
		"name": "NOKIROVA API",
		"version": "1.0.0",
		"status": "operational",
		"docs": "/api/docs",
	}


@app.get("/health", tags=["Santé"])
@app.get("/sante", tags=["Santé"], include_in_schema=False)
async def health():
	"""Vérification de l'état de l'API."""
	return {
		"status": "healthy",
		"service": "NOKIROVA API",
		"version": "1.0.0",
	}
