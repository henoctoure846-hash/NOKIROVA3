"""
NOKIROVA — Configuration centrale du Backend

Toute la configuration est chargée depuis les variables d'environnement.
Aucune valeur en dur. Aucun secret dans le code.

Principe : Provider-agnostic — chaque service peut changer de fournisseur
sans modifier le code métier.

Compatible Pydantic v2 + pydantic-settings v2.
"""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# ═══════════════════════════════════════════════════════════════════════════════
# Sous-configurations
# ═══════════════════════════════════════════════════════════════════════════════


class DatabaseSettings(BaseSettings):
	"""Configuration PostgreSQL"""

	model_config = SettingsConfigDict(env_prefix="DATABASE_", extra="ignore")

	host: str = Field(default="localhost")
	port: int = Field(default=5432)
	name: str = Field(default="nokirova_db")
	user: str = Field(default="nokirova_admin")
	password: str = Field(default="")
	pool_size: int = Field(default=5, description="Taille du pool de connexions")
	max_overflow: int = Field(default=10, description="Overflow max du pool")

	@property
	def url(self) -> str:
		"""URL async (asyncpg) pour SQLAlchemy."""
		return f"postgresql+asyncpg://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"

	@property
	def url_sync(self) -> str:
		"""URL synchrone (psycopg2) pour Alembic."""
		return f"postgresql+psycopg2://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"


class RedisSettings(BaseSettings):
	"""Configuration Redis"""

	model_config = SettingsConfigDict(env_prefix="REDIS_", extra="ignore")

	host: str = Field(default="localhost")
	port: int = Field(default=6379)
	password: str | None = Field(default=None)
	db: int = Field(default=0)

	@property
	def url(self) -> str:
		"""URL Redis complète."""
		auth = f":{self.password}@" if self.password else ""
		return f"redis://{auth}{self.host}:{self.port}/{self.db}"


class JWTSettings(BaseSettings):
	"""Configuration JWT"""

	model_config = SettingsConfigDict(env_prefix="JWT_", extra="ignore")

	secret: str = Field(default="")
	algorithm: str = Field(default="HS256")
	access_token_expire_minutes: int = Field(default=30)
	refresh_token_expire_days: int = Field(default=7)


class AISettings(BaseSettings):
	"""Configuration IA — Provider-agnostic"""

	model_config = SettingsConfigDict(env_prefix="AI_", extra="ignore")

	provider: str = Field(default="openai")
	api_key: str = Field(default="")
	model_default: str = Field(default="gpt-4")
	model_vision: str = Field(default="gpt-4-vision-preview")
	model_embeddings: str = Field(default="text-embedding-3-small")
	max_tokens: int = Field(default=4096)
	temperature: float = Field(default=0.7)


class StorageSettings(BaseSettings):
	"""Configuration Stockage — Provider-agnostic"""

	model_config = SettingsConfigDict(env_prefix="STORAGE_", extra="ignore")

	provider: str = Field(default="local")
	path: str = Field(default="./storage")
	key: str | None = Field(default=None)
	secret: str | None = Field(default=None)
	bucket: str | None = Field(default=None)
	region: str | None = Field(default=None)


class OCRSettings(BaseSettings):
	"""Configuration OCR"""

	model_config = SettingsConfigDict(env_prefix="OCR_", extra="ignore")

	engine: str = Field(default="tesseract")
	language: str = Field(default="fra+eng")


class VectorDBSettings(BaseSettings):
	"""Configuration Recherche Vectorielle"""

	model_config = SettingsConfigDict(env_prefix="VECTOR_", extra="ignore")

	db_provider: str = Field(default="pgvector")
	dimension: int = Field(default=1536)


class MailSettings(BaseSettings):
	"""Configuration Mail"""

	model_config = SettingsConfigDict(env_prefix="MAIL_", extra="ignore")

	provider: str = Field(default="smtp")
	host: str = Field(default="smtp.gmail.com")
	port: int = Field(default=587)
	user: str | None = Field(default=None)
	password: str | None = Field(default=None)
	from_email: str = Field(default="noreply@nokirova.com")


class CORSSettings(BaseSettings):
	"""Configuration CORS"""

	model_config = SettingsConfigDict(env_prefix="CORS_", extra="ignore")

	origins: str = Field(
		default="http://localhost:3000,http://localhost:8000",
		description="Origines CORS séparées par des virgules",
	)
	allow_credentials: bool = Field(default=True)

	@property
	def origins_list(self) -> list[str]:
		"""Origines CORS sous forme de liste."""
		return [o.strip() for o in self.origins.split(",") if o.strip()]


class RateLimitSettings(BaseSettings):
	"""Configuration Rate Limiting"""

	model_config = SettingsConfigDict(env_prefix="RATE_LIMIT_", extra="ignore")

	per_minute: int = Field(default=60)
	auth_per_minute: int = Field(default=10)


class BackupSettings(BaseSettings):
	"""Configuration Sauvegarde"""

	model_config = SettingsConfigDict(env_prefix="BACKUP_", extra="ignore")

	local_path: str = Field(default="./backups/local")
	cloud_enabled: bool = Field(default=False)
	encryption_key: str | None = Field(default=None)
	retention_days: int = Field(default=30)


# ═══════════════════════════════════════════════════════════════════════════════
# Configuration globale
# ═══════════════════════════════════════════════════════════════════════════════


class AppSettings(BaseSettings):
	"""Configuration globale NOKIROVA"""

	model_config = SettingsConfigDict(
		env_file=".env",
		env_file_encoding="utf-8",
		extra="ignore",
	)

	# Identité
	project_name: str = Field(default="NOKIROVA", validation_alias="PROJECT_NAME")
	environment: str = Field(default="development", validation_alias="ENVIRONMENT")
	version: str = Field(default="0.1.0", validation_alias="VERSION")
	debug: bool = Field(default=True, validation_alias="DEBUG")

	# Event Bus
	event_bus_max_stream_length: int = Field(
		default=10000,
		validation_alias="EVENT_BUS_MAX_STREAM_LENGTH",
		description="Longueur max des streams Redis pour l'Event Bus",
	)

	# Chiffrement au repos — Principe BIBLE #8 : Confidentialité
	encryption_key: str = Field(
		default="",
		validation_alias="ENCRYPTION_KEY",
		description="Clé secrète pour le chiffrement Fernet au repos (PBKDF2 dérivé)",
	)

	# Sous-configurations — instanciées à la création (chargées depuis env vars)
	database: DatabaseSettings = Field(default_factory=DatabaseSettings)
	redis: RedisSettings = Field(default_factory=RedisSettings)
	jwt: JWTSettings = Field(default_factory=JWTSettings)
	ai: AISettings = Field(default_factory=AISettings)
	storage: StorageSettings = Field(default_factory=StorageSettings)
	ocr: OCRSettings = Field(default_factory=OCRSettings)
	vector_db: VectorDBSettings = Field(default_factory=VectorDBSettings)
	mail: MailSettings = Field(default_factory=MailSettings)
	cors: CORSSettings = Field(default_factory=CORSSettings)
	rate_limit: RateLimitSettings = Field(default_factory=RateLimitSettings)
	backup: BackupSettings = Field(default_factory=BackupSettings)


@lru_cache
def get_settings() -> AppSettings:
	"""Cache la configuration — chargée une seule fois."""
	return AppSettings()  # type: ignore[call-arg]


# Instance singleton — accessible directement via `from src.core.config import settings`
settings: AppSettings = get_settings()
