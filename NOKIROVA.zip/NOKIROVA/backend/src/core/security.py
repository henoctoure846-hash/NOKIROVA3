"""
NOKIROVA — Sécurité centrale

Gère : JWT, hachage, vérification de mot de passe, 2FA, permissions.

Principe : Aucune donnée sensible en clair. Jamais.
"""

from datetime import UTC, datetime, timedelta
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

from .config import get_settings

# ── Hachage des mots de passe ──────────────────────────────────────
pwd_context = CryptContext(schemes=["argon2", "bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
	"""Hache un mot de passe avec Argon2id (ou bcrypt en fallback)"""
	return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
	"""Vérifie un mot de passe contre son hachage"""
	return pwd_context.verify(plain_password, hashed_password)


# ── JWT Tokens ─────────────────────────────────────────────────────


class TokenData(BaseModel):
	"""Données encodées dans le token JWT"""

	user_id: str
	role: str
	exp: datetime | None = None
	iat: datetime | None = None
	jti: str | None = None  # ID unique pour révocation


def create_access_token(data: dict[str, Any]) -> str:
	"""Crée un token d'accès JWT"""
	settings = get_settings()
	to_encode = data.copy()
	now = datetime.now(UTC)
	expire = now + timedelta(minutes=settings.jwt.access_token_expire_minutes)
	to_encode.update(
		{
			"exp": expire,
			"iat": now,
			"jti": __import__("uuid").uuid4().hex,
		}
	)
	return jwt.encode(to_encode, settings.jwt.secret, algorithm=settings.jwt.algorithm)


def create_refresh_token(data: dict[str, Any]) -> str:
	"""Crée un token de rafraîchissement JWT"""
	settings = get_settings()
	to_encode = data.copy()
	now = datetime.now(UTC)
	expire = now + timedelta(days=settings.jwt.refresh_token_expire_days)
	to_encode.update(
		{
			"exp": expire,
			"iat": now,
			"type": "refresh",
			"jti": __import__("uuid").uuid4().hex,
		}
	)
	return jwt.encode(to_encode, settings.jwt.secret, algorithm=settings.jwt.algorithm)


def decode_token(token: str) -> TokenData:
	"""Décode et vérifie un token JWT"""
	settings = get_settings()
	try:
		payload = jwt.decode(token, settings.jwt.secret, algorithms=[settings.jwt.algorithm])
		return TokenData(
			user_id=payload.get("sub", ""),
			role=payload.get("role", "student"),
			exp=payload.get("exp"),
			iat=payload.get("iat"),
			jti=payload.get("jti"),
		)
	except JWTError as e:
		raise InvalidTokenError(f"Token invalide : {e}") from e


def decode_access_token(token: str) -> dict[str, Any] | None:
	"""Décode un token d'accès JWT et retourne le payload brut (dict).

	Retourne None si le token est invalide ou expiré.
	Utilisé par les dépendances FastAPI (api/deps.py).
	"""
	settings = get_settings()
	try:
		payload = jwt.decode(token, settings.jwt.secret, algorithms=[settings.jwt.algorithm])
		return payload
	except JWTError:
		return None


class InvalidTokenError(Exception):
	"""Erreur de token JWT invalide"""

	pass


# ── Vérification 2FA (TOTP) ──────────────────────────────────────


def generate_totp_secret() -> str:
	"""Génère un secret TOTP pour l'authentification double facteur"""
	import pyotp

	return pyotp.random_base32()


def verify_totp(secret: str, code: str) -> bool:
	"""Vérifie un code TOTP"""
	import pyotp

	totp = pyotp.TOTP(secret)
	return totp.verify(code, valid_window=1)


def generate_totp_uri(secret: str, email: str) -> str:
	"""Génère l'URI TOTP pour les applications d'authentification"""
	import pyotp

	totp = pyotp.TOTP(secret)
	return totp.provisioning_uri(name=email, issuer_name="NOKIROVA")


# ── Rôles et Permissions ─────────────────────────────────────────


class Role:
	"""Rôles NOKIROVA"""

	STUDENT = "student"
	TEACHER = "teacher"
	CREATOR = "creator"
	DEVELOPER = "developer"
	ADMIN = "admin"
	SUPER_ADMIN = "super_admin"


class Permission:
	"""Permissions NOKIROVA"""

	# Documents
	DOCUMENT_READ = "document:read"
	DOCUMENT_WRITE = "document:write"
	DOCUMENT_DELETE = "document:delete"
	DOCUMENT_SHARE = "document:share"
	DOCUMENT_EXPORT = "document:export"
	DOCUMENT_IMPORT = "document:import"

	# Apprentissage
	COURSE_READ = "course:read"
	COURSE_WRITE = "course:write"
	QUIZ_TAKE = "quiz:take"
	QUIZ_CREATE = "quiz:create"
	EXAM_TAKE = "exam:take"
	EXAM_CREATE = "exam:create"
	FLASHCARD_CREATE = "flashcard:create"
	FLASHCARD_DELETE = "flashcard:delete"

	# Communauté
	COMMUNITY_POST = "community:post"
	COMMUNITY_MODERATE = "community:moderate"
	GROUP_CREATE = "group:create"
	GROUP_MANAGE = "group:manage"

	# IA
	AI_CHAT = "ai:chat"
	AI_ADVANCED = "ai:advanced"
	AI_ADMIN = "ai:admin"

	# Système
	PLUGIN_INSTALL = "plugin:install"
	PLUGIN_MANAGE = "plugin:manage"
	SETTINGS_READ = "settings:read"
	SETTINGS_WRITE = "settings:write"
	ADMIN_ACCESS = "admin:access"
	USER_MANAGE = "user:manage"
	ANALYTICS_READ = "analytics:read"
	BACKUP_MANAGE = "backup:manage"


# ── Matrice Rôle → Permissions ───────────────────────────────────

ROLE_PERMISSIONS: dict[str, list] = {
	Role.STUDENT: [
		Permission.DOCUMENT_READ,
		Permission.DOCUMENT_WRITE,
		Permission.DOCUMENT_EXPORT,
		Permission.COURSE_READ,
		Permission.QUIZ_TAKE,
		Permission.EXAM_TAKE,
		Permission.FLASHCARD_CREATE,
		Permission.FLASHCARD_DELETE,
		Permission.COMMUNITY_POST,
		Permission.GROUP_CREATE,
		Permission.AI_CHAT,
		Permission.SETTINGS_READ,
	],
	Role.TEACHER: [
		# Hérite de STUDENT + permissions enseignant
		Permission.COURSE_WRITE,
		Permission.QUIZ_CREATE,
		Permission.EXAM_CREATE,
		Permission.COMMUNITY_MODERATE,
		Permission.AI_ADVANCED,
		Permission.ANALYTICS_READ,
	],
	Role.CREATOR: [
		# Hérite de STUDENT + créateur de contenu
		Permission.DOCUMENT_SHARE,
		Permission.DOCUMENT_IMPORT,
		Permission.COURSE_WRITE,
		Permission.PLUGIN_INSTALL,
	],
	Role.DEVELOPER: [
		# Accès technique
		Permission.PLUGIN_INSTALL,
		Permission.PLUGIN_MANAGE,
		Permission.AI_ADMIN,
		Permission.ANALYTICS_READ,
		Permission.ADMIN_ACCESS,
	],
	Role.ADMIN: [
		# Toutes les permissions sauf super_admin
		Permission.USER_MANAGE,
		Permission.BACKUP_MANAGE,
		Permission.SETTINGS_WRITE,
		Permission.COMMUNITY_MODERATE,
	],
	Role.SUPER_ADMIN: [
		# Toutes les permissions
		"*",
	],
}


def has_permission(role: str, permission: str) -> bool:
	"""Vérifie si un rôle possède une permission"""
	perms = ROLE_PERMISSIONS.get(role, [])
	if "*" in perms:
		return True
	return permission in perms


def get_role_permissions(role: str) -> list:
	"""Retourne toutes les permissions d'un rôle"""
	return ROLE_PERMISSIONS.get(role, [])
