"""
NOKIROVA — Système de journalisation centralisé

Chaque événement est enregistré avec contexte.
Règle : Aucun événement sans journal.
"""

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from .config import get_settings


class NOKIROVAFormatter(logging.Formatter):
	"""Formateur JSON structuré pour les logs NOKIROVA"""

	def format(self, record: logging.LogRecord) -> str:
		log_data = {
			"timestamp": datetime.now(UTC).isoformat(),
			"level": record.levelname,
			"logger": record.name,
			"message": record.getMessage(),
			"module": record.module,
			"function": record.funcName,
			"line": record.lineno,
		}

		# Ajouter le contexte personnalisé
		if hasattr(record, "nokirova_context"):
			log_data["context"] = record.nokirova_context

		# Ajouter les erreurs
		if record.exc_info and record.exc_info[1]:
			log_data["error"] = {
				"type": record.exc_info[0].__name__ if record.exc_info[0] else "Unknown",
				"message": str(record.exc_info[1]),
			}

		return json.dumps(log_data, ensure_ascii=False)


class NOKIROVALogger:
	"""Logger NOKIROVA avec contexte enrichi"""

	def __init__(self, name: str = "nokirova"):
		self.logger = logging.getLogger(name)
		self._configure()

	def _configure(self):
		"""Configure le logger selon l'environnement"""
		settings = get_settings()

		if not self.logger.handlers:
			handler = logging.StreamHandler(sys.stdout)
			handler.setFormatter(NOKIROVAFormatter())
			self.logger.addHandler(handler)

		level = getattr(logging, settings.environment.upper() == "PRODUCTION" and "WARNING" or "INFO")
		self.logger.setLevel(level)

	def _log(self, level: int, message: str, **context: Any):
		"""Log avec contexte NOKIROVA"""
		record = self.logger.makeRecord(self.logger.name, level, "", 0, message, (), None)
		record.nokirova_context = context if context else None
		self.logger.handle(record)

	def info(self, message: str, **context: Any):
		self._log(logging.INFO, message, **context)

	def warning(self, message: str, **context: Any):
		self._log(logging.WARNING, message, **context)

	def error(self, message: str, **context: Any):
		self._log(logging.ERROR, message, **context)

	def critical(self, message: str, **context: Any):
		self._log(logging.CRITICAL, message, **context)

	def debug(self, message: str, **context: Any):
		self._log(logging.DEBUG, message, **context)

	def api(self, method: str, path: str, status: int, duration_ms: float, **extra: Any):
		"""Journalise un appel API"""
		self.info("API Call", method=method, path=path, status=status, duration_ms=duration_ms, **extra)

	def auth(self, action: str, user_id: str | None = None, **extra: Any):
		"""Journalise un événement d'authentification"""
		self.info("Auth Event", action=action, user_id=user_id, **extra)

	def ai(self, agent: str, task: str, duration_ms: float, **extra: Any):
		"""Journalise un événement IA"""
		self.info("AI Event", agent=agent, task=task, duration_ms=duration_ms, **extra)

	def workflow(self, workflow_name: str, step: str, **extra: Any):
		"""Journalise une étape de workflow"""
		self.info("Workflow Step", workflow=workflow_name, step=step, **extra)

	def error_detail(self, error_code: str, cause: str, solution: str, **extra: Any):
		"""Journalise une erreur avec code, cause et solution"""
		self.error("Error Detail", error_code=error_code, cause=cause, solution=solution, **extra)


def get_logger(name: str = "nokirova") -> NOKIROVALogger:
	"""Crée ou récupère un logger NOKIROVA pour le module donné.

	Utilisé partout dans le projet pour obtenir un logger contextualisé.
	"""
	return NOKIROVALogger(name)


# Instance globale
logger = NOKIROVALogger("nokirova")
