"""
NOKIROVA — Exceptions spécifiques pour les sondes de santé

Permettent de remplacer les except Exception génériques dans les
endpoints de santé par des exceptions ciblées, conformément au
principe BIBLE #4 (Élégance) — attraper l'exception la plus
spécifique possible.

Principe BIBLE #10 Fiabilité : monitoring précis, erreurs qualifiées.
"""

import asyncio

from redis.exceptions import ConnectionError as RedisConnectionError
from redis.exceptions import RedisError
from sqlalchemy.exc import DBAPIError, IntegrityError, InterfaceError, OperationalError

# ── Tuples d'exceptions pour chaque catégorie de sonde ──────────

# Sonde base de données PostgreSQL
DB_EXCEPTIONS = (OperationalError, InterfaceError, DBAPIError, OSError)

# Sonde Redis
REDIS_EXCEPTIONS = (RedisError, RedisConnectionError, asyncio.TimeoutError, OSError)

# Sonde stockage fichier
STORAGE_EXCEPTIONS = (OSError, ValueError, PermissionError)

# Sonde IA / configuration
AI_CONFIG_EXCEPTIONS = (ValueError, AttributeError, ImportError, KeyError)

# Sonde Event Bus
EVENT_BUS_EXCEPTIONS = (RedisError, asyncio.TimeoutError, RuntimeError, ConnectionError, ValueError)

# Sonde Celery / workers
WORKER_EXCEPTIONS = (OSError, ConnectionError, TimeoutError, ImportError, RuntimeError)

# Sonde système (psutil, OS)
SYSTEM_EXCEPTIONS = (OSError, ImportError, ValueError, PermissionError)

# Opération base de données générique (privacy, services)
DB_OPERATION_EXCEPTIONS = (OperationalError, InterfaceError, DBAPIError, IntegrityError)

# Opération Redis cache
CACHE_EXCEPTIONS = (RedisError, RedisConnectionError, asyncio.TimeoutError, OSError, ValueError)

# Self-healing / orchestration
HEALING_EXCEPTIONS = (RuntimeError, ValueError, TimeoutError, ConnectionError, OSError)


# Agent / orchestration IA
AGENT_EXCEPTIONS = (RuntimeError, ValueError, asyncio.TimeoutError, ConnectionError, OSError)
