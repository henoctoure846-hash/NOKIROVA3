"""
NOKIROVA — Service de chiffrement au repos

Chiffrement symétrique Fernet (AES-128-CBC + HMAC-SHA256) pour
les données sensibles au repos : clés API, PII, secrets.

Principe BIBLE #8 Confidentialité : toute donnée sensible
doit être chiffrée au repos. Aucune clé en dur dans le code.

Fonctionnalités :
- encrypt(plaintext) → token Fernet
- decrypt(token) → plaintext
- rotate_key(old_key, new_key) → re-chiffrement par lot
- mask_token(token) → "••••••••" pour les réponses API
- encrypt_dict(data, champs) → chiffre uniquement les champs PII d'un dict
- decrypt_dict(data, champs) → déchiffre les champs PII d'un dict

Usage :
	from src.core.encryption import encryption_service

	# Chiffrer
	token = encryption_service.encrypt("sk-abc123")

	# Déchiffrer
	plaintext = encryption_service.decrypt(token)

	# Rotation de clé
	new_tokens = await encryption_service.rotate_key_batch(old_key, tokens)

	# Masquer pour réponse API
	masked = encryption_service.mask_token(token)  # "••••••••"
"""

from __future__ import annotations

import base64
import json
import os

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from src.core.logging import get_logger

logger = get_logger(__name__)


# ─── Constantes ──────────────────────────────────────────────────────────────

MASQUE_DEFAUT = "••••••••"
SALT_FIXE = b"NOKIROVA_FERNET_SALT_V1"  # Sel pour dérivation de clé (fixe pour réversibilité)
ITERATIONS_KDF = 480_000  # Recommandation OWASP 2023 pour PBKDF2


# ─── Fonctions utilitaires ────────────────────────────────────────────────────


def _derive_fernet_key(secret: str) -> bytes:
	"""
	Dérive une clé Fernet valide (32 bytes, URL-safe base64)
	à partir d'un secret lisible (env var).

	Utilise PBKDF2-HMAC-SHA256 avec un sel fixe pour garantir
	que le même secret produit toujours la même clé Fernet.

	Args:
		secret: Chaîne secrète depuis la configuration (ENCRYPTION_KEY)

	Returns:
		Clé Fernet encodée en base64 URL-safe (32 bytes)
	"""
	kdf = PBKDF2HMAC(
		algorithm=hashes.SHA256(),
		length=32,
		salt=SALT_FIXE,
		iterations=ITERATIONS_KDF,
		backend=default_backend(),
	)
	cle_derivee = kdf.derive(secret.encode("utf-8"))
	return base64.urlsafe_b64encode(cle_derivee)


# ─── Service de chiffrement ────────────────────────────────────────────────────


class EncryptionService:
	"""
	Service singleton de chiffrement au repos NOKIROVA.

	Utilise Fernet (AES-128-CBC + HMAC-SHA256) via la bibliothèque
	cryptography. La clé est dérivée depuis ENCRYPTION_KEY via PBKDF2.

	Principe BIBLE #8 : Confidentialité — toute donnée sensible
	doit être chiffrée au repos. Aucune exception.
	"""

	def __init__(self, encryption_key: str) -> None:
		"""
		Initialise le service avec la clé de chiffrement.

		Args:
			encryption_key: Clé secrète depuis la configuration (ENCRYPTION_KEY)

		Raises:
			ValueError: Si la clé est vide ou absente
		"""
		if not encryption_key:
			raise ValueError(
				"ENCRYPTION_KEY est vide ou absente. "
				"Définissez la variable d'environnement ENCRYPTION_KEY "
				"avec une chaîne secrète d'au moins 32 caractères."
			)

		self._cle_fernet = _derive_fernet_key(encryption_key)
		self._fernet = Fernet(self._cle_fernet)
		logger.info("Service de chiffrement initialisé avec succès")

	def encrypt(self, plaintext: str) -> str:
		"""
		Chiffre une chaîne en clair et retourne le token Fernet encodé.

		Args:
			plaintext: Chaîne en clair à chiffrer

		Returns:
			Token Fernet encodé en base64 (chaîne)

		Raises:
			ValueError: Si le plaintext est vide
		"""
		if not plaintext:
			raise ValueError("Impossible de chiffrer une chaîne vide")

		token = self._fernet.encrypt(plaintext.encode("utf-8"))
		return token.decode("utf-8")

	def decrypt(self, token: str) -> str:
		"""
		Déchiffre un token Fernet et retourne la chaîne en clair.

		Args:
			token: Token Fernet encodé en base64 (chaîne)

		Returns:
			Chaîne en clair déchiffrée

		Raises:
			InvalidToken: Si le token est invalide ou corrompu
			ValueError: Si le token est vide
		"""
		if not token:
			raise ValueError("Impossible de déchiffrer un token vide")

		try:
			plaintext = self._fernet.decrypt(token.encode("utf-8"))
			return plaintext.decode("utf-8")
		except InvalidToken:
			logger.error("Tentative de déchiffrement d'un token invalide ou corrompu")
			raise

	# ─── Rotation de clé ──────────────────────────────────────────────────────

	def rotate_key(
		self,
		ancien_token: str,
		ancienne_cle: str,
	) -> str:
		"""
		Re-chiffre un token avec la clé actuelle du service.

		Utilisé lors de la rotation de clé : on déchiffre avec l'ancienne
		clé puis on re-chiffre avec la clé courante.

		Args:
			ancien_token: Token Fernet chiffré avec l'ancienne clé
			ancienne_cle: Ancienne clé de chiffrement (secret lisible)

		Returns:
			Nouveau token Fernet chiffré avec la clé courante
		"""
		# Dériver l'ancienne clé Fernet
		ancienne_cle_fernet = _derive_fernet_key(ancienne_cle)
		ancien_fernet = Fernet(ancienne_cle_fernet)

		try:
			plaintext = ancien_fernet.decrypt(ancien_token.encode("utf-8"))
			nouveau_token = self._fernet.encrypt(plaintext)
			logger.info("Rotation de clé effectuée avec succès")
			return nouveau_token.decode("utf-8")
		except InvalidToken:
			logger.error("Échec de rotation de clé — token invalide avec l'ancienne clé")
			raise

	async def rotate_key_batch(
		self,
		tokens: list[str],
		ancienne_cle: str,
	) -> list[str]:
		"""
		Re-chiffre un lot de tokens avec la clé courante.

		Args:
			tokens: Liste de tokens Fernet chiffrés avec l'ancienne clé
			ancienne_cle: Ancienne clé de chiffrement (secret lisible)

		Returns:
			Liste de nouveaux tokens Fernet chiffrés avec la clé courante
		"""
		nouveaux_tokens = []
		for token in tokens:
			try:
				nouveau = self.rotate_key(token, ancienne_cle)
				nouveaux_tokens.append(nouveau)
			except InvalidToken:
				logger.warning("Rotation par lot : token ignoré (invalide avec l'ancienne clé)")

		logger.info(f"Rotation de clé par lot : {len(nouveaux_tokens)}/{len(tokens)} tokens traités")
		return nouveaux_tokens

	# ─── Masquage pour réponses API ───────────────────────────────────────────

	def mask_token(self, token: str | None = None) -> str:
		"""
		Retourne un masque pour les réponses API.

		Ne révèle JAMAIS le token chiffré dans les réponses.
		Principe BIBLE #8 : Confidentialité — les secrets ne transitent
		jamais en clair dans les réponses API.

		Args:
			token: Token Fernet (ignoré, toujours masqué)

		Returns:
			Chaîne masquée "••••••••"
		"""
		return MASQUE_DEFAUT

	# ─── Opérations sur dictionnaires ─────────────────────────────────────────

	def encrypt_dict(
		self,
		data: dict,
		champs: list[str],
	) -> dict:
		"""
		Chiffre uniquement les champs spécifiés d'un dictionnaire.

		Les champs absents du dictionnaire sont ignorés silencieusement.
		Les champs avec valeur None sont ignorés.

		Args:
			data: Dictionnaire source
			champs: Liste des noms de champs à chiffrer

		Returns:
			Nouveau dictionnaire avec les champs spécifiés chiffrés
		"""
		resultat = dict(data)
		for champ in champs:
			if champ in resultat and resultat[champ] is not None:
				valeur = resultat[champ]
				if isinstance(valeur, str):
					resultat[champ] = self.encrypt(valeur)
				else:
					# Convertir en JSON puis chiffrer pour les types non-chaînes
					resultat[champ] = self.encrypt(json.dumps(valeur, ensure_ascii=False))
		return resultat

	def decrypt_dict(
		self,
		data: dict,
		champs: list[str],
	) -> dict:
		"""
		Déchiffre les champs spécifiés d'un dictionnaire.

		Les champs absents ou None sont ignorés.
		En cas d'InvalidToken, le champ est conservé tel quel avec
		un avertissement dans les journaux.

		Args:
			data: Dictionnaire source (avec champs chiffrés)
			champs: Liste des noms de champs à déchiffrer

		Returns:
			Nouveau dictionnaire avec les champs spécifiés déchiffrés
		"""
		resultat = dict(data)
		for champ in champs:
			if champ in resultat and resultat[champ] is not None:
				valeur = resultat[champ]
				if isinstance(valeur, str):
					try:
						resultat[champ] = self.decrypt(valeur)
					except InvalidToken:
						logger.warning(f"{champ} : token invalide, conservé tel quel")
		return resultat

	# ─── Utilitaires de génération ────────────────────────────────────────────

	@staticmethod
	def generate_key() -> str:
		"""
		Génère une nouvelle clé Fernet aléatoire.

		Utile pour le setup initial ou la rotation de clé.
		La clé générée est encodée en base64 URL-safe.

		Returns:
			Clé Fernet encodée en base64 (prête à utiliser)
		"""
		return Fernet.generate_key().decode("utf-8")

	@staticmethod
	def generate_secret() -> str:
		"""
		Génère un secret lisible aléatoire pour ENCRYPTION_KEY.

		Contrairement à generate_key(), cette méthode produit
		une chaîne hexadécimale de 64 caractères (32 bytes),
		qui sera ensuite dérivée via PBKDF2 pour produire
		la clé Fernet.

		Returns:
			Chaîne hexadécimale de 64 caractères
		"""
		return os.urandom(32).hex()


# ─── Instance singleton ──────────────────────────────────────────────────────

_encryption_service: EncryptionService | None = None


def get_encryption_service() -> EncryptionService:
	"""
	Récupère l'instance singleton du service de chiffrement.

	Initialise le service au premier appel avec la clé depuis
	la configuration AppSettings.

	Returns:
		Instance unique d'EncryptionService

	Raises:
		RuntimeError: Si ENCRYPTION_KEY n'est pas configurée
	"""
	global _encryption_service

	if _encryption_service is None:
		from src.core.config import get_settings

		settings = get_settings()
		encryption_key = settings.encryption_key

		if not encryption_key:
			raise RuntimeError(
				"ENCRYPTION_KEY n'est pas configurée. "
				"Définissez la variable d'environnement ENCRYPTION_KEY "
				"(utilisez EncryptionService.generate_secret() pour générer une clé)."
			)

		_encryption_service = EncryptionService(encryption_key)

	return _encryption_service


def reset_encryption_service() -> None:
	"""
	Réinitialise le singleton du service de chiffrement.

	Utile pour les tests ou après une rotation de clé
	nécessitant une réinitialisation.
	"""
	global _encryption_service
	_encryption_service = None
