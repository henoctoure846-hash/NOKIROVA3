"""
NOKIROVA — Système d'erreurs professionnel

Chaque erreur possède : Code, Cause, Description, Solution, Journal, Priorité.

Règle : Aucune API sans erreur structurée.
"""

from enum import Enum, StrEnum
from typing import Any


class ErrorPriority(StrEnum):
	"""Priorité des erreurs NOKIROVA"""

	LOW = "low"
	MEDIUM = "medium"
	HIGH = "high"
	CRITICAL = "critical"


class NOKIROVAErrorCode(StrEnum):
	"""Codes d'erreur NOKIROVA — Format : DOMAINE-NNNN"""

	# ── Authentification (AUTH-1xxx) ──
	AUTH_1001 = "AUTH-1001"
	AUTH_1002 = "AUTH-1002"
	AUTH_1003 = "AUTH-1003"
	AUTH_1004 = "AUTH-1004"
	AUTH_1005 = "AUTH-1005"

	# ── Documents (DOC-2xxx) ──
	DOC_2001 = "DOC-2001"
	DOC_2002 = "DOC-2002"
	DOC_2003 = "DOC-2003"
	DOC_2004 = "DOC-2004"
	DOC_2005 = "DOC-2005"

	# ── IA (AI-3xxx) ──
	AI_3001 = "AI-3001"
	AI_3002 = "AI-3002"
	AI_3003 = "AI-3003"
	AI_3004 = "AI-3004"
	AI_4021 = "AI-4021"  # OCR_TIMEOUT

	# ── Base de données (DB-4xxx) ──
	DB_4001 = "DB-4001"
	DB_4002 = "DB-4002"

	# ── Stockage (STO-5xxx) ──
	STO_5001 = "STO-5001"
	STO_5002 = "STO-5002"

	# ── Permissions (PERM-6xxx) ──
	PERM_6001 = "PERM-6001"
	PERM_6002 = "PERM-6002"

	# ── Système (SYS-9xxx) ──
	SYS_9001 = "SYS-9001"
	SYS_9002 = "SYS-9002"


# ── Catalogue des erreurs ──────────────────────────────────────────
ERROR_CATALOG: dict[str, dict[str, Any]] = {
	# Auth
	NOKIROVAErrorCode.AUTH_1001: {
		"code": "AUTH-1001",
		"cause": "Identifiants incorrects",
		"description": "L'email ou le mot de passe ne correspond pas",
		"solution": "Vérifier les identifiants ou réinitialiser le mot de passe",
		"priority": ErrorPriority.MEDIUM,
	},
	NOKIROVAErrorCode.AUTH_1002: {
		"code": "AUTH-1002",
		"cause": "Token expiré",
		"description": "Le token JWT a expiré",
		"solution": "Rafraîchir le token avec le refresh token",
		"priority": ErrorPriority.LOW,
	},
	NOKIROVAErrorCode.AUTH_1003: {
		"code": "AUTH-1003",
		"cause": "Compte désactivé",
		"description": "Le compte utilisateur est désactivé",
		"solution": "Contacter l'administration",
		"priority": ErrorPriority.HIGH,
	},
	NOKIROVAErrorCode.AUTH_1004: {
		"code": "AUTH-1004",
		"cause": "2FA requis",
		"description": "L'authentification double facteur est requise",
		"solution": "Fournir le code TOTP",
		"priority": ErrorPriority.MEDIUM,
	},
	NOKIROVAErrorCode.AUTH_1005: {
		"code": "AUTH-1005",
		"cause": "Trop de tentatives",
		"description": "Trop de tentatives de connexion échouées",
		"solution": "Attendre 15 minutes ou réinitialiser le mot de passe",
		"priority": ErrorPriority.HIGH,
	},
	# Documents
	NOKIROVAErrorCode.DOC_2001: {
		"code": "DOC-2001",
		"cause": "Format non supporté",
		"description": "Le format de fichier n'est pas supporté",
		"solution": "Utiliser un format supporté : PDF, DOCX, ODT, TXT, MD, HTML, CSV, images",
		"priority": ErrorPriority.LOW,
	},
	NOKIROVAErrorCode.DOC_2002: {
		"code": "DOC-2002",
		"cause": "Fichier trop volumineux",
		"description": "Le fichier dépasse la taille maximale autorisée",
		"solution": "Compresser le fichier ou le découper en parties",
		"priority": ErrorPriority.MEDIUM,
	},
	NOKIROVAErrorCode.DOC_2003: {
		"code": "DOC-2003",
		"cause": "Document protégé",
		"description": "Le PDF est protégé par mot de passe",
		"solution": "Fournir le mot de passe du document",
		"priority": ErrorPriority.MEDIUM,
	},
	NOKIROVAErrorCode.DOC_2004: {
		"code": "DOC-2004",
		"cause": "Quota dépassé",
		"description": "Le quota de stockage est dépassé",
		"solution": "Libérer de l'espace ou augmenter le quota",
		"priority": ErrorPriority.HIGH,
	},
	NOKIROVAErrorCode.DOC_2005: {
		"code": "DOC-2005",
		"cause": "Document corrompu",
		"description": "Le fichier est corrompu ou illisible",
		"solution": "Réimporter le fichier depuis la source originale",
		"priority": ErrorPriority.MEDIUM,
	},
	# IA
	NOKIROVAErrorCode.AI_3001: {
		"code": "AI-3001",
		"cause": "Fournisseur IA indisponible",
		"description": "Le fournisseur d'IA est temporairement indisponible",
		"solution": "Basculement automatique vers un fournisseur alternatif",
		"priority": ErrorPriority.HIGH,
	},
	NOKIROVAErrorCode.AI_3002: {
		"code": "AI-3002",
		"cause": "Limite de tokens atteinte",
		"description": "La limite de tokens IA est atteinte pour cette requête",
		"solution": "Découper la requête en parties plus petites",
		"priority": ErrorPriority.MEDIUM,
	},
	NOKIROVAErrorCode.AI_4021: {
		"code": "AI-4021",
		"cause": "OCR_TIMEOUT",
		"description": "PDF trop lourd pour l'OCR",
		"solution": "Découpage automatique. Nouvelle tentative. Sinon notification.",
		"priority": ErrorPriority.MEDIUM,
	},
	# Base de données
	NOKIROVAErrorCode.DB_4001: {
		"code": "DB-4001",
		"cause": "Connexion impossible",
		"description": "Impossible de se connecter à la base de données",
		"solution": "Vérifier les paramètres de connexion et l'état du serveur PostgreSQL",
		"priority": ErrorPriority.CRITICAL,
	},
	# Permissions
	NOKIROVAErrorCode.PERM_6001: {
		"code": "PERM-6001",
		"cause": "Permission insuffisante",
		"description": "L'utilisateur n'a pas la permission requise",
		"solution": "Contacter un administrateur pour obtenir la permission",
		"priority": ErrorPriority.MEDIUM,
	},
}


class NOKIROVAError(Exception):
	"""Exception NOKIROVA structurée — API unifiée"""

	def __init__(
		self,
		error_code: NOKIROVAErrorCode,
		detail: str | None = None,
		context: dict[str, Any] | None = None,
	):
		self.error_code = error_code
		self.detail = detail
		self.context = context or {}

		# Charger les infos du catalogue
		catalog = ERROR_CATALOG.get(error_code, {})
		self.cause = catalog.get("cause", "Inconnue")
		self.description = catalog.get("description", detail or "Erreur inconnue")
		self.solution = catalog.get("solution", "Non définie")
		self.priority = catalog.get("priority", ErrorPriority.MEDIUM)

		super().__init__(self.description)

	def to_dict(self) -> dict[str, Any]:
		"""Convertit l'erreur en dictionnaire pour la réponse API unifiée"""
		return {
			"code": self.error_code.value if isinstance(self.error_code, Enum) else self.error_code,
			"cause": self.cause,
			"description": self.description,
			"solution": self.solution,
			"priority": self.priority.value
			if isinstance(self.priority, ErrorPriority)
			else str(self.priority),
			"context": self.context,
		}


class NotFoundException(NOKIROVAError):
	"""Ressource non trouvée"""

	def __init__(self, resource: str, resource_id: str = ""):
		super().__init__(
			error_code=NOKIROVAErrorCode.SYS_9001,
			detail=f"{resource} non trouvé" + (f" (id: {resource_id})" if resource_id else ""),
			context={"resource": resource, "id": resource_id},
		)


class ForbiddenException(NOKIROVAError):
	"""Accès interdit"""

	def __init__(self, permission: str = ""):
		super().__init__(
			error_code=NOKIROVAErrorCode.PERM_6001,
			detail="Permission insuffisante" + (f" ({permission})" if permission else ""),
			context={"permission": permission},
		)


class ValidationException(NOKIROVAError):
	"""Erreur de validation"""

	def __init__(self, field: str, message: str):
		super().__init__(
			error_code=NOKIROVAErrorCode.SYS_9002,
			detail=message,
			context={"field": field, "validation_error": message},
		)


# ── Alias de compatibilité — services anciens utilisent *Error au lieu de *Exception ──


class NotFoundError(NotFoundException):
	"""Alias de compatibilité — accepte un message simple comme une string."""

	def __init__(self, message: str = ""):
		super().__init__(resource=message, resource_id="")


class ForbiddenError(ForbiddenException):
	"""Alias de compatibilité — accepte un message simple comme une string."""

	def __init__(self, message: str = ""):
		super().__init__(permission=message)


class ConflictError(NOKIROVAError):
	"""Conflit de ressource — duplication, état invalide."""

	def __init__(self, message: str = ""):
		super().__init__(
			error_code=NOKIROVAErrorCode.SYS_9002,
			detail=message,
			context={"conflict": message},
		)


class UnauthorizedError(NOKIROVAError):
	"""Non authentifié — identifiants invalides ou session expirée."""

	def __init__(self, message: str = ""):
		super().__init__(
			error_code=NOKIROVAErrorCode.AUTH_1001,
			detail=message,
			context={"unauthorized": message},
		)
