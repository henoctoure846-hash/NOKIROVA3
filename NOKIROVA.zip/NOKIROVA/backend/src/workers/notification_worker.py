"""
NOKIROVA — Worker Notification

Envoie les notifications push, in-app, email.
Queue : notification
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="notification.send", bind=True, max_retries=3, default_retry_delay=5, queue="notification")
def notification_send_task(
	self, user_id: str, notification_type: str, title: str, body: str, data: dict | None = None
) -> dict:
	"""Envoie une notification à un utilisateur."""
	try:
		# À implémenter : Intégrer Firebase Cloud Messaging / WebSocket push
		return {"user_id": user_id, "type": notification_type, "status": "sent"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="notification.broadcast", bind=True, max_retries=2, queue="notification")
def notification_broadcast_task(
	self, notification_type: str, title: str, body: str, target_group: str | None = None
) -> dict:
	"""Diffuse une notification à un groupe d'utilisateurs."""
	try:
		# À implémenter : Récupérer les utilisateurs du groupe et envoyer
		return {"type": notification_type, "group": target_group, "status": "broadcasted"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
