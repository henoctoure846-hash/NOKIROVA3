"""NOKIROVA — Workers Celery

9 workers spécialisés :
  ai, ocr, pdf, email, backup, search, notification, compression, scheduler

Chaque worker tourne sur sa propre queue.
Communication avec les services via Event Bus.
"""
