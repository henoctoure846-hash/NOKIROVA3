"""
NOKIROVA — Worker IA

Traite les tâches IA : appels LLM, génération, analyse.
Queue : ai
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="ai.generate", bind=True, max_retries=3, default_retry_delay=10, queue="ai")
def ai_generate_task(self, agent_name: str, prompt: str, context: dict | None = None) -> dict:
	"""Appelle un agent IA pour générer du contenu."""
	import asyncio

	from src.ai.agents import get_agent

	agent = get_agent(agent_name)
	if not agent:
		return {"error": f"Agent '{agent_name}' introuvable", "status": "failed"}

	try:
		result = asyncio.run(agent.run(prompt=prompt, context=context or {}))
		return {"output": result.output, "tokens": result.tokens_used, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="ai.sio_process", bind=True, max_retries=2, default_retry_delay=5, queue="ai")
def ai_sio_process_task(self, query: str, user_id: str, context: dict | None = None) -> dict:
	"""Exécute le pipeline SIO complet."""
	import asyncio

	from src.ai.orchestrator.orchestrator import sio_orchestrator

	try:
		result = asyncio.run(sio_orchestrator.process(query=query, user_id=user_id, context=context))
		return {"request_id": result.request_id, "confidence": result.confidence_score, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
