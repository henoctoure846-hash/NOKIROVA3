"""
NOKIROVA — Worker Email

Envoie les emails transactionnels et notifications.
Queue : email
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="email.send", bind=True, max_retries=5, default_retry_delay=60, queue="email")
def email_send_task(self, to: str, subject: str, template: str, context: dict | None = None) -> dict:
	"""Envoie un email via le service configuré (SMTP / SendGrid / etc.)."""
	try:
		# À implémenter : Intégrer le service d'envoi d'email
		# from src.services.email import send_email
		# send_email(to=to, subject=subject, template=template, context=context)
		return {"to": to, "subject": subject, "status": "sent"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
