"""
NOKIROVA — Worker Compression

Compresse les fichiers média (images, PDF) pour optimiser le stockage.
Queue : compression
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(
	name="compression.compress_image", bind=True, max_retries=2, default_retry_delay=5, queue="compression"
)
def compression_compress_image_task(self, file_url: str, quality: int = 80, max_width: int = 1920) -> dict:
	"""Compresse une image."""
	try:
		# À implémenter : Intégrer Pillow / ImageMagick pour compression
		return {"source": file_url, "quality": quality, "max_width": max_width, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="compression.compress_pdf", bind=True, max_retries=2, queue="compression")
def compression_compress_pdf_task(self, file_url: str, quality: str = "screen") -> dict:
	"""Compresse un PDF."""
	try:
		# À implémenter : Intégrer Ghostscript pour compression PDF
		return {"source": file_url, "quality": quality, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
