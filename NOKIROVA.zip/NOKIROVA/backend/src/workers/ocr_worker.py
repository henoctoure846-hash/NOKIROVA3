"""
NOKIROVA — Worker OCR

Traite les documents pour extraction de texte.
Queue : ocr
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="ocr.extract_text", bind=True, max_retries=2, default_retry_delay=15, queue="ocr")
def ocr_extract_text_task(self, document_id: str, file_url: str, language: str = "fra") -> dict:
	"""Extrait le texte d'un document image/PDF via OCR."""
	import asyncio

	from src.ai.agents import get_agent

	agent = get_agent("ocr")
	if not agent:
		return {"error": "Agent OCR introuvable", "status": "failed"}

	try:
		result = asyncio.run(
			agent.run(
				prompt=f"Extrais le texte de ce document : {file_url}",
				context={"language": language, "document_id": document_id},
			)
		)
		return {"document_id": document_id, "text": result.output, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
