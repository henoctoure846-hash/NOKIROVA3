"""
NOKIROVA — Worker Search

Indexation et recherche dans le Knowledge Graph.
Queue : search
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="search.index_document", bind=True, max_retries=3, default_retry_delay=5, queue="search")
def search_index_document_task(self, document_id: str, content: str, metadata: dict | None = None) -> dict:
	"""Indexe un document dans le moteur de recherche vectoriel."""
	import asyncio

	from src.ai.agents import get_agent

	agent = get_agent("embedding")
	if not agent:
		return {"error": "Agent embedding introuvable", "status": "failed"}

	try:
		asyncio.run(
			agent.run(
				prompt=f"Vectorise ce contenu pour indexation : {content[:2000]}",
				context={"document_id": document_id, "metadata": metadata},
			)
		)
		return {"document_id": document_id, "indexed": True, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="search.reindex_all", bind=True, max_retries=1, queue="search")
def search_reindex_all_task(self) -> dict:
	"""Réindexe tous les documents — self-healing si index corrompu."""
	try:
		# À implémenter : Boucle sur tous les documents et réindexe
		return {"status": "completed", "documents_indexed": 0}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
