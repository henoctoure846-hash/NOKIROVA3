"""
NOKIROVA — Worker PDF

Génère, convertit, et manipule les PDF.
Queue : pdf
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="pdf.generate", bind=True, max_retries=2, default_retry_delay=10, queue="pdf")
def pdf_generate_task(self, template_id: str, data: dict, output_format: str = "pdf") -> dict:
	"""Génère un PDF depuis un template."""
	try:
		# À implémenter : Intégrer la bibliothèque de génération PDF (WeasyPrint / ReportLab)
		return {
			"template": template_id,
			"format": output_format,
			"status": "completed",
			"url": f"/exports/{template_id}.pdf",
		}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="pdf.convert", bind=True, max_retries=2, queue="pdf")
def pdf_convert_task(self, source_url: str, target_format: str = "pdf") -> dict:
	"""Convertit un document vers PDF ou depuis PDF."""
	try:
		# À implémenter : Intégrer LibreOffice headless pour conversion
		return {"source": source_url, "target_format": target_format, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
