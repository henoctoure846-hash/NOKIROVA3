"""NOKIROVA — Configuration Celery

9 queues spécialisées pour 9 workers.
Chaque worker écoute sa queue.
"""

from celery import Celery

from src.core.config import get_settings

# Instance Celery
_settings = get_settings()
celery_app = Celery(
	"nokirova",
	broker=_settings.redis.url,
	backend=_settings.redis.url,
)

# Configuration
celery_app.conf.update(
	task_serializer="json",
	accept_content=["json"],
	result_serializer="json",
	timezone="Europe/Paris",
	enable_utc=True,
	task_track_started=True,
	task_acks_late=True,
	worker_prefetch_multiplier=1,
	# 9 queues spécialisées
	task_queues={
		"ai": {"exchange": "ai", "routing_key": "ai"},
		"ocr": {"exchange": "ocr", "routing_key": "ocr"},
		"pdf": {"exchange": "pdf", "routing_key": "pdf"},
		"email": {"exchange": "email", "routing_key": "email"},
		"backup": {"exchange": "backup", "routing_key": "backup"},
		"search": {"exchange": "search", "routing_key": "search"},
		"notification": {"exchange": "notification", "routing_key": "notification"},
		"compression": {"exchange": "compression", "routing_key": "compression"},
		"scheduler": {"exchange": "scheduler", "routing_key": "scheduler"},
	},
	task_default_queue="ai",
	task_default_exchange="ai",
	task_default_routing_key="ai",
)

# Auto-découverte des tâches
celery_app.autodiscover_tasks(["src.workers"])
