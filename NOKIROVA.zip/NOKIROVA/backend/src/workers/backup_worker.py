"""
NOKIROVA — Worker Backup

Sauvegarde automatique des données et fichiers.
Queue : backup
"""

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app


@celery_app.task(name="backup.database", bind=True, max_retries=2, default_retry_delay=30, queue="backup")
def backup_database_task(self) -> dict:
	"""Sauvegarde la base de données PostgreSQL."""
	import subprocess

	from src.core.config import get_settings

	_settings = get_settings()
	try:
		result = subprocess.run(
			[
				"pg_dump",
				_settings.database.url_sync.replace("+psycopg2", ""),
				"-Fc",
				"-f",
				f"/backups/db_{self.request.id}.dump",
			],
			capture_output=True,
			text=True,
			timeout=600,
		)
		return {"status": "completed" if result.returncode == 0 else "failed", "output": result.stdout[:500]}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc


@celery_app.task(name="backup.files", bind=True, max_retries=2, queue="backup")
def backup_files_task(self, user_id: str | None = None) -> dict:
	"""Sauvegarde les fichiers utilisateurs vers le stockage configuré."""
	try:
		# À implémenter : Intégrer S3 / GCS / stockage local
		return {"user_id": user_id, "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		raise self.retry(exc=exc) from exc
