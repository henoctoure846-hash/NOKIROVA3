"""
NOKIROVA — Worker Scheduler

Planifie et exécute les tâches récurrentes.
Queue : scheduler
"""

from celery.schedules import crontab

from src.core.health_exceptions import WORKER_EXCEPTIONS
from src.workers.celery_app import celery_app

# ─── Tâches planifiées ─────────────────────────────────────────────────────────


@celery_app.task(name="scheduler.daily_cleanup", queue="scheduler")
def daily_cleanup_task() -> dict:
	"""Nettoyage quotidien : corbeille > 30 jours, sessions expirées, etc."""
	try:
		# À implémenter : Implémenter le nettoyage
		return {"task": "daily_cleanup", "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		return {"task": "daily_cleanup", "status": "failed", "error": str(exc)}


@celery_app.task(name="scheduler.spaced_rep_reminders", queue="scheduler")
def spaced_rep_reminders_task() -> dict:
	"""Envoie les rappels de révision espacée programmés."""
	try:
		# À implémenter : Calculer les rappels dûs et envoyer les notifications
		return {"task": "spaced_rep_reminders", "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		return {"task": "spaced_rep_reminders", "status": "failed", "error": str(exc)}


@celery_app.task(name="scheduler.analytics_aggregate", queue="scheduler")
def analytics_aggregate_task() -> dict:
	"""Agrège les métriques d'utilisation quotidiennes."""
	try:
		# À implémenter : Agréger et stocker les métriques
		return {"task": "analytics_aggregate", "status": "completed"}
	except WORKER_EXCEPTIONS as exc:
		return {"task": "analytics_aggregate", "status": "failed", "error": str(exc)}


# ─── Beat Schedule ─────────────────────────────────────────────────────────────

celery_app.conf.beat_schedule = {
	"nettoyage-quotidien": {
		"task": "scheduler.daily_cleanup",
		"schedule": crontab(hour=3, minute=0),  # 3h du matin
	},
	"rappels-revision": {
		"task": "scheduler.spaced_rep_reminders",
		"schedule": crontab(hour=8, minute=0),  # 8h du matin
	},
	"agregation-analytics": {
		"task": "scheduler.analytics_aggregate",
		"schedule": crontab(hour=1, minute=0),  # 1h du matin
	},
}
