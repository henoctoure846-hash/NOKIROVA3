"""NOKIROVA — Middleware de confidentialité

Ajoute les en-têtes de sécurité et de confidentialité à chaque
réponse HTTP, conformément au Principe BIBLE #8 Confidentialité.

En-têtes ajoutés :
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY
- X-XSS-Protection: 1; mode=block
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy: (restrictif — pas de caméra, micro, géoloc)
- Content-Security-Policy: default-src 'self'
- Strict-Transport-Security: max-age=31536000; includeSubDomains

Cookie de consentement :
- nokirova_consent : préférences de cookies de l'utilisateur

Principe BIBLE #8 : Confidentialité — protection des données
en transit et conformité RGPD par défaut.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from src.core.logging import get_logger

logger = get_logger(__name__)


# ─── Constantes ──────────────────────────────────────────────────────────────

# En-têtes de sécurité appliqués à TOUTES les réponses
EN_TETES_SECURITE = {
	"X-Content-Type-Options": "nosniff",
	"X-Frame-Options": "DENY",
	"X-XSS-Protection": "1; mode=block",
	"Referrer-Policy": "strict-origin-when-cross-origin",
	"Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
	"Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' wss: https:",
	"Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
}

# Cookie de consentement RGPD
NOM_COOKIE_CONSENT = "nokirova_consent"
DUREE_COOKIE_CONSENT = 365  # jours


class PrivacyMiddleware(BaseHTTPMiddleware):
	"""
	Middleware de confidentialité NOKIROVA.

	Ajoute les en-têtes de sécurité et gère le cookie de
	consentement RGPD sur chaque réponse.

	Principe BIBLE #8 : Confidentialité — protection par défaut.
	Aucune donnée ne transite sans protection.
	"""

	async def dispatch(
		self,
		request: Request,
		call_next: Callable[[Request], Awaitable[Response]],
	) -> Response:
		"""
		Intercepte chaque requête pour :
		1. Ajouter les en-têtes de sécurité à la réponse
		2. Vérifier et gérer le cookie de consentement
		3. Journaliser les accès pour audit

		Args:
			request: Requête HTTP entrante
			call_next: Prochain middleware/handler dans la chaîne

		Returns:
			Réponse HTTP avec en-têtes de confidentialité
		"""
		# ── Appeler le handler suivant ──
		response = await call_next(request)

		# ── Ajouter les en-têtes de sécurité ──
		for en_tete, valeur in EN_TETES_SECURITE.items():
			response.headers[en_tete] = valeur

		# ── Cookie de consentement ──
		consent = request.cookies.get(NOM_COOKIE_CONSENT)
		if consent is None:
			# Premier visiteur — définir le cookie de consentement par défaut
			# L'utilisateur n'a pas encore consenti → cookie "non-consenti"
			date_expiration = datetime.now(UTC) + timedelta(days=DUREE_COOKIE_CONSENT)
			response.set_cookie(
				key=NOM_COOKIE_CONSENT,
				value="non-consenti",
				expires=date_expiration,
				httponly=True,
				samesite="lax",
				secure=True,
				path="/",
			)
			logger.debug("Cookie de consentement initial défini pour un nouveau visiteur")

		# ── En-tête personnalisé NOKIROVA (audit) ──
		response.headers["X-NOKIROVA-Privacy"] = "enabled"

		# ── Journalisation d'audit (Principe BIBLE #12) ──
		chemin = request.url.path
		methode = request.method
		logger.debug(f"{methode} {chemin} — en-têtes de confidentialité appliqués")

		return response
