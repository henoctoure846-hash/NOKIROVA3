"""
NOKIROVA — Middleware d'isolation tenant

Isolation des données par tenant (organisation).
Injecte le tenant_id dans le contexte de la requête.
Principe : pas de fuite de données entre tenants.
"""

from __future__ import annotations

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from src.core.logging import logger


class TenantMiddleware(BaseHTTPMiddleware):
	"""
	Isolation multi-tenant.

	Le tenant_id est extrait depuis :
	1. Le header X-Tenant-ID
	2. Le JWT de l'utilisateur
	3. Le sous-domaine

	Le tenant_id est injecté dans request.state pour
	être utilisé par les repositories.
	"""

	async def dispatch(self, request: Request, call_next):
		# Extraire le tenant_id
		tenant_id = request.headers.get("X-Tenant-ID")

		if not tenant_id and hasattr(request.state, "user"):
			user = request.state.user
			tenant_id = getattr(user, "tenant_id", None)

		if not tenant_id:
			# Tenant par défaut (mode mono-tenant)
			tenant_id = "default"

		request.state.tenant_id = tenant_id
		logger.debug(f"Tenant isolé : {tenant_id}")

		return await call_next(request)
