"""
NOKIROVA — Middleware de limitation de taux

Limitation par IP et par utilisateur.
Utilise Redis pour le comptage distribué.

Principe : Self-healing — si Redis indisponible, on laisse passer.
"""

from __future__ import annotations

import time
from collections.abc import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.core.logging import logger


class RateLimiterMiddleware(BaseHTTPMiddleware):
	"""
	Limitation du taux de requêtes.

	Configuration :
	- Par IP : 60 req/min par défaut
	- Par utilisateur : 120 req/min par défaut
	- Burst : 10 req/sec

	Self-healing : si Redis échoue, on laisse passer.
	"""

	def __init__(
		self,
		app,
		ip_rate: int = 60,
		user_rate: int = 120,
		burst: int = 10,
		window_seconds: int = 60,
	):
		super().__init__(app)
		self.ip_rate = ip_rate
		self.user_rate = user_rate
		self.burst = burst
		self.window_seconds = window_seconds
		# Fallback en mémoire si Redis indisponible
		self._memory_store: dict[str, list[float]] = {}

	async def dispatch(self, request: Request, call_next: Callable) -> Response:
		# Identifier le client
		client_ip = request.client.host if request.client else "unknown"
		user_id = getattr(request.state, "user_id", None)

		# Vérifier la limite
		key = f"rate:{client_ip}"
		limit = self.ip_rate

		if user_id:
			key = f"rate:user:{user_id}"
			limit = self.user_rate

		# Comptage (avec fallback mémoire)
		try:
			count = await self._check_redis(key, limit)
		except DB_OPERATION_EXCEPTIONS:
			# Self-healing : si Redis échoue, vérifier en mémoire
			count = self._check_memory(key, limit)

		if count > limit:
			logger.warning(f"Rate limit dépassé : {key} ({count}/{limit})")
			return Response(
				content='{"success":false,"message":"Trop de requêtes. Réessayez plus tard.","errors":["rate_limited"]}',
				status_code=429,
				media_type="application/json",
				headers={"Retry-After": str(self.window_seconds)},
			)

		return await call_next(request)

	async def _check_redis(self, key: str, limit: int) -> int:
		"""Comptage via Redis."""
		import redis.asyncio as aioredis

		from src.core.config import get_settings

		async with aioredis.from_url(get_settings().redis.url) as r:
			now = time.time()
			pipe = r.pipeline()
			pipe.zadd(key, {str(now): now})
			pipe.zremrangebyscore(key, 0, now - self.window_seconds)
			pipe.zcard(key)
			pipe.expire(key, self.window_seconds)
			results = await pipe.execute()
			return results[2]

	def _check_memory(self, key: str, limit: int) -> int:
		"""Comptage en mémoire — fallback."""
		now = time.time()
		if key not in self._memory_store:
			self._memory_store[key] = []
		# Nettoyer les entrées expirées
		self._memory_store[key] = [t for t in self._memory_store[key] if now - t < self.window_seconds]
		self._memory_store[key].append(now)
		return len(self._memory_store[key])
