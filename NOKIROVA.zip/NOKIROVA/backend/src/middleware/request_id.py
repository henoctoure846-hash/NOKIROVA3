"""
NOKIROVA — Middleware Request ID

Injecte un identifiant unique par requête pour le traçage.
"""

import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware


class RequestIDMiddleware(BaseHTTPMiddleware):
	"""
	Ajoute un request_id unique à chaque requête.

	- Si le header X-Request-ID est fourni, on le conserve
	- Sinon, on génère un UUID v4
	- Le request_id est disponible dans request.state.request_id
	- Et dans le header de réponse X-Request-ID
	"""

	async def dispatch(self, request: Request, call_next):
		request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
		request.state.request_id = request_id

		response: Response = await call_next(request)
		response.headers["X-Request-ID"] = request_id
		return response
