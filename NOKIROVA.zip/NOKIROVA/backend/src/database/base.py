"""
NOKIROVA — Classe de base ORM

Tous les modèles héritent de NOKIROVABase.
Champs communs : id, created_at, updated_at, is_active, metadata.
Règle : Aucun modèle sans champ de traçabilité.
"""

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import Boolean, DateTime, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class NOKIROVABase(DeclarativeBase):
	"""Classe de base pour tous les modèles NOKIROVA"""

	pass


class NOKIROVAModelMixin:
	"""Mixin commun pour tous les modèles NOKIROVA"""

	# UUID comme clé primaire
	id: Mapped[str] = mapped_column(
		UUID(as_uuid=False),
		primary_key=True,
		default=lambda: str(uuid.uuid4()),
	)

	# Horodatage
	created_at: Mapped[datetime] = mapped_column(
		DateTime(timezone=True),
		server_default=func.now(),
		nullable=False,
	)
	updated_at: Mapped[datetime] = mapped_column(
		DateTime(timezone=True),
		server_default=func.now(),
		onupdate=func.now(),
		nullable=False,
	)

	# Soft delete
	is_active: Mapped[bool] = mapped_column(
		Boolean,
		default=True,
		nullable=False,
		index=True,
	)

	# Métadonnées extensibles (JSON)
	extra_metadata: Mapped[dict | None] = mapped_column(
		JSONB,
		nullable=True,
		default=dict,
	)

	def to_dict(self) -> dict[str, Any]:
		"""Convertit le modèle en dictionnaire"""
		result = {}
		for column in self.__table__.columns:
			value = getattr(self, column.key)
			if isinstance(value, datetime):
				value = value.isoformat()
			result[column.key] = value
		return result

	def soft_delete(self):
		"""Suppression douce — marque comme inactif"""
		self.is_active = False

	def restore(self):
		"""Restauration après suppression douce"""
		self.is_active = True
