"""
NOKIROVA — Moteur de base de données asynchrone

PostgreSQL avec asyncpg. Pool de connexions configuré.
"""

from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from ..core.config import get_settings

_engine: AsyncEngine | None = None


def get_engine() -> AsyncEngine:
	"""Retourne le moteur de base de données (singleton)"""
	global _engine
	if _engine is None:
		settings = get_settings()
		_engine = create_async_engine(
			settings.database.url,
			echo=settings.debug,
			pool_size=settings.database.pool_size,
			max_overflow=settings.database.max_overflow,
			pool_pre_ping=True,  # Vérifie la connexion avant usage
			pool_recycle=3600,  # Recyclage toutes les heures
		)
	return _engine


async def dispose_engine():
	"""Ferme proprement le moteur de base de données"""
	global _engine
	if _engine:
		await _engine.dispose()
		_engine = None
