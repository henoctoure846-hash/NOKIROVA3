"""
NOKIROVA — Session de base de données asynchrone

Fournit les sessions pour les repositories.
Règle : Aucune requête hors session.
"""

from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import (
	AsyncSession,
	async_sessionmaker,
)

from src.core.health_exceptions import DB_EXCEPTIONS

from .engine import get_engine

_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_session_factory() -> async_sessionmaker[AsyncSession]:
	"""Retourne la fabrique de sessions (singleton)"""
	global _session_factory
	if _session_factory is None:
		_session_factory = async_sessionmaker(
			bind=get_engine(),
			class_=AsyncSession,
			expire_on_commit=False,
		)
	return _session_factory


async def get_db() -> AsyncGenerator[AsyncSession, None]:
	"""Dépendance FastAPI — fournit une session par requête"""
	factory = get_session_factory()
	async with factory() as session:
		try:
			yield session
			await session.commit()
		except DB_EXCEPTIONS:
			await session.rollback()
			raise
		finally:
			await session.close()
