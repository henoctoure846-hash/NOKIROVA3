"""
NOKIROVA — Modèles du domaine Analytics

Tables : analytics_events, analytics_daily_stats, analytics_user_activity,
         analytics_course_stats, analytics_ai_usage_stats.
"""

from sqlalchemy import Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class AnalyticsEvent(NOKIROVABase, NOKIROVAModelMixin):
	"""Événement analytique brut"""

	__tablename__ = "analytics_events"

	user_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
	)
	event_type: Mapped[str] = mapped_column(
		String(100), nullable=False, index=True
	)  # page_view, quiz_completed, document_created, etc.
	event_category: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # navigation, learning, production, social, ai
	event_action: Mapped[str] = mapped_column(String(100), nullable=False)  # view, create, update, delete, complete
	event_label: Mapped[str | None] = mapped_column(String(255), nullable=True)
	event_value: Mapped[float | None] = mapped_column(Float, nullable=True)
	resource_type: Mapped[str | None] = mapped_column(String(50), nullable=True)  # course, document, quiz, etc.
	resource_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	session_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	device_type: Mapped[str | None] = mapped_column(String(20), nullable=True)  # desktop, tablet, mobile
	platform: Mapped[str | None] = mapped_column(String(20), nullable=True)  # web, ios, android
	ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
	user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
	properties: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	occurred_at: Mapped[str] = mapped_column(String, nullable=False, index=True)


class AnalyticsDailyStats(NOKIROVABase, NOKIROVAModelMixin):
	"""Statistiques quotidiennes agrégées"""

	__tablename__ = "analytics_daily_stats"

	date: Mapped[str] = mapped_column(String, nullable=False, index=True)  # YYYY-MM-DD
	total_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	active_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	new_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_documents: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	documents_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	quizzes_completed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	flashcards_reviewed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	ai_conversations: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	ai_tokens_used: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	community_posts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	study_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	revenue: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	extra_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class AnalyticsUserActivity(NOKIROVABase, NOKIROVAModelMixin):
	"""Activité quotidienne d'un utilisateur"""

	__tablename__ = "analytics_user_activity"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	date: Mapped[str] = mapped_column(String, nullable=False, index=True)  # YYYY-MM-DD
	is_active: Mapped[bool] = mapped_column(default=False, nullable=False)
	study_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	documents_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	quizzes_taken: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	flashcards_reviewed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	ai_messages: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	community_interactions: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	pages_visited: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	xp_earned: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	sessions_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	activity_breakdown: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Détail par heure


class AnalyticsCourseStats(NOKIROVABase, NOKIROVAModelMixin):
	"""Statistiques d'un cours"""

	__tablename__ = "analytics_course_stats"

	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	date: Mapped[str] = mapped_column(String, nullable=False, index=True)
	enrolled_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	active_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	completed_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	average_progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	average_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	quiz_attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	drop_off_rate: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	satisfaction_score: Mapped[float | None] = mapped_column(Float, nullable=True)
	popular_topics: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class AnalyticsAIUsageStats(NOKIROVABase, NOKIROVAModelMixin):
	"""Statistiques d'utilisation IA"""

	__tablename__ = "analytics_ai_usage_stats"

	date: Mapped[str] = mapped_column(String, nullable=False, index=True)
	model_provider: Mapped[str] = mapped_column(String(50), nullable=False)
	model_name: Mapped[str] = mapped_column(String(100), nullable=False)
	total_requests: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_tokens_prompt: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_tokens_completion: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_cost_usd: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	average_latency_ms: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	error_rate: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	unique_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	by_agent_type: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Répartition par agent
	by_operation: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Répartition par opération
