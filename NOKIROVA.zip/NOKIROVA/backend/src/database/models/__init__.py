"""
NOKIROVA — Import central de tous les modèles de domaine

Tous les modèles sont importés ici pour qu'Alembic et l'ORM
puissent les découvrir automatiquement.
"""

# === Modèles Core ===
# === Modèles Administration ===
from .admin import AdminAction, AdminRole, AdminUserRole, MaintenanceWindow, SystemSetting

# === Modèles IA (IA Studio) ===
from .ai import AIAgent, AIConversation, AIMessage, AIModelConfig, AIReasoningChain, AIUsageLog

# === Modèles Analytics ===
from .analytics import (
	AnalyticsAIUsageStats,
	AnalyticsCourseStats,
	AnalyticsDailyStats,
	AnalyticsEvent,
	AnalyticsUserActivity,
)

# === Modèles Archive ===
from .archive import ArchivePolicy, ArchiveRecord

# === Modèles Authentification ===
from .auth import LoginHistory, OAuthConnection, PasswordReset, RefreshToken

# === Modèles Chat ===
from .chat import ChatAttachment, ChatMember, ChatMessage, ChatRoom

# === Modèles Communauté ===
from .community import (
	CommunityBadgeUser,
	CommunityComment,
	CommunityEvent,
	CommunityGroup,
	CommunityLike,
	CommunityPost,
	CommunityReport,
)
from .core import FeatureFlag, Setting, Translation

# === Modèles Documents (Produire) ===
from .documents import Document, DocumentCollaborator, DocumentFolder, DocumentShare, DocumentVersion

# === Modèles Examens (Réviser) ===
from .exams import Exam, ExamQuestion, ExamResult, ExamSchedule, ExamSubmission

# === Modèles Flashcards (Réviser) ===
from .flashcards import Flashcard, FlashcardDeck, FlashcardReview, FlashcardStudySession

# === Modèles Gamification (Progression) ===
from .gamification import (
	GamificationAchievement,
	GamificationBadge,
	GamificationChallenge,
	GamificationLeaderboard,
	GamificationReward,
	GamificationStreak,
	GamificationUserXP,
)

# === Modèles Indexation ===
from .indexing import IndexJob, SearchIndex, VectorEmbedding

# === Modèles Knowledge Graph ===
from .knowledge_graph import KGAttribute, KGConcept, KGLearningPath, KGRelationship

# === Modèles Knowledge Lake ===
from .knowledge_lake import KLDocument, KLEmbedding, KLSource, KLSyncLog, KLTag

# === Modèles Logs ===
from .logs import APILog, AuditTrail, ErrorLog, SystemLog

# === Modèles Marketplace ===
from .marketplace import MarketplaceCategory, MarketplaceItem, MarketplacePurchase, MarketplaceReview

# === Modèles Mémoire (Jumeau Pédagogique) ===
from .memory import MemoryContext, MemoryEdge, MemoryNode, MemorySnapshot

# === Modèles Monitoring ===
from .monitoring import Alert, AlertRule, HealthCheck, ServiceMetric

# === Modèles Notes ===
from .notes import Note, NoteAnnotation, NoteLink

# === Modèles Notifications ===
from .notifications import Notification, NotificationChannel, NotificationPreference

# === Modèles OCR ===
from .ocr import OCRJob, OCRPage, OCRResult

# === Modèles Plugins ===
from .plugins import Plugin, PluginConfig, PluginHook, PluginPermission

# === Modèles Quiz (Réviser) ===
from .quiz import Quiz, QuizAnswer, QuizAttempt, QuizQuestion

# === Modèles Révision ===
from .revision import RevisionPlan, RevisionSession, RevisionStats, RevisionTopic

# === Modèles Stockage ===
from .storage import File, StorageQuota

# === Modèles Université (Apprendre) ===
from .university import (
	Course,
	Module,
	UniversityAnnouncement,
	UniversityAssignment,
	UniversityEnrollment,
	UniversityGrade,
	UniversityLesson,
	UniversityPrerequisite,
	UniversitySchedule,
	UniversitySubmission,
)

# === Modèles Utilisateurs ===
from .users import User, UserConsent, UserDevice, UserPreference, UserProfile

__all__ = [
	# Core
	"Setting",
	"Translation",
	"FeatureFlag",
	# Utilisateurs
	"User",
	"UserProfile",
	"UserPreference",
	"UserConsent",
	"UserDevice",
	# Auth
	"RefreshToken",
	"PasswordReset",
	"LoginHistory",
	"OAuthConnection",
	# Université
	"Course",
	"Module",
	"UniversityLesson",
	"UniversityEnrollment",
	"UniversityAssignment",
	"UniversitySubmission",
	"UniversityGrade",
	"UniversityAnnouncement",
	"UniversitySchedule",
	"UniversityPrerequisite",
	# Documents
	"Document",
	"DocumentVersion",
	"DocumentFolder",
	"DocumentCollaborator",
	"DocumentShare",
	# Stockage
	"File",
	"StorageQuota",
	# OCR
	"OCRJob",
	"OCRResult",
	"OCRPage",
	# Indexation
	"SearchIndex",
	"VectorEmbedding",
	"IndexJob",
	# Notes
	"Note",
	"NoteAnnotation",
	"NoteLink",
	# Flashcards
	"FlashcardDeck",
	"Flashcard",
	"FlashcardReview",
	"FlashcardStudySession",
	# Quiz
	"Quiz",
	"QuizQuestion",
	"QuizAnswer",
	"QuizAttempt",
	# Examens
	"Exam",
	"ExamQuestion",
	"ExamSubmission",
	"ExamResult",
	"ExamSchedule",
	# IA
	"AIAgent",
	"AIConversation",
	"AIMessage",
	"AIReasoningChain",
	"AIModelConfig",
	"AIUsageLog",
	# Chat
	"ChatRoom",
	"ChatMessage",
	"ChatMember",
	"ChatAttachment",
	# Mémoire
	"MemoryNode",
	"MemoryEdge",
	"MemoryContext",
	"MemorySnapshot",
	# Révision
	"RevisionPlan",
	"RevisionSession",
	"RevisionTopic",
	"RevisionStats",
	# Communauté
	"CommunityPost",
	"CommunityComment",
	"CommunityLike",
	"CommunityGroup",
	"CommunityEvent",
	"CommunityReport",
	"CommunityBadgeUser",
	# Marketplace
	"MarketplaceCategory",
	"MarketplaceItem",
	"MarketplaceReview",
	"MarketplacePurchase",
	# Gamification
	"GamificationBadge",
	"GamificationAchievement",
	"GamificationUserXP",
	"GamificationStreak",
	"GamificationLeaderboard",
	"GamificationChallenge",
	"GamificationReward",
	# Analytics
	"AnalyticsEvent",
	"AnalyticsDailyStats",
	"AnalyticsUserActivity",
	"AnalyticsCourseStats",
	"AnalyticsAIUsageStats",
	# Notifications
	"Notification",
	"NotificationPreference",
	"NotificationChannel",
	# Plugins
	"Plugin",
	"PluginConfig",
	"PluginHook",
	"PluginPermission",
	# Logs
	"SystemLog",
	"APILog",
	"ErrorLog",
	"AuditTrail",
	# Monitoring
	"HealthCheck",
	"ServiceMetric",
	"Alert",
	"AlertRule",
	# Administration
	"AdminRole",
	"AdminUserRole",
	"AdminAction",
	"SystemSetting",
	"MaintenanceWindow",
	# Archive
	"ArchiveRecord",
	"ArchivePolicy",
	# Knowledge Graph
	"KGConcept",
	"KGRelationship",
	"KGAttribute",
	"KGLearningPath",
	# Knowledge Lake
	"KLSource",
	"KLDocument",
	"KLEmbedding",
	"KLTag",
	"KLSyncLog",
]
