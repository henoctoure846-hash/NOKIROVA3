"""
NOKIROVA — Modèles du domaine Révision

Tables : revision_plans, revision_sessions, revision_topics, revision_stats.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class RevisionPlan(NOKIROVABase, NOKIROVAModelMixin):
	"""Plan de révision"""

	__tablename__ = "revision_plans"

	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True
	)
	plan_type: Mapped[str] = mapped_column(
		String(30), default="spaced", nullable=False
	)  # spaced, cram, pomodoro, custom
	start_date: Mapped[str | None] = mapped_column(String, nullable=True)
	end_date: Mapped[str | None] = mapped_column(String, nullable=True)
	exam_date: Mapped[str | None] = mapped_column(String, nullable=True)  # date de l'examen cible
	daily_hours: Mapped[float] = mapped_column(Float, default=2.0, nullable=False)
	priority: Mapped[str] = mapped_column(
		String(20), default="medium", nullable=False
	)  # low, medium, high, critical
	status: Mapped[str] = mapped_column(
		String(20), default="active", nullable=False
	)  # draft, active, paused, completed, archived
	ai_generated: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	algorithm: Mapped[str] = mapped_column(String(50), default="sm2", nullable=False)  # sm2, leitner, custom
	settings: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)  # 0.0 - 100.0
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	sessions = relationship("RevisionSession", back_populates="plan", cascade="all, delete-orphan")
	topics = relationship("RevisionTopic", back_populates="plan", cascade="all, delete-orphan")


class RevisionSession(NOKIROVABase, NOKIROVAModelMixin):
	"""Session de révision"""

	__tablename__ = "revision_sessions"

	plan_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("revision_plans.id", ondelete="CASCADE"), nullable=False, index=True
	)
	topic_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("revision_topics.id", ondelete="SET NULL"), nullable=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	session_type: Mapped[str] = mapped_column(
		String(20), default="study", nullable=False
	)  # study, review, practice, break
	duration_minutes: Mapped[int] = mapped_column(Integer, default=25, nullable=False)
	actual_duration_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
	focus_score: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0-100 score de concentration
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	ended_at: Mapped[str | None] = mapped_column(String, nullable=True)
	status: Mapped[str] = mapped_column(
		String(20), default="scheduled", nullable=False
	)  # scheduled, in_progress, completed, skipped
	notes: Mapped[str | None] = mapped_column(Text, nullable=True)

	# Relations
	plan = relationship("RevisionPlan", back_populates="sessions")


class RevisionTopic(NOKIROVABase, NOKIROVAModelMixin):
	"""Sujet de révision dans un plan"""

	__tablename__ = "revision_topics"

	plan_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("revision_plans.id", ondelete="CASCADE"), nullable=False, index=True
	)
	name: Mapped[str] = mapped_column(String(200), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	subject: Mapped[str | None] = mapped_column(String(100), nullable=True)
	priority: Mapped[str] = mapped_column(
		String(20), default="medium", nullable=False
	)  # low, medium, high, critical
	difficulty: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)  # easy, medium, hard
	confidence_level: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)  # 0.0 - 1.0 auto-estimé
	estimated_hours: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	actual_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	mastery_level: Mapped[str] = mapped_column(
		String(20), default="new", nullable=False
	)  # new, learning, familiar, proficient, mastered
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	resource_refs: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # références vers ressources

	# Relations
	plan = relationship("RevisionPlan", back_populates="topics")


class RevisionStats(NOKIROVABase, NOKIROVAModelMixin):
	"""Statistiques de révision"""

	__tablename__ = "revision_stats"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	plan_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("revision_plans.id", ondelete="SET NULL"), nullable=True
	)
	date: Mapped[str] = mapped_column(String, nullable=False, index=True)  # date du jour
	total_study_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_break_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	sessions_completed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	topics_covered: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	avg_focus_score: Mapped[float | None] = mapped_column(Float, nullable=True)
	streak_days: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
