"""
NOKIROVA — Modèles du domaine Authentification

Tables : refresh_tokens, password_resets, login_history, oauth_connections.
"""

from sqlalchemy import Boolean, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class RefreshToken(NOKIROVABase, NOKIROVAModelMixin):
	"""Tokens de rafraîchissement"""

	__tablename__ = "auth_refresh_tokens"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	token_jti: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
	expires_at: Mapped[str] = mapped_column(String, nullable=False)  # datetime iso
	is_revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	device_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)


class PasswordReset(NOKIROVABase, NOKIROVAModelMixin):
	"""Demandes de réinitialisation de mot de passe"""

	__tablename__ = "auth_password_resets"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
	expires_at: Mapped[str] = mapped_column(String, nullable=False)  # datetime iso
	is_used: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class LoginHistory(NOKIROVABase, NOKIROVAModelMixin):
	"""Historique des connexions"""

	__tablename__ = "auth_login_history"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
	user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)
	was_successful: Mapped[bool] = mapped_column(Boolean, nullable=False)
	failure_reason: Mapped[str | None] = mapped_column(String(100), nullable=True)
	location: Mapped[str | None] = mapped_column(String(255), nullable=True)  # Approximatif


class OAuthConnection(NOKIROVABase, NOKIROVAModelMixin):
	"""Connexions OAuth (Google, Microsoft, etc.)"""

	__tablename__ = "auth_oauth_connections"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	provider: Mapped[str] = mapped_column(String(50), nullable=False, index=True)  # google, microsoft, apple
	provider_user_id: Mapped[str] = mapped_column(String(255), nullable=False)
	access_token: Mapped[str | None] = mapped_column(Text, nullable=True)
	refresh_token: Mapped[str | None] = mapped_column(Text, nullable=True)
	token_expires_at: Mapped[str | None] = mapped_column(String, nullable=True)
	scope: Mapped[str | None] = mapped_column(Text, nullable=True)

	__table_args__ = (UniqueConstraint("provider", "provider_user_id", name="uq_oauth_provider_user"),)
