"""
NOKIROVA — Modèles du domaine Knowledge Lake (Lac de connaissances)

Tables : kl_sources, kl_documents, kl_embeddings, kl_tags, kl_sync_logs.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class KLSource(NOKIROVABase, NOKIROVAModelMixin):
	"""Source de connaissances (connecteur)"""

	__tablename__ = "kl_sources"

	name: Mapped[str] = mapped_column(String(200), nullable=False)
	source_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # web, pdf, youtube, notion, moodle, google_drive, github
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # configuration du connecteur
	sync_frequency: Mapped[str] = mapped_column(
		String(20), default="daily", nullable=False
	)  # hourly, daily, weekly, manual
	last_sync_at: Mapped[str | None] = mapped_column(String, nullable=True)
	sync_status: Mapped[str] = mapped_column(
		String(20), default="idle", nullable=False
	)  # idle, syncing, error, completed
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	priority: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	documents = relationship("KLDocument", back_populates="source", cascade="all, delete-orphan")


class KLDocument(NOKIROVABase, NOKIROVAModelMixin):
	"""Document ingéré dans le lac de connaissances"""

	__tablename__ = "kl_documents"

	source_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kl_sources.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(500), nullable=False)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)  # texte extrait
	summary: Mapped[str | None] = mapped_column(Text, nullable=True)  # résumé auto-généré
	doc_type: Mapped[str] = mapped_column(String(30), nullable=False)  # article, video, pdf, page, note
	url: Mapped[str | None] = mapped_column(Text, nullable=True)  # URL d'origine
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	word_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	is_indexed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	indexed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	published_at: Mapped[str | None] = mapped_column(String, nullable=True)  # date de publication originale
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	chunk_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

	# Relations
	source = relationship("KLSource", back_populates="documents")
	embeddings = relationship("KLEmbedding", back_populates="document", cascade="all, delete-orphan")


class KLEmbedding(NOKIROVABase, NOKIROVAModelMixin):
	"""Embedding vectoriel d'un chunk de document"""

	__tablename__ = "kl_embeddings"

	document_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kl_documents.id", ondelete="CASCADE"), nullable=False, index=True
	)
	chunk_index: Mapped[int] = mapped_column(Integer, nullable=False)  # index du chunk dans le document
	chunk_text: Mapped[str] = mapped_column(Text, nullable=False)  # texte du chunk
	chunk_type: Mapped[str] = mapped_column(
		String(20), default="paragraph", nullable=False
	)  # paragraph, sentence, heading
	embedding_model: Mapped[str] = mapped_column(String(100), nullable=False)  # nom du modèle d'embedding
	vector_id: Mapped[str | None] = mapped_column(
		String(100), nullable=True
	)  # identifiant dans le stockage vectoriel
	token_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	relevance_score: Mapped[float | None] = mapped_column(Float, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	document = relationship("KLDocument", back_populates="embeddings")


class KLTag(NOKIROVABase, NOKIROVAModelMixin):
	"""Tag pour les documents du lac"""

	__tablename__ = "kl_tags"

	name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	color: Mapped[str | None] = mapped_column(String(20), nullable=True)
	usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class KLSyncLog(NOKIROVABase, NOKIROVAModelMixin):
	"""Journal de synchronisation d'une source"""

	__tablename__ = "kl_sync_logs"

	source_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kl_sources.id", ondelete="CASCADE"), nullable=False, index=True
	)
	sync_type: Mapped[str] = mapped_column(String(20), default="full", nullable=False)  # full, incremental, delta
	status: Mapped[str] = mapped_column(String(20), nullable=False)  # started, completed, failed
	documents_fetched: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	documents_added: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	documents_updated: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	documents_failed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	started_at: Mapped[str] = mapped_column(String, nullable=False)
	finished_at: Mapped[str | None] = mapped_column(String, nullable=True)
