"""
NOKIROVA — Modèles du domaine Stockage

Tables : files, file_chunks, storage_quotas.
"""

from sqlalchemy import BigInteger, Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class File(NOKIROVABase, NOKIROVAModelMixin):
	"""Fichier stocké"""

	__tablename__ = "storage_files"

	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	original_name: Mapped[str] = mapped_column(String(500), nullable=False)
	stored_name: Mapped[str] = mapped_column(String(500), nullable=False)
	mime_type: Mapped[str] = mapped_column(String(100), nullable=False)
	size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
	storage_path: Mapped[str] = mapped_column(Text, nullable=False)
	storage_provider: Mapped[str] = mapped_column(String(30), default="local", nullable=False)  # local, s3, gcs
	bucket: Mapped[str | None] = mapped_column(String(255), nullable=True)
	checksum_md5: Mapped[str | None] = mapped_column(String(32), nullable=True)
	checksum_sha256: Mapped[str | None] = mapped_column(String(64), nullable=True)
	is_encrypted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	document_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="SET NULL"), nullable=True
	)
	folder_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	thumbnail_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	preview_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	processing_status: Mapped[str] = mapped_column(
		String(30), default="pending", nullable=False
	)  # pending, processing, completed, failed
	processing_error: Mapped[str | None] = mapped_column(Text, nullable=True)
	file_metadata: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # EXIF, dimensions, etc.


class StorageQuota(NOKIROVABase, NOKIROVAModelMixin):
	"""Quota de stockage par utilisateur"""

	__tablename__ = "storage_quotas"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
	)
	max_bytes: Mapped[int] = mapped_column(BigInteger, default=5368709120, nullable=False)  # 5 Go par défaut
	used_bytes: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
	file_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	plan: Mapped[str] = mapped_column(String(30), default="free", nullable=False)  # free, pro, enterprise
