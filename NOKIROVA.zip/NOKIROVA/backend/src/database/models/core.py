"""
NOKIROVA — Modèles du domaine Core

Tables système fondamentales : settings, translations, feature_flags.
"""

from sqlalchemy import Boolean, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Setting(NOKIROVABase, NOKIROVAModelMixin):
	"""Paramètres système (clé-valeur)"""

	__tablename__ = "core_settings"

	key: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
	value: Mapped[str] = mapped_column(Text, nullable=False)
	category: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	value_type: Mapped[str] = mapped_column(String(20), default="string", nullable=False)  # string, int, bool, json


class Translation(NOKIROVABase, NOKIROVAModelMixin):
	"""Traductions i18n"""

	__tablename__ = "core_translations"

	key: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
	locale: Mapped[str] = mapped_column(String(10), nullable=False, index=True)  # fr, en, es, etc.
	value: Mapped[str] = mapped_column(Text, nullable=False)
	namespace: Mapped[str] = mapped_column(String(100), default="common", nullable=False)


class FeatureFlag(NOKIROVABase, NOKIROVAModelMixin):
	"""Feature flags pour déploiement progressif"""

	__tablename__ = "core_feature_flags"

	name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
	is_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	target_roles: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)  # Rôles ciblés
	target_users: Mapped[list | None] = mapped_column(ARRAY(UUID(as_uuid=False)), nullable=True)
	rollout_percentage: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 0-100
