"""
NOKIROVA — Modèles du domaine Examens

Tables : exams, exam_questions, exam_submissions, exam_results, exam_schedules.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Exam(NOKIROVABase, NOKIROVAModelMixin):
	"""Examen"""

	__tablename__ = "exams"

	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	exam_type: Mapped[str] = mapped_column(
		String(30), default="practice", nullable=False
	)  # practice, midterm, final, quiz, certification
	duration_minutes: Mapped[int] = mapped_column(Integer, default=60, nullable=False)
	total_points: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
	passing_score: Mapped[float] = mapped_column(Float, default=50.0, nullable=False)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_timed: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	allow_retake: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	max_retakes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	shuffle_questions: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	show_results: Mapped[str] = mapped_column(
		String(20), default="after_submission", nullable=False
	)  # after_submission, after_deadline, manual
	created_by: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
	)
	settings: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	questions = relationship("ExamQuestion", back_populates="exam", cascade="all, delete-orphan")
	submissions = relationship("ExamSubmission", back_populates="exam", cascade="all, delete-orphan")


class ExamQuestion(NOKIROVABase, NOKIROVAModelMixin):
	"""Question d'examen"""

	__tablename__ = "exam_questions"

	exam_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True
	)
	question_text: Mapped[str] = mapped_column(Text, nullable=False)
	question_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # multiple_choice, essay, true_false, short_answer, code
	points: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	options: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # choix multiples
	correct_answer: Mapped[str | None] = mapped_column(Text, nullable=True)
	explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

	# Relations
	exam = relationship("Exam", back_populates="questions")


class ExamSubmission(NOKIROVABase, NOKIROVAModelMixin):
	"""Soumission d'examen"""

	__tablename__ = "exam_submissions"

	exam_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True
	)
	student_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	status: Mapped[str] = mapped_column(
		String(20), default="in_progress", nullable=False
	)  # in_progress, submitted, graded
	answers: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	score: Mapped[float | None] = mapped_column(Float, nullable=True)
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	submitted_at: Mapped[str | None] = mapped_column(String, nullable=True)
	graded_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	graded_at: Mapped[str | None] = mapped_column(String, nullable=True)
	time_spent_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)

	# Relations
	exam = relationship("Exam", back_populates="submissions")


class ExamResult(NOKIROVABase, NOKIROVAModelMixin):
	"""Résultat d'examen"""

	__tablename__ = "exam_results"

	exam_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True
	)
	student_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	submission_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("exam_submissions.id", ondelete="CASCADE"), nullable=False
	)
	score: Mapped[float] = mapped_column(Float, nullable=False)
	max_score: Mapped[float] = mapped_column(Float, nullable=False)
	percentage: Mapped[float] = mapped_column(Float, nullable=False)
	passed: Mapped[bool] = mapped_column(Boolean, nullable=False)
	grade: Mapped[str | None] = mapped_column(String(10), nullable=True)  # A, B, C, D, F
	feedback: Mapped[str | None] = mapped_column(Text, nullable=True)


class ExamSchedule(NOKIROVABase, NOKIROVAModelMixin):
	"""Planification d'examen"""

	__tablename__ = "exam_schedules"

	exam_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False, index=True
	)
	scheduled_at: Mapped[str] = mapped_column(String, nullable=False)
	ends_at: Mapped[str | None] = mapped_column(String, nullable=True)
	room: Mapped[str | None] = mapped_column(String(100), nullable=True)
	proctor_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	notes: Mapped[str | None] = mapped_column(Text, nullable=True)
