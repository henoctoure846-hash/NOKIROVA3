"""
NOKIROVA — Modèles du domaine Notifications

Tables : notifications, notification_preferences, notification_channels.
"""

from sqlalchemy import Boolean, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Notification(NOKIROVABase, NOKIROVAModelMixin):
	"""Notification"""

	__tablename__ = "notifications"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	notification_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # achievement, reminder, social, system, ai, revision, course
	title: Mapped[str] = mapped_column(String(255), nullable=False)
	message: Mapped[str] = mapped_column(Text, nullable=False)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	action_url: Mapped[str | None] = mapped_column(String(500), nullable=True)  # URL d'action
	action_text: Mapped[str | None] = mapped_column(String(100), nullable=True)  # Texte du bouton
	resource_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
	resource_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	sender_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	priority: Mapped[str] = mapped_column(String(10), default="normal", nullable=False)  # low, normal, high, urgent
	is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_dismissed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	read_at: Mapped[str | None] = mapped_column(String, nullable=True)
	delivery_channels: Mapped[list | None] = mapped_column(
		JSONB, nullable=True
	)  # ["push", "email", "in_app", "sms"]
	delivery_status: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # {channel: status}
	scheduled_at: Mapped[str | None] = mapped_column(String, nullable=True)
	expires_at: Mapped[str | None] = mapped_column(String, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class NotificationPreference(NOKIROVABase, NOKIROVAModelMixin):
	"""Préférences de notification d'un utilisateur"""

	__tablename__ = "notification_preferences"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True
	)
	achievement_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	reminder_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	social_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	system_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	ai_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	revision_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	course_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	marketing_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	push_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	email_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	sms_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	quiet_hours_start: Mapped[str | None] = mapped_column(String, nullable=True)  # HH:MM
	quiet_hours_end: Mapped[str | None] = mapped_column(String, nullable=True)  # HH:MM
	digest_frequency: Mapped[str | None] = mapped_column(String(20), nullable=True)  # none, daily, weekly
	preferred_language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)


class NotificationChannel(NOKIROVABase, NOKIROVAModelMixin):
	"""Canal de notification (configuration technique)"""

	__tablename__ = "notification_channels"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	channel_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # push, email, sms, webhook, slack, discord
	channel_address: Mapped[str] = mapped_column(String(255), nullable=False)  # Email, n° tél, URL webhook
	is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	verification_code: Mapped[str | None] = mapped_column(String(20), nullable=True)
	config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
