"""
NOKIROVA — Modèles du domaine Communauté

Tables : community_posts, community_comments, community_likes, community_groups, community_events, community_reports, community_badges_users.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class CommunityPost(NOKIROVABase, NOKIROVAModelMixin):
	"""Publication communautaire"""

	__tablename__ = "community_posts"

	author_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	content: Mapped[str] = mapped_column(Text, nullable=False)
	category: Mapped[str] = mapped_column(
		String(50), nullable=False, index=True
	)  # question, share, discussion, resource
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	is_pinned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_locked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	view_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	group_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("community_groups.id", ondelete="SET NULL"), nullable=True
	)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	comments = relationship("CommunityComment", back_populates="post", cascade="all, delete-orphan")
	likes = relationship("CommunityLike", back_populates="post", cascade="all, delete-orphan")


class CommunityComment(NOKIROVABase, NOKIROVAModelMixin):
	"""Commentaire sur une publication"""

	__tablename__ = "community_comments"

	post_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("community_posts.id", ondelete="CASCADE"), nullable=False, index=True
	)
	author_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	parent_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("community_comments.id", ondelete="CASCADE"), nullable=True
	)
	content: Mapped[str] = mapped_column(Text, nullable=False)
	is_edited: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

	# Relations
	post = relationship("CommunityPost", back_populates="comments")


class CommunityLike(NOKIROVABase, NOKIROVAModelMixin):
	"""Like / Réaction sur une publication"""

	__tablename__ = "community_likes"

	post_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("community_posts.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	reaction_type: Mapped[str] = mapped_column(
		String(20), default="like", nullable=False
	)  # like, love, helpful, insightful

	# Relations
	post = relationship("CommunityPost", back_populates="likes")


class CommunityGroup(NOKIROVABase, NOKIROVAModelMixin):
	"""Groupe communautaire"""

	__tablename__ = "community_groups"

	name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	group_type: Mapped[str] = mapped_column(String(20), default="public", nullable=False)  # public, private, hidden
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	member_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	rules: Mapped[str | None] = mapped_column(Text, nullable=True)


class CommunityEvent(NOKIROVABase, NOKIROVAModelMixin):
	"""Événement communautaire"""

	__tablename__ = "community_events"

	title: Mapped[str] = mapped_column(String(200), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	event_type: Mapped[str] = mapped_column(String(50), nullable=False)  # workshop, meetup, hackathon, study_group
	starts_at: Mapped[str] = mapped_column(String, nullable=False)
	ends_at: Mapped[str | None] = mapped_column(String, nullable=True)
	location: Mapped[str | None] = mapped_column(String(255), nullable=True)  # physique ou URL
	max_participants: Mapped[int | None] = mapped_column(Integer, nullable=True)
	organizer_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	group_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("community_groups.id", ondelete="SET NULL"), nullable=True
	)


class CommunityReport(NOKIROVABase, NOKIROVAModelMixin):
	"""Signalement de contenu"""

	__tablename__ = "community_reports"

	reporter_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	target_type: Mapped[str] = mapped_column(String(20), nullable=False)  # post, comment, user
	target_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False)
	reason: Mapped[str] = mapped_column(String(50), nullable=False)  # spam, harassment, inappropriate, other
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	status: Mapped[str] = mapped_column(
		String(20), default="pending", nullable=False
	)  # pending, reviewed, dismissed, actioned
	reviewed_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)


class CommunityBadgeUser(NOKIROVABase, NOKIROVAModelMixin):
	"""Badge communautaire attribué à un utilisateur"""

	__tablename__ = "community_badges_users"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	badge_name: Mapped[str] = mapped_column(String(100), nullable=False)  # helper, expert, contributor, pioneer
	awarded_at: Mapped[str] = mapped_column(String, nullable=False)
	awarded_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
