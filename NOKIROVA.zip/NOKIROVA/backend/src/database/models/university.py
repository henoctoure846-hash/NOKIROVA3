"""
NOKIROVA — Modèles du domaine Université

Tables : university_courses, university_modules, university_lessons, university_enrollments,
         university_assignments, university_submissions, university_grades, university_announcements,
         university_schedules, university_prerequisites.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Course(NOKIROVABase, NOKIROVAModelMixin):
	"""Cours universitaire"""

	__tablename__ = "university_courses"

	title: Mapped[str] = mapped_column(String(300), nullable=False, index=True)
	code: Mapped[str] = mapped_column(
		String(20), nullable=False, unique=True, index=True
	)  # code du cours (ex: CS101)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	instructor_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
	)
	department: Mapped[str | None] = mapped_column(String(100), nullable=True)
	credits: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
	level: Mapped[str] = mapped_column(
		String(20), default="undergraduate", nullable=False
	)  # undergraduate, graduate, doctoral, open
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	semester: Mapped[str | None] = mapped_column(String(20), nullable=True)  # automne-2026, printemps-2027
	year: Mapped[int | None] = mapped_column(Integer, nullable=True)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_enrollable: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	max_enrollment: Mapped[int | None] = mapped_column(Integer, nullable=True)
	enrollment_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	cover_image: Mapped[str | None] = mapped_column(Text, nullable=True)
	syllabus: Mapped[str | None] = mapped_column(Text, nullable=True)
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	modules = relationship("Module", back_populates="course", cascade="all, delete-orphan")
	enrollments = relationship("UniversityEnrollment", back_populates="course", cascade="all, delete-orphan")


class Module(NOKIROVABase, NOKIROVAModelMixin):
	"""Module de cours"""

	__tablename__ = "university_modules"

	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	module_type: Mapped[str] = mapped_column(
		String(30), default="content", nullable=False
	)  # content, lab, project, exam_prep, workshop
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_required: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	estimated_hours: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	course = relationship("Course", back_populates="modules")
	lessons = relationship("UniversityLesson", back_populates="module", cascade="all, delete-orphan")


class UniversityLesson(NOKIROVABase, NOKIROVAModelMixin):
	"""Leçon dans un module"""

	__tablename__ = "university_lessons"

	module_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_modules.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)
	lesson_type: Mapped[str] = mapped_column(
		String(30), default="video", nullable=False
	)  # video, article, interactive, live, lab
	duration_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_free: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	video_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	attachment_urls: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	transcript: Mapped[str | None] = mapped_column(Text, nullable=True)

	# Relations
	module = relationship("Module", back_populates="lessons")


class UniversityEnrollment(NOKIROVABase, NOKIROVAModelMixin):
	"""Inscription à un cours"""

	__tablename__ = "university_enrollments"

	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	student_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	role: Mapped[str] = mapped_column(
		String(20), default="student", nullable=False
	)  # student, teaching_assistant, auditor
	status: Mapped[str] = mapped_column(
		String(20), default="active", nullable=False
	)  # active, completed, dropped, suspended
	enrolled_at: Mapped[str] = mapped_column(String, nullable=False)
	completed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	progress: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)  # 0.0 - 100.0
	final_grade: Mapped[str | None] = mapped_column(String(10), nullable=True)

	# Relations
	course = relationship("Course", back_populates="enrollments")


class UniversityAssignment(NOKIROVABase, NOKIROVAModelMixin):
	"""Devoir / Travail à rendre"""

	__tablename__ = "university_assignments"

	module_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_modules.id", ondelete="SET NULL"), nullable=True
	)
	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	assignment_type: Mapped[str] = mapped_column(
		String(30), default="homework", nullable=False
	)  # homework, project, lab, essay, presentation
	due_date: Mapped[str | None] = mapped_column(String, nullable=True)
	max_points: Mapped[float] = mapped_column(Float, default=100.0, nullable=False)
	weight: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # pondération dans la note finale
	allow_late: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	late_penalty: Mapped[float | None] = mapped_column(Float, nullable=True)  # pourcentage de pénalité par jour
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	submission_format: Mapped[str | None] = mapped_column(String(50), nullable=True)  # file, text, url, code
	instructions: Mapped[str | None] = mapped_column(Text, nullable=True)


class UniversitySubmission(NOKIROVABase, NOKIROVAModelMixin):
	"""Soumission de devoir"""

	__tablename__ = "university_submissions"

	assignment_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False),
		ForeignKey("university_assignments.id", ondelete="CASCADE"),
		nullable=False,
		index=True,
	)
	student_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)
	file_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	status: Mapped[str] = mapped_column(
		String(20), default="submitted", nullable=False
	)  # submitted, graded, returned, late
	score: Mapped[float | None] = mapped_column(Float, nullable=True)
	feedback: Mapped[str | None] = mapped_column(Text, nullable=True)
	graded_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	submitted_at: Mapped[str] = mapped_column(String, nullable=False)
	graded_at: Mapped[str | None] = mapped_column(String, nullable=True)


class UniversityGrade(NOKIROVABase, NOKIROVAModelMixin):
	"""Note universitaire"""

	__tablename__ = "university_grades"

	student_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	assignment_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_assignments.id", ondelete="SET NULL"), nullable=True
	)
	grade_type: Mapped[str] = mapped_column(String(30), nullable=False)  # assignment, exam, participation, final
	score: Mapped[float] = mapped_column(Float, nullable=False)
	max_score: Mapped[float] = mapped_column(Float, nullable=False)
	weight: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	letter_grade: Mapped[str | None] = mapped_column(String(5), nullable=True)
	comment: Mapped[str | None] = mapped_column(Text, nullable=True)
	graded_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)


class UniversityAnnouncement(NOKIROVABase, NOKIROVAModelMixin):
	"""Annonce de cours"""

	__tablename__ = "university_announcements"

	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=True, index=True
	)
	author_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	content: Mapped[str] = mapped_column(Text, nullable=False)
	priority: Mapped[str] = mapped_column(String(20), default="normal", nullable=False)  # low, normal, high, urgent
	is_pinned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	expires_at: Mapped[str | None] = mapped_column(String, nullable=True)


class UniversitySchedule(NOKIROVABase, NOKIROVAModelMixin):
	"""Créneau horaire de cours"""

	__tablename__ = "university_schedules"

	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	day_of_week: Mapped[str] = mapped_column(String(10), nullable=False)  # lundi, mardi, etc.
	start_time: Mapped[str] = mapped_column(String, nullable=False)  # HH:MM
	end_time: Mapped[str] = mapped_column(String, nullable=False)
	room: Mapped[str | None] = mapped_column(String(100), nullable=True)
	is_virtual: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	meeting_url: Mapped[str | None] = mapped_column(Text, nullable=True)


class UniversityPrerequisite(NOKIROVABase, NOKIROVAModelMixin):
	"""Prérequis de cours"""

	__tablename__ = "university_prerequisites"

	course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False, index=True
	)
	required_course_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="CASCADE"), nullable=False
	)
	prerequisite_type: Mapped[str] = mapped_column(
		String(20), default="required", nullable=False
	)  # required, recommended, co_requisite
	min_grade: Mapped[str | None] = mapped_column(String(5), nullable=True)  # note minimale requise
