"""
NOKIROVA — Modèles du domaine Utilisateurs

Tables : users, user_profiles, user_preferences, user_devices.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class User(NOKIROVABase, NOKIROVAModelMixin):
	"""Utilisateur NOKIROVA"""

	__tablename__ = "users"

	email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False, index=True)
	username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
	password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
	role: Mapped[str] = mapped_column(String(20), default="student", nullable=False, index=True)
	is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_2fa_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	totp_secret: Mapped[str | None] = mapped_column(String(255), nullable=True)
	avatar_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	last_login_at: Mapped[str | None] = mapped_column(String, nullable=True)  # datetime iso
	login_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	failed_login_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	locked_until: Mapped[str | None] = mapped_column(String, nullable=True)  # datetime iso
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	timezone: Mapped[str] = mapped_column(String(50), default="Europe/Paris", nullable=False)

	# Relations
	profile = relationship("UserProfile", back_populates="user", uselist=False)
	preferences = relationship("UserPreference", back_populates="user", uselist=False)
	consent = relationship("UserConsent", back_populates="user", uselist=False)


class UserProfile(NOKIROVABase, NOKIROVAModelMixin):
	"""Profil utilisateur étendu"""

	__tablename__ = "user_profiles"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
	)
	first_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
	last_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
	display_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
	bio: Mapped[str | None] = mapped_column(Text, nullable=True)
	birth_date: Mapped[str | None] = mapped_column(String, nullable=True)  # date iso
	institution: Mapped[str | None] = mapped_column(String(255), nullable=True)
	degree: Mapped[str | None] = mapped_column(String(255), nullable=True)
	study_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
	skills: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
	interests: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
	social_links: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # {linkedin, github, etc.}

	# Relations
	user = relationship("User", back_populates="profile")


class UserPreference(NOKIROVABase, NOKIROVAModelMixin):
	"""Préférences utilisateur"""

	__tablename__ = "user_preferences"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
	)
	theme: Mapped[str] = mapped_column(String(20), default="system", nullable=False)  # light, dark, system
	font_size: Mapped[str] = mapped_column(String(10), default="medium", nullable=False)  # small, medium, large
	notifications_email: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	notifications_push: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	notifications_in_app: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	ai_model_preference: Mapped[str | None] = mapped_column(String(50), nullable=True)
	adaptive_ui: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	study_reminder_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	study_reminder_time: Mapped[str | None] = mapped_column(String(5), nullable=True)  # HH:MM
	focus_mode_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	reduced_motion: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	high_contrast: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

	# Relations
	user = relationship("User", back_populates="preferences")


class UserConsent(NOKIROVABase, NOKIROVAModelMixin):
	"""Consentements RGPD utilisateur"""

	__tablename__ = "user_consents"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True
	)
	marketing: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	analytics: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	ai_personalization: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	data_sharing: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

	# Relations
	user = relationship("User", back_populates="consent")


class UserDevice(NOKIROVABase, NOKIROVAModelMixin):
	"""Appareils connectés de l'utilisateur"""

	__tablename__ = "user_devices"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	device_type: Mapped[str] = mapped_column(String(50), nullable=False)  # desktop, mobile, tablet
	device_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
	os: Mapped[str | None] = mapped_column(String(100), nullable=True)
	browser: Mapped[str | None] = mapped_column(String(100), nullable=True)
	push_token: Mapped[str | None] = mapped_column(Text, nullable=True)
	last_used_at: Mapped[str | None] = mapped_column(String, nullable=True)
