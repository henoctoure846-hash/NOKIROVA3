"""
NOKIROVA — Modèles du domaine Marketplace (Place de marché)

Tables : marketplace_categories, marketplace_items, marketplace_reviews, marketplace_purchases.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class MarketplaceCategory(NOKIROVABase, NOKIROVAModelMixin):
	"""Catégorie de la place de marché"""

	__tablename__ = "marketplace_categories"

	name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	slug: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	parent_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("marketplace_categories.id", ondelete="SET NULL"), nullable=True
	)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	is_featured: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	item_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	color: Mapped[str | None] = mapped_column(String(20), nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	items = relationship("MarketplaceItem", back_populates="category", cascade="all, delete-orphan")


class MarketplaceItem(NOKIROVABase, NOKIROVAModelMixin):
	"""Article de la place de marché"""

	__tablename__ = "marketplace_items"

	category_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False),
		ForeignKey("marketplace_categories.id", ondelete="SET NULL"),
		nullable=True,
		index=True,
	)
	author_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	item_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # course, template, plugin, dataset, flashcard_deck, study_guide
	price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)  # 0 = gratuit
	currency: Mapped[str] = mapped_column(String(3), default="EUR", nullable=False)
	is_free: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	download_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	rating_avg: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	rating_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	cover_image: Mapped[str | None] = mapped_column(Text, nullable=True)
	preview_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	content_ref: Mapped[str | None] = mapped_column(Text, nullable=True)  # référence vers le contenu réel
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	license_type: Mapped[str] = mapped_column(String(30), default="cc-by", nullable=False)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	category = relationship("MarketplaceCategory", back_populates="items")
	reviews = relationship("MarketplaceReview", back_populates="item", cascade="all, delete-orphan")
	purchases = relationship("MarketplacePurchase", back_populates="item", cascade="all, delete-orphan")


class MarketplaceReview(NOKIROVABase, NOKIROVAModelMixin):
	"""Avis sur un article de la place de marché"""

	__tablename__ = "marketplace_reviews"

	item_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("marketplace_items.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	rating: Mapped[int] = mapped_column(Integer, nullable=False)  # 1-5
	title: Mapped[str | None] = mapped_column(String(200), nullable=True)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)
	is_verified_purchase: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

	# Relations
	item = relationship("MarketplaceItem", back_populates="reviews")


class MarketplacePurchase(NOKIROVABase, NOKIROVAModelMixin):
	"""Achat sur la place de marché"""

	__tablename__ = "marketplace_purchases"

	item_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("marketplace_items.id", ondelete="CASCADE"), nullable=False, index=True
	)
	buyer_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	price_paid: Mapped[float] = mapped_column(Float, nullable=False)
	currency: Mapped[str] = mapped_column(String(3), default="EUR", nullable=False)
	payment_method: Mapped[str | None] = mapped_column(String(50), nullable=True)
	payment_ref: Mapped[str | None] = mapped_column(String(200), nullable=True)
	status: Mapped[str] = mapped_column(
		String(20), default="completed", nullable=False
	)  # pending, completed, refunded

	# Relations
	item = relationship("MarketplaceItem", back_populates="purchases")
