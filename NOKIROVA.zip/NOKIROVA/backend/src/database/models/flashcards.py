"""
NOKIROVA — Modèles du domaine Flashcards (Cartes mémoire)

Tables : flashcard_decks, flashcards, flashcard_reviews, flashcard_study_sessions.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class FlashcardDeck(NOKIROVABase, NOKIROVAModelMixin):
	"""Paquet de cartes mémoire"""

	__tablename__ = "flashcard_decks"

	title: Mapped[str] = mapped_column(String(200), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True
	)
	is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	card_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	difficulty: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)  # easy, medium, hard
	algorithm: Mapped[str] = mapped_column(
		String(30), default="spaced_repetition", nullable=False
	)  # spaced_repetition, leitner, custom
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	cover_image: Mapped[str | None] = mapped_column(Text, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	cards = relationship("Flashcard", back_populates="deck", cascade="all, delete-orphan")
	reviews = relationship("FlashcardReview", back_populates="deck", cascade="all, delete-orphan")


class Flashcard(NOKIROVABase, NOKIROVAModelMixin):
	"""Carte mémoire"""

	__tablename__ = "flashcards"

	deck_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("flashcard_decks.id", ondelete="CASCADE"), nullable=False, index=True
	)
	front_content: Mapped[str] = mapped_column(Text, nullable=False)
	back_content: Mapped[str] = mapped_column(Text, nullable=False)
	card_type: Mapped[str] = mapped_column(
		String(20), default="basic", nullable=False
	)  # basic, cloze, image, audio
	hint: Mapped[str | None] = mapped_column(Text, nullable=True)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	difficulty: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)  # easy, medium, hard
	media_urls: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	interval_days: Mapped[int] = mapped_column(Integer, default=1, nullable=False)  # espacement en jours (SM-2)
	ease_factor: Mapped[float] = mapped_column(Float, default=2.5, nullable=False)  # facteur de facilité
	repetitions: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	next_review_at: Mapped[str | None] = mapped_column(String, nullable=True)
	last_reviewed_at: Mapped[str | None] = mapped_column(String, nullable=True)

	# Relations
	deck = relationship("FlashcardDeck", back_populates="cards")


class FlashcardReview(NOKIROVABase, NOKIROVAModelMixin):
	"""Revue de carte mémoire (réponse d'un utilisateur)"""

	__tablename__ = "flashcard_reviews"

	deck_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("flashcard_decks.id", ondelete="CASCADE"), nullable=False, index=True
	)
	card_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("flashcards.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	quality: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-5 échelle SM-2 (0=oubli, 5=parfait)
	response_time_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
	reviewed_at: Mapped[str] = mapped_column(String, nullable=False)

	# Relations
	deck = relationship("FlashcardDeck", back_populates="reviews")


class FlashcardStudySession(NOKIROVABase, NOKIROVAModelMixin):
	"""Session d'étude de cartes mémoire"""

	__tablename__ = "flashcard_study_sessions"

	deck_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("flashcard_decks.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	cards_reviewed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	cards_correct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	duration_seconds: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	started_at: Mapped[str] = mapped_column(String, nullable=False)
	ended_at: Mapped[str | None] = mapped_column(String, nullable=True)
	session_type: Mapped[str] = mapped_column(String(20), default="review", nullable=False)  # review, learn, cram
