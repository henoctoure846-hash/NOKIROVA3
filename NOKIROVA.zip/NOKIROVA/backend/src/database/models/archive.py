"""
NOKIROVA — Modèles du domaine Archive

Tables : archive_records, archive_policies.
Pas de suppression permanente — les données sont archivées.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class ArchiveRecord(NOKIROVABase, NOKIROVAModelMixin):
	"""Enregistrement archivé (soft delete permanent)"""

	__tablename__ = "archive_records"

	original_table: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	original_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False, index=True)
	original_data: Mapped[dict] = mapped_column(JSONB, nullable=False)  # Instantané complet des données
	archived_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	archive_reason: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # user_deleted, expired, policy, admin_action
	policy_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("archive_policies.id", ondelete="SET NULL"), nullable=True
	)
	original_created_at: Mapped[str | None] = mapped_column(String, nullable=True)
	original_updated_at: Mapped[str | None] = mapped_column(String, nullable=True)
	is_restorable: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	restored_at: Mapped[str | None] = mapped_column(String, nullable=True)
	restored_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	scheduled_purge_at: Mapped[str | None] = mapped_column(String, nullable=True)  # Purge définitive planifiée
	is_purged: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	purged_at: Mapped[str | None] = mapped_column(String, nullable=True)
	storage_path: Mapped[str | None] = mapped_column(String(500), nullable=True)  # Chemin stockage froid
	compressed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
	related_archives: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # IDs des archives liées
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class ArchivePolicy(NOKIROVABase, NOKIROVAModelMixin):
	"""Politique d'archivage"""

	__tablename__ = "archive_policies"

	name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	resource_type: Mapped[str] = mapped_column(String(50), nullable=False)  # Table concernée
	retention_days: Mapped[int] = mapped_column(Integer, nullable=False)  # Durée de rétention en jours
	archive_after_days: Mapped[int] = mapped_column(Integer, nullable=False)  # Archiver après X jours d'inactivité
	auto_archive: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	auto_purge: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	purge_after_days: Mapped[int | None] = mapped_column(Integer, nullable=True)  # Purge définitive après X jours
	compress: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	conditions: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Conditions additionnelles
