"""
NOKIROVA — Modèles du domaine OCR

Tables : ocr_jobs, ocr_results, ocr_pages.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class OCRJob(NOKIROVABase, NOKIROVAModelMixin):
	"""Tâche OCR"""

	__tablename__ = "ocr_jobs"

	file_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("storage_files.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
	status: Mapped[str] = mapped_column(
		String(20), default="pending", nullable=False
	)  # pending, processing, completed, failed, retrying
	engine: Mapped[str] = mapped_column(
		String(50), default="tesseract", nullable=False
	)  # tesseract, papyrus, google_vision
	language: Mapped[str] = mapped_column(String(10), default="fra", nullable=False)
	page_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	processed_pages: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	confidence_avg: Mapped[float | None] = mapped_column(Float, nullable=True)
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	retry_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	max_retries: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	completed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	processing_time_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
	config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Configuration OCR


class OCRResult(NOKIROVABase, NOKIROVAModelMixin):
	"""Résultat OCR d'un document"""

	__tablename__ = "ocr_results"

	job_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ocr_jobs.id", ondelete="CASCADE"), nullable=False, index=True
	)
	document_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="SET NULL"), nullable=True
	)
	full_text: Mapped[str | None] = mapped_column(Text, nullable=True)
	structured_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Sections, titres, tables
	confidence_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	word_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	language_detected: Mapped[str | None] = mapped_column(String(10), nullable=True)


class OCRPage(NOKIROVABase, NOKIROVAModelMixin):
	"""Résultat OCR d'une page"""

	__tablename__ = "ocr_pages"

	job_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ocr_jobs.id", ondelete="CASCADE"), nullable=False, index=True
	)
	page_number: Mapped[int] = mapped_column(Integer, nullable=False)
	text: Mapped[str | None] = mapped_column(Text, nullable=True)
	confidence: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	blocks: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Blocs de texte avec positions
	has_images: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	has_tables: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	has_formulas: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	image_urls: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # Images extraites
