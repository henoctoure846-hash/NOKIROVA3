"""
NOKIROVA — Modèles du domaine Plugins

Tables : plugins, plugin_configs, plugin_hooks, plugin_permissions.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Plugin(NOKIROVABase, NOKIROVAModelMixin):
	"""Plugin / Extension"""

	__tablename__ = "plugins"

	name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	slug: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	version: Mapped[str] = mapped_column(String(30), nullable=False)
	author_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	plugin_type: Mapped[str] = mapped_column(
		String(30), default="community", nullable=False
	)  # official, community, custom
	category: Mapped[str] = mapped_column(String(50), nullable=False)  # ai, ui, content, integration, analytics
	homepage_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	repo_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	is_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_installed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_premium: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	price: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	download_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	rating_avg: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	rating_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	min_app_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
	max_app_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
	entry_point: Mapped[str | None] = mapped_column(String(200), nullable=True)  # chemin du point d'entrée
	settings_schema: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # schéma JSON des paramètres
	default_config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	permissions_required: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	hooks: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # hooks déclarés
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	configs = relationship("PluginConfig", back_populates="plugin", cascade="all, delete-orphan")


class PluginConfig(NOKIROVABase, NOKIROVAModelMixin):
	"""Configuration d'un plugin pour un utilisateur"""

	__tablename__ = "plugin_configs"

	plugin_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("plugins.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	config_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	plugin = relationship("Plugin", back_populates="configs")


class PluginHook(NOKIROVABase, NOKIROVAModelMixin):
	"""Point d'accroche (hook) d'un plugin"""

	__tablename__ = "plugin_hooks"

	plugin_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("plugins.id", ondelete="CASCADE"), nullable=False, index=True
	)
	hook_name: Mapped[str] = mapped_column(
		String(100), nullable=False, index=True
	)  # before_save, after_login, on_render, etc.
	hook_type: Mapped[str] = mapped_column(String(20), default="action", nullable=False)  # action, filter, event
	priority: Mapped[int] = mapped_column(Integer, default=10, nullable=False)
	handler_path: Mapped[str] = mapped_column(String(500), nullable=False)  # chemin vers le gestionnaire


class PluginPermission(NOKIROVABase, NOKIROVAModelMixin):
	"""Permission requise par un plugin"""

	__tablename__ = "plugin_permissions"

	plugin_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("plugins.id", ondelete="CASCADE"), nullable=False, index=True
	)
	permission_name: Mapped[str] = mapped_column(String(100), nullable=False)  # read_courses, write_documents, etc.
	permission_type: Mapped[str] = mapped_column(String(20), default="allow", nullable=False)  # allow, deny
	scope: Mapped[str] = mapped_column(String(30), default="user", nullable=False)  # user, course, global
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
