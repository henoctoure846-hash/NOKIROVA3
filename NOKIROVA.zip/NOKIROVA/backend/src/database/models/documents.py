"""
NOKIROVA — Modèles du domaine Documents

Tables : documents, document_versions, document_folders, document_collaborators, document_shares.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Document(NOKIROVABase, NOKIROVAModelMixin):
	"""Document collaboratif"""

	__tablename__ = "documents"

	title: Mapped[str] = mapped_column(String(500), nullable=False)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	folder_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("document_folders.id", ondelete="SET NULL"), nullable=True
	)
	doc_type: Mapped[str] = mapped_column(
		String(30), default="note", nullable=False
	)  # note, paper, report, summary, presentation
	content: Mapped[str | None] = mapped_column(Text, nullable=True)  # contenu markdown ou JSON
	word_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	is_template: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	status: Mapped[str] = mapped_column(
		String(20), default="draft", nullable=False
	)  # draft, review, published, archived
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	current_version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

	# Relations
	versions = relationship("DocumentVersion", back_populates="document", cascade="all, delete-orphan")
	collaborators = relationship("DocumentCollaborator", back_populates="document", cascade="all, delete-orphan")


class DocumentVersion(NOKIROVABase, NOKIROVAModelMixin):
	"""Version d'un document"""

	__tablename__ = "document_versions"

	document_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True
	)
	version_number: Mapped[int] = mapped_column(Integer, nullable=False)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)
	change_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
	edited_by: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
	)
	word_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

	# Relations
	document = relationship("Document", back_populates="versions")


class DocumentFolder(NOKIROVABase, NOKIROVAModelMixin):
	"""Dossier de documents"""

	__tablename__ = "document_folders"

	name: Mapped[str] = mapped_column(String(200), nullable=False)
	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	parent_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("document_folders.id", ondelete="CASCADE"), nullable=True
	)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	color: Mapped[str | None] = mapped_column(String(20), nullable=True)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class DocumentCollaborator(NOKIROVABase, NOKIROVAModelMixin):
	"""Collaborateur sur un document"""

	__tablename__ = "document_collaborators"

	document_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	role: Mapped[str] = mapped_column(
		String(20), default="viewer", nullable=False
	)  # owner, editor, commenter, viewer
	can_share: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

	# Relations
	document = relationship("Document", back_populates="collaborators")


class DocumentShare(NOKIROVABase, NOKIROVAModelMixin):
	"""Lien de partage de document"""

	__tablename__ = "document_shares"

	document_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True
	)
	shared_by: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
	)
	share_token: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
	permission: Mapped[str] = mapped_column(String(20), default="view", nullable=False)  # view, comment, edit
	expires_at: Mapped[str | None] = mapped_column(String, nullable=True)
	password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
	access_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
