"""
NOKIROVA — Modèles du domaine IA

Tables : ai_agents, ai_conversations, ai_messages, ai_reasoning_chains, ai_model_configs, ai_usage_logs.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class AIAgent(NOKIROVABase, NOKIROVAModelMixin):
	"""Agent IA configuré"""

	__tablename__ = "ai_agents"

	name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	agent_type: Mapped[str] = mapped_column(String(50), nullable=False)  # tutor, assistant, evaluator, creative
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	model_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ai_model_configs.id", ondelete="SET NULL"), nullable=True
	)
	system_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
	temperature: Mapped[float] = mapped_column(Float, default=0.7, nullable=False)
	max_tokens: Mapped[int] = mapped_column(Integer, default=2048, nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	conversations = relationship("AIMessage", back_populates="conversation", cascade="all, delete-orphan")


class AIConversation(NOKIROVABase, NOKIROVAModelMixin):
	"""Conversation avec l'IA"""

	__tablename__ = "ai_conversations"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	agent_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ai_agents.id", ondelete="SET NULL"), nullable=True
	)
	title: Mapped[str | None] = mapped_column(String(255), nullable=True)
	context: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	is_archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	summary: Mapped[str | None] = mapped_column(Text, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	messages = relationship("AIMessage", back_populates="conversation", cascade="all, delete-orphan")


class AIMessage(NOKIROVABase, NOKIROVAModelMixin):
	"""Message dans une conversation IA"""

	__tablename__ = "ai_messages"

	conversation_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ai_conversations.id", ondelete="CASCADE"), nullable=False, index=True
	)
	role: Mapped[str] = mapped_column(String(20), nullable=False)  # user, assistant, system, tool
	content: Mapped[str] = mapped_column(Text, nullable=False)
	token_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
	model_used: Mapped[str | None] = mapped_column(String(100), nullable=True)
	latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
	cost: Mapped[float | None] = mapped_column(Float, nullable=True)
	tool_calls: Mapped[list | None] = mapped_column(JSONB, nullable=True)

	# Relations
	conversation = relationship("AIConversation", back_populates="messages")
	reasoning_chain = relationship("AIReasoningChain", back_populates="message", uselist=False)


class AIReasoningChain(NOKIROVABase, NOKIROVAModelMixin):
	"""Chaîne de raisonnement IA (CoT)"""

	__tablename__ = "ai_reasoning_chains"

	message_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False),
		ForeignKey("ai_messages.id", ondelete="CASCADE"),
		unique=True,
		nullable=False,
		index=True,
	)
	chain_type: Mapped[str] = mapped_column(String(50), nullable=False)  # cot, tot, got
	steps: Mapped[list] = mapped_column(JSONB, nullable=False)
	final_answer: Mapped[str | None] = mapped_column(Text, nullable=True)
	confidence_score: Mapped[float | None] = mapped_column(Float, nullable=True)

	# Relations
	message = relationship("AIMessage", back_populates="reasoning_chain")


class AIModelConfig(NOKIROVABase, NOKIROVAModelMixin):
	"""Configuration d'un modèle IA"""

	__tablename__ = "ai_model_configs"

	provider: Mapped[str] = mapped_column(String(50), nullable=False)  # openai, anthropic, google, local
	model_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	display_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
	api_endpoint: Mapped[str | None] = mapped_column(String(500), nullable=True)
	api_key_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
	context_window: Mapped[int] = mapped_column(Integer, default=4096, nullable=False)
	input_cost_per_1k: Mapped[float | None] = mapped_column(Float, nullable=True)
	output_cost_per_1k: Mapped[float | None] = mapped_column(Float, nullable=True)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	capabilities: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # ["chat", "vision", "code"]
	config: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class AIUsageLog(NOKIROVABase, NOKIROVAModelMixin):
	"""Journal d'utilisation IA"""

	__tablename__ = "ai_usage_logs"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	model_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ai_model_configs.id", ondelete="SET NULL"), nullable=True
	)
	conversation_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("ai_conversations.id", ondelete="SET NULL"), nullable=True
	)
	request_type: Mapped[str] = mapped_column(String(50), nullable=False)  # chat, completion, embedding, image
	prompt_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	completion_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	total_tokens: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	cost: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
	is_cached: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	engine: Mapped[str | None] = mapped_column(String(50), nullable=True)
