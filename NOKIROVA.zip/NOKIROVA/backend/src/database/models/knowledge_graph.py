"""
NOKIROVA — Modèles du domaine Knowledge Graph

Tables : kg_concepts, kg_relationships, kg_attributes, kg_learning_paths.
Graphe de connaissances pour relier les concepts entre eux.
"""

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class KGConcept(NOKIROVABase, NOKIROVAModelMixin):
	"""Concept du graphe de connaissances"""

	__tablename__ = "kg_concepts"

	name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
	display_name: Mapped[str] = mapped_column(String(255), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	concept_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # topic, skill, theory, tool, method, person
	domain: Mapped[str] = mapped_column(String(100), nullable=False, index=True)  # math, physics, cs, etc.
	sub_domain: Mapped[str | None] = mapped_column(String(100), nullable=True)
	difficulty_level: Mapped[str] = mapped_column(
		String(10), default="intermediate", nullable=False
	)  # beginner, intermediate, advanced, expert
	importance: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)  # 0-1, centralité du concept
	aliases: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)  # Noms alternatifs
	tags: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
	prerequisites: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)  # IDs concepts prérequis
	related_courses: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)  # IDs cours liés
	related_documents: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)  # IDs documents liés
	embedding_vector_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), nullable=True
	)  # Référence au vecteur
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	popularity_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	mastery_distribution: Mapped[dict | None] = mapped_column(
		JSONB, nullable=True
	)  # Répartition de maîtrise utilisateurs

	# Relations
	outgoing_relationships = relationship(
		"KGRelationship",
		foreign_keys="KGRelationship.source_concept_id",
		back_populates="source_concept",
		cascade="all, delete-orphan",
	)
	incoming_relationships = relationship(
		"KGRelationship",
		foreign_keys="KGRelationship.target_concept_id",
		back_populates="target_concept",
		cascade="all, delete-orphan",
	)
	attributes = relationship("KGAttribute", back_populates="concept", cascade="all, delete-orphan")


class KGRelationship(NOKIROVABase, NOKIROVAModelMixin):
	"""Relation entre concepts"""

	__tablename__ = "kg_relationships"

	source_concept_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kg_concepts.id", ondelete="CASCADE"), nullable=False, index=True
	)
	target_concept_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kg_concepts.id", ondelete="CASCADE"), nullable=False, index=True
	)
	relationship_type: Mapped[str] = mapped_column(
		String(50), nullable=False, index=True
	)  # prerequisite_of, related_to, part_of, derives_from, contradicts, builds_on
	weight: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # Poids de la relation (0-1)
	confidence: Mapped[float] = mapped_column(Float, default=0.8, nullable=False)  # Confiance dans la relation
	is_bidirectional: Mapped[bool] = mapped_column(default=False, nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	evidence: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Preuves/sources de la relation
	is_ai_generated: Mapped[bool] = mapped_column(default=False, nullable=False)
	is_verified: Mapped[bool] = mapped_column(default=False, nullable=False)
	verified_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)

	# Relations
	source_concept = relationship(
		"KGConcept", foreign_keys="KGRelationship.source_concept_id", back_populates="outgoing_relationships"
	)
	target_concept = relationship(
		"KGConcept", foreign_keys="KGRelationship.target_concept_id", back_populates="incoming_relationships"
	)


class KGAttribute(NOKIROVABase, NOKIROVAModelMixin):
	"""Attribut d'un concept"""

	__tablename__ = "kg_attributes"

	concept_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kg_concepts.id", ondelete="CASCADE"), nullable=False, index=True
	)
	attribute_key: Mapped[str] = mapped_column(
		String(100), nullable=False
	)  # formula, definition, example, application
	attribute_value: Mapped[str] = mapped_column(Text, nullable=False)
	value_type: Mapped[str] = mapped_column(
		String(20), default="text", nullable=False
	)  # text, math, code, url, image
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	source: Mapped[str | None] = mapped_column(String(255), nullable=True)  # Source de l'information
	order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

	# Relations
	concept = relationship("KGConcept", back_populates="attributes")


class KGLearningPath(NOKIROVABase, NOKIROVAModelMixin):
	"""Chemin d'apprentissage dans le graphe"""

	__tablename__ = "kg_learning_paths"

	user_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True
	)
	name: Mapped[str] = mapped_column(String(255), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	target_concept_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("kg_concepts.id", ondelete="CASCADE"), nullable=False
	)
	path_nodes: Mapped[list] = mapped_column(JSONB, nullable=False)  # [{concept_id, order, status}]
	total_concepts: Mapped[int] = mapped_column(Integer, nullable=False)
	completed_concepts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	estimated_hours: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	is_ai_generated: Mapped[bool] = mapped_column(default=False, nullable=False)
	is_public: Mapped[bool] = mapped_column(default=False, nullable=False)
	difficulty_curve: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
