"""
NOKIROVA — Modèles du domaine Notes

Tables : notes, note_annotations, note_links.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Note(NOKIROVABase, NOKIROVAModelMixin):
	"""Note d'étude"""

	__tablename__ = "notes"

	owner_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	title: Mapped[str] = mapped_column(String(500), nullable=False)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)  # Contenu Markdown
	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True, index=True
	)
	lesson_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_lessons.id", ondelete="SET NULL"), nullable=True
	)
	document_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="SET NULL"), nullable=True
	)
	note_type: Mapped[str] = mapped_column(
		String(20), default="personal", nullable=False
	)  # personal, course, annotation
	color: Mapped[str | None] = mapped_column(String(7), nullable=True)
	tags: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
	is_pinned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_ai_generated: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	ai_summary: Mapped[str | None] = mapped_column(Text, nullable=True)  # Résumé IA
	source_page: Mapped[int | None] = mapped_column(Integer, nullable=True)  # Page source
	position_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Position dans le document


class NoteAnnotation(NOKIROVABase, NOKIROVAModelMixin):
	"""Annotation sur un document"""

	__tablename__ = "note_annotations"

	note_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("notes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	document_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True
	)
	annotation_type: Mapped[str] = mapped_column(
		String(20), nullable=False
	)  # highlight, underline, strikeout, comment
	color: Mapped[str | None] = mapped_column(String(7), nullable=True)
	text: Mapped[str | None] = mapped_column(Text, nullable=True)  # Texte de l'annotation
	selected_text: Mapped[str | None] = mapped_column(Text, nullable=True)  # Texte sélectionné
	page_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
	position: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Coordonnées dans le document


class NoteLink(NOKIROVABase, NOKIROVAModelMixin):
	"""Lien entre notes (Knowledge Graph)"""

	__tablename__ = "note_links"

	source_note_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("notes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	target_note_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("notes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	link_type: Mapped[str] = mapped_column(
		String(30), default="related", nullable=False
	)  # related, prerequisite, extends, contradicts, example
	description: Mapped[str | None] = mapped_column(String(500), nullable=True)
	strength: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # 0.0-1.0
