"""
NOKIROVA — Modèles du domaine Monitoring

Tables : health_checks, service_metrics, alerts, alert_rules.
Système de monitoring avec self-healing intégré.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class HealthCheck(NOKIROVABase, NOKIROVAModelMixin):
	"""Vérification de santé des services"""

	__tablename__ = "health_checks"

	service_name: Mapped[str] = mapped_column(
		String(100), nullable=False, index=True
	)  # database, redis, celery, ai_engine, etc.
	status: Mapped[str] = mapped_column(String(20), nullable=False)  # healthy, degraded, unhealthy, dead
	response_time_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
	details: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	checked_at: Mapped[str] = mapped_column(String, nullable=False, index=True)
	next_check_at: Mapped[str | None] = mapped_column(String, nullable=True)


class ServiceMetric(NOKIROVABase, NOKIROVAModelMixin):
	"""Métrique de service"""

	__tablename__ = "service_metrics"

	service_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	metric_name: Mapped[str] = mapped_column(
		String(100), nullable=False
	)  # cpu_usage, memory_usage, request_rate, error_rate
	metric_value: Mapped[float] = mapped_column(Float, nullable=False)
	metric_unit: Mapped[str] = mapped_column(String(20), nullable=False)  # percent, ms, count, bytes
	timestamp: Mapped[str] = mapped_column(String, nullable=False, index=True)
	tags: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class Alert(NOKIROVABase, NOKIROVAModelMixin):
	"""Alerte"""

	__tablename__ = "alerts"

	alert_rule_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("alert_rules.id", ondelete="SET NULL"), nullable=True
	)
	service_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
	severity: Mapped[str] = mapped_column(String(10), nullable=False)  # info, warning, critical, emergency
	title: Mapped[str] = mapped_column(String(255), nullable=False)
	message: Mapped[str] = mapped_column(Text, nullable=False)
	metric_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
	metric_value: Mapped[float | None] = mapped_column(Float, nullable=True)
	threshold_value: Mapped[float | None] = mapped_column(Float, nullable=True)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	is_acknowledged: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	acknowledged_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	acknowledged_at: Mapped[str | None] = mapped_column(String, nullable=True)
	resolved_at: Mapped[str | None] = mapped_column(String, nullable=True)
	auto_resolved: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	self_healing_triggered: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	self_healing_action: Mapped[str | None] = mapped_column(
		String(100), nullable=True
	)  # restart, rebuild, reindex, isolate
	self_healing_result: Mapped[str | None] = mapped_column(String(20), nullable=True)  # success, failed, partial
	notification_sent: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class AlertRule(NOKIROVABase, NOKIROVAModelMixin):
	"""Règle d'alerte"""

	__tablename__ = "alert_rules"

	name: Mapped[str] = mapped_column(String(255), nullable=False)
	service_name: Mapped[str] = mapped_column(String(100), nullable=False)
	metric_name: Mapped[str] = mapped_column(String(100), nullable=False)
	condition: Mapped[str] = mapped_column(String(20), nullable=False)  # gt, lt, gte, lte, eq, neq
	threshold: Mapped[float] = mapped_column(Float, nullable=False)
	duration_seconds: Mapped[int] = mapped_column(Integer, default=60, nullable=False)  # Durée avant déclenchement
	severity: Mapped[str] = mapped_column(String(10), nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	cooldown_seconds: Mapped[int] = mapped_column(Integer, default=300, nullable=False)  # Temps entre alertes
	self_healing_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	self_healing_action: Mapped[str | None] = mapped_column(String(100), nullable=True)
	notification_channels: Mapped[list | None] = mapped_column(
		JSONB, nullable=True
	)  # ["email", "slack", "webhook"]
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
