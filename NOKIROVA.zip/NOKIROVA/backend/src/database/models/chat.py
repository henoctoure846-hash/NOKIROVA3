"""
NOKIROVA — Modèles du domaine Chat

Tables : chat_rooms, chat_messages, chat_members, chat_attachments.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class ChatRoom(NOKIROVABase, NOKIROVAModelMixin):
	"""Salon de discussion"""

	__tablename__ = "chat_rooms"

	name: Mapped[str] = mapped_column(String(100), nullable=False)
	room_type: Mapped[str] = mapped_column(
		String(20), default="group", nullable=False
	)  # direct, group, course, study
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True
	)
	is_private: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	max_members: Mapped[int] = mapped_column(Integer, default=50, nullable=False)
	icon: Mapped[str | None] = mapped_column(String(50), nullable=True)
	created_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)

	# Relations
	messages = relationship("ChatMessage", back_populates="room", cascade="all, delete-orphan")
	members = relationship("ChatMember", back_populates="room", cascade="all, delete-orphan")


class ChatMessage(NOKIROVABase, NOKIROVAModelMixin):
	"""Message de chat"""

	__tablename__ = "chat_messages"

	room_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("chat_rooms.id", ondelete="CASCADE"), nullable=False, index=True
	)
	sender_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=False, index=True
	)
	content: Mapped[str] = mapped_column(Text, nullable=False)
	message_type: Mapped[str] = mapped_column(
		String(20), default="text", nullable=False
	)  # text, image, file, system
	reply_to_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("chat_messages.id", ondelete="SET NULL"), nullable=True
	)
	is_edited: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_pinned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	room = relationship("ChatRoom", back_populates="messages")
	attachments = relationship("ChatAttachment", back_populates="message", cascade="all, delete-orphan")


class ChatMember(NOKIROVABase, NOKIROVAModelMixin):
	"""Membre d'un salon"""

	__tablename__ = "chat_members"

	room_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("chat_rooms.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	role: Mapped[str] = mapped_column(String(20), default="member", nullable=False)  # owner, admin, member
	is_muted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	last_read_at: Mapped[str | None] = mapped_column(String, nullable=True)

	# Relations
	room = relationship("ChatRoom", back_populates="members")


class ChatAttachment(NOKIROVABase, NOKIROVAModelMixin):
	"""Pièce jointe de chat"""

	__tablename__ = "chat_attachments"

	message_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("chat_messages.id", ondelete="CASCADE"), nullable=False, index=True
	)
	file_url: Mapped[str] = mapped_column(Text, nullable=False)
	file_type: Mapped[str] = mapped_column(String(50), nullable=False)  # image, document, video, audio
	file_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
	file_size: Mapped[int | None] = mapped_column(Integer, nullable=True)
	thumbnail_url: Mapped[str | None] = mapped_column(Text, nullable=True)

	# Relations
	message = relationship("ChatMessage", back_populates="attachments")
