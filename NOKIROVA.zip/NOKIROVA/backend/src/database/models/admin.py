"""
NOKIROVA — Modèles du domaine Administration

Tables : admin_roles, admin_permissions, admin_actions, system_settings, maintenance_windows.
"""

from sqlalchemy import Boolean, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class AdminRole(NOKIROVABase, NOKIROVAModelMixin):
	"""Rôle administratif"""

	__tablename__ = "admin_roles"

	name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	priority: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

	# Relations
	user_roles = relationship("AdminUserRole", back_populates="role", cascade="all, delete-orphan")


class AdminUserRole(NOKIROVABase, NOKIROVAModelMixin):
	"""Assignation rôle admin à un utilisateur"""

	__tablename__ = "admin_user_roles"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	role_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("admin_roles.id", ondelete="CASCADE"), nullable=False, index=True
	)
	granted_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	expires_at: Mapped[str | None] = mapped_column(String, nullable=True)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

	# Relations
	role = relationship("AdminRole", back_populates="user_roles")


class AdminAction(NOKIROVABase, NOKIROVAModelMixin):
	"""Action administrative (journal)"""

	__tablename__ = "admin_actions"

	admin_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=False, index=True
	)
	action_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # ban_user, delete_content, update_setting, etc.
	target_type: Mapped[str | None] = mapped_column(String(50), nullable=True)  # user, content, system
	target_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	target_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
	details: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	reason: Mapped[str | None] = mapped_column(Text, nullable=True)
	ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
	is_reversible: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	reversed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	reversed_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)


class SystemSetting(NOKIROVABase, NOKIROVAModelMixin):
	"""Paramètre système"""

	__tablename__ = "system_settings"

	key: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
	value: Mapped[str] = mapped_column(Text, nullable=False)
	value_type: Mapped[str] = mapped_column(
		String(20), default="string", nullable=False
	)  # string, number, boolean, json
	category: Mapped[str] = mapped_column(
		String(50), nullable=False, index=True
	)  # general, ai, storage, security, email
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # Visible par le client
	is_editable: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	default_value: Mapped[str | None] = mapped_column(Text, nullable=True)
	requires_restart: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class MaintenanceWindow(NOKIROVABase, NOKIROVAModelMixin):
	"""Fenêtre de maintenance"""

	__tablename__ = "maintenance_windows"

	title: Mapped[str] = mapped_column(String(255), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	starts_at: Mapped[str] = mapped_column(String, nullable=False)
	ends_at: Mapped[str] = mapped_column(String, nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	affects: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # ["api", "ai_engine", "storage"]
	message: Mapped[str | None] = mapped_column(Text, nullable=True)  # Message affiché aux utilisateurs
	created_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
