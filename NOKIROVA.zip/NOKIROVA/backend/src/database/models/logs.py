"""
NOKIROVA — Modèles du domaine Logs

Tables : system_logs, api_logs, error_logs, audit_trail.
"""

from sqlalchemy import Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class SystemLog(NOKIROVABase, NOKIROVAModelMixin):
	"""Journal système"""

	__tablename__ = "system_logs"

	level: Mapped[str] = mapped_column(
		String(10), nullable=False, index=True
	)  # DEBUG, INFO, WARNING, ERROR, CRITICAL
	module: Mapped[str] = mapped_column(String(100), nullable=False, index=True)  # module source
	message: Mapped[str] = mapped_column(Text, nullable=False)
	stack_trace: Mapped[str | None] = mapped_column(Text, nullable=True)
	context: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Contexte additionnel
	hostname: Mapped[str | None] = mapped_column(String(255), nullable=True)
	process_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
	thread_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
	environment: Mapped[str] = mapped_column(String(20), default="production", nullable=False)
	logger_name: Mapped[str | None] = mapped_column(String(100), nullable=True)


class APILog(NOKIROVABase, NOKIROVAModelMixin):
	"""Journal des appels API"""

	__tablename__ = "api_logs"

	user_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
	)
	method: Mapped[str] = mapped_column(String(10), nullable=False)  # GET, POST, PUT, DELETE
	path: Mapped[str] = mapped_column(String(500), nullable=False, index=True)
	query_params: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	request_headers: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	request_body: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	status_code: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
	response_time_ms: Mapped[float] = mapped_column(Float, nullable=False)
	response_size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
	ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
	user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
	api_version: Mapped[str | None] = mapped_column(String(10), nullable=True)  # v1, v2
	rate_limit_remaining: Mapped[int | None] = mapped_column(Integer, nullable=True)
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	trace_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)  # ID de trace distribué


class ErrorLog(NOKIROVABase, NOKIROVAModelMixin):
	"""Journal des erreurs"""

	__tablename__ = "error_logs"

	error_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)  # TypeError, ValueError, etc.
	error_code: Mapped[str | None] = mapped_column(String(50), nullable=True)  # Code métier
	message: Mapped[str] = mapped_column(Text, nullable=False)
	stack_trace: Mapped[str | None] = mapped_column(Text, nullable=True)
	source_module: Mapped[str | None] = mapped_column(String(100), nullable=True)
	source_file: Mapped[str | None] = mapped_column(String(500), nullable=True)
	line_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
	severity: Mapped[str] = mapped_column(
		String(10), default="error", nullable=False
	)  # warning, error, critical, fatal
	user_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	request_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	context: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	is_resolved: Mapped[bool] = mapped_column(default=False, nullable=False)
	resolved_at: Mapped[str | None] = mapped_column(String, nullable=True)
	resolved_by: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
	)
	resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)
	occurrence_count: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
	first_occurred_at: Mapped[str | None] = mapped_column(String, nullable=True)


class AuditTrail(NOKIROVABase, NOKIROVAModelMixin):
	"""Piste d'audit"""

	__tablename__ = "audit_trail"

	user_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
	)
	action: Mapped[str] = mapped_column(
		String(50), nullable=False, index=True
	)  # create, read, update, delete, export, import, share
	resource_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
	resource_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False, index=True)
	resource_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
	changes: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # {field: {old, new}}
	previous_state: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	new_state: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
	ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
	user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
	session_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	is_suspicious: Mapped[bool] = mapped_column(default=False, nullable=False)
	risk_level: Mapped[str] = mapped_column(
		String(10), default="low", nullable=False
	)  # low, medium, high, critical
