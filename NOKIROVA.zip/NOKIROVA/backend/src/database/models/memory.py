"""
NOKIROVA — Modèles du domaine Mémoire (Jumeau Pédagogique)

Tables : memory_nodes, memory_edges, memory_contexts, memory_snapshots.
Le Jumeau Pédagogique mémorise le parcours, les préférences, et les lacunes de l'étudiant.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class MemoryNode(NOKIROVABase, NOKIROVAModelMixin):
	"""Nœud de mémoire du Jumeau Pédagogique"""

	__tablename__ = "memory_nodes"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	node_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # concept, skill, preference, weakness, strength, goal, event, emotion
	key: Mapped[str] = mapped_column(String(255), nullable=False)  # Clé unique du nœud
	value: Mapped[str | None] = mapped_column(Text, nullable=True)  # Valeur textuelle
	value_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Valeur structurée
	confidence: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # 0.0 - 1.0
	importance: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)  # 0.0 - 1.0
	source: Mapped[str] = mapped_column(String(100), nullable=False)  # quiz, chat, document, explicit, inference
	source_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	decay_rate: Mapped[float] = mapped_column(Float, default=0.01, nullable=False)  # Taux de déclin temporel
	last_accessed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	access_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

	# Relations
	outgoing_edges = relationship(
		"MemoryEdge",
		foreign_keys="MemoryEdge.source_node_id",
		back_populates="source_node",
		cascade="all, delete-orphan",
	)
	incoming_edges = relationship(
		"MemoryEdge",
		foreign_keys="MemoryEdge.target_node_id",
		back_populates="target_node",
		cascade="all, delete-orphan",
	)


class MemoryEdge(NOKIROVABase, NOKIROVAModelMixin):
	"""Lien entre nœuds de mémoire"""

	__tablename__ = "memory_edges"

	source_node_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("memory_nodes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	target_node_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("memory_nodes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	relation_type: Mapped[str] = mapped_column(
		String(100), nullable=False
	)  # prerequisite_of, related_to, strengthens, weakens, depends_on, contradicts
	weight: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	is_bidirectional: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	source_node = relationship(
		"MemoryNode", foreign_keys="MemoryEdge.source_node_id", back_populates="outgoing_edges"
	)
	target_node = relationship(
		"MemoryNode", foreign_keys="MemoryEdge.target_node_id", back_populates="incoming_edges"
	)


class MemoryContext(NOKIROVABase, NOKIROVAModelMixin):
	"""Contexte de mémoire pour une session"""

	__tablename__ = "memory_contexts"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	session_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False, index=True)
	context_type: Mapped[str] = mapped_column(String(50), nullable=False)  # study, quiz, chat, revision, production
	node_ids: Mapped[list | None] = mapped_column(JSONB, nullable=True)  # IDs des nœuds actifs
	summary: Mapped[str | None] = mapped_column(Text, nullable=True)  # Résumé du contexte
	emotional_state: Mapped[str | None] = mapped_column(
		String(30), nullable=True
	)  # confident, confused, frustrated, engaged
	cognitive_load: Mapped[str | None] = mapped_column(String(10), nullable=True)  # low, medium, high
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	ended_at: Mapped[str | None] = mapped_column(String, nullable=True)


class MemorySnapshot(NOKIROVABase, NOKIROVAModelMixin):
	"""Instantané de l'état de la mémoire"""

	__tablename__ = "memory_snapshots"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	snapshot_type: Mapped[str] = mapped_column(
		String(30), default="scheduled", nullable=False
	)  # scheduled, manual, pre_event, post_event
	node_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	edge_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Dump complet
	stats: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Statistiques
	compressed_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # Données compressées
