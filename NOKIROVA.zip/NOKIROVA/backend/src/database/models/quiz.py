"""
NOKIROVA — Modèles du domaine Quiz

Tables : quizzes, quiz_questions, quiz_answers, quiz_attempts.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import NOKIROVABase, NOKIROVAModelMixin


class Quiz(NOKIROVABase, NOKIROVAModelMixin):
	"""Quiz"""

	__tablename__ = "quizzes"

	title: Mapped[str] = mapped_column(String(300), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	course_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_courses.id", ondelete="SET NULL"), nullable=True, index=True
	)
	module_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("university_modules.id", ondelete="SET NULL"), nullable=True
	)
	created_by: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
	)
	quiz_type: Mapped[str] = mapped_column(
		String(30), default="formative", nullable=False
	)  # formative, summative, diagnostic, practice
	difficulty: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)  # easy, medium, hard
	time_limit_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)  # None = pas de limite
	max_attempts: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
	is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	is_adaptive: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # quiz adaptatif via IA
	shuffle_questions: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	shuffle_answers: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	show_correct_answers: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	show_explanation: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	passing_score: Mapped[float] = mapped_column(Float, default=50.0, nullable=False)
	total_points: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
	question_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	tags: Mapped[list | None] = mapped_column(JSONB, nullable=True)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	questions = relationship("QuizQuestion", back_populates="quiz", cascade="all, delete-orphan")
	attempts = relationship("QuizAttempt", back_populates="quiz", cascade="all, delete-orphan")


class QuizQuestion(NOKIROVABase, NOKIROVAModelMixin):
	"""Question de quiz"""

	__tablename__ = "quiz_questions"

	quiz_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("quizzes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	question_text: Mapped[str] = mapped_column(Text, nullable=False)
	question_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # multiple_choice, true_false, short_answer, essay, ordering, matching, fill_blank
	points: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)
	hint: Mapped[str | None] = mapped_column(Text, nullable=True)
	explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
	image_url: Mapped[str | None] = mapped_column(Text, nullable=True)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	difficulty: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

	# Relations
	quiz = relationship("Quiz", back_populates="questions")
	answers = relationship("QuizAnswer", back_populates="question", cascade="all, delete-orphan")


class QuizAnswer(NOKIROVABase, NOKIROVAModelMixin):
	"""Réponse possible à une question de quiz"""

	__tablename__ = "quiz_answers"

	question_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("quiz_questions.id", ondelete="CASCADE"), nullable=False, index=True
	)
	answer_text: Mapped[str] = mapped_column(Text, nullable=False)
	is_correct: Mapped[bool] = mapped_column(Boolean, nullable=False)
	sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
	feedback: Mapped[str | None] = mapped_column(Text, nullable=True)

	# Relations
	question = relationship("QuizQuestion", back_populates="answers")


class QuizAttempt(NOKIROVABase, NOKIROVAModelMixin):
	"""Tentative de quiz par un utilisateur"""

	__tablename__ = "quiz_attempts"

	quiz_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("quizzes.id", ondelete="CASCADE"), nullable=False, index=True
	)
	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	attempt_number: Mapped[int] = mapped_column(Integer, nullable=False)
	status: Mapped[str] = mapped_column(
		String(20), default="in_progress", nullable=False
	)  # in_progress, completed, abandoned, timed_out
	score: Mapped[float | None] = mapped_column(Float, nullable=True)
	max_score: Mapped[float | None] = mapped_column(Float, nullable=True)
	percentage: Mapped[float | None] = mapped_column(Float, nullable=True)
	passed: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
	responses: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # réponses de l'utilisateur par question
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	completed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	time_spent_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)

	# Relations
	quiz = relationship("Quiz", back_populates="attempts")
