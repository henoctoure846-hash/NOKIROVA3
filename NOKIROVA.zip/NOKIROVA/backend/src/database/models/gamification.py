"""
NOKIROVA — Modèles du domaine Gamification

Tables : gamification_badges, gamification_achievements, gamification_user_xp,
         gamification_streaks, gamification_leaderboards, gamification_challenges,
         gamification_rewards.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class GamificationBadge(NOKIROVABase, NOKIROVAModelMixin):
	"""Badge de gamification"""

	__tablename__ = "gamification_badges"

	name: Mapped[str] = mapped_column(String(100), nullable=False)
	description: Mapped[str] = mapped_column(Text, nullable=False)
	icon: Mapped[str] = mapped_column(String(100), nullable=False)  # Nom de l'icône ou URL
	category: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # learning, social, productivity, mastery, special
	rarity: Mapped[str] = mapped_column(
		String(20), default="common", nullable=False
	)  # common, rare, epic, legendary
	xp_reward: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	criteria: Mapped[dict] = mapped_column(JSONB, nullable=False)  # Critères d'obtention
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	is_secret: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # Badge caché
	order_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class GamificationAchievement(NOKIROVABase, NOKIROVAModelMixin):
	"""Succès de gamification"""

	__tablename__ = "gamification_achievements"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	badge_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("gamification_badges.id", ondelete="SET NULL"), nullable=True
	)
	achievement_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # first_quiz, streak_7, mastery_course, etc.
	title: Mapped[str] = mapped_column(String(255), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	xp_earned: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	earned_at: Mapped[str] = mapped_column(String, nullable=False)
	progress: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # 0.0-1.0
	metadata_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class GamificationUserXP(NOKIROVABase, NOKIROVAModelMixin):
	"""Points d'expérience utilisateur"""

	__tablename__ = "gamification_user_xp"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True
	)
	total_xp: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	level: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
	current_level_xp: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	next_level_xp: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
	weekly_xp: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	monthly_xp: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	xp_history: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # Historique quotidien


class GamificationStreak(NOKIROVABase, NOKIROVAModelMixin):
	"""Série de jours consécutifs"""

	__tablename__ = "gamification_streaks"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True
	)
	current_streak: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	longest_streak: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	last_activity_date: Mapped[str | None] = mapped_column(String, nullable=True)
	streak_type: Mapped[str] = mapped_column(String(30), default="daily", nullable=False)  # daily, study, review
	is_frozen: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # Gel de série
	freezes_available: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
	history: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class GamificationLeaderboard(NOKIROVABase, NOKIROVAModelMixin):
	"""Classement"""

	__tablename__ = "gamification_leaderboards"

	name: Mapped[str] = mapped_column(String(255), nullable=False)
	leaderboard_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # global, course, group, weekly, monthly
	scope_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)  # ID du cours/groupe
	period: Mapped[str | None] = mapped_column(String(20), nullable=True)  # weekly, monthly, all_time
	entries: Mapped[dict | None] = mapped_column(JSONB, nullable=True)  # [{user_id, xp, rank, ...}]
	last_updated_at: Mapped[str | None] = mapped_column(String, nullable=True)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class GamificationChallenge(NOKIROVABase, NOKIROVAModelMixin):
	"""Défi de gamification"""

	__tablename__ = "gamification_challenges"

	title: Mapped[str] = mapped_column(String(255), nullable=False)
	description: Mapped[str | None] = mapped_column(Text, nullable=True)
	challenge_type: Mapped[str] = mapped_column(String(30), nullable=False)  # daily, weekly, monthly, special
	objective: Mapped[str] = mapped_column(String(100), nullable=False)  # quiz_count, study_minutes, streak_days
	target_value: Mapped[int] = mapped_column(Integer, nullable=False)
	xp_reward: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	badge_id: Mapped[str | None] = mapped_column(
		UUID(as_uuid=False), ForeignKey("gamification_badges.id", ondelete="SET NULL"), nullable=True
	)
	starts_at: Mapped[str | None] = mapped_column(String, nullable=True)
	ends_at: Mapped[str | None] = mapped_column(String, nullable=True)
	is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
	participant_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	completion_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class GamificationReward(NOKIROVABase, NOKIROVAModelMixin):
	"""Récompense"""

	__tablename__ = "gamification_rewards"

	user_id: Mapped[str] = mapped_column(
		UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
	)
	reward_type: Mapped[str] = mapped_column(
		String(50), nullable=False
	)  # xp, badge, title, feature_unlock, discount
	reward_value: Mapped[str] = mapped_column(String(255), nullable=False)
	source: Mapped[str] = mapped_column(String(50), nullable=False)  # challenge, achievement, streak, admin
	source_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
	claimed_at: Mapped[str | None] = mapped_column(String, nullable=True)
	expires_at: Mapped[str | None] = mapped_column(String, nullable=True)
	is_claimed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
