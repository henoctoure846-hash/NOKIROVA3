"""
NOKIROVA — Modèles du domaine Indexation

Tables : search_index, vector_embeddings, index_jobs.
Innovation : Knowledge Graph + Knowledge Lake.
"""

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from ..base import NOKIROVABase, NOKIROVAModelMixin


class SearchIndex(NOKIROVABase, NOKIROVAModelMixin):
	"""Index de recherche plein texte"""

	__tablename__ = "indexing_search"

	resource_type: Mapped[str] = mapped_column(
		String(50), nullable=False, index=True
	)  # document, course, lesson, note
	resource_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False, index=True)
	title: Mapped[str] = mapped_column(String(500), nullable=False)
	content: Mapped[str | None] = mapped_column(Text, nullable=True)  # Contenu textuel indexé
	summary: Mapped[str | None] = mapped_column(Text, nullable=True)  # Résumé pour recherche sémantique
	keywords: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
	language: Mapped[str] = mapped_column(String(10), default="fr", nullable=False)
	owner_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
	is_public: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
	relevance_score: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)


class VectorEmbedding(NOKIROVABase, NOKIROVAModelMixin):
	"""Embeddings vectoriels pour recherche sémantique (pgvector)"""

	__tablename__ = "indexing_vectors"

	resource_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
	resource_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False, index=True)
	chunk_index: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # Pour les documents découpés
	chunk_text: Mapped[str | None] = mapped_column(Text, nullable=True)  # Texte du chunk
	embedding_model: Mapped[str] = mapped_column(String(50), nullable=False)  # text-embedding-3-small, etc.
	embedding_dim: Mapped[int] = mapped_column(Integer, default=1536, nullable=False)
	# Note: la colonne vector est ajoutée via migration Alembic avec pgvector
	# vector = mapped_column(Vector(1536), nullable=True)
	index_metadata: Mapped[dict | None] = mapped_column(JSONB, nullable=True)


class IndexJob(NOKIROVABase, NOKIROVAModelMixin):
	"""Tâche d'indexation"""

	__tablename__ = "indexing_jobs"

	resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
	resource_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False)
	job_type: Mapped[str] = mapped_column(
		String(30), nullable=False
	)  # full_index, update_index, reindex, delete_index
	status: Mapped[str] = mapped_column(
		String(20), default="pending", nullable=False
	)  # pending, processing, completed, failed
	chunks_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	embeddings_created: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
	error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
	started_at: Mapped[str | None] = mapped_column(String, nullable=True)
	completed_at: Mapped[str | None] = mapped_column(String, nullable=True)
