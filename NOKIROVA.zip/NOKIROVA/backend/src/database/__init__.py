"""
NOKIROVA — Couche base de données

Initialisation du moteur, de la session et import des modèles.
"""

from .base import NOKIROVABase, NOKIROVAModelMixin
from .base_repository import BaseRepository
from .engine import dispose_engine, get_engine

# Import de tous les modèles pour enregistrement ORM
from .models import *  # noqa: F401, F403
from .session import get_db, get_session_factory

__all__ = [
	"get_engine",
	"dispose_engine",
	"get_db",
	"get_session_factory",
	"NOKIROVABase",
	"NOKIROVAModelMixin",
	"BaseRepository",
]
