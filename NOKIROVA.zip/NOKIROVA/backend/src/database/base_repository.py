"""
NOKIROVA — Dépôt de base générique

Classe de base pour tous les dépôts, éliminant la duplication
de ~150 lignes de CRUD par dépôt. Conforme au principe
BIBLE #4 (Élégance) — factorisation du code répétitif.

Utilisation :
	class DocumentRepository(BaseRepository[Document]):
		async def get_by_owner(self, owner_id: str): ...
"""

from collections.abc import Sequence
from typing import Generic, TypeVar

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.base import NOKIROVAModelMixin

# ── Type générique pour le modèle SQLAlchemy ────────────────────────

ModelType = TypeVar("ModelType", bound=NOKIROVAModelMixin)


# ── Dépôt de base ───────────────────────────────────────────────────


class BaseRepository(Generic[ModelType]):
	"""
	Dépôt générique avec opérations CRUD communes.

	Fournit : create, get_by_id, get_by_id_active, list_all,
	count, update, soft_delete, restore.
	Les sous-classes ajoutent les requêtes spécifiques au domaine.
	"""

	def __init__(self, model: type[ModelType], session: AsyncSession) -> None:
		"""
		Initialise le dépôt.

		Args:
			model: La classe du modèle SQLAlchemy (ex: Document).
			session: La session AsyncSession active.
		"""
		self.model = model
		self.session = session

	# ── Création ────────────────────────────────────────────────

	async def create(self, data: dict) -> ModelType:
		"""
		Crée une nouvelle entité.

		Args:
			data: Dictionnaire des champs à hydrater.

		Returns:
			L'entité créée, rafraîchie depuis la base.
		"""
		instance = self.model(**data)
		self.session.add(instance)
		await self.session.flush()
		return instance

	# ── Lecture ─────────────────────────────────────────────────

	async def get_by_id(self, entity_id: str) -> ModelType | None:
		"""
		Récupère une entité par son identifiant (actif ou non).

		Args:
			entity_id: Identifiant UUID de l'entité.

		Returns:
			L'entité ou None si introuvable.
		"""
		stmt = select(self.model).where(self.model.id == entity_id)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def get_by_id_active(self, entity_id: str) -> ModelType | None:
		"""
		Récupère une entité active par son identifiant.
		Filtre automatiquement par is_active=True.

		Args:
			entity_id: Identifiant UUID de l'entité.

		Returns:
			L'entité active ou None.
		"""
		stmt = select(self.model).where(
			and_(
				self.model.id == entity_id,
				self.model.is_active == True,  # noqa: E712
			)
		)
		result = await self.session.execute(stmt)
		return result.scalar_one_or_none()

	async def list_all(
		self,
		offset: int = 0,
		limit: int = 50,
		active_only: bool = True,
		order_by: str = "created_at",
		descending: bool = True,
	) -> Sequence[ModelType]:
		"""
		Liste les entités avec pagination.

		Args:
			offset: Décalage pour la pagination.
			limit: Nombre maximal de résultats.
			active_only: Si True, filtre par is_active=True.
			order_by: Champ de tri (défaut: created_at).
			descending: Tri décroissant si True.

		Returns:
			Séquence d'entités.
		"""
		stmt = select(self.model)
		if active_only:
			stmt = stmt.where(
				self.model.is_active == True  # noqa: E712
			)
		order_col = getattr(self.model, order_by, self.model.created_at)
		stmt = stmt.order_by(order_col.desc()) if descending else stmt.order_by(order_col.asc())
		stmt = stmt.offset(offset).limit(limit)
		result = await self.session.execute(stmt)
		return result.scalars().all()

	async def count(self, active_only: bool = True) -> int:
		"""
		Compte les entités.

		Args:
			active_only: Si True, ne compte que les actives.

		Returns:
			Nombre d'entités.
		"""
		stmt = select(func.count()).select_from(self.model)
		if active_only:
			stmt = stmt.where(
				self.model.is_active == True  # noqa: E712
			)
		result = await self.session.execute(stmt)
		return result.scalar() or 0

	# ── Mise à jour ────────────────────────────────────────────

	async def update(self, entity_id: str, data: dict) -> ModelType | None:
		"""
		Met à jour une entité par attributs.
		NOKIROVAModelMixin gère updated_at automatiquement.

		Args:
			entity_id: Identifiant UUID de l'entité.
			data: Dictionnaire des champs à modifier.

		Returns:
			L'entité mise à jour ou None si introuvable.
		"""
		instance = await self.get_by_id_active(entity_id)
		if not instance:
			return None
		for key, value in data.items():
			if hasattr(instance, key) and value is not None:
				setattr(instance, key, value)
		await self.session.flush()
		return instance

	async def update_by_id(self, entity_id: str, data: dict) -> ModelType | None:
		"""
		Met à jour via SQL UPDATE (plus performant pour mise à jour en masse).

		Args:
			entity_id: Identifiant UUID de l'entité.
			data: Dictionnaire des champs à modifier.

		Returns:
			L'entité rafraîchie ou None.
		"""
		await self.session.execute(update(self.model).where(self.model.id == entity_id).values(**data))
		return await self.get_by_id(entity_id)

	# ── Suppression douce ───────────────────────────────────────

	async def soft_delete(self, entity_id: str) -> ModelType | None:
		"""
		Suppression douce — marque is_active=False.
		Conforme au principe NOKIROVA : pas de suppression permanente.

		Args:
			entity_id: Identifiant UUID de l'entité.

		Returns:
			L'entité désactivée ou None si introuvable.
		"""
		instance = await self.get_by_id_active(entity_id)
		if not instance:
			return None
		instance.soft_delete()
		await self.session.flush()
		return instance

	async def restore(self, entity_id: str) -> ModelType | None:
		"""
		Restauration après suppression douce.

		Args:
			entity_id: Identifiant UUID de l'entité.

		Returns:
			L'entité restaurée ou None si introuvable.
		"""
		instance = await self.get_by_id(entity_id)
		if not instance:
			return None
		instance.restore()
		await self.session.flush()
		return instance
