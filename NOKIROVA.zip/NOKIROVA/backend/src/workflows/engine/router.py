"""
NOKIROVA — Router API pour les Workflows

Endpoints :
  POST /            — Lancer un workflow
  GET /             — Lister les workflows
  GET /{id}         — Détail d'un workflow
  GET /runs         — Lister les runs
  GET /runs/{id}    — Détail d'un run
  POST /runs/{id}/pause   — Pauser un run
  POST /runs/{id}/resume  — Reprendre un run
  DELETE /runs/{id}       — Annuler un run
"""

from fastapi import APIRouter
from pydantic import BaseModel

from src.api.deps import ActiveUser
from src.api.response import nokirova_error, nokirova_not_found, nokirova_success
from src.workflows.engine.engine import (
	WorkflowStatus,
	workflow_engine,
)

workflow_router = APIRouter()


# ─── Schémas ───────────────────────────────────────────────────────────────────


class StartWorkflowRequest(BaseModel):
	workflow_id: str
	context: dict | None = None


# ─── Endpoints ─────────────────────────────────────────────────────────────────


@workflow_router.get("")
async def list_workflows(category: str | None = None, space: str | None = None, user: ActiveUser = None):
	"""Liste les workflows enregistrés."""
	defs = workflow_engine.list_definitions(category=category, space=space)
	return nokirova_success(data=[d.model_dump() for d in defs], message=f"{len(defs)} workflows trouvés")


@workflow_router.get("/{workflow_id}")
async def get_workflow(workflow_id: str, user: ActiveUser = None):
	"""Détail d'un workflow."""
	definition = workflow_engine.get_definition(workflow_id)
	if not definition:
		return nokirova_not_found(message=f"Workflow '{workflow_id}' introuvable")
	return nokirova_success(data=definition.model_dump())


@workflow_router.post("/start")
async def start_workflow(req: StartWorkflowRequest, user: ActiveUser = None):
	"""Lance un workflow."""
	try:
		run = await workflow_engine.start(req.workflow_id, context=req.context)
		return nokirova_success(data=run.model_dump(), message="Workflow lancé")
	except ValueError as e:
		return nokirova_error(message=str(e))


@workflow_router.get("/runs")
async def list_runs(workflow_id: str | None = None, status: WorkflowStatus | None = None, user: ActiveUser = None):
	"""Liste les runs de workflows."""
	runs = workflow_engine.list_runs(workflow_id=workflow_id, status=status)
	return nokirova_success(data=[r.model_dump() for r in runs])


@workflow_router.get("/runs/{run_id}")
async def get_run(run_id: str, user: ActiveUser = None):
	"""Détail d'un run."""
	run = workflow_engine.get_run(run_id)
	if not run:
		return nokirova_not_found(message=f"Run '{run_id}' introuvable")
	return nokirova_success(data=run.model_dump())


@workflow_router.post("/runs/{run_id}/pause")
async def pause_run(run_id: str, user: ActiveUser = None):
	"""Met en pause un run."""
	success = await workflow_engine.pause(run_id)
	if not success:
		return nokirova_error(message="Impossible de mettre en pause ce run")
	return nokirova_success(message="Run mis en pause")


@workflow_router.post("/runs/{run_id}/resume")
async def resume_run(run_id: str, user: ActiveUser = None):
	"""Reprend un run en pause."""
	success = await workflow_engine.resume(run_id)
	if not success:
		return nokirova_error(message="Impossible de reprendre ce run")
	return nokirova_success(message="Run repris")


@workflow_router.delete("/runs/{run_id}")
async def cancel_run(run_id: str, user: ActiveUser = None):
	"""Annule un run."""
	success = await workflow_engine.cancel(run_id)
	if not success:
		return nokirova_error(message="Impossible d'annuler ce run")
	return nokirova_success(message="Run annulé")
