"""
NOKIROVA — Moteur de Workflows

Chaque workflow possède 16 champs normalisés :
  id, name, version, description, category, space,
  trigger, steps, conditions, error_handling,
  timeout, retry_policy, priority, tags,
  metadata, created_at

Étapes possibles : sequence, parallel, conditional, loop, sub-workflow
États : pending → running → completed | failed | cancelled | paused
Communication via Event Bus.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

from src.core.health_exceptions import DB_OPERATION_EXCEPTIONS
from src.events.bus import event_bus

# ─── Modèles de données ────────────────────────────────────────────────────────


class WorkflowStatus(StrEnum):
	PENDING = "pending"
	RUNNING = "running"
	COMPLETED = "completed"
	FAILED = "failed"
	CANCELLED = "cancelled"
	PAUSED = "paused"


class StepType(StrEnum):
	SEQUENCE = "sequence"
	PARALLEL = "parallel"
	CONDITIONAL = "conditional"
	LOOP = "loop"
	SUB_WORKFLOW = "sub_workflow"
	AGENT_CALL = "agent_call"
	EVENT_EMIT = "event_emit"
	HTTP_CALL = "http_call"


class StepStatus(StrEnum):
	PENDING = "pending"
	RUNNING = "running"
	COMPLETED = "completed"
	FAILED = "failed"
	SKIPPED = "skipped"


class WorkflowStep(BaseModel):
	"""Une étape de workflow."""

	id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
	name: str
	step_type: StepType = StepType.SEQUENCE
	agent_name: str | None = None
	agent_prompt: str | None = None
	condition: str | None = None
	sub_workflow_id: str | None = None
	event_name: str | None = None
	event_payload: dict[str, Any] | None = None
	http_url: str | None = None
	http_method: str = "POST"
	http_body: dict[str, Any] | None = None
	loop_var: str | None = None
	loop_over: list[Any] | None = None
	timeout_seconds: float = 120.0
	retry_count: int = 0
	retry_max: int = 3
	on_failure: str = "stop"  # stop | skip | fallback
	fallback_step_id: str | None = None
	status: StepStatus = StepStatus.PENDING
	output: Any = None
	error: str | None = None
	started_at: datetime | None = None
	completed_at: datetime | None = None


class RetryPolicy(BaseModel):
	max_retries: int = 3
	backoff_seconds: float = 2.0
	backoff_multiplier: float = 2.0
	retry_on: list[str] = ["timeout", "agent_error", "provider_error"]


class WorkflowDefinition(BaseModel):
	"""Définition complète d'un workflow — 16 champs normalisés."""

	id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
	name: str
	version: str = "1.0.0"
	description: str = ""
	category: str = "general"
	space: str = "accueil"
	trigger: str = "manual"  # manual | event | schedule | api
	trigger_event: str | None = None
	trigger_cron: str | None = None
	steps: list[WorkflowStep] = []
	conditions: dict[str, Any] = {}
	error_handling: str = "stop"  # stop | skip | self_heal
	timeout: float = 300.0
	retry_policy: RetryPolicy = Field(default_factory=RetryPolicy)
	priority: int = 5
	tags: list[str] = []
	metadata: dict[str, Any] = {}
	created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class WorkflowRun(BaseModel):
	"""Instance d'exécution d'un workflow."""

	id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
	workflow_id: str
	status: WorkflowStatus = WorkflowStatus.PENDING
	steps_status: dict[str, StepStatus] = {}
	steps_output: dict[str, Any] = {}
	context: dict[str, Any] = {}
	error: str | None = None
	started_at: datetime | None = None
	completed_at: datetime | None = None
	duration_ms: float | None = None


# ─── Moteur d'exécution ────────────────────────────────────────────────────────


class WorkflowEngine:
	"""
	Moteur de workflows NOKIROVA.

	Principe : Toute fonctionnalité est un workflow.
	- Exécution séquentielle, parallèle, conditionnelle, boucle
	- Appel d'agents IA à chaque étape
	- Émission/réception d'événements via Event Bus
	- Self-healing : retry, fallback, skip
	- Persistance des runs en mémoire (Redis pour production)
	"""

	def __init__(self) -> None:
		self._definitions: dict[str, WorkflowDefinition] = {}
		self._runs: dict[str, WorkflowRun] = {}
		self._running_tasks: dict[str, asyncio.Task] = {}

	# ── Gestion des définitions ─────────────────────────────────────────────

	def register(self, definition: WorkflowDefinition) -> str:
		"""Enregistre un workflow. Retourne l'ID."""
		self._definitions[definition.id] = definition
		return definition.id

	def get_definition(self, workflow_id: str) -> WorkflowDefinition | None:
		return self._definitions.get(workflow_id)

	def list_definitions(self, category: str | None = None, space: str | None = None) -> list[WorkflowDefinition]:
		defs = list(self._definitions.values())
		if category:
			defs = [d for d in defs if d.category == category]
		if space:
			defs = [d for d in defs if d.space == space]
		return defs

	def remove_definition(self, workflow_id: str) -> bool:
		return self._definitions.pop(workflow_id, None) is not None

	# ── Exécution ──────────────────────────────────────────────────────────

	async def start(self, workflow_id: str, context: dict[str, Any] | None = None) -> WorkflowRun:
		"""Lance un workflow. Retourne le run."""
		definition = self._definitions.get(workflow_id)
		if not definition:
			raise ValueError(f"Workflow '{workflow_id}' introuvable")

		run = WorkflowRun(
			workflow_id=workflow_id,
			status=WorkflowStatus.RUNNING,
			context=context or {},
			started_at=datetime.now(UTC),
		)
		# Initialiser le statut de chaque étape
		for step in definition.steps:
			run.steps_status[step.id] = StepStatus.PENDING

		self._runs[run.id] = run

		# Lancer en arrière-plan
		task = asyncio.create_task(self._execute_workflow(definition, run))
		self._running_tasks[run.id] = task

		return run

	async def _execute_workflow(self, definition: WorkflowDefinition, run: WorkflowRun) -> None:
		"""Exécution complète d'un workflow."""
		try:
			# Émettre événement de début
			await event_bus.publish(
				f"workflow.{definition.id}.started",
				{"run_id": run.id, "workflow_id": definition.id, "context": run.context},
			)

			# Exécuter les étapes
			for step in definition.steps:
				if run.status == WorkflowStatus.CANCELLED:
					break

				step_result = await self._execute_step(step, run, definition)
				run.steps_status[step.id] = step_result
				run.steps_output[step.id] = run.context.get(f"_step_{step.id}_output")

				if step_result == StepStatus.FAILED:
					if step.on_failure == "stop" or definition.error_handling == "stop":
						run.status = WorkflowStatus.FAILED
						run.error = f"Étape '{step.name}' échouée"
						break
					elif step.on_failure == "skip":
						continue
					elif step.on_failure == "fallback" and step.fallback_step_id:
						# Chercher l'étape de fallback
						fallback = next(
							(s for s in definition.steps if s.id == step.fallback_step_id),
							None,
						)
						if fallback:
							await self._execute_step(fallback, run, definition)

			if run.status != WorkflowStatus.FAILED and run.status != WorkflowStatus.CANCELLED:
				run.status = WorkflowStatus.COMPLETED

			run.completed_at = datetime.now(UTC)
			if run.started_at and run.completed_at:
				run.duration_ms = (run.completed_at - run.started_at).total_seconds() * 1000

			# Émettre événement de fin
			event_name = f"workflow.{definition.id}.{'completed' if run.status == WorkflowStatus.COMPLETED else 'failed'}"
			await event_bus.publish(event_name, {"run_id": run.id, "status": run.status.value})

		except DB_OPERATION_EXCEPTIONS as exc:
			run.status = WorkflowStatus.FAILED
			run.error = str(exc)
			run.completed_at = datetime.now(UTC)
			# Self-healing : publier pour qu'un handler puisse intervenir
			await event_bus.publish(
				f"workflow.{definition.id}.error",
				{"run_id": run.id, "error": str(exc)},
			)

	async def _execute_step(
		self, step: WorkflowStep, run: WorkflowRun, definition: WorkflowDefinition
	) -> StepStatus:
		"""Exécute une seule étape avec retry et self-healing."""
		run.steps_status[step.id] = StepStatus.RUNNING
		step.started_at = datetime.now(UTC)

		max_attempts = step.retry_max + 1
		policy = definition.retry_policy

		for attempt in range(1, max_attempts + 1):
			try:
				result = await asyncio.wait_for(
					self._run_step_logic(step, run),
					timeout=step.timeout_seconds,
				)
				run.context[f"_step_{step.id}_output"] = result
				step.output = result
				step.status = StepStatus.COMPLETED
				step.completed_at = datetime.now(UTC)
				return StepStatus.COMPLETED

			except TimeoutError:
				step.retry_count = attempt
				if attempt < max_attempts:
					backoff = policy.backoff_seconds * (policy.backoff_multiplier ** (attempt - 1))
					await asyncio.sleep(backoff)
					continue

			except DB_OPERATION_EXCEPTIONS as exc:
				step.retry_count = attempt
				step.error = str(exc)
				if attempt < max_attempts:
					backoff = policy.backoff_seconds * (policy.backoff_multiplier ** (attempt - 1))
					await asyncio.sleep(backoff)
					continue

		step.status = StepStatus.FAILED
		step.completed_at = datetime.now(UTC)
		return StepStatus.FAILED

	async def _run_step_logic(self, step: WorkflowStep, run: WorkflowRun) -> Any:
		"""Logique spécifique au type d'étape."""

		if step.step_type == StepType.AGENT_CALL and step.agent_name:
			# Appeler un agent IA
			from src.ai.agents import get_agent

			agent = get_agent(step.agent_name)
			if not agent:
				raise ValueError(f"Agent '{step.agent_name}' introuvable")
			# Injecter les résultats des étapes précédentes
			prompt = step.agent_prompt or ""
			for key, val in run.context.items():
				if key.startswith("_step_") and val is not None:
					prompt = prompt.replace(f"{{{{{key}}}}}", str(val))
			result = await agent.run(prompt=prompt, context=run.context)
			return result.output

		elif step.step_type == StepType.EVENT_EMIT and step.event_name:
			await event_bus.publish(step.event_name, step.event_payload or {})
			return {"event": step.event_name, "published": True}

		elif step.step_type == StepType.CONDITIONAL and step.condition:
			# Évaluation simplifiée : on vérifie les variables du contexte
			cond_result = eval(step.condition, {"__builtins__": {}}, run.context)
			return {"condition": step.condition, "result": bool(cond_result)}

		elif step.step_type == StepType.LOOP and step.loop_var and step.loop_over:
			results = []
			for item in step.loop_over:
				run.context[step.loop_var] = item
				# Ré-exécuter l'agent si défini
				if step.agent_name:
					from src.ai.agents import get_agent

					agent = get_agent(step.agent_name)
					if agent:
						r = await agent.run(prompt=step.agent_prompt or "", context=run.context)
						results.append(r.output)
				else:
					results.append(item)
			return results

		elif step.step_type == StepType.SUB_WORKFLOW and step.sub_workflow_id:
			sub_run = await self.start(step.sub_workflow_id, context=run.context)
			# Attendre la complétion du sous-workflow
			while sub_run.status in (WorkflowStatus.PENDING, WorkflowStatus.RUNNING):
				await asyncio.sleep(0.5)
			return sub_run.steps_output

		elif step.step_type == StepType.HTTP_CALL and step.http_url:
			import httpx

			async with httpx.AsyncClient(timeout=step.timeout_seconds) as client:
				resp = await client.request(
					method=step.http_method,
					url=step.http_url,
					json=step.http_body or {},
				)
				return resp.json()

		# Fallback : étape séquentielle vide
		return {"step": step.name, "type": step.step_type.value, "executed": True}

	# ── Contrôle d'exécution ───────────────────────────────────────────────

	async def pause(self, run_id: str) -> bool:
		run = self._runs.get(run_id)
		if run and run.status == WorkflowStatus.RUNNING:
			run.status = WorkflowStatus.PAUSED
			return True
		return False

	async def resume(self, run_id: str) -> bool:
		run = self._runs.get(run_id)
		if run and run.status == WorkflowStatus.PAUSED:
			run.status = WorkflowStatus.RUNNING
			definition = self._definitions.get(run.workflow_id)
			if definition:
				task = asyncio.create_task(self._execute_workflow(definition, run))
				self._running_tasks[run_id] = task
			return True
		return False

	async def cancel(self, run_id: str) -> bool:
		run = self._runs.get(run_id)
		if run and run.status in (WorkflowStatus.RUNNING, WorkflowStatus.PAUSED):
			run.status = WorkflowStatus.CANCELLED
			run.completed_at = datetime.now(UTC)
			return True
		return False

	# ── Requêtes ───────────────────────────────────────────────────────────

	def get_run(self, run_id: str) -> WorkflowRun | None:
		return self._runs.get(run_id)

	def list_runs(self, workflow_id: str | None = None, status: WorkflowStatus | None = None) -> list[WorkflowRun]:
		runs = list(self._runs.values())
		if workflow_id:
			runs = [r for r in runs if r.workflow_id == workflow_id]
		if status:
			runs = [r for r in runs if r.status == status]
		return sorted(runs, key=lambda r: r.started_at or datetime.min.replace(tzinfo=UTC), reverse=True)


# ─── Singleton ─────────────────────────────────────────────────────────────────

workflow_engine = WorkflowEngine()
