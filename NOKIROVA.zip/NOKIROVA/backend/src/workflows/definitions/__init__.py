"""NOKIROVA — Définitions de workflows prédéfinis."""

from .builtin import register_builtin_workflows as register_builtin_workflows
