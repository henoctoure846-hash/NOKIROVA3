"""
NOKIROVA — Workflows prédéfinis

Toute fonctionnalité NOKIROVA est un workflow.
Ici on enregistre les workflows standards par espace.
"""

from src.workflows.engine.engine import (
	StepType,
	WorkflowDefinition,
	WorkflowStep,
	workflow_engine,
)


def _flashcard_workflow() -> WorkflowDefinition:
	"""Workflow : Génération de flashcards depuis un document."""
	return WorkflowDefinition(
		name="Générer Flashcards",
		version="1.0.0",
		description="Extrait les concepts clés et génère des flashcards espacées",
		category="revision",
		space="réviser",
		trigger="api",
		steps=[
			WorkflowStep(
				name="Analyser le document",
				step_type=StepType.AGENT_CALL,
				agent_name="summary",
				agent_prompt="Résume ce document et extrais les concepts clés : {{context.document_content}}",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Générer les flashcards",
				step_type=StepType.AGENT_CALL,
				agent_name="flashcard",
				agent_prompt="Crée 10 flashcards à partir de ce résumé : {{_step_analyze_output}}",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Calculer le schedule spaced repetition",
				step_type=StepType.AGENT_CALL,
				agent_name="memory",
				agent_prompt="Calcule les dates de révision optimales pour ces flashcards",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Émettre événement flashcards créées",
				step_type=StepType.EVENT_EMIT,
				event_name="flashcards.created",
				event_payload={"source": "workflow"},
			),
		],
		tags=["flashcards", "spaced-repetition", "révision"],
	)


def _quiz_workflow() -> WorkflowDefinition:
	"""Workflow : Génération de quiz depuis un cours."""
	return WorkflowDefinition(
		name="Générer Quiz",
		version="1.0.0",
		description="Crée un quiz adaptatif depuis un contenu de cours",
		category="revision",
		space="réviser",
		trigger="api",
		steps=[
			WorkflowStep(
				name="Analyser le cours",
				step_type=StepType.AGENT_CALL,
				agent_name="summary",
				agent_prompt="Analyse ce cours et identifie les points évaluables : {{context.course_content}}",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Générer les questions",
				step_type=StepType.AGENT_CALL,
				agent_name="quiz",
				agent_prompt="Crée un quiz varié (QCM, vrai/faux, open-ended) : {{_step_analyze_output}}",
				timeout_seconds=90,
			),
			WorkflowStep(
				name="Vérifier les sources",
				step_type=StepType.AGENT_CALL,
				agent_name="citation",
				agent_prompt="Vérifie la factualité des questions générées",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Émettre événement quiz créé",
				step_type=StepType.EVENT_EMIT,
				event_name="quiz.created",
			),
		],
		tags=["quiz", "évaluation", "révision"],
	)


def _tutor_workflow() -> WorkflowDefinition:
	"""Workflow : Session de tutorat IA (SIO complet)."""
	return WorkflowDefinition(
		name="Session Tutorat SIO",
		version="1.0.0",
		description="Pipeline SIO complet : Comprendre→Chercher→Comparer→Raisonner→Produire→Vérifier→Citer→Mémoriser",
		category="tutorat",
		space="apprendre",
		trigger="api",
		steps=[
			WorkflowStep(
				name="Comprendre",
				step_type=StepType.AGENT_CALL,
				agent_name="tutor",
				agent_prompt="Analyse et comprends la question : {{context.question}}",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Chercher",
				step_type=StepType.AGENT_CALL,
				agent_name="search",
				agent_prompt="Recherche des informations pertinentes",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Comparer",
				step_type=StepType.AGENT_CALL,
				agent_name="knowledge",
				agent_prompt="Compare avec le Knowledge Graph existant",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Raisonner",
				step_type=StepType.AGENT_CALL,
				agent_name="tutor",
				agent_prompt="Raisonne logiquement à partir des informations collectées",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Produire",
				step_type=StepType.AGENT_CALL,
				agent_name="writing",
				agent_prompt="Produis une réponse structurée et pédagogique",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Vérifier",
				step_type=StepType.AGENT_CALL,
				agent_name="citation",
				agent_prompt="Vérifie la factualité et la cohérence",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Citer",
				step_type=StepType.AGENT_CALL,
				agent_name="citation",
				agent_prompt="Ajoute les citations et sources",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Mémoriser",
				step_type=StepType.AGENT_CALL,
				agent_name="memory",
				agent_prompt="Enregistre dans la mémoire pour spaced repetition",
				timeout_seconds=20,
			),
		],
		tags=["tutorat", "SIO", "pipeline"],
	)


def _document_import_workflow() -> WorkflowDefinition:
	"""Workflow : Import et traitement d'un document."""
	return WorkflowDefinition(
		name="Importer Document",
		version="1.0.0",
		description="OCR, extraction, résumé, indexation d'un document",
		category="document",
		space="produire",
		trigger="event",
		trigger_event="document.uploaded",
		steps=[
			WorkflowStep(
				name="OCR & Extraction",
				step_type=StepType.AGENT_CALL,
				agent_name="ocr",
				agent_prompt="Extrais le texte de ce document",
				timeout_seconds=120,
			),
			WorkflowStep(
				name="Résumer",
				step_type=StepType.AGENT_CALL,
				agent_name="summary",
				agent_prompt="Résume le contenu extrait",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Embedding & Indexation",
				step_type=StepType.AGENT_CALL,
				agent_name="embedding",
				agent_prompt="Chunk et vectorise ce contenu",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Mettre à jour Knowledge Graph",
				step_type=StepType.AGENT_CALL,
				agent_name="knowledge",
				agent_prompt="Mets à jour le graphe de connaissances",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Événement document traité",
				step_type=StepType.EVENT_EMIT,
				event_name="document.processed",
			),
		],
		tags=["document", "OCR", "indexation"],
	)


def _community_moderation_workflow() -> WorkflowDefinition:
	"""Workflow : Modération communautaire."""
	return WorkflowDefinition(
		name="Modérer Contenu",
		version="1.0.0",
		description="Vérifie et modère un contenu communautaire",
		category="modération",
		space="communauté",
		trigger="event",
		trigger_event="community.content_posted",
		steps=[
			WorkflowStep(
				name="Analyser le contenu",
				step_type=StepType.AGENT_CALL,
				agent_name="moderation",
				agent_prompt="Analyse ce contenu pour conformité",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Vérifier les sources",
				step_type=StepType.AGENT_CALL,
				agent_name="citation",
				agent_prompt="Vérifie les affirmations et sources",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Décision",
				step_type=StepType.CONDITIONAL,
				condition="moderation_result == 'approved'",
				timeout_seconds=5,
			),
			WorkflowStep(
				name="Émettre événement",
				step_type=StepType.EVENT_EMIT,
				event_name="community.moderation_completed",
			),
		],
		tags=["modération", "communauté", "sécurité"],
	)


def _revision_plan_workflow() -> WorkflowDefinition:
	"""Workflow : Plan de révision personnalisé."""
	return WorkflowDefinition(
		name="Plan de Révision",
		version="1.0.0",
		description="Génère un plan de révision basé sur le niveau et les échéances",
		category="révision",
		space="réviser",
		trigger="api",
		steps=[
			WorkflowStep(
				name="Évaluer le niveau",
				step_type=StepType.AGENT_CALL,
				agent_name="analytics",
				agent_prompt="Évalue le niveau actuel de l'utilisateur",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Analyser les échéances",
				step_type=StepType.AGENT_CALL,
				agent_name="revision",
				agent_prompt="Analyse les échéances et priorités",
				timeout_seconds=30,
			),
			WorkflowStep(
				name="Générer le plan",
				step_type=StepType.AGENT_CALL,
				agent_name="revision",
				agent_prompt="Génère un plan de révision optimal",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Créer les flashcards",
				step_type=StepType.AGENT_CALL,
				agent_name="flashcard",
				agent_prompt="Crée des flashcards pour les points clés",
				timeout_seconds=60,
			),
			WorkflowStep(
				name="Émettre événement plan créé",
				step_type=StepType.EVENT_EMIT,
				event_name="revision.plan_created",
			),
		],
		tags=["révision", "planning", "spaced-repetition"],
	)


def register_builtin_workflows() -> None:
	"""Enregistre tous les workflows prédéfinis dans le moteur."""
	workflows = [
		_flashcard_workflow(),
		_quiz_workflow(),
		_tutor_workflow(),
		_document_import_workflow(),
		_community_moderation_workflow(),
		_revision_plan_workflow(),
	]
	for wf in workflows:
		workflow_engine.register(wf)
	print(f"✅ {len(workflows)} workflows prédéfinis enregistrés")
