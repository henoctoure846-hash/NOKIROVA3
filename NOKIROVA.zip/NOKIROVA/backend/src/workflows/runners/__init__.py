"""NOKIROVA — Runners de workflows."""

from .celery_runner import celery_workflow_task as celery_workflow_task
