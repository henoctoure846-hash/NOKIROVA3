"""
NOKIROVA — Runner Celery pour les workflows

Exécute les workflows de manière asynchrone via Celery.
Utile pour les workflows longs (document processing, OCR, etc.).
"""

from celery import shared_task

from src.core.health_exceptions import WORKER_EXCEPTIONS


@shared_task(name="nokirova.run_workflow", bind=True, max_retries=3, default_retry_delay=30)
def celery_workflow_task(self, workflow_id: str, context: dict | None = None) -> dict:
	"""
	Lance un workflow via Celery.

	Args:
		workflow_id: ID du workflow enregistré
		context: Contexte d'exécution

	Returns:
		Résumé du run
	"""
	import asyncio

	from src.workflows.engine.engine import workflow_engine

	try:
		run = asyncio.run(workflow_engine.start(workflow_id, context=context))
		return {
			"run_id": run.id,
			"workflow_id": workflow_id,
			"status": run.status.value,
		}
	except WORKER_EXCEPTIONS as exc:
		# Self-healing : retry automatique
		raise self.retry(exc=exc) from exc
