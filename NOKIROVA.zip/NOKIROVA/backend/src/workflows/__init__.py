"""
NOKIROVA — Module Workflows

Moteur de workflows — toute fonctionnalité NOKIROVA est un workflow.
16 champs par workflow, exécution pilotée par états.
"""
