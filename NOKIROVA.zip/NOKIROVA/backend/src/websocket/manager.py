"""
NOKIROVA — Gestionnaire WebSocket

Gestion des connexions WebSocket en temps réel :
- Connexions par utilisateur et par espace
- Diffusion ciblée (user, space, room, broadcast)
- Heartbeat et reconnexion automatique
- Intégration avec l'Event Bus

Principe : chaque espace (8 espaces NOKIROVA) a ses canaux temps réel.
"""

from __future__ import annotations

import contextlib
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import StrEnum

from fastapi import WebSocket

from src.core.health_exceptions import CACHE_EXCEPTIONS
from src.core.logging import logger


class Space(StrEnum):
	"""Les 8 espaces NOKIROVA."""

	ACCUEIL = "accueil"
	APPRENDRE = "apprendre"
	REVISER = "reviser"
	PRODUIRE = "produire"
	IA_STUDIO = "ia_studio"
	COMMUNAUTE = "communaute"
	PROGRESSION = "progression"
	PARAMETRES = "parametres"


@dataclass
class WebSocketConnection:
	"""Représente une connexion WebSocket."""

	websocket: WebSocket
	user_id: str
	session_id: str
	spaces: set[Space] = field(default_factory=set)
	connected_at: float = field(default_factory=time.time)
	last_heartbeat: float = field(default_factory=time.time)
	metadata: dict = field(default_factory=dict)

	@property
	def is_alive(self) -> bool:
		"""Vérifie si la connexion est encore active (heartbeat < 60s)."""
		return (time.time() - self.last_heartbeat) < 60


class WebSocketManager:
	"""
	Gestionnaire central des WebSockets.

	Fonctionnalités :
	- Connexion/déconnexion avec tracking
	- Envoi ciblé par utilisateur, espace, room
	- Broadcast global
	- Heartbeat automatique
	- Statistiques en temps réel
	- Nettoyage des connexions mortes
	"""

	def __init__(self):
		# user_id → liste de connexions (un user peut avoir plusieurs onglets)
		self._connections: dict[str, list[WebSocketConnection]] = defaultdict(list)
		# space → set de user_ids
		self._space_users: dict[Space, set[str]] = defaultdict(set)
		# room_name → set de user_ids
		self._rooms: dict[str, set[str]] = defaultdict(set)
		self._stats = {
			"total_connections": 0,
			"messages_sent": 0,
			"messages_failed": 0,
			"heartbeats_received": 0,
		}

	# ── Connexion / Déconnexion ───────────────────────────────

	async def connect(
		self,
		websocket: WebSocket,
		user_id: str,
		session_id: str,
		spaces: list[Space] | None = None,
		metadata: dict | None = None,
	):
		"""
		Enregistre une nouvelle connexion WebSocket.
		"""
		await websocket.accept()

		conn = WebSocketConnection(
			websocket=websocket,
			user_id=user_id,
			session_id=session_id,
			spaces=set(spaces or []),
			metadata=metadata or {},
		)

		self._connections[user_id].append(conn)
		self._stats["total_connections"] += 1

		# Inscrire dans les espaces
		for space in conn.spaces:
			self._space_users[space].add(user_id)

		logger.info(
			f"WebSocket connecté : user={user_id}, session={session_id}, "
			f"espaces={[s.value for s in conn.spaces]}"
		)

		# Message de bienvenue
		await self._send_to_connection(
			conn,
			{
				"type": "connected",
				"session_id": session_id,
				"spaces": [s.value for s in conn.spaces],
				"timestamp": time.time(),
			},
		)

	async def disconnect(self, user_id: str, session_id: str):
		"""
		Déconnecte une session WebSocket.
		"""
		conns = self._connections.get(user_id, [])
		conn_to_remove = None
		for conn in conns:
			if conn.session_id == session_id:
				conn_to_remove = conn
				break

		if conn_to_remove:
			# Retirer des espaces
			for space in conn_to_remove.spaces:
				self._space_users[space].discard(user_id)
				if not self._space_users[space]:
					del self._space_users[space]

			# Retirer des rooms
			for _room_name, members in self._rooms.items():
				members.discard(user_id)

			conns.remove(conn_to_remove)
			if not conns:
				del self._connections[user_id]

			logger.info(f"WebSocket déconnecté : user={user_id}, session={session_id}")

	# ── Envoi de messages ─────────────────────────────────────

	async def _send_to_connection(self, conn: WebSocketConnection, data: dict):
		"""Envoie un message à une connexion spécifique."""
		try:
			await conn.websocket.send_json(data)
			self._stats["messages_sent"] += 1
		except CACHE_EXCEPTIONS as e:
			self._stats["messages_failed"] += 1
			logger.warning(f"Erreur envoi WebSocket : {e}")

	async def send_to_user(self, user_id: str, data: dict):
		"""Envoie un message à toutes les sessions d'un utilisateur."""
		conns = self._connections.get(user_id, [])
		for conn in conns:
			await self._send_to_connection(conn, data)

	async def send_to_space(self, space: Space, data: dict):
		"""Envoie un message à tous les utilisateurs d'un espace."""
		user_ids = self._space_users.get(space, set())
		for uid in user_ids:
			await self.send_to_user(uid, data)

	async def broadcast(self, data: dict):
		"""Diffuse un message à tous les utilisateurs connectés."""
		for user_id in self._connections:
			await self.send_to_user(user_id, data)

	# ── Rooms ─────────────────────────────────────────────────

	async def join_room(self, user_id: str, room_name: str):
		"""Inscrit un utilisateur dans une room."""
		self._rooms[room_name].add(user_id)
		logger.debug(f"User {user_id} a rejoint la room '{room_name}'")

	async def leave_room(self, user_id: str, room_name: str):
		"""Retire un utilisateur d'une room."""
		self._rooms[room_name].discard(user_id)
		if not self._rooms[room_name]:
			del self._rooms[room_name]

	async def send_to_room(self, room_name: str, data: dict, exclude_user: str | None = None):
		"""Envoie un message à tous les membres d'une room."""
		members = self._rooms.get(room_name, set())
		for uid in members:
			if uid != exclude_user:
				await self.send_to_user(uid, data)

	# ── Heartbeat ─────────────────────────────────────────────

	async def handle_heartbeat(self, user_id: str, session_id: str):
		"""
		Traite un heartbeat d'un client.
		"""
		conns = self._connections.get(user_id, [])
		for conn in conns:
			if conn.session_id == session_id:
				conn.last_heartbeat = time.time()
				self._stats["heartbeats_received"] += 1
				# Répondre au heartbeat
				await self._send_to_connection(
					conn,
					{
						"type": "heartbeat_ack",
						"timestamp": time.time(),
					},
				)
				return

	async def cleanup_dead_connections(self):
		"""
		Nettoie les connexions mortes (heartbeat > 60s).
		Auto-guérison : connexion morte → nettoyage automatique.
		"""
		dead_count = 0
		for user_id, conns in list(self._connections.items()):
			dead_conns = [c for c in conns if not c.is_alive]
			for conn in dead_conns:
				with contextlib.suppress(CACHE_EXCEPTIONS):
					await conn.websocket.close()
				conns.remove(conn)
				dead_count += 1

				# Nettoyer les espaces
				for space in conn.spaces:
					self._space_users[space].discard(user_id)

			if not conns:
				del self._connections[user_id]

		if dead_count > 0:
			logger.info(f"Nettoyage WebSocket : {dead_count} connexions mortes supprimées")

	# ── Statistiques ──────────────────────────────────────────

	def get_stats(self) -> dict:
		"""Retourne les statistiques WebSocket."""
		return {
			**self._stats,
			"active_users": len(self._connections),
			"total_sessions": sum(len(conns) for conns in self._connections.values()),
			"active_spaces": {s.value: len(users) for s, users in self._space_users.items()},
			"active_rooms": len(self._rooms),
			"room_members": {name: len(members) for name, members in self._rooms.items()},
		}

	def get_online_users(self) -> list[str]:
		"""Retourne la liste des utilisateurs en ligne."""
		return list(self._connections.keys())

	def is_user_online(self, user_id: str) -> bool:
		"""Vérifie si un utilisateur est en ligne."""
		return user_id in self._connections and len(self._connections[user_id]) > 0


# Singleton du gestionnaire WebSocket
websocket_manager = WebSocketManager()
