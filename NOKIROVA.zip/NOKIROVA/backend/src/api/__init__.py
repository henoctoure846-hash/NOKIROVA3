"""
NOKIROVA — Couche API

Routeur principal, réponse unifiée, dépendances et versionnage.
"""

from .deps import get_admin_user, get_current_active_user, get_current_user, get_db, get_redis
from .response import NOKIROVAResponse, nokirova_response
from .router import api_router

__all__ = [
	"NOKIROVAResponse",
	"nokirova_response",
	"get_current_user",
	"get_current_active_user",
	"get_admin_user",
	"get_db",
	"get_redis",
	"api_router",
]
