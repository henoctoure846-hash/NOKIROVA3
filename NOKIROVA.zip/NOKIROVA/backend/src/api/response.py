"""
NOKIROVA — Réponse API unifiée

Format standard : { success, message, data, errors, metadata }
Toutes les réponses API passent par ce module.
"""

from typing import Any

from fastapi import status
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# --- Modèles de réponse ---


class ResponseMetadata(BaseModel):
	"""Métadonnées de la réponse"""

	page: int | None = None
	per_page: int | None = None
	total: int | None = None
	total_pages: int | None = None
	request_id: str | None = None
	timestamp: str | None = None
	version: str = "v1"


class NOKIROVAResponse(BaseModel):
	"""Réponse API unifiée NOKIROVA"""

	success: bool = True
	message: str = "Opération réussie"
	data: Any = None
	errors: list[dict] | None = None
	metadata: ResponseMetadata | None = None


# --- Fonctions utilitaires ---


def nokirova_response(
	data: Any = None,
	message: str = "Opération réussie",
	success: bool = True,
	errors: list[dict] | None = None,
	status_code: int = status.HTTP_200_OK,
	metadata: ResponseMetadata | None = None,
	**meta_kwargs,
) -> JSONResponse:
	"""
	Construit une réponse API unifiée.

	Args:
		data: Données de la réponse
		message: Message descriptif
		success: Indicateur de succès
		errors: Liste d'erreurs [{code, field, message}]
		status_code: Code HTTP
		metadata: Métadonnées de pagination/info
		**meta_kwargs: Champs additionnels pour metadata

	Returns:
		JSONResponse formatée
	"""
	if metadata is None and meta_kwargs:
		metadata = ResponseMetadata(**meta_kwargs)

	body = NOKIROVAResponse(
		success=success,
		message=message,
		data=data,
		errors=errors,
		metadata=metadata,
	)

	return JSONResponse(
		content=body.model_dump(exclude_none=True),
		status_code=status_code,
	)


def nokirova_success(data: Any = None, message: str = "Opération réussie", **kwargs) -> JSONResponse:
	"""Raccourci pour réponse de succès."""
	return nokirova_response(data=data, message=message, success=True, **kwargs)


def nokirova_error(
	message: str = "Une erreur est survenue",
	errors: list[dict] | None = None,
	status_code: int = status.HTTP_400_BAD_REQUEST,
	**kwargs,
) -> JSONResponse:
	"""Raccourci pour réponse d'erreur."""
	return nokirova_response(message=message, success=False, errors=errors, status_code=status_code, **kwargs)


def nokirova_paginated(
	data: list, total: int, page: int = 1, per_page: int = 20, message: str = "Données récupérées", **kwargs
) -> JSONResponse:
	"""Raccourci pour réponse paginée."""
	total_pages = max(1, (total + per_page - 1) // per_page)
	metadata = ResponseMetadata(
		page=page,
		per_page=per_page,
		total=total,
		total_pages=total_pages,
	)
	return nokirova_response(data=data, message=message, success=True, metadata=metadata, **kwargs)


def nokirova_created(
	data: Any = None,
	message: str = "Ressource créée avec succès",
) -> JSONResponse:
	"""Raccourci pour réponse 201 Created."""
	return nokirova_response(
		data=data,
		message=message,
		success=True,
		status_code=status.HTTP_201_CREATED,
	)


def nokirova_deleted(
	message: str = "Ressource supprimée (archivée)",
) -> JSONResponse:
	"""Raccourci pour réponse de suppression (archivage)."""
	return nokirova_response(
		message=message,
		success=True,
		status_code=status.HTTP_200_OK,
	)


def nokirova_not_found(
	message: str = "Ressource introuvable",
	resource_type: str = "",
	resource_id: str = "",
) -> JSONResponse:
	"""Raccourci pour réponse 404."""
	errors = [{"code": "NOT_FOUND", "message": message}]
	if resource_type:
		errors[0]["field"] = resource_type
	if resource_id:
		errors[0]["value"] = resource_id
	return nokirova_response(
		message=message,
		success=False,
		errors=errors,
		status_code=status.HTTP_404_NOT_FOUND,
	)


def nokirova_unauthorized(
	message: str = "Authentification requise",
) -> JSONResponse:
	"""Raccourci pour réponse 401."""
	return nokirova_response(
		message=message,
		success=False,
		errors=[{"code": "UNAUTHORIZED", "message": message}],
		status_code=status.HTTP_401_UNAUTHORIZED,
	)


def nokirova_forbidden(
	message: str = "Accès refusé",
) -> JSONResponse:
	"""Raccourci pour réponse 403."""
	return nokirova_response(
		message=message,
		success=False,
		errors=[{"code": "FORBIDDEN", "message": message}],
		status_code=status.HTTP_403_FORBIDDEN,
	)


# --- Alias courts (raccourcis pratiques) ---

success = nokirova_success
created = nokirova_created
deleted = nokirova_deleted
paginated = nokirova_paginated
not_found = nokirova_not_found
unauthorized = nokirova_unauthorized
forbidden = nokirova_forbidden
error = nokirova_error
response = nokirova_response
