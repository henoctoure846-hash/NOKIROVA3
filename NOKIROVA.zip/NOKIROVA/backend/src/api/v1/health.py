"""NOKIROVA — Façade Santé Système

Regroupe les 6 domaines de monitoring :
  - _health_checks          : /, /detailed, /dependencies
  - _health_self_healing    : /self-healing/status, /history, /trigger
  - _health_diagnostics     : /diagnose
  - _health_metrics         : /metrics
  - _health_mission_control : /mission-control
  - _health_probes          : /live, /ready (K8s)

Principe BIBLE #10 : Fiabilité — monitoring en temps réel.
Principe BIBLE #8 : Confidentialité — métriques anonymisées.
"""

from __future__ import annotations

from fastapi import APIRouter

from ._health_checks import router as checks_router
from ._health_diagnostics import router as diagnostics_router
from ._health_metrics import router as metrics_router
from ._health_mission_control import router as mission_control_router
from ._health_probes import router as probes_router
from ._health_self_healing import router as self_healing_router

router = APIRouter()

# Inclusion des sous-modules santé
router.include_router(checks_router)
router.include_router(self_healing_router)
router.include_router(diagnostics_router)
router.include_router(metrics_router)
router.include_router(mission_control_router)
router.include_router(probes_router)
