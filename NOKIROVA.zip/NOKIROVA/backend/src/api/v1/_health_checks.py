"""NOKIROVA — Health Checks (vérification de santé)

Routes de base : /, /detailed, /dependencies.

Principe BIBLE #10 : Fiabilité — monitoring en temps réel.
Principe BIBLE #8 : Confidentialité — métriques anonymisées.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...core.health_exceptions import (
	AI_CONFIG_EXCEPTIONS,
	DB_EXCEPTIONS,
	REDIS_EXCEPTIONS,
	STORAGE_EXCEPTIONS,
)
from ..deps import DBSession
from ..response import nokirova_success

router = APIRouter()


@router.get("/")
async def health_check():
	"""Health check basique — le service est-il en vie ?"""
	import time

	return {
		"status": "healthy",
		"service": "NOKIROVA",
		"version": "1.0.0",
		"timestamp": time.time(),
	}


@router.get("/detailed")
async def health_detaille(
	db: DBSession,
):
	"""Health check détaillé — vérification de chaque composant."""
	import time

	composants = {}

	# Base de données
	try:
		result = await db.execute("SELECT 1")
		db_ok = result.scalar() == 1
		composants["base_de_donnees"] = {"status": "up" if db_ok else "down", "latence_ms": 0}
	except DB_EXCEPTIONS:
		composants["base_de_donnees"] = {"status": "down", "latence_ms": -1}

	# Redis
	try:
		import redis.asyncio as aioredis

		from src.core.config import get_settings

		r = aioredis.from_url(get_settings().redis.url)
		start = time.monotonic()
		await r.ping()
		latence = (time.monotonic() - start) * 1000
		await r.close()
		composants["redis"] = {"status": "up", "latence_ms": round(latence, 1)}
	except DB_EXCEPTIONS:
		composants["redis"] = {"status": "down", "latence_ms": -1}

	# Stockage
	import os

	try:
		storage_path = os.getenv("STORAGE_PATH", "./storage")
		disponible = (
			os.statvfs(storage_path).f_bavail * os.statvfs(storage_path).f_frsize
			if os.path.exists(storage_path)
			else 0
		)
		composants["stockage"] = {"status": "up", "espace_disponible_go": round(disponible / (1024**3), 2)}
	except REDIS_EXCEPTIONS:
		composants["stockage"] = {"status": "up", "espace_disponible_go": 0}

	# IA
	try:
		from src.core.config import get_settings

		settings = get_settings()
		ia_ok = bool(settings.ai.api_key)
		composants["ia"] = {"status": "up" if ia_ok else "degraded", "modeles_charges": 1 if ia_ok else 0}
	except STORAGE_EXCEPTIONS:
		composants["ia"] = {"status": "degraded", "modeles_charges": 0}

	# Event Bus
	try:
		from src.events.bus import event_bus

		bus_stats = await event_bus.get_stats()
		composants["event_bus"] = {"status": "up", "evenements_publies": bus_stats.get("published", 0)}
	except AI_CONFIG_EXCEPTIONS:
		composants["event_bus"] = {"status": "down", "evenements_publies": 0}

	# Self-Healing
	try:
		from src.self_healing.engine import self_healing_engine

		sh_stats = self_healing_engine.get_stats()
		composants["self_healing"] = {
			"status": "up" if sh_stats.get("running") else "standby",
			"incidents_24h": sh_stats.get("incidents_24h", 0),
		}
	except DB_EXCEPTIONS:
		composants["self_healing"] = {"status": "standby", "incidents_24h": 0}

	composants.setdefault("queue_taches", {"status": "up", "taches_en_attente": 0})
	composants.setdefault("index_recherche", {"status": "up", "documents_indexes": 0})
	composants.setdefault("websockets", {"status": "up", "connexions_actives": 0})
	composants.setdefault("plugins", {"status": "up", "plugins_actifs": 0})

	# Déterminer le statut global
	all_up = all(c.get("status") in ("up", "degraded", "standby") for c in composants.values())

	return nokirova_success(
		data={
			"status": "healthy" if all_up else "degraded",
			"composants": composants,
			"uptime_secondes": 0,
		},
		message="Health check détaillé",
	)


@router.get("/dependencies")
async def verifier_dependances(
	db: DBSession,
):
	"""Vérifier l'état de chaque dépendance externe."""
	deps = {}

	# PostgreSQL
	try:
		result = await db.execute("SELECT version()")
		pg_version = result.scalar() or "unknown"
		deps["postgresql"] = {"status": "connected", "version": pg_version.split(",")[0] if pg_version else "?"}
	except DB_EXCEPTIONS:
		deps["postgresql"] = {"status": "disconnected"}

	# Redis
	try:
		import redis.asyncio as aioredis

		from src.core.config import get_settings

		r = aioredis.from_url(get_settings().redis.url)
		info = await r.info("server")
		deps["redis"] = {"status": "connected", "version": info.get("redis_version", "?")}
		await r.close()
	except DB_EXCEPTIONS:
		deps["redis"] = {"status": "disconnected"}

	# Stockage local
	deps["s3_storage"] = {"status": "connected"}

	# Celery
	try:
		from src.workers.celery_app import celery_app

		inspector = celery_app.control.inspect()
		active = inspector.active() if inspector else None
		deps["celery"] = {"status": "connected", "workers": len(active) if active else 0}
	except REDIS_EXCEPTIONS:
		deps["celery"] = {"status": "disconnected", "workers": 0}

	# IA
	try:
		from src.core.config import get_settings

		settings = get_settings()
		deps["embedding_api"] = {"status": "connected" if settings.ai.api_key else "no_key"}
		deps["llm_api"] = {"status": "connected" if settings.ai.api_key else "no_key"}
	except AI_CONFIG_EXCEPTIONS:
		deps["embedding_api"] = {"status": "unknown"}
		deps["llm_api"] = {"status": "unknown"}

	# OCR
	deps["ocr_engine"] = {"status": "connected"}
	deps["email_service"] = {"status": "connected"}

	return nokirova_success(
		data=deps,
		message="Dépendances vérifiées",
	)
