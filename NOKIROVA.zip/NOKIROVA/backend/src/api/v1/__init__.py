"""
NOKIROVA — Routeurs API v1

Export de tous les sous-routeurs du domaine.
"""

from .admin import router as admin_router
from .ai import router as ai_router
from .analytics import router as analytics_router
from .auth import router as auth_router
from .chat import router as chat_router
from .community import router as community_router
from .courses import router as courses_router
from .documents import router as documents_router
from .exams import router as exams_router
from .flashcards import router as flashcards_router
from .gamification import router as gamification_router
from .health import router as health_router
from .knowledge import router as knowledge_router
from .marketplace import router as marketplace_router
from .memory import router as memory_router
from .notes import router as notes_router
from .notifications import router as notifications_router
from .plugins import router as plugins_router
from .privacy import router as privacy_router
from .quiz import router as quiz_router
from .revision import router as revision_router
from .search import router as search_router
from .users import router as users_router

__all__ = [
	"auth_router",
	"users_router",
	"courses_router",
	"documents_router",
	"notes_router",
	"flashcards_router",
	"quiz_router",
	"exams_router",
	"ai_router",
	"chat_router",
	"memory_router",
	"revision_router",
	"community_router",
	"marketplace_router",
	"gamification_router",
	"analytics_router",
	"notifications_router",
	"plugins_router",
	"knowledge_router",
	"admin_router",
	"health_router",
	"search_router",
	"privacy_router",
]
