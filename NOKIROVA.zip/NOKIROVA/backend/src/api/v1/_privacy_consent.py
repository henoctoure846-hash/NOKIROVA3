"""NOKIROVA — Routes Consentement RGPD (articles 6-7)

Gestion du consentement utilisateur : consultation, mise à jour,
révocation. Traçabilité complète de chaque changement.

Principe BIBLE #8 : Confidentialité — consentement explicite et traçable.
Principe BIBLE #3 : Traçabilité — chaque changement de consentement
est journalisé et horodaté.
"""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Body
from pydantic import BaseModel, Field
from sqlalchemy import select

from ...core.logging import get_logger
from ...database.models.users import UserConsent
from ...events.bus import Event, event_bus
from ..deps import ActiveUser, DBSession
from ..response import success

logger = get_logger(__name__)

DOMAINE_EVENEMENT = "privacy"


# ─── Modèles Pydantic ─────────────────────────────────────────────────────────


class ConsentementDTO(BaseModel):
	"""DTO pour la mise à jour du consentement"""

	consentement_marketing: bool | None = Field(
		None,
		description="Accepte les communications marketing",
	)
	consentement_analytics: bool | None = Field(
		None,
		description="Accepte la collecte analytique",
	)
	consentement_ia: bool | None = Field(
		None,
		description="Accepte l'utilisation de l'IA pour la personnalisation",
	)
	consentement_partage: bool | None = Field(
		None,
		description="Accepte le partage de données avec des partenaires",
	)


class ConsentementReponseDTO(BaseModel):
	"""DTO de réponse pour l'état du consentement"""

	consentement_marketing: bool
	consentement_analytics: bool
	consentement_ia: bool
	consentement_partage: bool
	date_mise_a_jour: str


# ─── Routes ───────────────────────────────────────────────────────────────────

router = APIRouter(tags=["Confidentialité (RGPD)"])


@router.get("/consent", summary="Consulter mes consentements actuels")
async def consulter_consentements(
	user: ActiveUser,
	db: DBSession,
):
	"""
	Consulte l'état actuel de tous les consentements utilisateur.

	Principe BIBLE #8 : Confidentialité — transparence totale
	sur les consentements accordés.
	"""
	resultat = await db.execute(select(UserConsent).where(UserConsent.user_id == user.id))
	consentement = resultat.scalar_one_or_none()

	if consentement is None:
		# Aucun consentement enregistré = tout refusé par défaut
		return success(
			data=ConsentementReponseDTO(
				consentement_marketing=False,
				consentement_analytics=False,
				consentement_ia=False,
				consentement_partage=False,
				date_mise_a_jour=datetime.now(UTC).isoformat(),
			).model_dump(),
			message="Aucun consentement enregistré — tout refusé par défaut",
		)

	return success(
		data=ConsentementReponseDTO(
			consentement_marketing=consentement.marketing,
			consentement_analytics=consentement.analytics,
			consentement_ia=consentement.ai_personalization,
			consentement_partage=consentement.data_sharing,
			date_mise_a_jour=consentement.updated_at.isoformat()
			if consentement.updated_at
			else datetime.now(UTC).isoformat(),
		).model_dump(),
		message="Consentements récupérés avec succès",
	)


@router.put("/consent", summary="Mettre à jour mes consentements")
async def mettre_a_jour_consentements(
	user: ActiveUser,
	db: DBSession,
	corps: ConsentementDTO = Body(...),
):
	"""
	Met à jour les consentements utilisateur.

	Chaque changement est journalisé et horodaté.
	Principe BIBLE #3 : Traçabilité — traçabilité complète des
	changements de consentement.
	"""
	resultat = await db.execute(select(UserConsent).where(UserConsent.user_id == user.id))
	consentement = resultat.scalar_one_or_none()

	changements = []

	if consentement is None:
		# Créer un nouveau consentement
		consentement = UserConsent(
			user_id=user.id,
			marketing=corps.consentement_marketing or False,
			analytics=corps.consentement_analytics or False,
			ai_personalization=corps.consentement_ia or False,
			data_sharing=corps.consentement_partage or False,
		)
		db.add(consentement)
		changements = ["création_initiale"]
	else:
		# Mettre à jour les champs fournis uniquement
		if corps.consentement_marketing is not None and consentement.marketing != corps.consentement_marketing:
			changements.append(f"marketing:{consentement.marketing}->{corps.consentement_marketing}")
			consentement.marketing = corps.consentement_marketing

		if corps.consentement_analytics is not None and consentement.analytics != corps.consentement_analytics:
			changements.append(f"analytics:{consentement.analytics}->{corps.consentement_analytics}")
			consentement.analytics = corps.consentement_analytics

		if corps.consentement_ia is not None and consentement.ai_personalization != corps.consentement_ia:
			changements.append(f"ia:{consentement.ai_personalization}->{corps.consentement_ia}")
			consentement.ai_personalization = corps.consentement_ia

		if corps.consentement_partage is not None and consentement.data_sharing != corps.consentement_partage:
			changements.append(f"partage:{consentement.data_sharing}->{corps.consentement_partage}")
			consentement.data_sharing = corps.consentement_partage

	await db.commit()
	await db.refresh(consentement)

	# ── Journalisation et événement ──
	if changements:
		await event_bus.publish(
			Event(
				event_type="privacy_consent_updated",
				domain=DOMAINE_EVENEMENT,
				payload={
					"user_id": str(user.id),
					"changements": changements,
					"horodatage": datetime.now(UTC).isoformat(),
				},
			)
		)

		logger.info(f"Consentement mis à jour pour l'utilisateur {user.id} : {', '.join(changements)}")

	return success(
		data=ConsentementReponseDTO(
			consentement_marketing=consentement.marketing,
			consentement_analytics=consentement.analytics,
			consentement_ia=consentement.ai_personalization,
			consentement_partage=consentement.data_sharing,
			date_mise_a_jour=consentement.updated_at.isoformat()
			if consentement.updated_at
			else datetime.now(UTC).isoformat(),
		).model_dump(),
		message="Consentements mis à jour avec succès",
	)


@router.delete("/consent", summary="Révoquer tous mes consentements")
async def revoquer_consentements(
	user: ActiveUser,
	db: DBSession,
):
	"""
	Révoque TOUS les consentements utilisateur.

	Équivalent à tout refuser : marketing, analytics,
	IA, partage de données.

	Principe BIBLE #8 : Confidentialité — droit de retirer
	son consentement à tout moment.
	"""
	resultat = await db.execute(select(UserConsent).where(UserConsent.user_id == user.id))
	consentement = resultat.scalar_one_or_none()

	if consentement is None:
		return success(
			data={
				"consentement_marketing": False,
				"consentement_analytics": False,
				"consentement_ia": False,
				"consentement_partage": False,
			},
			message="Aucun consentement à révoquer — déjà tous refusés par défaut",
		)

	consentement.marketing = False
	consentement.analytics = False
	consentement.ai_personalization = False
	consentement.data_sharing = False

	await db.commit()

	# ── Journalisation et événement ──
	await event_bus.publish(
		Event(
			event_type="privacy_consent_revoked",
			domain=DOMAINE_EVENEMENT,
			payload={
				"user_id": str(user.id),
				"horodatage": datetime.now(UTC).isoformat(),
			},
		)
	)

	logger.info(f"Tous consentements révoqués pour l'utilisateur {user.id}")

	return success(
		data={
			"consentement_marketing": False,
			"consentement_analytics": False,
			"consentement_ia": False,
			"consentement_partage": False,
		},
		message="Tous les consentements ont été révoqués avec succès",
	)
