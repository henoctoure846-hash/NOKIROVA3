"""NOKIROVA — Mission Control

Route GET /mission-control — données agrégées pour le
tableau de bord temps réel.

Principe BIBLE #10 : Fiabilité — vue consolidée.
Principe BIBLE #2 : Architecture — agrégation multi-domaine.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...core.health_exceptions import (
	AI_CONFIG_EXCEPTIONS,
	DB_EXCEPTIONS,
	REDIS_EXCEPTIONS,
	STORAGE_EXCEPTIONS,
)
from ..deps import AdminUser, DBSession
from ..response import nokirova_success

router = APIRouter()


@router.get("/mission-control")
async def donnees_mission_control(
	db: DBSession,
	admin: AdminUser,
):
	"""
	Données agrégées pour Mission Control.

	Combine health, self-healing, event bus, métriques en un seul appel.
	Optimisé pour le rafraîchissement en temps réel.
	"""
	import time

	data = {
		"timestamp": time.time(),
		"sante": {},
		"event_bus": {},
		"self_healing": {},
		"metriques": {},
	}

	# Santé des composants
	try:
		composants = {}
		try:
			result = await db.execute("SELECT 1")
			composants["postgresql"] = {"ok": result.scalar() == 1}
		except DB_EXCEPTIONS:
			composants["postgresql"] = {"ok": False}

		try:
			import redis.asyncio as aioredis

			from src.core.config import get_settings

			r = aioredis.from_url(get_settings().redis.url)
			composants["redis"] = {"ok": await r.ping()}
			await r.close()
		except DB_EXCEPTIONS:
			composants["redis"] = {"ok": False}

		try:
			from src.core.config import get_settings

			settings = get_settings()
			composants["ia"] = {"ok": bool(settings.ai.api_key)}
		except DB_EXCEPTIONS:
			composants["ia"] = {"ok": False}

		data["sante"] = composants
	except REDIS_EXCEPTIONS:
		pass

	# Event Bus
	try:
		from src.events.bus import event_bus

		data["event_bus"] = await event_bus.get_stats()
		dl_count = await event_bus.get_dead_letter_count()
		data["event_bus"]["dead_letter_count"] = dl_count
	except AI_CONFIG_EXCEPTIONS:
		data["event_bus"] = {"status": "non_disponible"}

	# Self-Healing
	try:
		from src.self_healing.engine import self_healing_engine

		data["self_healing"] = self_healing_engine.get_stats()
		data["self_healing"]["incidents_actifs"] = self_healing_engine.get_active_incidents()
	except AI_CONFIG_EXCEPTIONS:
		data["self_healing"] = {"status": "non_disponible"}

	# Métriques système
	try:
		import psutil

		data["metriques"] = {
			"cpu_pourcent": psutil.cpu_percent(),
			"memoire_pourcent": psutil.virtual_memory().percent,
			"disque_pourcent": psutil.disk_usage("/").percent,
		}
	except STORAGE_EXCEPTIONS:
		data["metriques"] = {}

	return nokirova_success(
		data=data,
		message="Données Mission Control récupérées",
	)
