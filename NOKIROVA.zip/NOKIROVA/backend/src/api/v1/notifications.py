"""
NOKIROVA — Routes API Notifications

Notifications push, email, in-app. Préférences, canaux, historique,
marquage lu/non-lu, groupes de notification.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from ..deps import ActiveUser, DBSession, Pagination
from ..response import (
	nokirova_created,
	nokirova_deleted,
	nokirova_not_found,
	nokirova_paginated,
	nokirova_success,
)

router = APIRouter()


# ═══════════════════════════════════════
# DTO — Notifications
# ═══════════════════════════════════════


class NotificationPreferenceDTO(BaseModel):
	"""Préférences de notification."""

	channel: str = Field(..., pattern="^(push|email|in_app|sms)$", description="Canal")
	category: str = Field(..., description="Catégorie (revision, social, systeme, ia, etc.)")
	enabled: bool = Field(True, description="Activé")
	quiet_hours_start: str | None = Field(None, description="Début heures calmes (HH:MM)")
	quiet_hours_end: str | None = Field(None, description="Fin heures calmes (HH:MM)")
	frequency: str = Field("immediate", pattern="^(immediate|batched|daily|weekly)$", description="Fréquence")


class NotificationSendDTO(BaseModel):
	"""Envoi de notification (interne / admin)."""

	user_id: str = Field(..., description="Destinataire")
	title: str = Field(..., min_length=3, max_length=200, description="Titre")
	message: str = Field(..., min_length=1, max_length=5000, description="Message")
	category: str = Field("systeme", description="Catégorie")
	priority: str = Field("normal", pattern="^(low|normal|high|urgent)$", description="Priorité")
	action_url: str | None = Field(None, description="URL d'action")
	icon: str | None = Field(None, description="Icône")
	data: dict = Field(default_factory=dict, description="Données supplémentaires")


# ═══════════════════════════════════════
# Liste des notifications
# ═══════════════════════════════════════


@router.get("/")
async def lister_notifications(
	db: DBSession,
	user: ActiveUser,
	pagination: Pagination,
	categorie: str | None = Query(None, description="Filtrer par catégorie"),
	lue: bool | None = Query(None, description="Filtrer par statut lu/non-lu"),
	priorite: str | None = Query(None, description="Filtrer par priorité"),
):
	"""Lister les notifications de l'utilisateur."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Notifications récupérées",
	)


@router.get("/unread-count")
async def compteur_non_lues(
	db: DBSession,
	user: ActiveUser,
):
	"""Nombre de notifications non lues."""
	return nokirova_success(
		data={"count": 0},
		message="Compteur récupéré",
	)


@router.get("/recent")
async def notifications_recentes(
	db: DBSession,
	user: ActiveUser,
	limite: int = Query(10, ge=1, le=50, description="Nombre maximum"),
):
	"""Notifications récentes (pour dropdown / badge)."""
	return nokirova_success(
		data=[],
		message="Notifications récentes récupérées",
	)


# ═══════════════════════════════════════
# Actions sur les notifications
# ═══════════════════════════════════════


@router.get("/{notification_id}")
async def detail_notification(
	notification_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Détail d'une notification."""
	return nokirova_not_found(
		message="Notification introuvable",
		resource_type="notification",
		resource_id=notification_id,
	)


@router.post("/{notification_id}/read")
async def marquer_lue(
	notification_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Marquer une notification comme lue."""
	return nokirova_success(message="Notification marquée comme lue")


@router.post("/read-all")
async def marquer_toutes_lues(
	db: DBSession,
	user: ActiveUser,
):
	"""Marquer toutes les notifications comme lues."""
	return nokirova_success(message="Toutes les notifications marquées comme lues")


@router.delete("/{notification_id}")
async def supprimer_notification(
	notification_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Supprimer (archiver) une notification."""
	return nokirova_deleted(message="Notification supprimée")


@router.delete("/")
async def supprimer_toutes(
	db: DBSession,
	user: ActiveUser,
):
	"""Supprimer toutes les notifications."""
	return nokirova_deleted(message="Toutes les notifications supprimées")


# ═══════════════════════════════════════
# Préférences de notification
# ═══════════════════════════════════════


@router.get("/preferences")
async def preferences_notification(
	db: DBSession,
	user: ActiveUser,
):
	"""Préférences de notification de l'utilisateur."""
	return nokirova_success(
		data={
			"channels": {
				"push": True,
				"email": True,
				"in_app": True,
				"sms": False,
			},
			"categories": {
				"revision": {"enabled": True, "frequency": "immediate"},
				"social": {"enabled": True, "frequency": "batched"},
				"systeme": {"enabled": True, "frequency": "immediate"},
				"ia": {"enabled": True, "frequency": "batched"},
			},
			"quiet_hours": {"enabled": False, "start": "22:00", "end": "08:00"},
		},
		message="Préférences récupérées",
	)


@router.put("/preferences")
async def modifier_preferences(
	dto: NotificationPreferenceDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Modifier les préférences de notification."""
	return nokirova_success(
		data={"channel": dto.channel, "category": dto.category, "enabled": dto.enabled},
		message="Préférences mises à jour",
	)


@router.put("/preferences/bulk")
async def modifier_preferences_bulk(
	preferences: list[NotificationPreferenceDTO],
	db: DBSession,
	user: ActiveUser,
):
	"""Modifier plusieurs préférences en une fois."""
	return nokirova_success(
		message=f"{len(preferences)} préférences mises à jour",
	)


# ═══════════════════════════════════════
# Abonnement push (Web Push)
# ═══════════════════════════════════════


@router.post("/push/subscribe")
async def abonnement_push(
	db: DBSession,
	user: ActiveUser,
	endpoint: str = Query(..., description="Endpoint Web Push"),
	p256dh: str = Query(..., description="Clé publique"),
	auth: str = Query(..., description="Clé d'authentification"),
):
	"""S'abonner aux notifications push (Web Push API)."""
	return nokirova_created(
		data={"channel": "push"},
		message="Abonnement push enregistré",
	)


@router.post("/push/unsubscribe")
async def desabonnement_push(
	db: DBSession,
	user: ActiveUser,
):
	"""Se désabonner des notifications push."""
	return nokirova_success(message="Désabonnement push effectué")
