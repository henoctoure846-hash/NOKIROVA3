"""
NOKIROVA — Routes Quiz v1

CRUD quiz, questions, soumissions, scoring, analytics.
Espace Réviser.
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ...database.models.quiz import Quiz, QuizAttempt, QuizQuestion
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, not_found, paginated, success

router = APIRouter()


class CreateQuizDTO(BaseModel):
	title: str = Field(min_length=1, max_length=300)
	description: str | None = None
	course_id: str | None = None
	time_limit_minutes: int | None = Field(None, ge=1, le=180)
	max_attempts: int = Field(default=1, ge=1, le=10)
	is_public: bool = False
	shuffle_questions: bool = True
	shuffle_options: bool = True
	show_correct_answers: bool = True
	passing_score: float = Field(default=60.0, ge=0, le=100)


class CreateQuestionDTO(BaseModel):
	quiz_id: str
	question_text: str = Field(min_length=1)
	question_type: str = Field(pattern=r"^(multiple_choice|true_false|short_answer|essay|matching|ordering)$")
	options: list[dict] = []  # Options de réponse
	correct_answer: str | list[str] | None = None
	points: float = 1.0
	explanation: str | None = None
	difficulty: str = Field(default="medium", pattern=r"^(easy|medium|hard)$")


class SubmitQuizDTO(BaseModel):
	answers: list[dict]  # [{question_id, answer}]


@router.get("/", summary="Liste des quiz")
async def list_quizzes(current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(Quiz).where(Quiz.is_deleted == False)  # noqa
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	quizzes = result.scalars().all()
	return paginated(
		items=[{"id": q.id, "title": q.title, "question_count": 0} for q in quizzes],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/", summary="Créer un quiz")
async def create_quiz(dto: CreateQuizDTO, current_user: ActiveUser, db: DBSession):
	quiz = Quiz(
		title=dto.title,
		description=dto.description,
		course_id=dto.course_id,
		creator_id=current_user.id,
		time_limit_minutes=dto.time_limit_minutes,
		max_attempts=dto.max_attempts,
		is_public=dto.is_public,
		shuffle_questions=dto.shuffle_questions,
		passing_score=dto.passing_score,
	)
	db.add(quiz)
	await db.flush()
	return created(message="Quiz créé", data={"id": quiz.id, "title": quiz.title})


@router.get("/{quiz_id}", summary="Détail d'un quiz")
async def get_quiz(quiz_id: str, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(Quiz).where(Quiz.id == quiz_id, Quiz.is_deleted == False))  # noqa
	quiz = result.scalar_one_or_none()
	if quiz is None:
		return not_found("Quiz introuvable")
	return success(message="Quiz récupéré", data={"id": quiz.id, "title": quiz.title})


@router.post("/{quiz_id}/questions", summary="Ajouter une question")
async def add_question(quiz_id: str, dto: CreateQuestionDTO, current_user: ActiveUser, db: DBSession):
	question = QuizQuestion(
		quiz_id=quiz_id,
		question_text=dto.question_text,
		question_type=dto.question_type,
		options=dto.options,
		correct_answer=dto.correct_answer,
		points=dto.points,
		explanation=dto.explanation,
		difficulty=dto.difficulty,
	)
	db.add(question)
	await db.flush()
	return created(message="Question ajoutée", data={"id": question.id})


@router.post("/{quiz_id}/submit", summary="Soumettre un quiz")
async def submit_quiz(quiz_id: str, dto: SubmitQuizDTO, current_user: ActiveUser, db: DBSession):
	submission = QuizAttempt(quiz_id=quiz_id, user_id=current_user.id, answers=dto.answers, status="submitted")
	db.add(submission)
	await db.flush()
	# À implémenter : Calculer le score via service
	return created(message="Quiz soumis", data={"id": submission.id, "status": "submitted"})


@router.get("/{quiz_id}/results", summary="Résultats d'un quiz")
async def get_quiz_results(quiz_id: str, current_user: ActiveUser, db: DBSession):
	"""Résultats et analytics du quiz pour l'utilisateur courant."""
	# À implémenter : Agréger depuis le service analytics
	return success(
		message="Résultats récupérés", data={"score": 0, "max_score": 0, "percentage": 0, "passed": False}
	)


@router.post("/generate", summary="Générer un quiz par IA")
async def generate_quiz(current_user: ActiveUser, db: DBSession):
	"""Génère un quiz automatiquement depuis un document ou des notes."""
	# À implémenter : Lancer workflow QuizGenerationWorkflow via SIO
	return success(message="Génération IA lancée", data={"status": "processing"})
