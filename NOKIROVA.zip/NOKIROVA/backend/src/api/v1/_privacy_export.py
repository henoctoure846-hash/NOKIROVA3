"""NOKIROVA — Route Export RGPD (portabilité, article 20)

Droit à la portabilité — export JSON complet des données utilisateur.

Principe BIBLE #8 : Confidentialité — transparence totale
sur les données stockées.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import select

from ...core.health_exceptions import DB_OPERATION_EXCEPTIONS
from ...core.logging import get_logger
from ...database.models.ai import AIConversation
from ...database.models.documents import Document
from ...database.models.flashcards import Flashcard
from ...database.models.notes import Note
from ...database.models.notifications import Notification
from ...database.models.quiz import QuizAttempt
from ...database.models.storage import File
from ...database.models.users import UserDevice, UserProfile
from ...events.bus import Event, event_bus
from ..deps import ActiveUser, DBSession
from ..response import success

logger = get_logger(__name__)

DOMAINE_EVENEMENT = "privacy"


# ─── Modèles Pydantic ─────────────────────────────────────────────────────────


class ExportDonneesDTO(BaseModel):
	"""DTO de réponse pour l'export de données"""

	utilisateur: dict[str, Any]
	profil: dict[str, Any]
	appareils: list[dict[str, Any]]
	documents: list[dict[str, Any]]
	notes: list[dict[str, Any]]
	flashcards: list[dict[str, Any]]
	quiz_tentatives: list[dict[str, Any]]
	fichiers: list[dict[str, Any]]
	conversations_ia: list[dict[str, Any]]
	notifications: list[dict[str, Any]]
	date_export: str
	format: str = "json"


# ─── Route ────────────────────────────────────────────────────────────────────

router = APIRouter(tags=["Confidentialité (RGPD)"])


@router.post("/export", summary="Exporter toutes mes données (portabilité RGPD)")
async def exporter_donnees(
	user: ActiveUser,
	db: DBSession,
):
	"""
	Droit à la portabilité — article 20 RGPD.

	Exporte TOUTES les données de l'utilisateur en JSON :
	profil, documents, notes, flashcards, quiz, fichiers,
	conversations IA, notifications.

	Principe BIBLE #8 : Confidentialité — transparence totale
	sur les données stockées.
	"""
	logger.info(f"Export RGPD demandé par l'utilisateur {user.id}")

	# ── Profil utilisateur ──
	profil_result = await db.execute(select(UserProfile).where(UserProfile.user_id == user.id))
	profil = profil_result.scalar_one_or_none()

	# ── Appareils ──
	appareils_result = await db.execute(select(UserDevice).where(UserDevice.user_id == user.id))
	appareils = appareils_result.scalars().all()

	# ── Documents ──
	try:
		docs_result = await db.execute(select(Document).where(Document.owner_id == user.id))
		documents = docs_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		documents = []

	# ── Notes ──
	try:
		notes_result = await db.execute(select(Note).where(Note.user_id == user.id))
		notes = notes_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		notes = []

	# ── Flashcards ──
	try:
		fc_result = await db.execute(select(Flashcard).where(Flashcard.user_id == user.id))
		flashcards = fc_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		flashcards = []

	# ── Tentatives de quiz ──
	try:
		quiz_result = await db.execute(select(QuizAttempt).where(QuizAttempt.user_id == user.id))
		quiz_tentatives = quiz_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		quiz_tentatives = []

	# ── Fichiers stockés ──
	try:
		fichiers_result = await db.execute(select(File).where(File.owner_id == user.id))
		fichiers = fichiers_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		fichiers = []

	# ── Conversations IA ──
	try:
		convs_result = await db.execute(select(AIConversation).where(AIConversation.user_id == user.id))
		conversations_ia = convs_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		conversations_ia = []

	# ── Notifications ──
	try:
		notif_result = await db.execute(select(Notification).where(Notification.user_id == user.id))
		notifications = notif_result.scalars().all()
	except DB_OPERATION_EXCEPTIONS:
		notifications = []

	# ── Construction de l'export ──
	def _serialiser(obj) -> dict:
		"""Sérialise un modèle ORM en dictionnaire JSON-safe."""
		if obj is None:
			return {}
		resultat = {}
		for colonne in obj.__table__.columns:
			valeur = getattr(obj, colonne.name, None)
			if isinstance(valeur, datetime):
				valeur = valeur.isoformat()
			resultat[colonne.name] = valeur
		return resultat

	export = ExportDonneesDTO(
		utilisateur=_serialiser(user),
		profil=_serialiser(profil),
		appareils=[_serialiser(a) for a in appareils],
		documents=[_serialiser(d) for d in documents],
		notes=[_serialiser(n) for n in notes],
		flashcards=[_serialiser(f) for f in flashcards],
		quiz_tentatives=[_serialiser(q) for q in quiz_tentatives],
		fichiers=[_serialiser(fi) for fi in fichiers],
		conversations_ia=[_serialiser(c) for c in conversations_ia],
		notifications=[_serialiser(n) for n in notifications],
		date_export=datetime.now(UTC).isoformat(),
	)

	# ── Journalisation et événement ──
	await event_bus.publish(
		Event(
			event_type="privacy_export",
			domain=DOMAINE_EVENEMENT,
			payload={"user_id": user.id},
		)
	)

	logger.info(f"Export RGPD terminé pour l'utilisateur {user.id}")

	return success(
		data=export.model_dump(mode="json"),
		message="Export de données RGPD généré avec succès",
	)
