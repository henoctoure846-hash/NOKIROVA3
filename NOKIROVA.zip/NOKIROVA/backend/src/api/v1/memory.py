"""
NOKIROVA — Routes Mémoire / Jumeau Pédagogique v1

Profil d'apprentissage, lacunes, mémoire à long terme,
interactions sauvegardées, rappels.
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ...database.models.memory import MemoryNode
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, not_found, paginated, success

router = APIRouter()


class UpdateLearningProfileDTO(BaseModel):
	"""Mise à jour du profil d'apprentissage du Jumeau."""

	preferred_learning_style: str | None = Field(None, pattern=r"^(visual|auditory|kinesthetic|reading)$")
	preferred_difficulty: str | None = Field(None, pattern=r"^(beginner|intermediate|advanced|adaptive)$")
	preferred_study_time: str | None = None
	attention_span_minutes: int | None = Field(None, ge=5, le=120)
	goals: list[str] | None = None
	weaknesses: list[str] | None = None
	strengths: list[str] | None = None


class CreateMemoryDTO(BaseModel):
	"""Créer une entrée de mémoire."""

	content: str = Field(min_length=1, max_length=10000)
	memory_type: str = Field(pattern=r"^(fact|concept|procedure|experience|insight)$")
	source_type: str | None = Field(None, pattern=r"^(document|conversation|quiz|note|ai)$")
	source_id: str | None = None
	importance: float = Field(default=0.5, ge=0.0, le=1.0)
	tags: list[str] = []


@router.get("/profile", summary="Profil d'apprentissage")
async def get_learning_profile(current_user: ActiveUser, db: DBSession):
	"""Retourne le profil d'apprentissage complet du Jumeau Pédagogique."""
	from sqlalchemy import select

	result = await db.execute(select(MemoryNode).where(MemoryNode.user_id == current_user.id))
	memory = result.scalar_one_or_none()
	if memory is None:
		return success(message="Profil vide — à initialiser", data={"initialized": False})
	return success(message="Profil récupéré", data={"initialized": True, "user_id": current_user.id})


@router.put("/profile", summary="Mettre à jour le profil")
async def update_learning_profile(dto: UpdateLearningProfileDTO, current_user: ActiveUser, db: DBSession):
	"""Met à jour le profil d'apprentissage."""
	# À implémenter : Déléguer au service de mémoire
	return success(message="Profil mis à jour")


@router.post("/entries", summary="Créer une entrée mémoire")
async def create_memory_entry(dto: CreateMemoryDTO, current_user: ActiveUser, db: DBSession):
	entry = MemoryNode(
		user_id=current_user.id,
		node_type=dto.memory_type,
		key=dto.content[:255],
		value=dto.content,
		source=dto.source_type or "explicit",
		source_id=dto.source_id,
		importance=dto.importance,
	)
	db.add(entry)
	await db.flush()
	return created(message="Entrée mémoire créée", data={"id": entry.id})


@router.get("/entries", summary="Rechercher dans la mémoire")
async def search_memory(current_user: ActiveUser, db: DBSession, pagination: Pagination, query: str | None = None):
	"""Recherche sémantique dans la mémoire de l'utilisateur."""
	# À implémenter : Intégrer recherche vectorielle
	return paginated(items=[], total=0, page=pagination.page, per_page=pagination.per_page)


@router.get("/insights", summary="Insights du Jumeau")
async def get_jumeau_insights(current_user: ActiveUser, db: DBSession):
	"""
	Retourne les insights du Jumeau Pédagogique :
	lacunes détectées, recommandations, progrès.
	"""
	# À implémenter : Calculer depuis le service mémoire + analytics
	return success(
		message="Insights récupérés",
		data={
			"detected_weaknesses": [],
			"recommended_topics": [],
			"study_streak": 0,
			"estimated_mastery": {},
			"next_review_topics": [],
		},
	)


@router.delete("/entries/{entry_id}", summary="Supprimer une entrée (soft delete)")
async def delete_memory_entry(entry_id: str, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(MemoryNode).where(MemoryNode.id == entry_id))
	entry = result.scalar_one_or_none()
	if entry is None:
		return not_found("Entrée introuvable")
	entry.is_deleted = True
	return success(message="Entrée archivée")
