"""
NOKIROVA — Routes Notes v1

Notes intelligentes, linking, extraction, synapse.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from ...database.models.notes import Note
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, deleted, not_found, paginated, success

router = APIRouter()


class CreateNoteDTO(BaseModel):
	title: str = Field(min_length=1, max_length=300)
	content: str = Field(min_length=1)
	document_id: str | None = None
	course_id: str | None = None
	tags: list[str] = []
	is_public: bool = False


class UpdateNoteDTO(BaseModel):
	title: str | None = Field(None, max_length=300)
	content: str | None = None
	tags: list[str] | None = None
	is_public: bool | None = None


@router.get("/", summary="Liste des notes")
async def list_notes(current_user: ActiveUser, db: DBSession, pagination: Pagination, search: str | None = Query(None)):
	from sqlalchemy import func, select

	query = select(Note).where(Note.owner_id == current_user.id, Note.is_deleted == False)  # noqa
	if search:
		query = query.where(Note.title.ilike(f"%{search}%"))
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	notes = result.scalars().all()
	return paginated(
		items=[{"id": n.id, "title": n.title, "created_at": str(n.created_at)} for n in notes],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/", summary="Créer une note")
async def create_note(dto: CreateNoteDTO, current_user: ActiveUser, db: DBSession):
	note = Note(
		title=dto.title,
		content=dto.content,
		document_id=dto.document_id,
		course_id=dto.course_id,
		owner_id=current_user.id,
		tags=dto.tags,
		is_public=dto.is_public,
	)
	db.add(note)
	await db.flush()
	# À implémenter : Émettre événement NoteCreated, lancer IA extraction
	return created(message="Note créée", data={"id": note.id, "title": note.title})


@router.get("/{note_id}", summary="Détail d'une note")
async def get_note(note_id: str, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(Note).where(Note.id == note_id, Note.is_deleted == False))  # noqa
	note = result.scalar_one_or_none()
	if note is None:
		return not_found("Note introuvable")
	return success(message="Note récupérée", data={"id": note.id, "title": note.title, "content": note.content})


@router.patch("/{note_id}", summary="Mettre à jour une note")
async def update_note(note_id: str, dto: UpdateNoteDTO, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(Note).where(Note.id == note_id))
	note = result.scalar_one_or_none()
	if note is None:
		return not_found("Note introuvable")
	for field, value in dto.model_dump(exclude_unset=True).items():
		setattr(note, field, value)
	# À implémenter : Émettre événement NoteUpdated, relancer IA extraction
	return success(message="Note mise à jour")


@router.delete("/{note_id}", summary="Supprimer une note (soft delete)")
async def delete_note(note_id: str, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(Note).where(Note.id == note_id))
	note = result.scalar_one_or_none()
	if note is None:
		return not_found("Note introuvable")
	note.is_deleted = True
	return deleted(message="Note archivée")


@router.get("/{note_id}/links", summary="Liens d'une note")
async def get_note_links(note_id: str, current_user: ActiveUser, db: DBSession):
	"""Retourne les connexions synaptiques d'une note (Knowledge Graph)."""
	# À implémenter : Déléguer au service Knowledge Graph
	return success(message="Liens récupérés", data=[])


@router.post("/{note_id}/extract", summary="Extraction IA d'une note")
async def extract_note(note_id: str, current_user: ActiveUser, db: DBSession):
	"""Lance l'extraction IA d'une note : concepts clés, résumé, flashcards."""
	# À implémenter : Déléguer au service IA via Event Bus
	return success(message="Extraction IA lancée", data={"status": "processing"})
