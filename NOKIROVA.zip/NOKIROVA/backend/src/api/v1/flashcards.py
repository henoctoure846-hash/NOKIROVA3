"""
NOKIROVA — Routes Flashcards v1

CRUD flashcards, decks, révision espacée, statistiques.
Espace Réviser.
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ...database.models.flashcards import Flashcard, FlashcardDeck
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, not_found, paginated, success

router = APIRouter()


class CreateDeckDTO(BaseModel):
	name: str = Field(min_length=1, max_length=200)
	description: str | None = Field(None, max_length=1000)
	course_id: str | None = None
	is_public: bool = False
	tags: list[str] = []


class CreateFlashcardDTO(BaseModel):
	deck_id: str
	front: str = Field(min_length=1, max_length=2000)
	back: str = Field(min_length=1, max_length=2000)
	difficulty: str = Field(default="medium", pattern=r"^(easy|medium|hard)$")
	tags: list[str] = []


class ReviewFlashcardDTO(BaseModel):
	quality: int = Field(ge=0, le=5, description="Qualité de rappel (0-5, SM-2)")


# --- Decks ---


@router.get("/decks/", summary="Liste des decks")
async def list_decks(current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(FlashcardDeck).where(
		FlashcardDeck.owner_id == current_user.id, ~FlashcardDeck.is_deleted
	)
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	decks = result.scalars().all()
	return paginated(
		items=[{"id": d.id, "name": d.title, "card_count": d.card_count} for d in decks],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/decks/", summary="Créer un deck")
async def create_deck(dto: CreateDeckDTO, current_user: ActiveUser, db: DBSession):
	deck = FlashcardDeck(
		title=dto.name,
		description=dto.description,
		course_id=dto.course_id,
		owner_id=current_user.id,
		is_public=dto.is_public,
		tags=dto.tags,
	)
	db.add(deck)
	await db.flush()
	return created(message="Deck créé", data={"id": deck.id, "name": deck.title})


# --- Flashcards ---


@router.get("/decks/{deck_id}/cards", summary="Cartes d'un deck")
async def list_flashcards(deck_id: str, current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(Flashcard).where(Flashcard.deck_id == deck_id, Flashcard.is_deleted == False)  # noqa
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	cards = result.scalars().all()
	return paginated(
		items=[
			{"id": c.id, "front": c.front_content, "back": c.back_content, "type": c.card_type}
			for c in cards
		],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/decks/{deck_id}/cards", summary="Ajouter une carte")
async def create_flashcard(deck_id: str, dto: CreateFlashcardDTO, current_user: ActiveUser, db: DBSession):
	card = Flashcard(deck_id=deck_id, front_content=dto.front, back_content=dto.back, card_type="basic")
	db.add(card)
	await db.flush()
	return created(message="Carte créée", data={"id": card.id})


@router.post("/decks/{deck_id}/cards/{card_id}/review", summary="Réviser une carte (SM-2)")
async def review_flashcard(
	deck_id: str, card_id: str, dto: ReviewFlashcardDTO, current_user: ActiveUser, db: DBSession
):
	"""
	Enregistre la révision d'une flashcard et met à jour l'intervalle SM-2.
	"""
	from sqlalchemy import select

	result = await db.execute(select(Flashcard).where(Flashcard.id == card_id))
	card = result.scalar_one_or_none()
	if card is None:
		return not_found("Carte introuvable")

	# À implémenter : Implémenter algorithme SM-2 complet via service
	# Mise à jour simplifiée : qualité → intervalle
	new_interval = max(1, card.interval_days * (1 + dto.quality * 0.2)) if hasattr(card, "interval_days") else 1

	return success(
		message="Révision enregistrée",
		data={"card_id": card_id, "new_interval": new_interval, "quality": dto.quality},
	)


@router.get("/decks/{deck_id}/due", summary="Cartes dues pour révision")
async def get_due_cards(deck_id: str, current_user: ActiveUser, db: DBSession):
	"""Retourne les cartes dues pour révision aujourd'hui."""
	# À implémenter : Calculer via le service de révision espacée
	return success(message="Cartes dues récupérées", data=[])


@router.post("/generate", summary="Générer des flashcards par IA")
async def generate_flashcards(current_user: ActiveUser, db: DBSession):
	"""
	Génère automatiquement des flashcards depuis un document ou des notes.
	Délègue au SIO (IA Orchestrateur).
	"""
	# À implémenter : Lancer workflow FlashcardGenerationWorkflow
	return success(message="Génération IA lancée", data={"status": "processing"})
