"""NOKIROVA — Façade RGPD (Confidentialité)

Regroupe les 3 domaines RGPD :
  - _privacy_export : portabilité (article 20)
  - _privacy_erase  : effacement (article 17)
  - _privacy_consent : consentement (articles 6-7)

Principe BIBLE #8 : Confidentialité — données et consentement
sous contrôle total de l'utilisateur.
Principe BIBLE #10 : Modularité — chaque domaine RGPD dans
son propre sous-module, façade déléguée.
"""

from __future__ import annotations

from fastapi import APIRouter

from ._privacy_consent import router as consent_router
from ._privacy_erase import router as erase_router
from ._privacy_export import router as export_router

router = APIRouter(tags=["Confidentialité (RGPD)"])

# Inclusion des sous-modules RGPD
router.include_router(export_router)
router.include_router(erase_router)
router.include_router(consent_router)
