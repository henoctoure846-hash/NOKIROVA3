"""NOKIROVA — Routes Cours v1

CRUD cours, inscription, modules, leçons, progression.
Espace Apprendre.
Aligné sur les modèles réels de university.py.
"""

from fastapi import APIRouter, Query

from ...services.course.dto import (
	CourseCreateRequest,
	CourseUpdateRequest,
	EnrollmentRequest,
	LessonCreateRequest,
	LessonUpdateRequest,
	ModuleCreateRequest,
)
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, deleted, paginated, success

router = APIRouter()


# --- Endpoints Cours ---


@router.get("/", summary="Liste des cours")
async def list_courses(
	db: DBSession,
	pagination: Pagination,
	search: str | None = Query(None),
	department: str | None = Query(None),
	level: str | None = Query(None),
):
	"""Liste paginée des cours publiés."""
	from ...services.course.service import CourseService

	svc = CourseService()
	result = await svc.list_courses(
		db,
		offset=pagination.offset,
		limit=pagination.per_page,
		department=department,
		level=level,
		is_published=True,
		search=search,
	)
	return paginated(
		items=[c.model_dump() for c in result.courses],
		total=result.total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/", summary="Créer un cours")
async def create_course(dto: CourseCreateRequest, current_user: ActiveUser, db: DBSession):
	"""Crée un nouveau cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	course = await svc.create_course(db, instructor_id=current_user.id, data=dto)
	return created(message="Cours créé", data=course.model_dump())


@router.get("/{course_id}", summary="Détail d'un cours")
async def get_course(course_id: str, db: DBSession):
	"""Retourne les détails complets d'un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	course = await svc.get_course(db, course_id)
	return success(message="Cours récupéré", data=course.model_dump())


@router.patch("/{course_id}", summary="Mettre à jour un cours")
async def update_course(course_id: str, dto: CourseUpdateRequest, current_user: ActiveUser, db: DBSession):
	"""Met à jour un cours existant."""
	from ...services.course.service import CourseService

	svc = CourseService()
	course = await svc.update_course(db, course_id, current_user.id, dto)
	return success(message="Cours mis à jour", data=course.model_dump())


@router.delete("/{course_id}", summary="Supprimer un cours (archivage)")
async def delete_course(course_id: str, current_user: ActiveUser, db: DBSession):
	"""Archivage doux d'un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	await svc.archive_course(db, course_id, current_user.id)
	return deleted(message="Cours archivé")


# --- Endpoints Inscription ---


@router.post("/{course_id}/enroll", summary="S'inscrire à un cours")
async def enroll_course(course_id: str, current_user: ActiveUser, db: DBSession):
	"""Inscrit l'utilisateur à un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	enrollment_dto = EnrollmentRequest(course_id=course_id, role="student")
	enrollment = await svc.enroll(db, student_id=current_user.id, data=enrollment_dto)
	return created(message="Inscription réussie", data=enrollment.model_dump())


@router.delete("/{course_id}/enroll", summary="Se désinscrire d'un cours")
async def unenroll_course(course_id: str, current_user: ActiveUser, db: DBSession):
	"""Désinscription d'un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	await svc.unenroll(db, student_id=current_user.id, course_id=course_id)
	return deleted(message="Désinscription réussie")


@router.get("/{course_id}/progress", summary="Progression dans un cours")
async def get_course_progress(course_id: str, current_user: ActiveUser, db: DBSession):
	"""Retourne la progression de l'utilisateur dans un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	enrollment = await svc.update_progress(db, student_id=current_user.id, course_id=course_id, progress=-1)
	# progress=-1 retourne juste la progression actuelle sans modification
	return success(message="Progression récupérée", data=enrollment.model_dump())


# --- Endpoints Modules ---


@router.post("/{course_id}/modules", summary="Ajouter un module")
async def create_module(course_id: str, dto: ModuleCreateRequest, current_user: ActiveUser, db: DBSession):
	"""Ajoute un module à un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	module = await svc.create_module(db, course_id, current_user.id, dto)
	return created(message="Module créé", data=module.model_dump())


@router.get("/{course_id}/modules", summary="Modules d'un cours")
async def list_course_modules(course_id: str, db: DBSession, pagination: Pagination):
	"""Liste les modules d'un cours."""
	from ...services.course.service import CourseService

	svc = CourseService()
	course = await svc.get_course(db, course_id)
	modules = course.modules or []
	return paginated(
		items=[m.model_dump() for m in modules],
		total=len(modules),
		page=pagination.page,
		per_page=pagination.per_page,
	)


# --- Endpoints Leçons ---


@router.post("/{course_id}/modules/{module_id}/lessons", summary="Ajouter une leçon")
async def create_lesson(
	course_id: str, module_id: str, dto: LessonCreateRequest, current_user: ActiveUser, db: DBSession
):
	"""Ajoute une leçon à un module."""
	from ...services.course.service import CourseService

	svc = CourseService()
	lesson = await svc.create_lesson(db, module_id, course_id, current_user.id, dto)
	return created(message="Leçon créée", data=lesson.model_dump())


@router.patch("/{course_id}/modules/{module_id}/lessons/{lesson_id}", summary="Mettre à jour une leçon")
async def update_lesson(
	course_id: str,
	module_id: str,
	lesson_id: str,
	dto: LessonUpdateRequest,
	current_user: ActiveUser,
	db: DBSession,
):
	"""Met à jour une leçon existante."""
	from ...services.course.service import CourseService

	svc = CourseService()
	lesson = await svc.update_lesson(db, lesson_id, course_id, current_user.id, dto)
	return success(message="Leçon mise à jour", data=lesson.model_dump())
