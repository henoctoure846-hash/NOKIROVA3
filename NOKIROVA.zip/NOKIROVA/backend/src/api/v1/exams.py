"""
NOKIROVA — Routes Examens v1

Examens blancs, planification, simulation, correction IA.
Espace Réviser.
"""

from datetime import datetime

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ...database.models.exams import Exam, ExamSubmission
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, not_found, paginated, success

router = APIRouter()


class CreateExamDTO(BaseModel):
	title: str = Field(min_length=1, max_length=300)
	description: str | None = None
	course_id: str | None = None
	exam_type: str = Field(default="practice", pattern=r"^(practice|mock|real|simulation)$")
	duration_minutes: int = Field(ge=1, le=480)
	scheduled_at: datetime | None = None
	is_adaptive: bool = False


class StartExamDTO(BaseModel):
	exam_id: str


class SubmitExamDTO(BaseModel):
	answers: list[dict]
	time_spent_seconds: int


@router.get("/", summary="Liste des examens")
async def list_exams(current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(Exam).where(Exam.is_deleted == False)  # noqa
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	exams = result.scalars().all()
	return paginated(
		items=[{"id": e.id, "title": e.title, "exam_type": e.exam_type} for e in exams],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/", summary="Créer un examen")
async def create_exam(dto: CreateExamDTO, current_user: ActiveUser, db: DBSession):
	exam = Exam(
		title=dto.title,
		description=dto.description,
		course_id=dto.course_id,
		exam_type=dto.exam_type,
		duration_minutes=dto.duration_minutes,
		scheduled_at=dto.scheduled_at,
		creator_id=current_user.id,
		is_adaptive=dto.is_adaptive,
	)
	db.add(exam)
	await db.flush()
	return created(message="Examen créé", data={"id": exam.id})


@router.get("/{exam_id}", summary="Détail d'un examen")
async def get_exam(exam_id: str, current_user: ActiveUser, db: DBSession):
	from sqlalchemy import select

	result = await db.execute(select(Exam).where(Exam.id == exam_id))
	exam = result.scalar_one_or_none()
	if exam is None:
		return not_found("Examen introuvable")
	return success(
		message="Examen récupéré",
		data={
			"id": exam.id,
			"title": exam.title,
			"exam_type": exam.exam_type,
			"duration_minutes": exam.duration_minutes,
		},
	)


@router.post("/{exam_id}/start", summary="Démarrer un examen")
async def start_exam(exam_id: str, current_user: ActiveUser, db: DBSession):
	session = ExamSubmission(exam_id=exam_id, user_id=current_user.id, status="in_progress")
	db.add(session)
	await db.flush()
	# À implémenter : Calculer l'heure de fin, activer le timer
	return created(message="Examen démarré", data={"session_id": session.id, "status": "in_progress"})


@router.post("/{exam_id}/submit", summary="Soumettre un examen")
async def submit_exam(exam_id: str, dto: SubmitExamDTO, current_user: ActiveUser, db: DBSession):
	# À implémenter : Récupérer la session active, calculer le score, lancer correction IA
	return success(message="Examen soumis", data={"status": "grading"})


@router.get("/{exam_id}/analytics", summary="Analytics d'un examen")
async def get_exam_analytics(exam_id: str, current_user: ActiveUser, db: DBSession):
	"""Analytics détaillées : score par thème, temps par question, recommandations."""
	# À implémenter : Déléguer au service analytics + IA
	return success(message="Analytics récupérées", data={"exam_id": exam_id})
