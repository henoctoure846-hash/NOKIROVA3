"""NOKIROVA — Probes Kubernetes (Liveness / Readiness)

Routes /live et /ready pour les sondes K8s.

Principe BIBLE #10 : Fiabilité — orchestration cloud-native.
Principe BIBLE #6 : Résilience — redémarrage automatique si défaillant.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...core.health_exceptions import DB_EXCEPTIONS
from ..deps import DBSession

router = APIRouter()


@router.get("/live")
async def liveness_probe():
	"""Liveness probe — le processus est-il vivant ?"""
	return {"status": "alive"}


@router.get("/ready")
async def readiness_probe(
	db: DBSession,
):
	"""Readiness probe — le service est-il prêt à recevoir du trafic ?"""
	try:
		result = await db.execute("SELECT 1")
		if result.scalar() == 1:
			return {"status": "ready"}
	except DB_EXCEPTIONS:
		pass
	return {"status": "not_ready"}
