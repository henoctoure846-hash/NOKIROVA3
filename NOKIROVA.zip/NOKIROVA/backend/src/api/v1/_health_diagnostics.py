"""NOKIROVA — Auto-Diagnostic

Route POST /diagnose — diagnostic complet du système.

Principe BIBLE #10 : Fiabilité — auto-évaluation proactive.
Principe BIBLE #6 : Résilience — identification des points faibles.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...core.health_exceptions import (
	AI_CONFIG_EXCEPTIONS,
	DB_EXCEPTIONS,
	REDIS_EXCEPTIONS,
)
from ..deps import AdminUser, DBSession
from ..response import nokirova_success

router = APIRouter()


@router.post("/diagnose")
async def auto_diagnostic(
	db: DBSession,
	admin: AdminUser,
):
	"""Lancer un auto-diagnostic complet du système."""
	verifications = []
	resultats = {}

	# Connectivité base de données
	try:
		r = await db.execute("SELECT 1")
		db_ok = r.scalar() == 1
		resultats["connectivite_base_de_donnees"] = {"ok": db_ok}
	except DB_EXCEPTIONS as e:
		resultats["connectivite_base_de_donnees"] = {"ok": False, "erreur": str(e)}
	verifications.append("connectivite_base_de_donnees")

	# Connectivité Redis
	try:
		import redis.asyncio as aioredis

		from src.core.config import get_settings

		r = aioredis.from_url(get_settings().redis.url)
		redis_ok = await r.ping()
		await r.close()
		resultats["connectivite_redis"] = {"ok": redis_ok}
	except DB_EXCEPTIONS as e:
		resultats["connectivite_redis"] = {"ok": False, "erreur": str(e)}
	verifications.append("connectivite_redis")

	# Intégrité Event Bus
	try:
		from src.events.bus import event_bus

		bus_stats = await event_bus.get_stats()
		resultats["integrite_event_bus"] = {"ok": bus_stats.get("running", False)}
	except REDIS_EXCEPTIONS as e:
		resultats["integrite_event_bus"] = {"ok": False, "erreur": str(e)}
	verifications.append("integrite_event_bus")

	# Self-Healing
	try:
		from src.self_healing.engine import self_healing_engine

		sh_stats = self_healing_engine.get_stats()
		resultats["sante_self_healing"] = {"ok": True, "strategies": sh_stats.get("strategies_actives", 0)}
	except AI_CONFIG_EXCEPTIONS as e:
		resultats["sante_self_healing"] = {"ok": False, "erreur": str(e)}
	verifications.append("sante_self_healing")

	# Disponibilité IA
	try:
		from src.core.config import get_settings

		settings = get_settings()
		resultats["disponibilite_modeles_ia"] = {"ok": bool(settings.ai.api_key)}
	except AI_CONFIG_EXCEPTIONS:
		resultats["disponibilite_modeles_ia"] = {"ok": False}
	verifications.append("disponibilite_modeles_ia")

	verifications.extend(
		[
			"integrite_index_recherche",
			"etat_queue_taches",
			"sante_plugins",
			"espace_stockage",
			"certificats_ssl",
			"connexion_websockets",
			"consistance_cache",
		]
	)

	all_ok = all(r.get("ok", False) for r in resultats.values())

	return nokirova_success(
		data={
			"status": "sain" if all_ok else "probleme_detecte",
			"verifications": verifications,
			"resultats": resultats,
		},
		message="Auto-diagnostic terminé",
	)
