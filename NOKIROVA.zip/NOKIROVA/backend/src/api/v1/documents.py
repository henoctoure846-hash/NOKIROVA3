"""
NOKIROVA — Routes Documents v1

Upload, OCR, indexation, Document Vivant, versioning.
Espace Produire.
"""

from fastapi import APIRouter, File, Form, Query, UploadFile
from pydantic import BaseModel, Field

from ...database.models.documents import Document, DocumentVersion
from ..deps import ActiveUser, DBSession, Pagination, RedisClient
from ..response import created, deleted, not_found, paginated, success

router = APIRouter()


# --- DTOs ---


class DocumentMetadataDTO(BaseModel):
	title: str | None = Field(None, max_length=300)
	description: str | None = Field(None, max_length=1000)
	course_id: str | None = None
	tags: list[str] = []
	is_public: bool = False
	language: str = "fr"


class UpdateDocumentDTO(BaseModel):
	title: str | None = None
	description: str | None = None
	tags: list[str] | None = None
	is_public: bool | None = None


# --- Endpoints ---


@router.post("/upload", summary="Téléverser un document")
async def upload_document(
	current_user: ActiveUser,
	db: DBSession,
	redis: RedisClient,
	file: UploadFile = File(...),
	title: str = Form(None),
	course_id: str = Form(None),
	tags: str = Form(""),
	is_public: bool = Form(False),
):
	"""
	Téléverse un document et lance le pipeline :
	Stockage → OCR → Indexation → Event Bus
	"""
	# À implémenter : Déléguer au service de stockage
	# À implémenter : Lancer workflow DocumentUploadWorkflow
	# À implémenter : Émettre événement DocumentUploaded
	doc = Document(
		title=title or file.filename,
		original_filename=file.filename,
		content_type=file.content_type,
		size_bytes=file.size if hasattr(file, "size") else 0,
		owner_id=current_user.id,
		course_id=course_id,
		tags=tags.split(",") if tags else [],
		is_public=is_public,
		status="uploaded",
		language="fr",
	)
	db.add(doc)
	await db.flush()

	return created(
		message="Document téléversé. Traitement en cours.",
		data={"id": doc.id, "title": doc.title, "status": doc.status},
	)


@router.get("/", summary="Liste des documents")
async def list_documents(
	current_user: ActiveUser, db: DBSession, pagination: Pagination, search: str | None = Query(None)
):
	"""Liste paginée des documents de l'utilisateur."""
	from sqlalchemy import func, select

	query = select(Document).where(Document.owner_id == current_user.id, Document.is_deleted == False)  # noqa
	if search:
		query = query.where(Document.title.ilike(f"%{search}%"))

	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0

	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	docs = result.scalars().all()

	return paginated(
		items=[
			{
				"id": d.id,
				"title": d.title,
				"content_type": d.content_type,
				"status": d.status,
				"created_at": str(d.created_at),
			}
			for d in docs
		],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.get("/{document_id}", summary="Détail d'un document")
async def get_document(document_id: str, current_user: ActiveUser, db: DBSession):
	"""Retourne les détails d'un document, incluant les métadonnées OCR."""
	from sqlalchemy import select

	result = await db.execute(select(Document).where(Document.id == document_id, Document.is_deleted == False))  # noqa
	doc = result.scalar_one_or_none()
	if doc is None:
		return not_found("Document introuvable")
	return success(
		message="Document récupéré",
		data={
			"id": doc.id,
			"title": doc.title,
			"status": doc.status,
			"content_type": doc.content_type,
			"ocr_status": getattr(doc, "ocr_status", None),
		},
	)


@router.patch("/{document_id}", summary="Mettre à jour un document")
async def update_document(document_id: str, dto: UpdateDocumentDTO, current_user: ActiveUser, db: DBSession):
	"""Met à jour les métadonnées d'un document."""
	from sqlalchemy import select

	result = await db.execute(select(Document).where(Document.id == document_id))
	doc = result.scalar_one_or_none()
	if doc is None:
		return not_found("Document introuvable")
	for field, value in dto.model_dump(exclude_unset=True).items():
		setattr(doc, field, value)
	return success(message="Document mis à jour")


@router.delete("/{document_id}", summary="Supprimer un document (soft delete)")
async def delete_document(document_id: str, current_user: ActiveUser, db: DBSession):
	"""Soft delete d'un document."""
	from sqlalchemy import select

	result = await db.execute(select(Document).where(Document.id == document_id))
	doc = result.scalar_one_or_none()
	if doc is None:
		return not_found("Document introuvable")
	doc.is_deleted = True
	# À implémenter : Émettre événement DocumentDeleted
	return deleted(message="Document archivé")


@router.get("/{document_id}/versions", summary="Versions d'un document")
async def list_document_versions(document_id: str, current_user: ActiveUser, db: DBSession):
	"""Liste les versions du Document Vivant."""
	from sqlalchemy import select

	result = await db.execute(
		select(DocumentVersion)
		.where(DocumentVersion.document_id == document_id)
		.order_by(DocumentVersion.version_number.desc())
	)
	versions = result.scalars().all()
	return success(
		message="Versions récupérées",
		data=[{"id": v.id, "version": v.version_number, "created_at": str(v.created_at)} for v in versions],
	)


@router.post("/{document_id}/reindex", summary="Réindexer un document")
async def reindex_document(document_id: str, current_user: ActiveUser, db: DBSession, redis: RedisClient):
	"""Relance l'indexation d'un document (Self-Healing)."""
	# À implémenter : Intégrer avec le service d'indexation
	await redis.publish("document:reindex", document_id)
	return success(message="Réindexation lancée")
