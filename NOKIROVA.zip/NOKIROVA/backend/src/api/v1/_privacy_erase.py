"""NOKIROVA — Route Effacement RGPD (article 17)

Droit à l'effacement — suppression irréversible de toutes
les données utilisateur avec confirmation.

Principe BIBLE #8 : Confidentialité — l'utilisateur contrôle
ses données, y compris leur suppression.
Principe BIBLE #12 : Responsabilité — chaque effacement est journalisé.
"""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Body
from pydantic import BaseModel, Field
from sqlalchemy import delete as sql_delete
from sqlalchemy import select

from ...core.exceptions import ForbiddenException, ValidationException
from ...core.health_exceptions import DB_OPERATION_EXCEPTIONS
from ...core.logging import get_logger
from ...database.models.ai import AIConversation, AIMessage
from ...database.models.documents import Document
from ...database.models.flashcards import Flashcard
from ...database.models.notes import Note
from ...database.models.notifications import Notification
from ...database.models.quiz import QuizAttempt
from ...database.models.storage import File, StorageQuota
from ...database.models.users import User, UserDevice, UserProfile
from ...events.bus import Event, event_bus
from ..deps import ActiveUser, DBSession
from ..response import deleted

logger = get_logger(__name__)

DOMAINE_EVENEMENT = "privacy"


# ─── Modèles Pydantic ─────────────────────────────────────────────────────────


class EffacementConfirmationDTO(BaseModel):
	"""DTO pour confirmer l'effacement dur des données"""

	confirmation: str = Field(
		...,
		description="Tapez 'EFFACER' pour confirmer la suppression irréversible",
	)
	mot_de_passe: str = Field(
		...,
		description="Mot de passe actuel pour vérification d'identité",
	)


# Tables à purger lors de l'effacement (ordre dépendances)
TABLES_EFFACEMENT = [
	"ai_messages",
	"ai_conversations",
	"ai_reasoning_chains",
	"ai_usage_logs",
	"documents",
	"notes",
	"flashcards",
	"quiz_attempts",
	"storage_files",
	"storage_quotas",
	"notifications",
	"user_devices",
	"user_profiles",
]


# ─── Route ────────────────────────────────────────────────────────────────────

router = APIRouter(tags=["Confidentialité (RGPD)"])


@router.delete("/data", summary="Supprimer toutes mes données (effacement RGPD)")
async def effacer_donnees(
	user: ActiveUser,
	db: DBSession,
	corps: EffacementConfirmationDTO = Body(...),
):
	"""
	Droit à l'effacement — article 17 RGPD.

	Suppression IRRÉVERSIBLE de toutes les données utilisateur.
	Nécessite une confirmation écrite ("EFFACER") et la vérification
	du mot de passe actuel.

	Principe BIBLE #8 : Confidentialité — l'utilisateur contrôle
	ses données, y compris leur suppression.
	Principe BIBLE #12 : Responsabilité — chaque effacement est journalisé.
	"""
	logger.warning(f"Tentative d'effacement RGPD par l'utilisateur {user.id}")

	# ── Vérification de la confirmation ──
	if corps.confirmation != "EFFACER":
		raise ValidationException(
			"confirmation",
			"Tapez 'EFFACER' pour confirmer la suppression irréversible de vos données",
		)

	# ── Vérification du mot de passe ──
	from src.core.security import verify_password

	if not verify_password(corps.mot_de_passe, user.password_hash):
		raise ForbiddenException("Mot de passe incorrect — effacement refusé")

	utilisateur_id = str(user.id)

	# ── Suppression des données dans l'ordre des dépendances ──
	nb_supprime = 0

	# Messages IA
	try:
		conv_ids_result = await db.execute(
			select(AIConversation.id).where(AIConversation.user_id == utilisateur_id)
		)
		conv_ids = [str(cid) for cid in conv_ids_result.scalars().all()]
		if conv_ids:
			await db.execute(sql_delete(AIMessage).where(AIMessage.conversation_id.in_(conv_ids)))
			nb_supprime += len(conv_ids)
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression messages IA : {e}")

	# Conversations IA
	try:
		resultat = await db.execute(sql_delete(AIConversation).where(AIConversation.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression conversations IA : {e}")

	# Documents
	try:
		resultat = await db.execute(sql_delete(Document).where(Document.owner_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression documents : {e}")

	# Notes
	try:
		resultat = await db.execute(sql_delete(Note).where(Note.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression notes : {e}")

	# Flashcards
	try:
		resultat = await db.execute(sql_delete(Flashcard).where(Flashcard.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression flashcards : {e}")

	# Tentatives de quiz
	try:
		resultat = await db.execute(sql_delete(QuizAttempt).where(QuizAttempt.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression quiz : {e}")

	# Fichiers stockés
	try:
		resultat = await db.execute(sql_delete(File).where(File.owner_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression fichiers : {e}")

	# Quota stockage
	try:
		resultat = await db.execute(sql_delete(StorageQuota).where(StorageQuota.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression quota : {e}")

	# Notifications
	try:
		resultat = await db.execute(sql_delete(Notification).where(Notification.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression notifications : {e}")

	# Appareils
	try:
		resultat = await db.execute(sql_delete(UserDevice).where(UserDevice.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression appareils : {e}")

	# Profil
	try:
		resultat = await db.execute(sql_delete(UserProfile).where(UserProfile.user_id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression profil : {e}")

	# Utilisateur (suppression dure — pas de soft delete)
	try:
		resultat = await db.execute(sql_delete(User).where(User.id == utilisateur_id))
		nb_supprime += resultat.rowcount if hasattr(resultat, "rowcount") else 0
	except DB_OPERATION_EXCEPTIONS as e:
		logger.error(f"Erreur suppression utilisateur : {e}")

	# ── Valider la transaction ──
	await db.commit()

	# ── Journalisation et événement ──
	await event_bus.publish(
		Event(
			event_type="privacy_data_erased",
			domain=DOMAINE_EVENEMENT,
			payload={
				"user_id": utilisateur_id,
				"enregistrements_supprimes": nb_supprime,
				"horodatage": datetime.now(UTC).isoformat(),
			},
		)
	)

	logger.warning(
		f"Effacement RGPD complet pour l'utilisateur {utilisateur_id} — {nb_supprime} enregistrements supprimés"
	)

	return deleted(
		message=f"Données utilisateur supprimées définitivement — {nb_supprime} enregistrements effacés",
	)
