"""
NOKIROVA — Routes Chat v1

Conversations, messages, historique, threads.
Communication inter-utilisateurs et avec l'IA.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from ...database.models.chat import ChatMessage, ChatRoom
from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, paginated

router = APIRouter()


class CreateConversationDTO(BaseModel):
	title: str | None = Field(None, max_length=200)
	type: str = Field(default="direct", pattern=r"^(direct|group|ai|course)$")
	participant_ids: list[str] = []
	course_id: str | None = None


class SendMessageDTO(BaseModel):
	content: str = Field(min_length=1, max_length=10000)
	message_type: str = Field(default="text", pattern=r"^(text|image|file|code|ai_response)$")
	metadata_json: dict = {}


@router.get("/conversations", summary="Liste des conversations")
async def list_conversations(current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(ChatRoom).where(ChatRoom.is_deleted == False)  # noqa
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	convs = result.scalars().all()
	return paginated(
		items=[{"id": c.id, "name": c.name, "type": c.room_type} for c in convs],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/conversations", summary="Créer une conversation")
async def create_conversation(dto: CreateConversationDTO, current_user: ActiveUser, db: DBSession):
	conv = ChatRoom(
		name=dto.title or "Nouvelle conversation",
		room_type=dto.type,
		course_id=dto.course_id,
		created_by=current_user.id,
	)
	db.add(conv)
	await db.flush()
	# À implémenter : Ajouter les participants
	# À implémenter : Émettre événement ConversationCreated
	return created(message="Conversation créée", data={"id": conv.id})


@router.get("/conversations/{conversation_id}/messages", summary="Messages d'une conversation")
async def list_messages(conversation_id: str, current_user: ActiveUser, db: DBSession, pagination: Pagination):
	from sqlalchemy import func, select

	query = select(ChatMessage).where(ChatMessage.room_id == conversation_id, ChatMessage.is_deleted == False)  # noqa
	total_result = await db.execute(select(func.count()).select_from(query.subquery()))
	total = total_result.scalar() or 0
	result = await db.execute(query.offset(pagination.offset).limit(pagination.per_page))
	msgs = result.scalars().all()
	return paginated(
		items=[
			{"id": m.id, "content": m.content, "type": m.message_type, "created_at": str(m.created_at)}
			for m in msgs
		],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/conversations/{conversation_id}/messages", summary="Envoyer un message")
async def send_message(conversation_id: str, dto: SendMessageDTO, current_user: ActiveUser, db: DBSession):
	msg = ChatMessage(
		room_id=conversation_id,
		sender_id=current_user.id,
		content=dto.content,
		message_type=dto.message_type,
		metadata_json=dto.metadata_json,
	)
	db.add(msg)
	await db.flush()
	# À implémenter : Émettre événement MessageSent via Event Bus (WebSocket)
	# À implémenter : Si conversation IA, router vers le SIO
	return created(message="Message envoyé", data={"id": msg.id})


@router.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
	"""
	WebSocket pour communication temps réel.
	Supporte : messages, notifications, collaborations en direct.
	"""
	await websocket.accept()
	try:
		while True:
			data = await websocket.receive_text()
			# À implémenter : Router le message via Event Bus
			await websocket.send_text(f"[Echo] {data}")
	except WebSocketDisconnect:
		pass
