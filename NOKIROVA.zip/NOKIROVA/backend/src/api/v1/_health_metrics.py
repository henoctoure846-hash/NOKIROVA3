"""NOKIROVA — Métriques Vitales

Route GET /metrics — indicateurs système en temps réel.

Principe BIBLE #10 : Fiabilité — monitoring en temps réel.
Principe BIBLE #8 : Confidentialité — métriques anonymisées.
"""

from __future__ import annotations

from fastapi import APIRouter

from ...core.health_exceptions import DB_EXCEPTIONS, STORAGE_EXCEPTIONS
from ..deps import DBSession
from ..response import nokirova_success

router = APIRouter()


@router.get("/metrics")
async def metriques_vitales(
	db: DBSession,
):
	"""Métriques vitales du système."""
	import psutil

	try:
		cpu = psutil.cpu_percent()
		mem = psutil.virtual_memory()
		disk = psutil.disk_usage("/")
	except DB_EXCEPTIONS:
		cpu, mem, disk = 0, None, None

	# Event Bus stats
	bus_published = 0
	bus_processed = 0
	bus_failed = 0
	try:
		from src.events.bus import event_bus

		stats = await event_bus.get_stats()
		bus_published = stats.get("published", 0)
		bus_processed = stats.get("processed", 0)
		bus_failed = stats.get("failed", 0)
	except STORAGE_EXCEPTIONS:
		pass

	return nokirova_success(
		data={
			"requetes_par_minute": 0,
			"temps_reponse_moyen_ms": 0,
			"taux_erreur": 0.0,
			"utilisateurs_actifs": 0,
			"connexions_websocket": 0,
			"taches_celery_en_attente": 0,
			"memoire_utilisee_pourcent": mem.percent if mem else 0,
			"cpu_utilise_pourcent": cpu,
			"disque_utilise_pourcent": disk.percent if disk else 0,
			"cache_taux_reussite_pourcent": 0,
			"event_bus_publies": bus_published,
			"event_bus_traites": bus_processed,
			"event_bus_echoues": bus_failed,
		},
		message="Métriques vitales récupérées",
	)
