"""
NOKIROVA — Routes Utilisateurs v1

Profil, préférences, avatar, statistiques, suppression (soft delete).
"""

from fastapi import APIRouter, File, UploadFile
from pydantic import BaseModel, Field

from ...database.models.users import User
from ..deps import ActiveUser, AdminUser, DBSession, Pagination
from ..response import deleted, not_found, paginated, success

router = APIRouter()


# --- DTOs ---


class UpdateProfileDTO(BaseModel):
	first_name: str | None = Field(None, max_length=100)
	last_name: str | None = Field(None, max_length=100)
	bio: str | None = Field(None, max_length=500)
	locale: str | None = Field(None, pattern=r"^(fr|en|es|de)$")
	timezone: str | None = None


class UpdatePreferencesDTO(BaseModel):
	theme: str | None = Field(None, pattern=r"^(light|dark|auto)$")
	notifications_enabled: bool | None = None
	email_notifications: bool | None = None
	revision_reminders: bool | None = None
	accessibility_mode: bool | None = None
	font_size: str | None = Field(None, pattern=r"^(small|medium|large|xlarge)$")


# --- Endpoints ---


@router.get("/me", summary="Profil courant")
async def get_me(current_user: ActiveUser, db: DBSession):
	"""Retourne le profil complet de l'utilisateur connecté."""
	return success(
		message="Profil récupéré",
		data={
			"id": current_user.id,
			"email": current_user.email,
			"first_name": current_user.first_name,
			"last_name": current_user.last_name,
			"bio": current_user.bio,
			"avatar_url": current_user.avatar_url,
			"locale": current_user.locale,
			"timezone": current_user.timezone,
			"is_verified": current_user.is_verified,
			"is_active": current_user.is_active,
			"created_at": str(current_user.created_at),
		},
	)


@router.patch("/me", summary="Mettre à jour le profil")
async def update_me(dto: UpdateProfileDTO, current_user: ActiveUser, db: DBSession):
	"""Met à jour les informations du profil de l'utilisateur connecté."""
	for field, value in dto.model_dump(exclude_unset=True).items():
		setattr(current_user, field, value)
	return success(message="Profil mis à jour")


@router.put("/me/preferences", summary="Préférences utilisateur")
async def update_preferences(dto: UpdatePreferencesDTO, current_user: ActiveUser, db: DBSession):
	"""Met à jour les préférences de l'utilisateur connecté."""
	# À implémenter : Déléguer au service de préférences
	return success(message="Préférences mises à jour")


@router.post("/me/avatar", summary="Téléverser un avatar")
async def upload_avatar(current_user: ActiveUser, file: UploadFile = File(...)):
	"""Téléverse et remplace l'avatar de l'utilisateur."""
	# À implémenter : Déléguer au service de stockage via Event Bus
	# À implémenter : Redimensionner, valider le format, stocker sur S3/GCS
	return success(message="Avatar mis à jour")


@router.get("/me/stats", summary="Statistiques personnelles")
async def get_my_stats(current_user: ActiveUser, db: DBSession):
	"""Retourne les statistiques globales de l'utilisateur."""
	# À implémenter : Agréger depuis les services gamification + analytics
	return success(
		message="Statistiques récupérées",
		data={
			"courses_enrolled": 0,
			"documents_uploaded": 0,
			"flashcards_created": 0,
			"quizzes_completed": 0,
			"study_hours": 0.0,
			"streak_days": 0,
			"xp_total": 0,
			"level": 1,
		},
	)


@router.delete("/me", summary="Supprimer son compte (soft delete)")
async def delete_me(current_user: ActiveUser, db: DBSession):
	"""
	Soft delete du compte utilisateur.
	Les données sont archivées, pas supprimées définitivement.
	"""
	current_user.is_active = False
	# À implémenter : Émettre événement UserDeleted via Event Bus
	# À implémenter : Lancer workflow d'archivage
	return deleted(message="Compte désactivé. Données archivées.")


@router.get("/{user_id}", summary="Profil public d'un utilisateur")
async def get_user_profile(user_id: str, db: DBSession):
	"""Retourne le profil public d'un utilisateur."""
	from sqlalchemy import select

	result = await db.execute(select(User).where(User.id == user_id, User.is_active == True))  # noqa
	user = result.scalar_one_or_none()
	if user is None:
		return not_found("Utilisateur introuvable")

	return success(
		message="Profil récupéré",
		data={
			"id": user.id,
			"first_name": user.first_name,
			"last_name": user.last_name,
			"bio": user.bio,
			"avatar_url": user.avatar_url,
			"created_at": str(user.created_at),
		},
	)


@router.get("/", summary="Liste des utilisateurs (admin)")
async def list_users(admin_user: AdminUser, db: DBSession, pagination: Pagination):
	"""Liste paginée de tous les utilisateurs (réservé aux admins)."""
	from sqlalchemy import func, select

	total_result = await db.execute(select(func.count()).select_from(User))
	total = total_result.scalar() or 0

	result = await db.execute(select(User).offset(pagination.offset).limit(pagination.per_page))
	users = result.scalars().all()

	return paginated(
		items=[
			{
				"id": u.id,
				"email": u.email,
				"first_name": u.first_name,
				"last_name": u.last_name,
				"is_active": u.is_active,
			}
			for u in users
		],
		total=total,
		page=pagination.page,
		per_page=pagination.per_page,
	)
