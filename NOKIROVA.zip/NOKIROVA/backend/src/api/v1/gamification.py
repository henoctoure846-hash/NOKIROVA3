"""
NOKIROVA — Routes API Gamification

XP, badges, niveaux, séries (streaks), défis, classements, récompenses.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from ..deps import ActiveUser, DBSession, Pagination
from ..response import (
	nokirova_not_found,
	nokirova_paginated,
	nokirova_success,
)

router = APIRouter()


# ═══════════════════════════════════════
# DTO — Gamification
# ═══════════════════════════════════════


class ChallengeCreateDTO(BaseModel):
	"""Création d'un défi."""

	title: str = Field(..., min_length=3, max_length=200, description="Titre du défi")
	description: str = Field(..., min_length=10, max_length=5000, description="Description")
	challenge_type: str = Field(..., description="Type: quotidien, hebdomadaire, special")
	xp_reward: int = Field(..., ge=1, description="XP récompensé")
	badge_id: str | None = Field(None, description="Badge débloqué")
	criteria: dict = Field(default_factory=dict, description="Critères de validation")
	difficulty: str = Field("medium", pattern="^(easy|medium|hard|legendary)$", description="Difficulté")
	starts_at: str | None = Field(None, description="Date de début")
	ends_at: str | None = Field(None, description="Date de fin")


class BadgeCreateDTO(BaseModel):
	"""Création d'un badge."""

	name: str = Field(..., min_length=3, max_length=100, description="Nom du badge")
	description: str = Field(..., min_length=5, max_length=500, description="Description")
	icon: str = Field(..., description="Icône (emoji ou URL)")
	category: str = Field("general", max_length=50, description="Catégorie")
	rarity: str = Field("common", pattern="^(common|rare|epic|legendary)$", description="Rareté")
	criteria: dict = Field(default_factory=dict, description="Critères d'obtention")
	xp_bonus: int = Field(0, ge=0, description="Bonus XP")


# ═══════════════════════════════════════
# Profil de gamification
# ═══════════════════════════════════════


@router.get("/profile")
async def profil_gamification(
	db: DBSession,
	user: ActiveUser,
):
	"""Profil gamification complet : XP, niveau, badges, séries, statistiques."""
	return nokirova_success(
		data={
			"user_id": str(user.id),
			"xp_total": 0,
			"niveau": 1,
			"titre": "Débutant",
			"badges": [],
			"streak_actuel": 0,
			"streak_maximum": 0,
			"defis_completes": 0,
			"classement": None,
			"progression_niveau": {"actuel": 0, "objectif": 100, "pourcentage": 0},
		},
		message="Profil gamification récupéré",
	)


@router.get("/profile/{user_id}")
async def profil_gamification_utilisateur(
	user_id: str,
	db: DBSession,
):
	"""Consulter le profil gamification d'un autre utilisateur."""
	return nokirova_success(
		data={"user_id": user_id, "xp_total": 0, "niveau": 1},
		message="Profil gamification récupéré",
	)


# ═══════════════════════════════════════
# XP & Niveaux
# ═══════════════════════════════════════


@router.get("/xp/history")
async def historique_xp(
	db: DBSession,
	user: ActiveUser,
	pagination: Pagination,
	source: str | None = Query(None, description="Filtrer par source (cours, quiz, etc.)"),
):
	"""Historique des gains d'XP."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Historique XP récupéré",
	)


@router.get("/levels")
async def liste_niveaux(
	db: DBSession,
):
	"""Liste de tous les niveaux et leur paliers d'XP."""
	return nokirova_success(
		data=[],
		message="Niveaux récupérés",
	)


# ═══════════════════════════════════════
# Badges
# ═══════════════════════════════════════


@router.get("/badges")
async def liste_badges(
	db: DBSession,
	categorie: str | None = Query(None, description="Catégorie"),
):
	"""Lister tous les badges disponibles."""
	return nokirova_success(
		data=[],
		message="Badges récupérés",
	)


@router.get("/badges/{badge_id}")
async def detail_badge(
	badge_id: str,
	db: DBSession,
):
	"""Détail d'un badge."""
	return nokirova_not_found(
		message="Badge introuvable",
		resource_type="badge",
		resource_id=badge_id,
	)


@router.get("/badges/me")
async def mes_badges(
	db: DBSession,
	user: ActiveUser,
):
	"""Badges obtenus par l'utilisateur."""
	return nokirova_success(
		data=[],
		message="Vos badges récupérés",
	)


# ═══════════════════════════════════════
# Séries (Streaks)
# ═══════════════════════════════════════


@router.get("/streaks")
async def mes_series(
	db: DBSession,
	user: ActiveUser,
):
	"""Séries d'activité de l'utilisateur (journalière, hebdomadaire)."""
	return nokirova_success(
		data={
			"streak_journalier": {"actuel": 0, "maximum": 0, "derniere_activite": None},
			"streak_hebdomadaire": {"actuel": 0, "maximum": 0},
		},
		message="Séries récupérées",
	)


# ═══════════════════════════════════════
# Défis
# ═══════════════════════════════════════


@router.get("/challenges")
async def liste_defis(
	db: DBSession,
	pagination: Pagination,
	type_defi: str | None = Query(None, description="Type: quotidien, hebdomadaire, special"),
	statut: str | None = Query(None, description="Statut: actif, complete, expire"),
):
	"""Lister les défis disponibles."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Défis récupérés",
	)


@router.get("/challenges/{challenge_id}")
async def detail_defi(
	challenge_id: str,
	db: DBSession,
):
	"""Détail d'un défi."""
	return nokirova_not_found(
		message="Défi introuvable",
		resource_type="challenge",
		resource_id=challenge_id,
	)


@router.post("/challenges/{challenge_id}/accept")
async def accepter_defi(
	challenge_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Accepter un défi."""
	return nokirova_success(
		data={"challenge_id": challenge_id, "status": "en_cours"},
		message="Défi accepté",
	)


@router.post("/challenges/{challenge_id}/complete")
async def completer_defi(
	challenge_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Valider l'accomplissement d'un défi."""
	# Déclenche l'attribution d'XP et le déblocage de badge via Event Bus
	return nokirova_success(
		data={"challenge_id": challenge_id, "status": "complete", "xp_gagne": 0},
		message="Défi complété — récompenses attribuées",
	)


# ═══════════════════════════════════════
# Classements (Leaderboards)
# ═══════════════════════════════════════


@router.get("/leaderboard")
async def classement_global(
	db: DBSession,
	periode: str = Query("all", pattern="^(week|month|semester|all)$", description="Période"),
	matiere: str | None = Query(None, description="Matière"),
	limite: int = Query(50, ge=1, le=200, description="Nombre de résultats"),
):
	"""Classement global des étudiants."""
	return nokirova_success(
		data=[],
		message=f"Classement {periode} récupéré",
	)


@router.get("/leaderboard/friends")
async def classement_amis(
	db: DBSession,
	user: ActiveUser,
):
	"""Classement entre amis."""
	return nokirova_success(
		data=[],
		message="Classement entre amis récupéré",
	)


# ═══════════════════════════════════════
# Récompenses & Boutique
# ═══════════════════════════════════════


@router.get("/rewards")
async def boutique_recompenses(
	db: DBSession,
):
	"""Lister les récompenses échangeables contre des XP."""
	return nokirova_success(
		data=[],
		message="Récompenses disponibles",
	)


@router.post("/rewards/{reward_id}/redeem")
async def echanger_recompense(
	reward_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Échanger des XP contre une récompense."""
	return nokirova_success(
		data={"reward_id": reward_id},
		message="Récompense échangée avec succès",
	)
