"""
NOKIROVA — Routes API Marketplace

Marketplace de plugins, contenus et assistants IA.
Catalogue, installation, avis, recommandations IA.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field

from ..deps import ActiveUser, AdminUser, DBSession, Pagination
from ..response import (
	nokirova_created,
	nokirova_deleted,
	nokirova_not_found,
	nokirova_paginated,
	nokirova_success,
)

router = APIRouter()


# ═══════════════════════════════════════
# DTO — Marketplace
# ═══════════════════════════════════════


class PluginSubmitDTO(BaseModel):
	"""Soumission d'un plugin au marketplace."""

	name: str = Field(..., min_length=3, max_length=100, description="Nom du plugin")
	description: str = Field(..., min_length=10, max_length=5000, description="Description")
	category: str = Field(..., max_length=50, description="Catégorie")
	version: str = Field(..., description="Version sémantique")
	repository_url: str = Field(..., description="URL du dépôt")
	documentation_url: str | None = Field(None, description="URL de documentation")
	icon_url: str | None = Field(None, description="URL de l'icône")
	screenshots: list[str] = Field(default_factory=list, description="Captures d'écran")
	price: float = Field(0.0, ge=0, description="Prix (0 = gratuit)")
	tags: list[str] = Field(default_factory=list, description="Tags")
	permissions: list[str] = Field(default_factory=list, description="Permissions requises")


class PluginInstallDTO(BaseModel):
	"""Installation d'un plugin depuis le marketplace."""

	plugin_id: str = Field(..., description="Identifiant du plugin")
	version: str | None = Field(None, description="Version spécifique (défaut: dernière)")
	config: dict = Field(default_factory=dict, description="Configuration initiale")


class ReviewCreateDTO(BaseModel):
	"""Avis sur un plugin / contenu."""

	rating: int = Field(..., ge=1, le=5, description="Note (1-5)")
	title: str = Field(..., min_length=3, max_length=200, description="Titre de l'avis")
	content: str = Field("", max_length=5000, description="Contenu de l'avis")


class AssistantSubmitDTO(BaseModel):
	"""Soumission d'un assistant IA au marketplace."""

	name: str = Field(..., min_length=3, max_length=100, description="Nom de l'assistant")
	description: str = Field(..., min_length=10, max_length=5000, description="Description")
	system_prompt: str = Field(..., min_length=10, max_length=10000, description="Prompt système")
	model: str = Field("gpt-4", description="Modèle IA utilisé")
	capabilities: list[str] = Field(default_factory=list, description="Capacités")
	price: float = Field(0.0, ge=0, description="Prix par utilisation")
	tags: list[str] = Field(default_factory=list, description="Tags")


# ═══════════════════════════════════════
# Catalogue — Navigation
# ═══════════════════════════════════════


@router.get("/catalog")
async def catalogue_marketplace(
	db: DBSession,
	pagination: Pagination,
	type_article: str | None = Query(None, description="Type: plugin, contenu, assistant"),
	categorie: str | None = Query(None, description="Catégorie"),
	recherche: str | None = Query(None, description="Recherche textuelle"),
	tri: str = Query("populaire", pattern="^(populaire|recent|note|telechargement|prix)$", description="Tri"),
	gratuit: bool | None = Query(None, description="Uniquement gratuit"),
):
	"""Parcourir le catalogue du marketplace avec filtres et recommandations."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Catalogue marketplace récupéré",
	)


@router.get("/catalog/recommended")
async def recommandations_ia(
	db: DBSession,
	user: ActiveUser,
	limite: int = Query(10, ge=1, le=50, description="Nombre de résultats"),
):
	"""Recommandations IA personnalisées basées sur le profil et l'historique."""
	return nokirova_success(
		data=[],
		message="Recommandations IA générées",
	)


@router.get("/catalog/featured")
async def selections_editeur(
	db: DBSession,
):
	"""Sélections de l'équipe NOKIROVA — coups de projet."""
	return nokirova_success(
		data=[],
		message="Séctions de l'équipe récupérées",
	)


# ═══════════════════════════════════════
# Plugins — CRUD
# ═══════════════════════════════════════


@router.get("/plugins/{plugin_id}")
async def detail_plugin(
	plugin_id: str,
	db: DBSession,
):
	"""Détail d'un plugin avec statistiques et avis."""
	return nokirova_not_found(
		message="Plugin introuvable",
		resource_type="plugin",
		resource_id=plugin_id,
	)


@router.post("/plugins/submit")
async def soumettre_plugin(
	dto: PluginSubmitDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Soumettre un nouveau plugin au marketplace."""
	# Déclenche un workflow de validation IA + revue humaine
	return nokirova_created(
		data={"name": dto.name, "status": "en_revision"},
		message="Plugin soumis — en attente de validation",
	)


@router.put("/plugins/{plugin_id}")
async def mettre_a_jour_plugin(
	plugin_id: str,
	dto: PluginSubmitDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Mettre à jour un plugin existant."""
	return nokirova_success(
		data={"plugin_id": plugin_id},
		message="Plugin mis à jour",
	)


@router.delete("/plugins/{plugin_id}")
async def retirer_plugin(
	plugin_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Retirer un plugin du marketplace."""
	return nokirova_deleted(message="Plugin retiré du marketplace")


# ═══════════════════════════════════════
# Installation / Désinstallation
# ═══════════════════════════════════════


@router.post("/install")
async def installer_plugin(
	dto: PluginInstallDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Installer un plugin depuis le marketplace."""
	# Déclenche le workflow d'installation avec isolation sandbox
	return nokirova_created(
		data={"plugin_id": dto.plugin_id, "status": "installation_en_cours"},
		message="Installation du plugin en cours",
	)


@router.post("/uninstall/{install_id}")
async def desinstaller_plugin(
	install_id: str,
	db: DBSession,
	user: ActiveUser,
):
	"""Désinstaller un plugin."""
	return nokirova_success(
		data={"install_id": install_id},
		message="Plugin désinstallé",
	)


# ═══════════════════════════════════════
# Avis / Reviews
# ═══════════════════════════════════════


@router.get("/plugins/{plugin_id}/reviews")
async def avis_plugin(
	plugin_id: str,
	db: DBSession,
	pagination: Pagination,
):
	"""Lister les avis d'un plugin."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Avis récupérés",
	)


@router.post("/plugins/{plugin_id}/reviews")
async def creer_avis(
	plugin_id: str,
	dto: ReviewCreateDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Publier un avis sur un plugin."""
	return nokirova_created(
		data={"plugin_id": plugin_id, "rating": dto.rating},
		message="Avis publié",
	)


# ═══════════════════════════════════════
# Assistants IA
# ═══════════════════════════════════════


@router.get("/assistants")
async def lister_assistants(
	db: DBSession,
	pagination: Pagination,
	categorie: str | None = Query(None, description="Catégorie"),
):
	"""Lister les assistants IA du marketplace."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Assistants IA récupérés",
	)


@router.post("/assistants/submit")
async def soumettre_assistant(
	dto: AssistantSubmitDTO,
	db: DBSession,
	user: ActiveUser,
):
	"""Soumettre un assistant IA au marketplace."""
	return nokirova_created(
		data={"name": dto.name, "status": "en_revision"},
		message="Assistant IA soumis — en attente de validation",
	)


@router.get("/assistants/{assistant_id}")
async def detail_assistant(
	assistant_id: str,
	db: DBSession,
):
	"""Détail d'un assistant IA."""
	return nokirova_not_found(
		message="Assistant IA introuvable",
		resource_type="assistant",
		resource_id=assistant_id,
	)


# ═══════════════════════════════════════
# Administration marketplace
# ═══════════════════════════════════════


@router.get("/admin/submissions")
async def soumissions_en_attente(
	db: DBSession,
	pagination: Pagination,
	admin: AdminUser,
):
	"""Lister les soumissions en attente de validation (admin)."""
	return nokirova_paginated(
		data=[],
		total=0,
		page=pagination.page,
		per_page=pagination.per_page,
		message="Soumissions en attente récupérées",
	)


@router.post("/admin/submissions/{submission_id}/approve")
async def approuver_soumission(
	submission_id: str,
	db: DBSession,
	admin: AdminUser,
):
	"""Approuver une soumission de plugin/assistant."""
	return nokirova_success(
		data={"submission_id": submission_id, "status": "approuve"},
		message="Soumission approuvée",
	)


@router.post("/admin/submissions/{submission_id}/reject")
async def rejeter_soumission(
	submission_id: str,
	raison: str = Query(..., description="Raison du rejet"),
	db: DBSession = None,
	admin: AdminUser = None,
):
	"""Rejeter une soumission."""
	return nokirova_success(
		data={"submission_id": submission_id, "status": "rejete"},
		message="Soumission rejetée",
	)
