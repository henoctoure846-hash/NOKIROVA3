"""NOKIROVA — Routes Révision v1

Plan de révision, espacement adaptatif, sessions,
calendrier de révision. Espace Réviser.
"""

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..deps import ActiveUser, DBSession, Pagination
from ..response import created, paginated, success

router = APIRouter()


# --- DTOs locaux pour le routeur ---


class CreateRevisionPlanDTO(BaseModel):
	title: str = Field(min_length=3, max_length=200)
	description: str | None = Field(None, max_length=1000)
	course_id: str | None = None
	plan_type: str = Field(default="spaced", pattern=r"^(spaced|cram|pomodoro|custom)$")
	start_date: str | None = None
	end_date: str | None = None
	exam_date: str | None = None
	daily_hours: float = Field(default=2.0, ge=0.5, le=12.0)
	priority: str = Field(default="medium", pattern=r"^(low|medium|high|critical)$")
	algorithm: str = Field(default="sm2", pattern=r"^(sm2|leitner|custom)$")


class UpdateRevisionPlanDTO(BaseModel):
	title: str | None = Field(None, min_length=3, max_length=200)
	description: str | None = Field(None, max_length=1000)
	plan_type: str | None = Field(None, pattern=r"^(spaced|cram|pomodoro|custom)$")
	daily_hours: float | None = Field(None, ge=0.5, le=12.0)
	priority: str | None = Field(None, pattern=r"^(low|medium|high|critical)$")
	status: str | None = Field(None, pattern=r"^(draft|active|paused|completed|archived)$")


class AddTopicDTO(BaseModel):
	plan_id: str
	name: str = Field(min_length=1, max_length=200)
	description: str | None = Field(None, max_length=1000)
	subject: str | None = Field(None, max_length=100)
	priority: str = Field(default="medium", pattern=r"^(low|medium|high|critical)$")
	difficulty: str = Field(default="medium", pattern=r"^(easy|medium|hard)$")
	confidence_level: float = Field(default=0.5, ge=0.0, le=1.0)
	estimated_hours: float = Field(default=1.0, ge=0.1, le=100.0)


class LogRevisionDTO(BaseModel):
	plan_id: str
	topic_id: str | None = None
	session_type: str = Field(default="study", pattern=r"^(study|review|practice|break)$")
	duration_minutes: int = Field(default=25, ge=5, le=480)


class EndSessionDTO(BaseModel):
	actual_duration_minutes: int | None = Field(None, ge=1, le=480)
	focus_score: float | None = Field(None, ge=0.0, le=100.0)
	status: str | None = Field(None, pattern=r"^(completed|skipped)$")
	notes: str | None = Field(None, max_length=2000)


# --- Routes ---


@router.get("/plans", summary="Plans de révision")
async def list_plans(current_user: ActiveUser, db: DBSession, pagination: Pagination):
	"""Liste les plans de révision de l'utilisateur."""
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	result = await svc.list_plans(db, current_user.id, pagination.offset, pagination.per_page)
	return paginated(
		items=[p.model_dump() for p in result.plans],
		total=result.total,
		page=pagination.page,
		per_page=pagination.per_page,
	)


@router.post("/plans", summary="Créer un plan de révision")
async def create_plan(dto: CreateRevisionPlanDTO, current_user: ActiveUser, db: DBSession):
	"""Crée un nouveau plan de révision."""
	from src.services.revision.dto import RevisionPlanCreateRequest
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	req = RevisionPlanCreateRequest(**dto.model_dump())
	plan = await svc.create_plan(db, current_user.id, req)
	return created(message="Plan de révision créé", data=plan.model_dump())


@router.get("/plans/{plan_id}", summary="Détail d'un plan")
async def get_plan(plan_id: str, current_user: ActiveUser, db: DBSession):
	"""Récupère les détails d'un plan de révision."""
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	result = await svc.get_plan(db, plan_id, current_user.id)
	if not result:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Plan non trouvé")
	return success(message="Plan récupéré", data=result.model_dump())


@router.patch("/plans/{plan_id}", summary="Mettre à jour un plan")
async def update_plan(plan_id: str, dto: UpdateRevisionPlanDTO, current_user: ActiveUser, db: DBSession):
	"""Met à jour un plan de révision."""
	from src.services.revision.dto import RevisionPlanUpdateRequest
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	req = RevisionPlanUpdateRequest(**dto.model_dump(exclude_unset=True))
	result = await svc.update_plan(db, plan_id, current_user.id, req)
	if not result:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Plan non trouvé")
	return success(message="Plan mis à jour", data=result.model_dump())


@router.delete("/plans/{plan_id}", summary="Supprimer un plan")
async def delete_plan(plan_id: str, current_user: ActiveUser, db: DBSession):
	"""Supprime (logiquement) un plan de révision."""
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	ok = await svc.delete_plan(db, plan_id, current_user.id)
	if not ok:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Plan non trouvé")
	return success(message="Plan supprimé")


@router.post("/topics", summary="Ajouter un sujet de révision")
async def add_topic(dto: AddTopicDTO, current_user: ActiveUser, db: DBSession):
	"""Ajoute un sujet à un plan de révision."""
	from src.services.revision.dto import RevisionTopicCreateRequest
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	req = RevisionTopicCreateRequest(**dto.model_dump())
	result = await svc.add_topic(db, current_user.id, req)
	if not result:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Plan non trouvé")
	return created(message="Sujet ajouté", data=result.model_dump())


@router.post("/sessions/start", summary="Démarrer une session")
async def start_session(dto: LogRevisionDTO, current_user: ActiveUser, db: DBSession):
	"""Démarre une nouvelle session de révision."""
	from src.services.revision.dto import RevisionSessionStartRequest
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	req = RevisionSessionStartRequest(**dto.model_dump())
	result = await svc.start_session(db, current_user.id, req)
	if not result:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Plan non trouvé")
	return created(message="Session démarrée", data=result.model_dump())


@router.patch("/sessions/{session_id}/end", summary="Terminer une session")
async def end_session(session_id: str, dto: EndSessionDTO, current_user: ActiveUser, db: DBSession):
	"""Termine une session de révision en cours."""
	from src.services.revision.dto import RevisionSessionEndRequest
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	req = RevisionSessionEndRequest(**dto.model_dump(exclude_unset=True))
	result = await svc.end_session(db, session_id, current_user.id, req)
	if not result:
		from fastapi import HTTPException

		raise HTTPException(status_code=404, detail="Session non trouvée")
	return success(message="Session terminée", data=result.model_dump())


@router.get("/plans/{plan_id}/schedule", summary="Calendrier de révision")
async def get_schedule(plan_id: str, current_user: ActiveUser, db: DBSession):
	"""Retourne le calendrier de révision adaptatif."""
	# À implémenter : Calculer via le service de révision espacée
	return success(message="Calendrier récupéré", data={"plan_id": plan_id, "sessions": []})


@router.get("/today", summary="Révisions du jour")
async def get_today_revision(current_user: ActiveUser, db: DBSession):
	"""Retourne les items à réviser aujourd'hui."""
	# À implémenter : Calculer via le service de révision espacée
	return success(message="Révisions du jour", data={"items": [], "total_estimated_minutes": 0})


@router.get("/stats", summary="Statistiques de révision")
async def get_revision_stats(current_user: ActiveUser, db: DBSession):
	"""Statistiques globales de révision."""
	from src.services.revision.service import RevisionService

	svc = RevisionService()
	result = await svc.get_summary(db, current_user.id)
	return success(message="Statistiques récupérées", data=result)
