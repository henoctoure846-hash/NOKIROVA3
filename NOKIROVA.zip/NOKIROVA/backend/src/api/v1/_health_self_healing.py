"""NOKIROVA — Routes Self-Healing

Statut, historique et déclenchement manuel du système
d'auto-réparation.

Principe BIBLE #10 : Fiabilité — auto-réparation proactive.
Principe BIBLE #6 : Résilience — récupération automatique.
"""

from __future__ import annotations

from fastapi import APIRouter, Query

from ...core.health_exceptions import AI_CONFIG_EXCEPTIONS, DB_EXCEPTIONS
from ..deps import AdminUser, DBSession
from ..response import nokirova_error, nokirova_success

router = APIRouter()


@router.get("/self-healing/status")
async def statut_self_healing(
	db: DBSession,
):
	"""Statut du système de self-healing."""
	try:
		from src.self_healing.engine import self_healing_engine

		stats = self_healing_engine.get_stats()
		strategies = self_healing_engine.get_strategies_status()

		return nokirova_success(
			data={
				"active": stats.get("running", False),
				"strategies": {
					s["name"]: {
						"action": f"auto_heal_{s['name']}",
						"max_retries": s["max_retries"],
						"category": s["category"],
					}
					for s in strategies
				},
				"incidents_24h": stats.get("incidents_24h", 0),
				"auto_reparations_24h": stats.get("auto_reparations_24h", 0),
				"total_incidents": stats.get("total_incidents", 0),
				"incidents_resolus": stats.get("incidents_resolus", 0),
				"incidents_escalades": stats.get("incidents_escalades", 0),
			},
			message="Statut self-healing récupéré",
		)
	# Attrape-tout intentionnel : sonde santé
	except Exception as e:
		return nokirova_error(f"Erreur récupération statut self-healing : {e}")


@router.get("/self-healing/history")
async def historique_self_healing(
	db: DBSession,
	admin: AdminUser,
	limite: int = Query(50, ge=1, le=500, description="Nombre d'entrées"),
):
	"""Historique des auto-réparations."""
	try:
		from src.self_healing.engine import self_healing_engine

		history = self_healing_engine.get_incident_history(limit=limite)
		return nokirova_success(
			data=history,
			message="Historique self-healing récupéré",
		)
	except DB_EXCEPTIONS as e:
		return nokirova_error(f"Erreur récupération historique : {e}")


@router.post("/self-healing/trigger")
async def declencher_verification(
	db: DBSession,
	admin: AdminUser,
	categorie: str | None = Query(None, description="Catégorie spécifique à vérifier"),
):
	"""Déclencher une vérification manuelle du self-healing."""
	try:
		from src.self_healing.engine import self_healing_engine

		results = await self_healing_engine.trigger_manual_check(category=categorie)
		return nokirova_success(
			data={
				"verification_declenchee": True,
				"incidents_detectes": len(results),
				"incidents": results,
			},
			message="Vérification manuelle déclenchée",
		)
	except AI_CONFIG_EXCEPTIONS as e:
		return nokirova_error(f"Erreur vérification manuelle : {e}")
