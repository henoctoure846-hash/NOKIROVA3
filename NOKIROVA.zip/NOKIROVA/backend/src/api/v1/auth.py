"""
NOKIROVA — Routes Authentification v1

Inscription, connexion, déconnexion, rafraîchissement de token,
réinitialisation de mot de passe, vérification email, OAuth.
"""

from datetime import UTC

from fastapi import APIRouter, BackgroundTasks, Request
from pydantic import BaseModel, EmailStr, Field

from ...core.config import get_settings
from ...core.security import (
	create_access_token,
	create_refresh_token,
	decode_token,
	hash_password,
	verify_password,
)
from ...database.models.auth import (
	LoginHistory,
	PasswordReset,
)
from ...database.models.users import User
from ..deps import ActiveUser, DBSession, RedisClient
from ..response import created, error, success, unauthorized

router = APIRouter()


# --- DTOs (Data Transfer Objects) ---


class RegisterDTO(BaseModel):
	"""DTO d'inscription."""

	email: EmailStr
	password: str = Field(min_length=8, max_length=128)
	first_name: str = Field(min_length=1, max_length=100)
	last_name: str = Field(min_length=1, max_length=100)
	university_id: str | None = None
	locale: str = Field(default="fr", pattern=r"^(fr|en|es|de)$")


class LoginDTO(BaseModel):
	"""DTO de connexion."""

	email: EmailStr
	password: str
	device_fingerprint: str | None = None
	remember_me: bool = False


class RefreshDTO(BaseModel):
	"""DTO de rafraîchissement de token."""

	refresh_token: str


class ForgotPasswordDTO(BaseModel):
	"""DTO de demande de réinitialisation."""

	email: EmailStr


class ResetPasswordDTO(BaseModel):
	"""DTO de réinitialisation effective."""

	token: str
	new_password: str = Field(min_length=8, max_length=128)


class ChangePasswordDTO(BaseModel):
	"""DTO de changement de mot de passe."""

	current_password: str
	new_password: str = Field(min_length=8, max_length=128)


class VerifyEmailDTO(BaseModel):
	"""DTO de vérification email."""

	token: str


# --- Endpoints ---


@router.post("/register", summary="Inscription")
async def register(
	dto: RegisterDTO,
	db: DBSession,
	background_tasks: BackgroundTasks,
	request: Request,
):
	"""
	Inscription d'un nouvel utilisateur.
	- Vérifie l'unicité de l'email
	- Hache le mot de passe
	- Crée l'utilisateur et la session d'auth
	- Envoie l'email de vérification en arrière-plan
	"""
	from sqlalchemy import select

	# Vérifier unicité email
	result = await db.execute(select(User).where(User.email == dto.email))
	if result.scalar_one_or_none() is not None:
		return error("Cet email est déjà utilisé", status_code=409)

	# Créer utilisateur
	user = User(
		email=dto.email,
		password_hash=hash_password(dto.password),
		first_name=dto.first_name,
		last_name=dto.last_name,
		university_id=dto.university_id,
		locale=dto.locale,
		is_active=True,
		is_verified=False,
	)
	db.add(user)
	await db.flush()

	# Enregistrer la connexion dans l'historique
	login_record = LoginHistory(
		user_id=user.id,
		ip_address=request.client.host if request.client else None,
		user_agent=request.headers.get("user-agent", ""),
		was_successful=True,
	)
	db.add(login_record)

	# Email de vérification (arrière-plan)
	# À implémenter : Intégrer le service d'email via Event Bus
	# background_tasks.add_task(send_verification_email, user.id, user.email)

	# Tokens
	access = create_access_token({"sub": user.id, "email": user.email})
	refresh = create_refresh_token({"sub": user.id})

	return created(
		message="Inscription réussie. Vérifiez votre email.",
		data={
			"user": {"id": user.id, "email": user.email, "first_name": user.first_name},
			"access_token": access,
			"refresh_token": refresh,
			"token_type": "bearer",
		},
	)


@router.post("/login", summary="Connexion")
async def login(
	dto: LoginDTO,
	db: DBSession,
	redis: RedisClient,
	request: Request,
):
	"""
	Connexion d'un utilisateur existant.
	- Vérifie identifiants
	- Crée session d'authentification
	- Retourne les tokens JWT
	"""
	from sqlalchemy import select

	result = await db.execute(select(User).where(User.email == dto.email))
	user = result.scalar_one_or_none()

	if user is None or not verify_password(dto.password, user.password_hash):
		return unauthorized("Identifiants invalides")

	if not user.is_active:
		return error("Compte désactivé", status_code=403)

	# Enregistrer la connexion dans l'historique
	login_record = LoginHistory(
		user_id=user.id,
		ip_address=request.client.host if request.client else None,
		user_agent=request.headers.get("user-agent", ""),
		was_successful=True,
	)
	db.add(login_record)

	# Invalider anciens refresh tokens (rotation)
	# À implémenter : via repository

	# Tokens
	access = create_access_token({"sub": user.id, "email": user.email})
	refresh = create_refresh_token({"sub": user.id})

	# Cache Redis : session active
	await redis.setex(
		f"user:session:{user.id}",
		get_settings().jwt.access_token_expire_minutes * 60,
		login_record.id,
	)

	return success(
		message="Connexion réussie",
		data={
			"access_token": access,
			"refresh_token": refresh,
			"token_type": "bearer",
			"expires_in": get_settings().jwt.access_token_expire_minutes * 60,
		},
	)


@router.post("/refresh", summary="Rafraîchir le token")
async def refresh_token(dto: RefreshDTO, db: DBSession):
	"""Rafraîchit le token d'accès via le refresh token."""
	payload = decode_token(dto.refresh_token)
	if payload is None:
		return unauthorized("Refresh token invalide ou expiré")

	user_id = payload.get("sub")
	# À implémenter : Vérifier que le refresh token existe en base et n'est pas révoqué

	access = create_access_token({"sub": user_id})
	new_refresh = create_refresh_token({"sub": user_id})

	return success(
		message="Token rafraîchi",
		data={
			"access_token": access,
			"refresh_token": new_refresh,
			"token_type": "bearer",
		},
	)


@router.post("/logout", summary="Déconnexion")
async def logout(current_user: ActiveUser, db: DBSession, redis: RedisClient):
	"""
	Déconnexion : révoque la session courante et les tokens associés.
	"""
	await redis.delete(f"user:session:{current_user.id}")
	# À implémenter : Révoquer refresh tokens en base via repository
	return success(message="Déconnexion réussie")


@router.post("/forgot-password", summary="Mot de passe oublié")
async def forgot_password(dto: ForgotPasswordDTO, db: DBSession, background_tasks: BackgroundTasks):
	"""
	Demande un lien de réinitialisation de mot de passe.
	- Vérifie l'existence de l'utilisateur
	- Crée un token de réinitialisation
	- Envoie l'email (arrière-plan)
	"""
	import secrets

	from sqlalchemy import select

	result = await db.execute(select(User).where(User.email == dto.email))
	user = result.scalar_one_or_none()

	# Toujours répondre succès pour éviter l'énumération d'emails
	if user is None:
		return success(message="Si cet email existe, un lien de réinitialisation a été envoyé")

	token = secrets.token_urlsafe(32)
	from datetime import datetime, timedelta

	expires = (datetime.now(UTC) + timedelta(hours=1)).isoformat()
	reset = PasswordReset(
		user_id=user.id,
		token=hash_password(token),  # Hacher le token pour la base
		expires_at=expires,
	)
	db.add(reset)

	# À implémenter : Envoyer email via Event Bus
	# background_tasks.add_task(send_password_reset_email, user.email, token)

	return success(message="Si cet email existe, un lien de réinitialisation a été envoyé")


@router.post("/reset-password", summary="Réinitialiser le mot de passe")
async def reset_password(dto: ResetPasswordDTO, db: DBSession):
	"""Réinitialise le mot de passe via le token de réinitialisation."""
	# À implémenter : Vérifier le token en base via repository
	# À implémenter : Mettre à jour le mot de passe
	return success(message="Mot de passe réinitialisé avec succès")


@router.post("/verify-email", summary="Vérification email")
async def verify_email(dto: VerifyEmailDTO, db: DBSession):
	"""Vérifie l'email de l'utilisateur via le token envoyé."""
	# À implémenter : Vérifier le token de vérification en base
	# À implémenter : Marquer is_verified = True
	return success(message="Email vérifié avec succès")


@router.post("/change-password", summary="Changer le mot de passe")
async def change_password(dto: ChangePasswordDTO, current_user: ActiveUser, db: DBSession):
	"""Change le mot de passe de l'utilisateur connecté."""
	if not verify_password(dto.current_password, current_user.password_hash):
		return error("Mot de passe actuel incorrect", status_code=400)

	current_user.password_hash = hash_password(dto.new_password)
	return success(message="Mot de passe modifié avec succès")
