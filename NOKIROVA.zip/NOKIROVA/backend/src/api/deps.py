"""
NOKIROVA — Dépendances FastAPI

Injection de dépendances pour : authentification, base de données,
Redis, permissions admin, pagination, rate limiting.
"""

from typing import Annotated

import redis.asyncio as redis
from fastapi import Depends, HTTPException, Query, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.config import get_settings
from ..core.security import decode_access_token
from ..database import get_db
from ..database.models.users import User

# --- Schéma d'authentification ---

security_scheme = HTTPBearer(auto_error=False)


# --- Dépendances base de données ---


async def get_redis() -> redis.Redis:
	"""Dépendance : client Redis asynchrone."""
	redis_client = redis.from_url(
		get_settings().redis.url,
		encoding="utf-8",
		decode_responses=True,
	)
	try:
		yield redis_client
	finally:
		await redis_client.close()


# --- Dépendances authentification ---


async def get_current_user(
	credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(security_scheme)],
	db: Annotated[AsyncSession, Depends(get_db)],
) -> User:
	"""
	Dépendance : utilisateur courant authentifié.
	Lève 401 si le token est manquant, invalide ou expiré.
	"""
	if credentials is None:
		raise HTTPException(
			status_code=status.HTTP_401_UNAUTHORIZED,
			detail="Token d'authentification manquant",
		)

	payload = decode_access_token(credentials.credentials)
	if payload is None:
		raise HTTPException(
			status_code=status.HTTP_401_UNAUTHORIZED,
			detail="Token invalide ou expiré",
		)

	user_id = payload.get("sub")
	if user_id is None:
		raise HTTPException(
			status_code=status.HTTP_401_UNAUTHORIZED,
			detail="Token malformé",
		)

	# Récupérer l'utilisateur en base
	from sqlalchemy import select

	result = await db.execute(select(User).where(User.id == user_id))
	user = result.scalar_one_or_none()

	if user is None:
		raise HTTPException(
			status_code=status.HTTP_401_UNAUTHORIZED,
			detail="Utilisateur introuvable",
		)

	return user


async def get_current_active_user(
	current_user: Annotated[User, Depends(get_current_user)],
) -> User:
	"""
	Dépendance : utilisateur courant actif.
	Lève 403 si le compte est désactivé.
	"""
	if not current_user.is_active:
		raise HTTPException(
			status_code=status.HTTP_403_FORBIDDEN,
			detail="Compte désactivé",
		)
	return current_user


async def get_admin_user(
	current_user: Annotated[User, Depends(get_current_active_user)],
	db: Annotated[AsyncSession, Depends(get_db)],
) -> User:
	"""
	Dépendance : utilisateur administrateur.
	Lève 403 si l'utilisateur n'est pas admin.
	"""
	from sqlalchemy import select

	from ..database.models.admin import AdminRole, AdminUserRole

	result = await db.execute(
		select(AdminUserRole)
		.join(AdminRole)
		.where(
			AdminUserRole.user_id == current_user.id,
			AdminUserRole.is_active == True,  # noqa: E712
			AdminRole.level <= 1,  # super_admin ou admin
		)
	)
	admin_role = result.scalar_one_or_none()

	if admin_role is None:
		raise HTTPException(
			status_code=status.HTTP_403_FORBIDDEN,
			detail="Droits administrateur requis",
		)

	return current_user


# --- Dépendances pagination ---


class PaginationParams:
	"""Paramètres de pagination standardisés."""

	def __init__(
		self,
		page: int = Query(1, ge=1, description="Numéro de page"),
		per_page: int = Query(20, ge=1, le=100, description="Éléments par page"),
		sort_by: str | None = Query(None, description="Champ de tri"),
		sort_order: str = Query("desc", pattern="^(asc|desc)$", description="Ordre de tri"),
	):
		self.page = page
		self.per_page = per_page
		self.sort_by = sort_by
		self.sort_order = sort_order
		self.offset = (page - 1) * per_page


# --- Alias typés pour injection concise ---

CurrentUser = Annotated[User, Depends(get_current_user)]
ActiveUser = Annotated[User, Depends(get_current_active_user)]
AdminUser = Annotated[User, Depends(get_admin_user)]
DBSession = Annotated[AsyncSession, Depends(get_db)]
RedisClient = Annotated[redis.Redis, Depends(get_redis)]
Pagination = Annotated[PaginationParams, Depends()]
