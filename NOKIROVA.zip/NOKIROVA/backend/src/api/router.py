"""
NOKIROVA — Routeur API principal

Regroupe tous les sous-routeurs v1 sous /api/v1.
"""

from fastapi import APIRouter

from .v1 import (
	admin_router,
	ai_router,
	analytics_router,
	auth_router,
	chat_router,
	community_router,
	courses_router,
	documents_router,
	exams_router,
	flashcards_router,
	gamification_router,
	health_router,
	knowledge_router,
	marketplace_router,
	memory_router,
	notes_router,
	notifications_router,
	plugins_router,
	privacy_router,
	quiz_router,
	revision_router,
	search_router,
	users_router,
)

# Routeur principal v1
api_router = APIRouter(prefix="/api/v1")

# Enregistrement des sous-routeurs
api_router.include_router(auth_router, prefix="/auth", tags=["Authentification"])
api_router.include_router(users_router, prefix="/users", tags=["Utilisateurs"])
api_router.include_router(courses_router, prefix="/courses", tags=["Cours"])
api_router.include_router(documents_router, prefix="/documents", tags=["Documents"])
api_router.include_router(notes_router, prefix="/notes", tags=["Notes"])
api_router.include_router(flashcards_router, prefix="/flashcards", tags=["Flashcards"])
api_router.include_router(quiz_router, prefix="/quiz", tags=["Quiz"])
api_router.include_router(exams_router, prefix="/exams", tags=["Examens"])
api_router.include_router(ai_router, prefix="/ai", tags=["IA Studio"])
api_router.include_router(chat_router, prefix="/chat", tags=["Chat"])
api_router.include_router(memory_router, prefix="/memory", tags=["Mémoire / Jumeau Pédagogique"])
api_router.include_router(revision_router, prefix="/revision", tags=["Révision"])
api_router.include_router(community_router, prefix="/community", tags=["Communauté"])
api_router.include_router(marketplace_router, prefix="/marketplace", tags=["Marketplace"])
api_router.include_router(gamification_router, prefix="/gamification", tags=["Gamification"])
api_router.include_router(analytics_router, prefix="/analytics", tags=["Analytics"])
api_router.include_router(notifications_router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(plugins_router, prefix="/plugins", tags=["Plugins"])
api_router.include_router(knowledge_router, prefix="/knowledge", tags=["Knowledge Graph & Lake"])
api_router.include_router(admin_router, prefix="/admin", tags=["Administration"])
api_router.include_router(health_router, prefix="/health", tags=["Santé & Monitoring"])
api_router.include_router(search_router, prefix="/search", tags=["Recherche"])
api_router.include_router(privacy_router, prefix="/privacy", tags=["Confidentialité & RGPD"])
