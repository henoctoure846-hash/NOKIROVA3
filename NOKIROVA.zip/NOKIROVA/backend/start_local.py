#!/usr/bin/env python3
"""
NOKIROVA — Script de vérification de démarrage local

Vérifie que toutes les dépendances sont en place avant de lancer
le serveur FastAPI. Utile pour un premier démarrage sur PyCharm.

Usage :
    python start_local.py
    python start_local.py --fix   (tente les corrections automatiques)
"""

from __future__ import annotations

import sys
import os
import subprocess
import importlib
from pathlib import Path
from typing import List, Tuple


# Couleurs terminal (ANSI)
VERT = "\033[92m"
ROUGE = "\033[91m"
JAUNE = "\033[93m"
BLEU = "\033[94m"
RESET = "\033[0m"


def info(msg: str):
	print(f"{BLEU}ℹ{RESET} {msg}")


def ok(msg: str):
	print(f"{VERT}✓{RESET} {msg}")


def echec(msg: str):
	print(f"{ROUGE}✗{RESET} {msg}")


def avertissement(msg: str):
	print(f"{JAUNE}⚠{RESET} {msg}")


def verifier_python() -> bool:
	"""Vérifie la version de Python."""
	version = sys.version_info
	if version >= (3, 11):
		ok(f"Python {version.major}.{version.minor}.{version.micro}")
		return True
	elif version >= (3, 10):
		avertissement(f"Python {version.major}.{version.minor} — 3.11+ recommandé")
		return True
	else:
		echec(f"Python {version.major}.{version.minor} — 3.10 minimum requis")
		return False


def verifier_env() -> bool:
	"""Vérifie la présence du fichier .env."""
	backend_dir = Path(__file__).parent
	env_file = backend_dir / ".env"
	env_example = backend_dir / ".env.example"

	if env_file.exists():
		ok(f"Fichier .env trouvé ({env_file})")
		return True
	else:
		if env_example.exists():
			avertissement("Fichier .env absent — copie depuis .env.example")
			try:
				import shutil
				shutil.copy(env_example, env_file)
				ok(f"Fichier .env créé ({env_file})")
				avertissement("⚠ Vérifiez les valeurs dans .env avant de démarrer")
				return True
			except Exception as e:
				echec(f"Impossible de copier .env.example : {e}")
				return False
		else:
			echec("Fichiers .env et .env.example absents")
			return False


def verifier_postgresql() -> bool:
	"""Vérifie la connexion PostgreSQL."""
	try:
		import psycopg2
	except ImportError:
		avertissement("psycopg2 non installé — vérification ignorée")
		return True

	# Charger les variables depuis .env
	try:
		from dotenv import load_dotenv
		load_dotenv(Path(__file__).parent / ".env")
	except ImportError:
		pass

	db_url = os.getenv("DATABASE_URL", "")
	if not db_url:
		db_host = os.getenv("DATABASE_HOST", "localhost")
		db_port = os.getenv("DATABASE_PORT", "5432")
		db_name = os.getenv("DATABASE_NAME", "nokirova_db")
		db_user = os.getenv("DATABASE_USER", "nokirova_admin")
		db_password = os.getenv("DATABASE_PASSWORD", "")
		db_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"

	try:
		conn = psycopg2.connect(db_url)
		conn.close()
		ok("PostgreSQL connecté")
		return True
	except Exception as e:
		echec(f"PostgreSQL indisponible : {e}")
		return False


def verifier_redis() -> bool:
	"""Vérifie la connexion Redis."""
	try:
		import redis
	except ImportError:
		avertissement("redis-py non installé — vérification ignorée")
		return True

	redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")

	try:
		r = redis.from_url(redis_url)
		r.ping()
		ok("Redis connecté (PING → PONG)")
		return True
	except Exception as e:
		echec(f"Redis indisponible : {e}")
		return False


def verifier_dependances() -> bool:
	"""Vérifie les dépendances Python critiques."""
	from src.core.config import get_settings
	try:
		settings = get_settings()
		ok("Configuration Pydantic chargée")
	except Exception as e:
		echec(f"Configuration invalide : {e}")
		return False

	paquets_critiques = [
		("fastapi", "FastAPI"),
		("uvicorn", "Uvicorn"),
		("sqlalchemy", "SQLAlchemy"),
		("pydantic", "Pydantic"),
		("httpx", "HTTPX"),
	]

	tout_ok = True
	for module, nom in paquets_critiques:
		try:
			importlib.import_module(module)
			ok(f"Dépendance {nom} disponible")
		except ImportError:
			echec(f"Dépendance {nom} manquante")
			tout_ok = False

	return tout_ok


def verifier_structure() -> bool:
	"""Vérifie la structure des répertoires critiques."""
	backend_dir = Path(__file__).parent
	repertoires_attendus = [
		"src",
		"src/api",
		"src/core",
		"src/services",
		"src/database",
		"src/ai",
	]

	tout_ok = True
	for rep in repertoires_attendus:
		chemin = backend_dir / rep
		if chemin.is_dir():
			ok(f"Répertoire {rep}/ présent")
		else:
			echec(f"Répertoire {rep}/ manquant")
			tout_ok = False

	return tout_ok


def verifier_alembic() -> bool:
	"""Vérifie la configuration Alembic."""
	backend_dir = Path(__file__).parent
	alembic_ini = backend_dir / "alembic.ini"
	alembic_dir = backend_dir / "alembic"

	if alembic_ini.exists():
		ok("alembic.ini trouvé")
	else:
		echec("alembic.ini absent")
		return False

	if alembic_dir.is_dir():
		ok("Répertoire alembic/ présent")
	else:
		echec("Répertoire alembic/ absent")
		return False

	versions_dir = alembic_dir / "versions"
	if versions_dir.is_dir():
		migrations = list(versions_dir.glob("*.py"))
		ok(f"{len(migrations)} migration(s) Alembic trouvée(s)")
	else:
		avertissement("Répertoire alembic/versions/ absent")

	return True


def verifier_tout() -> bool:
	"""Exécute toutes les vérifications."""
	info("╔══════════════════════════════════════════════════╗")
	info("║        NOKIROVA — Vérification de démarrage      ║")
	info("╚══════════════════════════════════════════════════╝")
	print()

	resultats = []

	resultats.append(("Python", verifier_python()))
	resultats.append(("Environnement (.env)", verifier_env()))
	resultats.append(("PostgreSQL", verifier_postgresql()))
	resultats.append(("Redis", verifier_redis()))
	resultats.append(("Dépendances Python", verifier_dependances()))
	resultats.append(("Structure répertoires", verifier_structure()))
	resultats.append(("Alembic (migrations)", verifier_alembic()))

	print()
	info("── Résultat global ─────────────────────────────────")

	echecs = sum(1 for _, ok_val in resultats if not ok_val)
	if echecs == 0:
		ok("Toutes les vérifications sont passées ✅")
		ok("Lancez le serveur : uvicorn src.main:app --reload")
		return True
	else:
		echec(f"{echecs} vérification(s) ont échoué")
		for nom, ok_val in resultats:
			if not ok_val:
				echec(f"  ✗ {nom}")
		return False


if __name__ == "__main__":
	succes = verifier_tout()
	sys.exit(0 if succes else 1)
